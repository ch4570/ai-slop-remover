# Cycle12 evidence-led tooling fixes

Previous cycle was progress: committed dccdc055033b83c5d05d713afa81d30a60778ccc, clean tree. This cycle inspects another concrete repository boundary instead of repeating the product focus trial. No skill guidance edits, skill adoption, host installation, external service, browser/dependency update, global settings change, push or PR. All test installs and reproductions use disposable synthetic/local release copies.

## Export

Parent read exporter/checker and copied all76 release members plus the actual exporter/checker to original-export/, verifying copied hashes. Only copied README.ko.md mtime was set to Unix epoch. Actual Python3.9 CLI passed7skill/24static-contract validation, then exit1 with ZIP-before1980 error. Source bytes/mtimes did not change during execution. original-early.zip is the preserved partial output; it is not a successful release. No user source timestamp was modified.

Five new real-export tests were added before the implementation change. Original passed normal export, existing-output refusal and invalid-release refusal, but failed both timestamp extremes: pre1980 ValueError and post2107 struct.error traceback. After strict_timestamps=False, allfive passed. Each successful normal/edge archive is CRC checked, unique exact76member set and bytes/hashes compared, extracted to a new path and actually installed into an isolated project with every skill byte compared. Source content and mtimes remain equal. Only ZIP metadata timestamps are clamped, including two-second ZIP rounding. This is not a reproducible-build guarantee and does not add transactional cleanup for arbitrary I/O failure.

## Installer

Independent audit found a FIFO manifest without a writer makes --list/status/dry-run hang. Regression also covers install. Children are bounded, killed and reaped by subprocess.run(timeout); temporary FIFO sources and targets are synthetic. Four FIFO mode subtests actually timed out before the fix. Four directory subtests also fail the red run only because they require the new specific diagnostic; directories already returned an error. Do not report eight hang defects.

The fix lstat-checks manifest before JSON open, retaining symlink refusal and requiring a regular file. Snapshot helper now records special-file mode/mtime without opening pipes. Both tests/eight modes then pass; agent also ran81legacy/current installer tests. The preserved completion artifact is only the actual final output chunk plus its command, not the complete81test transcript. Missing manifest CLI error remains handled by existing OSError handling; direct load_bundle missing-file exception is now OSError rather than read_json's wrapped BundleError. No documented exception API was found. This is stable-path preflight, not protection from concurrent filesystem replacement.

## Final verification and review

After final Changelog entries and manifest refresh, parent full Python3.9 suite:300tests,253passed/47skipped, exit0. npm test:24passed, exit0, including real tarball aliases/install/status workflows. npm run check and check:js passed. The earlier full suite and exporter3.12 run preceded the Changelog-only update; they remain separately labeled and are not counted as new coverage. Final new-test Python3.12 command is recorded separately. Opt-in browser tests were not enabled this cycle; no cross-OS/physical-device or remote CI claim.

Independent reviewer inspected actual local Python3.9 zipfile behavior, source/tests/red/green evidence, and ran git diff --check. No actionable defect found. It did not duplicate integrated suites and its report explicitly excludes later Changelog/manifest checks. Parent independently read its complete report and final command outputs. Full agent tool transcripts are unavailable; retain exposed reports, artifacts and exact parent command stdout/stderr, not reconstructed transcripts.

Only install.py and CHANGELOG.md release hashes changed; all75 release paths and all65skill files remain unchanged. Parent preserves final changed files and update_manifest helper along with original release copy and readable patch. Agent-owned FIFO trees are not archived: only selected regular scripts/red/green/completion reports are included. Original failed exporter and tests are retained. Archive consistency is not a truth or runtime-coverage verdict.
