# Cycle12 evidence

Bounded fixes for FIFO bundle-manifest hangs and out-of-range offline ZIP timestamps. Base dccdc055033b83c5d05d713afa81d30a60778ccc. No skill guidance/model/adoption experiment this cycle.

`work/original-export/` is the pre-change76member release plus two actual exporter/checker scripts, copied/hash-checked before modification. Its copied README.ko.md timestamp alone was set to Unix epoch. Original failure command/metadata and partial ZIP are retained; do not install or distribute the partial archive. `work/final-source/` preserves the six changed implementation/test/release files plus update_manifest.py. The rest of work includes exact parent command/stdout/stderr, copy manifests, notes and patch. Seven new tests are in final-source; their red/green records are separate from final whole-suite results.

`installer-audit/` contains only five selected regular evidence files: FIFO reproduction, adjacent-boundary checker, exact red/green output and the actual final chunk of the81test run. The synthetic FIFO trees themselves and complete agent tool transcript are not archived. `review/` is the independent source/evidence review, not a duplicate integrated test run.

Source map records paths/bytes/hashes/modes/mtimes; direct tar streaming avoids duplicate staging. External inventory verifies the exact regular-file set including source-map.json. Build/static/archive-check outputs are preserved outside the tar they validate. Historical absolute paths and exposed logs are not rewritten; repro helpers with those paths need explicit adaptation in a new owned directory.

From the final repository revision, the primary new tests are:

```sh
python3 -B -m unittest tests.test_export_bundle tests.test_install.SkillSetInstallerTests.test_fifo_manifest_is_refused_without_waiting_for_a_writer tests.test_install.SkillSetInstallerTests.test_directory_manifest_is_refused_before_reading -v
```

Full recorded suite: `python3 -B -m unittest discover -s tests -q`; npm suite: `npm test`. Existing Python3.9.6 and3.12.14 were used, with no third-party dependencies. The full suite files are in the repository revision, not all duplicated in this archive. The archive was verified without extraction; no post-archive replay is claimed. Test-generated ZIPs were separately extracted and really installed during exporter checks. Those are different claims.

FIFO tests skip when os.mkfifo is unavailable. Local macOS runs do not establish Windows/Linux CI results or concurrent-path-replacement safety. Timestamp clamping changes ZIP metadata only, not source metadata/content; arbitrary export I/O failures can still leave a partial new output. No automatic cleanup or replacement of user-owned archives was added.
