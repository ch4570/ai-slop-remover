"""Read-only installer invocation with a synthetic FIFO manifest; files stay local."""
import os
from pathlib import Path
import shutil
import subprocess
import sys

workspace = Path(__file__).resolve().parent
bundle = workspace / "bundle"
bundle.mkdir(exist_ok=True)
shutil.copyfile(Path(sys.argv[1]).resolve() / "install.py", bundle / "install.py")
manifest = bundle / "manifest.json"
if not manifest.exists():
    os.mkfifo(manifest)
for args in (("--list",), ("--dest", str(workspace / "target"), "--status"),
             ("--dest", str(workspace / "target"), "--dry-run")):
    try:
        result = subprocess.run([sys.executable, str(bundle / "install.py"), *args],
                                capture_output=True, text=True, timeout=1, check=False)
        print(f"{args}: rc={result.returncode}, stderr={result.stderr.strip()!r}")
    except subprocess.TimeoutExpired:
        print(f"{args}: TIMEOUT after 1 second; child killed; no FIFO writer exists")
print("Destination exists:", (workspace / "target").exists())
