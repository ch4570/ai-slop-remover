"""Exercise non-regular adjacent paths using tiny, owned synthetic bundles."""
import contextlib
import hashlib
import io
import json
import os
from pathlib import Path
import runpy
import sys

api = runpy.run_path(str(Path(sys.argv[1]).resolve() / "install.py"))
base = Path(__file__).resolve().parent / "adjacent"
base.mkdir()
name = "ui-craft-bundle"
for location in ("source-payload", "source-release", "dest-root", "dest-marker", "dest-payload", "dest-parent"):
    case = base / location
    case.mkdir()
    bundle = case / "bundle"
    bundle.mkdir()
    contents = {"install.py": b"# synthetic installer\n", "README.ko.md": b"Synthetic readme\n",
                "skills/" + name + "/SKILL.md": b"Synthetic skill\n"}
    for relative, data in contents.items():
        path = bundle / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)
    manifest = {"schema": 1, "name": name, "version": "1.0.0",
                "files": {relative: hashlib.sha256(data).hexdigest() for relative, data in contents.items()}}
    (bundle / "manifest.json").write_text(json.dumps(manifest), encoding="utf-8")
    if location.startswith("source"):
        path = bundle / ("skills/" + name + "/SKILL.md" if location == "source-payload" else "README.ko.md")
        path.unlink()
        os.mkfifo(path)
        try:
            api["load_packages"](bundle)
        except api["BundleError"] as error:
            print(location + ": refused " + str(error).split(":", 1)[0])
        continue
    manifest, payloads = api["load_packages"](bundle)
    payload = payloads[name]
    dest = case / "dest"
    if location == "dest-root":
        os.mkfifo(dest)
    elif location == "dest-parent":
        os.mkfifo(dest)
        dest = dest / "child"
    else:
        dest.mkdir()
        (dest / "SKILL.md").write_bytes(payload["SKILL.md"])
        marker = dest / api["MARKER"]
        marker.write_text(json.dumps(api["install_marker"](manifest, payload)), encoding="utf-8")
        path = marker if location == "dest-marker" else dest / "SKILL.md"
        path.unlink()
        os.mkfifo(path)
    output = io.StringIO()
    with contextlib.redirect_stdout(output):
        api["report_status"](bundle, dest, manifest, name, payload)
    print(location + ": " + next(line.strip() for line in output.getvalue().splitlines() if "Status:" in line))
