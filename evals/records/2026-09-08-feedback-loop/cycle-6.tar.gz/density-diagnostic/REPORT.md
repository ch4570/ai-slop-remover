# Current Chrome density diagnostic

The historical 800/864 height reversal reproduced on Chrome/152.0.7977.83. This is an independent parent-side diagnostic, not a blind skill review or a product-readiness verdict.

Both products were served unchanged from `/tmp/lutriva-cycle6-density-source-AP4ld8/visual`. The collector imported the current repository `scripts/browser_harness.mjs` at repository HEAD `59c22c39ed441bb97252f523bdb03b8f2e67106e`; the archived `visual/check-focus-threshold.mjs` was only read as a recipe. All helper scripts and evidence are in this new directory.

## Same-condition results

Every case used a 320 CSS-pixel-wide viewport, DPR 1, `mobile:false`, and the same CSS text enlargement recipe: snapshot computed font sizes on `body` and all descendants, then set each element to twice its snapshot. This produced 32px body/button/cell text and a 56px heading. This is CSS text emulation, not native browser zoom or OS text scaling.

Three actual CDP Tab presses reached the first M-101 button through the two header links; Enter then generated a trusted click and changed the status to `M-101 주문을 선택했습니다.` in all four cases. The current bounded `pressKey` helper was used; recorded DOM key/focus/click events were trusted. No `nativeVirtualKeyCode`, unsafe shortcut, browser update UI, or mouse input was used.

| Product / height | Before Enter | After Enter | Document client width before → after | Table scrollLeft / maximum before → after |
| --- | --- | --- | --- | --- |
| Original / 800 | Full outline fits | Full outline fits | 305 → 305 | 353/353 → 353/353 |
| Candidate / 800 | Full outline fits | Right edge clipped | 320 → 305 | 338/338 → 338/353 |
| Original / 864 | Full outline fits | Right edge clipped | 320 → 305 | 338/338 → 338/353 |
| Candidate / 864 | Full outline fits | Full outline fits | 320 → 320 | 338/338 → 338/338 |

In both clipped cases, the status update creates a 15px vertical scrollbar. The table client width shrinks from 286px to 271px, while its existing horizontal scroll position stays at 338px instead of the new 353px maximum. The clipping boundary moves to x=288px. The button right edge remains x=291.1875px, so 3.1875px of its box and 8.1875px of its outer focus extent extend past that boundary; the outline is 3px with a 2px offset. The original already has the vertical scrollbar before Enter at height 800, while the candidate stays below that threshold at height 864. This measured sequence accounts for the height-dependent reversal.

## Actual image review

I opened all eight initial viewport PNGs with the image viewer:

- `original-product-800-before.png`, `original-product-800-after.png`
- `product-800-before.png`, `product-800-after.png`
- `original-product-864-before.png`, `original-product-864-after.png`
- `product-864-before.png`, `product-864-after.png`

The images agree with the geometry: every pre-Enter outline fits; candidate/800 and original/864 lose the right end of the first button outline after Enter. The first button's focus indication and complete `상세 보기` label remain recognizable, and the action's selected-order status is visible. The original/800 status extends below the viewport bottom, consistent with its already-scrollable page. Captures used `captureBeyondViewport:false`; all initial before/after measurements were identical to their corresponding after-capture measurements, so these captures did not reframe the table.

## Separate keyboard recovery attempt

A fresh collection in `keyboard-recovery/` tested only original/864 and candidate/800, preserving the initial comparison evidence. After reproducing each clipped Enter state, actual Tab moved focus to M-102 and Shift+Tab returned it to M-101. The horizontal scroll position remained 338px, and the right-edge clipping remained. All logged events were trusted; M-101 returned to `:focus-visible`, and its selected-order status remained present.

I also opened all four recovery viewport PNGs:

- `keyboard-recovery/original-product-864-after-enter.png`
- `keyboard-recovery/original-product-864-recovered.png`
- `keyboard-recovery/product-800-after-enter.png`
- `keyboard-recovery/product-800-recovered.png`

The `-recovered.png` filenames mean the capture after the recovery attempt; recovery did **not** succeed. Their appearance agrees with the still-clipped geometry. This tests one specific Tab → Shift+Tab route and does not establish that every possible keyboard recovery route fails.

## Integrity and verification

- `node /tmp/lutriva-cycle6-density-recheck-zBDh5Z/recheck-density.mjs` exited 0 with four complete observations and no collection exceptions.
- `node /tmp/lutriva-cycle6-density-recheck-zBDh5Z/check-keyboard-recovery.mjs` exited 0 with both recovery attempts fully collected and no collection exceptions. Exit 0 denotes successful evidence collection, not successful visual recovery.
- `Browser.getVersion` before and after every browser session returned the identical `Chrome/152.0.7977.83`, revision `@79460ebecaa5625e57a5fb679a735659e73dc687`.
- Both collections hashed every file and byte length in both product directories before and after, plus the current harness and archived recipe. Both report `inputBytesUnchanged:true`.
- Page target guards checked the two initial `about:blank` targets and then only the controlled local compare page plus the untouched blank page. All 24 initial-collection and 16 recovery-collection checks passed; no unexpected page target was accepted.
- `browser.json`, `run.log`, `inputs-before.json`, and `inputs-after.json` contain the initial evidence. `keyboard-recovery/browser.json` and `keyboard-recovery/run.log` contain the separate recovery evidence. The JSON records include exact helper hashes, browser versions, raw key events, dimensions, target checks, timestamps, and input manifests.

This establishes a reproducible, viewport-dependent right-edge clipping regression at 800px, and an improvement at 864px. It does not by itself establish a WCAG failure, unreadable button label, failed selection action, or a mandatory `changes-required` quality-gate verdict. No product fix, repository edit, install, commit, or push was performed.
