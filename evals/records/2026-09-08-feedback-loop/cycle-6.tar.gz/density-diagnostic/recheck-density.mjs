import { createHash } from 'node:crypto';
import { readFile, readdir, stat, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { claimBrowserEvidence, withBrowser } from '/Users/rex/Desktop/personal/lutriva/scripts/browser_harness.mjs';

const output = '/tmp/lutriva-cycle6-density-recheck-zBDh5Z';
const source = '/tmp/lutriva-cycle6-density-source-AP4ld8/visual';
const harness = '/Users/rex/Desktop/personal/lutriva/scripts/browser_harness.mjs';
const recipe = path.join(source, 'check-focus-threshold.mjs');
const names = ['original-product', 'product'];
const startedAt = new Date().toISOString();
const report = {
  startedAt, output, source, harness, recipe,
  conditions: { width: 320, heights: [800, 864], deviceScaleFactor: 1, mobile: false,
    textScale: 2, textMethod: 'Snapshot computed font sizes for body and every descendant, then set each inline fontSize to twice that snapshot.',
    input: 'Current repository pressKey helper; trusted CDP DOM Tab and Enter events. No nativeVirtualKeyCode, browser shortcuts, update UI, or mouse recovery.',
    imageMode: 'Page.captureScreenshot with captureBeyondViewport:false' },
  products: [], errors: [],
  limits: [
    'CSS-computed text enlargement is not native browser zoom, OS text scaling, or device emulation.',
    'Focus-outline fit geometry is a diagnostic. Partial outline clipping alone does not establish a WCAG violation.',
    'The tested viewport heights are 800 and 864 only.',
    'Keyboard recovery has not been tested by this initial collection.'
  ]
};
const logLines = [];
const log = (kind, detail) => {
  const entry = { time: new Date().toISOString(), kind, ...detail };
  logLines.push(JSON.stringify(entry));
  console.log(JSON.stringify(entry));
};
async function digest(file) {
  const bytes = await readFile(file);
  return { bytes: bytes.length, sha256: createHash('sha256').update(bytes).digest('hex') };
}
async function manifest(dir) {
  const files = {};
  for (const entry of (await readdir(dir, { withFileTypes: true })).sort((a, b) => a.name.localeCompare(b.name))) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      for (const [nested, value] of Object.entries(await manifest(full))) files[path.join(entry.name, nested)] = value;
    } else {
      if (!entry.isFile()) throw new Error(`Unexpected non-regular product input: ${full}`);
      files[entry.name] = await digest(full);
    }
  }
  return files;
}
report.inputBefore = { products: Object.fromEntries(await Promise.all(names.map(async name => [name, await manifest(path.join(source, name))]))), harness: await digest(harness), recipe: await digest(recipe) };
await writeFile(path.join(output, 'inputs-before.json'), JSON.stringify(report.inputBefore, null, 2) + '\n', { flag: 'wx' });
await claimBrowserEvidence(output, names.flatMap(name => [800, 864].flatMap(height => [`${name}-${height}-before.png`, `${name}-${height}-after.png`])));

const measureScript = `(() => {
  const button = document.querySelector('[data-order="M-101"]'), table = document.querySelector('.table-scroll');
  const b = button.getBoundingClientRect(), t = table.getBoundingClientRect(), s = getComputedStyle(button);
  const rect = r => ({ left:r.left, right:r.right, top:r.top, bottom:r.bottom, width:r.width, height:r.height });
  const edge = parseFloat(s.outlineWidth) + parseFloat(s.outlineOffset);
  const clip = { left:t.left+table.clientLeft, right:t.left+table.clientLeft+table.clientWidth, top:t.top+table.clientTop, bottom:t.top+table.clientTop+table.clientHeight };
  const active = document.activeElement;
  return {
    active: { tag:active.tagName, text:active.textContent.trim(), order:active.dataset.order ?? null, href:active.getAttribute('href'), focusVisible:active.matches(':focus-visible') },
    firstButtonFocusVisible: button.matches(':focus-visible'), outline:s.outline, outlineOffset:s.outlineOffset, outlineEdge:edge,
    button:rect(b), tableOuter:rect(t), clip,
    horizontalFocusFits:b.left-edge>=clip.left && b.right+edge<=clip.right,
    horizontalOutlineOverflow:{ left:Math.max(0,clip.left-(b.left-edge)),right:Math.max(0,b.right+edge-clip.right) },
    horizontalButtonFits:b.left>=clip.left && b.right<=clip.right,
    scrollLeft:table.scrollLeft, scrollTop:table.scrollTop, scrollMax:table.scrollWidth-table.clientWidth, clientWidth:table.clientWidth, clientHeight:table.clientHeight, scrollWidth:table.scrollWidth, scrollHeight:table.scrollHeight,
    documentWidth:document.documentElement.scrollWidth, documentHeight:document.documentElement.scrollHeight,
    documentClientWidth:document.documentElement.clientWidth, documentClientHeight:document.documentElement.clientHeight,
    viewportWidth:innerWidth, viewportHeight:innerHeight, pageScrollX:scrollX, pageScrollY:scrollY, devicePixelRatio,
    verticalScrollbarWidth:innerWidth-document.documentElement.clientWidth,
    visualViewport:{ width:visualViewport.width,height:visualViewport.height,scale:visualViewport.scale,offsetLeft:visualViewport.offsetLeft,offsetTop:visualViewport.offsetTop },
    cellPadding:getComputedStyle(document.querySelector('td')).paddingTop,
    fontSizes:{ body:getComputedStyle(document.body).fontSize,button:s.fontSize,heading:getComputedStyle(document.querySelector('h1')).fontSize,cell:getComputedStyle(document.querySelector('td')).fontSize },
    status:document.getElementById('detail').textContent,
    events:window.__densityEvents.slice()
  };
})()`;
try {
  for (const name of names) {
    const product = { name, observations: [], targetChecks: [], browserBefore: null, browserAfter: null };
    report.products.push(product);
    await withBrowser(path.join(source, name), output, async ({ origin, page, call, evaluate, pause, screenshot, pressKey, exceptions }) => {
      product.origin = origin;
      product.browserBefore = await call('Browser.getVersion');
      product.node = process.version;
      log('browser-before', { name, version:product.browserBefore });
      const initialTargets = (await call('Target.getTargets')).targetInfos.filter(target => target.type === 'page');
      if (initialTargets.length !== 2 || initialTargets.some(target => target.url !== 'about:blank')) throw new Error(`Unexpected initial page targets: ${JSON.stringify(initialTargets)}`);
      const baselineIds = initialTargets.map(target => target.targetId).sort();
      product.initialPageTargets = initialTargets;
      let controlledTarget;
      const guard = async stage => {
        const targets = (await call('Target.getTargets')).targetInfos.filter(target => target.type === 'page');
        const control = targets.filter(target => target.url === origin + '/compare.html');
        const safe = JSON.stringify(targets.map(target => target.targetId).sort()) === JSON.stringify(baselineIds)
          && control.length === 1 && (!controlledTarget || control[0].targetId === controlledTarget)
          && targets.every(target => target.url === 'about:blank' || target.url === origin + '/compare.html');
        product.targetChecks.push({ stage, safe, targets });
        if (!safe) throw new Error(`Unexpected page targets at ${stage}: ${JSON.stringify(targets)}`);
        controlledTarget = control[0].targetId;
      };
      try {
        for (const height of [800, 864]) {
          await page('Emulation.setDeviceMetricsOverride', { width:320, height, deviceScaleFactor:1, mobile:false });
          const oldTimeOrigin = await evaluate('performance.timeOrigin');
          await page('Page.navigate', { url:origin + '/compare.html' });
          let ready = false;
          for (let attempt=0; attempt<100; attempt++) {
            try { ready = await evaluate(`location.href === ${JSON.stringify(origin + '/compare.html')} && performance.timeOrigin !== ${oldTimeOrigin} && document.readyState === 'complete' && !!document.querySelector('[data-order="M-101"]')`); } catch {}
            if (ready) break;
            await pause(40);
          }
          if (!ready) throw new Error(`Comparison document did not load: ${name} ${height}`);
          await guard(`${height}-loaded`);
          await evaluate(`(() => {
            window.__densityEvents = [];
            for (const type of ['keydown','keyup','click','focusin']) document.addEventListener(type,event => window.__densityEvents.push({ type:event.type,key:event.key ?? null,code:event.code ?? null,shiftKey:event.shiftKey ?? false,isTrusted:event.isTrusted,tag:event.target.tagName,order:event.target.dataset?.order ?? null,text:event.target.textContent?.trim().slice(0,100) ?? null }),true);
            const elements = [...document.querySelectorAll('body, body *')];
            const sizes = elements.map(element => parseFloat(getComputedStyle(element).fontSize));
            elements.forEach((element,i) => element.style.fontSize = (sizes[i]*2)+'px');
          })()`);
          const observation = { width:320, height, fontScale:2, keys:[] };
          product.observations.push(observation);
          for (let step=0; step<6; step++) {
            if (await evaluate(`document.activeElement.dataset.order === 'M-101'`)) break;
            await guard(`${height}-before-tab-${step+1}`);
            await pressKey('Tab');
            const active = await evaluate(`({tag:document.activeElement.tagName,order:document.activeElement.dataset.order ?? null,text:document.activeElement.textContent.trim().slice(0,100)})`);
            observation.keys.push({ key:'Tab', active });
          }
          if (!await evaluate(`document.activeElement.dataset.order === 'M-101'`)) throw new Error(`Real Tab did not reach M-101: ${name} ${height}`);
          observation.before = await evaluate(measureScript);
          await screenshot(`${name}-${height}-before.png`, { captureBeyondViewport:false });
          observation.beforeCapture = await evaluate(measureScript);
          await guard(`${height}-before-enter`);
          await pressKey('Enter');
          observation.keys.push({ key:'Enter' });
          observation.after = await evaluate(measureScript);
          await screenshot(`${name}-${height}-after.png`, { captureBeyondViewport:false });
          observation.afterCapture = await evaluate(measureScript);
          await guard(`${height}-after-capture`);
          if (observation.after.status !== 'M-101 주문을 선택했습니다.') throw new Error(`Enter did not select M-101: ${name} ${height}`);
          log('observation', { name,height,beforeFocusFits:observation.before.horizontalFocusFits,afterFocusFits:observation.after.horizontalFocusFits,buttonFits:observation.after.horizontalButtonFits,overflow:observation.after.horizontalOutlineOverflow,documentHeight:observation.after.documentHeight,clientWidth:observation.after.documentClientWidth,scrollbarWidth:observation.after.verticalScrollbarWidth,status:observation.after.status });
        }
        if (exceptions.length) report.errors.push(...exceptions.map(value=>JSON.stringify(value)));
      } finally {
        product.browserAfter = await call('Browser.getVersion');
        log('browser-after', { name,version:product.browserAfter });
      }
    });
  }
} catch(error) {
  report.errors.push(String(error.stack ?? error));
  log('collection-error', { error:String(error.stack ?? error) });
} finally {
  report.inputAfter = { products:Object.fromEntries(await Promise.all(names.map(async name=>[name,await manifest(path.join(source,name))]))),harness:await digest(harness),recipe:await digest(recipe) };
  report.inputBytesUnchanged = JSON.stringify(report.inputBefore) === JSON.stringify(report.inputAfter);
  report.finishedAt = new Date().toISOString();
  report.helper = await digest(new URL(import.meta.url));
  await writeFile(path.join(output,'inputs-after.json'),JSON.stringify(report.inputAfter,null,2)+'\n',{flag:'wx'});
  await writeFile(path.join(output,'browser.json'),JSON.stringify(report,null,2)+'\n',{flag:'wx'});
  await writeFile(path.join(output,'run.log'),logLines.join('\n')+'\n',{flag:'wx'});
  if (!report.inputBytesUnchanged || report.errors.length || report.products.some(product=>product.observations.length!==2)) process.exitCode=1;
}
