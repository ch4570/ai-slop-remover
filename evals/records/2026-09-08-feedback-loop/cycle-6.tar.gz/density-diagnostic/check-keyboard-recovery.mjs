import { createHash } from 'node:crypto';
import { mkdir, readFile, readdir, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { claimBrowserEvidence, withBrowser } from '/Users/rex/Desktop/personal/lutriva/scripts/browser_harness.mjs';

const output = '/tmp/lutriva-cycle6-density-recheck-zBDh5Z/keyboard-recovery';
const source = '/tmp/lutriva-cycle6-density-source-AP4ld8/visual';
const harness = '/Users/rex/Desktop/personal/lutriva/scripts/browser_harness.mjs';
const recipe = path.join(source,'check-focus-threshold.mjs');
const cases = [{name:'original-product',height:864},{name:'product',height:800}];
const report = { startedAt:new Date().toISOString(),source,output,harness,cases:[],errors:[],limits:['This separate run tests only the two clipped cases from initial collection.','CSS font-size doubling is not native text zoom.','Keyboard recovery was tested with trusted Tab then Shift+Tab; no mouse input.','Partial outline clipping alone does not establish a WCAG violation.'] };
const lines=[];
const log=value=>{const entry={time:new Date().toISOString(),...value};lines.push(JSON.stringify(entry));console.log(JSON.stringify(entry));};
async function digest(file){const bytes=await readFile(file);return{bytes:bytes.length,sha256:createHash('sha256').update(bytes).digest('hex')};}
async function manifest(dir){const files={};for(const entry of(await readdir(dir,{withFileTypes:true})).sort((a,b)=>a.name.localeCompare(b.name))){const full=path.join(dir,entry.name);if(entry.isDirectory()){for(const[k,v]of Object.entries(await manifest(full)))files[path.join(entry.name,k)]=v;}else{if(!entry.isFile())throw Error('Unexpected non-regular input: '+full);files[entry.name]=await digest(full);}}return files;}
async function inputs(){return{products:Object.fromEntries(await Promise.all(['original-product','product'].map(async name=>[name,await manifest(path.join(source,name))]))),harness:await digest(harness),recipe:await digest(recipe)};}
report.inputBefore=await inputs();
await claimBrowserEvidence(output,cases.flatMap(({name,height})=>[`${name}-${height}-after-enter.png`,`${name}-${height}-recovered.png`]));
const measure=`(()=>{
  const first=document.querySelector('[data-order="M-101"]'),table=document.querySelector('.table-scroll'),active=document.activeElement;
  const b=first.getBoundingClientRect(),t=table.getBoundingClientRect(),s=getComputedStyle(first);
  const edge=parseFloat(s.outlineWidth)+parseFloat(s.outlineOffset),left=t.left+table.clientLeft,right=left+table.clientWidth;
  return{active:{tag:active.tagName,order:active.dataset.order??null,focusVisible:active.matches(':focus-visible')},firstButtonFocusVisible:first.matches(':focus-visible'),button:{left:b.left,right:b.right,top:b.top,bottom:b.bottom},outline:s.outline,outlineOffset:s.outlineOffset,clip:{left,right},horizontalFocusFits:b.left-edge>=left&&b.right+edge<=right,horizontalButtonFits:b.left>=left&&b.right<=right,scrollLeft:table.scrollLeft,scrollMax:table.scrollWidth-table.clientWidth,tableClientWidth:table.clientWidth,documentClientWidth:document.documentElement.clientWidth,documentHeight:document.documentElement.scrollHeight,viewportWidth:innerWidth,viewportHeight:innerHeight,status:document.getElementById('detail').textContent,events:window.__recoveryEvents.slice()};
})()`;
try{
  for(const entry of cases){
    const result={...entry,targetChecks:[],stages:[]};report.cases.push(result);
    await withBrowser(path.join(source,entry.name),output,async({origin,page,pressKey,call,evaluate,pause,screenshot,exceptions})=>{
      result.origin=origin;result.browserBefore=await call('Browser.getVersion');log({kind:'browser-before',name:entry.name,height:entry.height,version:result.browserBefore});
      const baseline=(await call('Target.getTargets')).targetInfos.filter(t=>t.type==='page');
      if(baseline.length!==2||baseline.some(t=>t.url!=='about:blank'))throw Error('Unexpected initial targets: '+JSON.stringify(baseline));
      const ids=baseline.map(t=>t.targetId).sort();let controlled;
      const guard=async stage=>{const targets=(await call('Target.getTargets')).targetInfos.filter(t=>t.type==='page');const matches=targets.filter(t=>t.url===origin+'/compare.html');const safe=JSON.stringify(targets.map(t=>t.targetId).sort())===JSON.stringify(ids)&&matches.length===1&&(!controlled||matches[0].targetId===controlled)&&targets.every(t=>t.url==='about:blank'||t.url===origin+'/compare.html');result.targetChecks.push({stage,safe,targets});if(!safe)throw Error('Unexpected page targets: '+JSON.stringify(targets));controlled=matches[0].targetId;};
      try{
        await page('Emulation.setDeviceMetricsOverride',{width:320,height:entry.height,deviceScaleFactor:1,mobile:false});
        await page('Page.navigate',{url:origin+'/compare.html'});
        let ready=false;for(let i=0;i<100;i++){try{ready=await evaluate(`location.href===${JSON.stringify(origin+'/compare.html')}&&document.readyState==='complete'&&!!document.querySelector('[data-order="M-101"]')`);}catch{}if(ready)break;await pause(40);}if(!ready)throw Error('Product did not load');
        await guard('loaded');
        await evaluate(`(()=>{window.__recoveryEvents=[];for(const type of ['keydown','keyup','focusin','click'])document.addEventListener(type,e=>window.__recoveryEvents.push({type:e.type,key:e.key??null,shift:e.shiftKey??false,isTrusted:e.isTrusted,tag:e.target.tagName,order:e.target.dataset?.order??null}),true);const elements=[...document.querySelectorAll('body, body *')],sizes=elements.map(e=>parseFloat(getComputedStyle(e).fontSize));elements.forEach((e,i)=>e.style.fontSize=sizes[i]*2+'px');})()`);
        for(let i=0;i<3;i++){await guard('before-initial-tab-'+i);await pressKey('Tab');}
        if(!await evaluate(`document.activeElement.dataset.order==='M-101'`))throw Error('Initial real Tab focus differed');
        result.stages.push({stage:'before-enter',measurement:await evaluate(measure)});
        await guard('before-enter');await pressKey('Enter');
        result.stages.push({stage:'after-enter',measurement:await evaluate(measure)});
        await screenshot(`${entry.name}-${entry.height}-after-enter.png`,{captureBeyondViewport:false});
        await guard('before-recovery-tab');await pressKey('Tab');
        result.stages.push({stage:'after-tab',measurement:await evaluate(measure)});
        await guard('before-recovery-shift-tab');await pressKey('Tab',{shift:true});
        result.stages.push({stage:'after-shift-tab',measurement:await evaluate(measure)});
        await screenshot(`${entry.name}-${entry.height}-recovered.png`,{captureBeyondViewport:false});
        result.stages.push({stage:'after-recovery-capture',measurement:await evaluate(measure)});
        await guard('after-recovery-capture');
        if(exceptions.length)report.errors.push(...exceptions.map(value=>JSON.stringify(value)));
        log({kind:'recovery',name:entry.name,height:entry.height,stages:result.stages.map(s=>({stage:s.stage,order:s.measurement.active.order,firstButtonFocusVisible:s.measurement.firstButtonFocusVisible,focusFits:s.measurement.horizontalFocusFits,scrollLeft:s.measurement.scrollLeft,scrollMax:s.measurement.scrollMax,status:s.measurement.status}))});
      }finally{result.browserAfter=await call('Browser.getVersion');log({kind:'browser-after',name:entry.name,height:entry.height,version:result.browserAfter});}
    });
  }
}catch(error){report.errors.push(String(error.stack??error));log({kind:'error',error:String(error.stack??error)});}
finally{
  report.inputAfter=await inputs();report.inputBytesUnchanged=JSON.stringify(report.inputBefore)===JSON.stringify(report.inputAfter);report.finishedAt=new Date().toISOString();report.helper=await digest(new URL(import.meta.url));
  await writeFile(path.join(output,'browser.json'),JSON.stringify(report,null,2)+'\n',{flag:'wx'});await writeFile(path.join(output,'run.log'),lines.join('\n')+'\n',{flag:'wx'});
  if(report.errors.length||!report.inputBytesUnchanged||report.cases.some(c=>c.stages.length!==5))process.exitCode=1;
}
