# 주문 비교 밀도 예외 최종 검수

판정: **pass — 원래 허용된 비교 표 패딩 및 디자인 문서 예외 변경 범위**, 아래의 실제 실행 환경과 비차단 한계를 포함한다. 주문 데이터·행 선택·공통 화면 보존·표 내부 열 접근을 막는 결함은 확인되지 않았다. 발견한 작은 포커스 가장자리 잘림은 아래에 남겼으며, 전체 접근성 적합성이나 배포 준비 전체에 대한 판정은 아니다.

출력 루트: `/tmp/lutriva-cycle6-quality-review-8IbTRT`

## 범위와 환경

- 입력은 `/tmp/lutriva-quality-gate-trial-O6pdDy`의 TASK.md, ORIGINAL-REQUEST.md, baseline/, release/, skills/, harness/, TOOLS.md로 제한했다. 이전 평가·구현자 보고서·저장소 records는 사용하지 않았다.
- 제공된 `skills/ui-quality-gate/SKILL.md` 및 지시된 principles, evidence-verdict, verification, web, UX foundations, layout, design-memory, interaction references를 읽었다. 스킬의 증거별 판정 원칙에 따라 정적 검토, 실행 결과, 직접 연 이미지와 미검증을 구분했다. 정적 비교는 별도 하위 검수와 자체 파일 해시·규칙 검사로 교차 확인했다.
- 실제 `Browser.getVersion`: **Chrome/152.0.7977.83**, revision `@79460ebecaa5625e57a5fb679a735659e73dc687`, V8 `15.2.124.21`. Node **v26.8.1**, host platform `darwin`. 제공 helper의 새 임시 프로필·headless Chrome·loopback 제품 서버를 사용했다.
- CSS viewport는 1280×900, 390×844, 320×800, DPR 1, `mobile:false`. 실제 물리 기기 또는 모바일 브라우저는 아니다.
- 텍스트 확대는 변경 전 각 요소의 computed font-size에 1.5 또는 2를 곱하는 임시 브라우저 표시 설정이다. 원래 line-height 선언은 유지했다. 실제 OS 글자 크기나 브라우저 zoom 조작을 검증한 것은 아니다.
- 긴 고객명은 첫 고객 셀에 `대한민국서울특별시성동구주문담당김민지와함께하는생활도자기공동구매고객`을 임시 표시했다. 원본 파일·주문 ID·행 버튼은 보존했다.

## 실제 결과

| 검수 항목 | 결과와 근거 |
| --- | --- |
| 허용된 파일·규칙 | 두 트리 각 7개 파일 중 `compare.css`, `DESIGN.md`만 다르다. 실제 CSS 변경은 같은 선택자의 `padding-block: 16px`→`8px`뿐이며 허용 정수 범위다. 새 파일·선택자·선언은 없다. |
| 디자인 예외 | DESIGN.md 마커 밖은 동일하다. 마커 안에 이유·compare.html·해당 선택자와 단일 CSS 코드 블록이 있고, 블록이 실제 compare.css와 정확히 같다. |
| 데이터·공통 화면 | app.js, 두 HTML, tokens.css, components.css의 파일 바이트가 전후 동일하다. 세 주문 ID·고객·상품·금액을 각 브라우저 조건에서 확인했다. master의 세 대표 viewport 초기 PNG도 전후 바이트가 같다. |
| 밀도 결과 | 기본 글자에서 비교 표 높이 **288.375→224.375 CSS px**, 행 높이 **76.59375→60.59375px**. master 높이는 그대로다. 큰 글자 조건도 비교 표 총높이가 64px 줄고 master는 동일했다. 데이터가 세 행이라 실제 보이는 행 수 증가를 별도 대량 데이터로 측정하지는 않았다. |
| 행 행동 | 전후 × master/compare × 7조건, 총 28조건에서 실제 Tab으로 M-101/M-102/M-103에 도달하고 Enter/Space로 해당 주문 ID의 `#detail` 문구가 바뀌는 것을 확인했다. Shift+Tab은 M-102로 돌아왔다. M-103 선택 후 포인터로 M-101을 선택하면 결과가 M-101로 바뀌었다. 제공 제품의 상세 행동은 이 선택 문구 표시이며 별도 상세 데이터 조회를 주장하지 않는다. |
| 작은 창·큰 글자·긴 이름 | 각 페이지에서 1280 기본, 390 기본, 320 기본, 320 긴 이름, 390 글자150%, 320 글자200%+긴 이름, 1280 글자200%+긴 이름을 실행했다. 문서 가로 넘침은 없었으며 표는 내부에서 가로로 스크롤됐다. 320px 일반 및 확대·긴 이름 조건에서 왼쪽 열과 오른쪽 작업 열을 방향키로 오가고 행 선택을 완료했다. |
| 버튼·포커스 | 기본 버튼 실측은 약 **85.56×43.59 CSS px**로 패딩 변경 전후 동일했다. 200%에서는 약143.70×69.19px다. 실행한 모든 행 선택에서 `:focus-visible`과 3px outline을 관찰했다. 다만 버튼 전체가 항상 자동으로 화면 안에 들어오는 것은 아니며 아래 한계를 참고한다. |
| 시각 검토 | 캡처 중 **27개 이미지를 직접 열어** 넓은/좁은 두 화면, 밀도 변화, 확대·긴 이름, 포커스 잘림과 복구를 확인했다. 열 정렬·브랜드 녹색·글꼴 역할·행 버튼은 보존됐다. 정확한 직접 검토 목록은 `visual-inspection.md`다. |
| 정적 실행·런타임 | `node --check baseline/app.js`, `node --check release/app.js` 통과. 모든 브라우저 세션에서 관찰된 Runtime 예외 0건. 정적 HTML/CSS/JS 입력에는 package/build/test 설정이 없으므로 빌드 통과를 주장하지 않는다. |

## 비차단 발견 사항과 재검사 범위

1. **390×844 기본 글자, 두 페이지 전후 공통: Tab 직후 버튼 오른쪽 일부 잘림.** 기대는 포커스된 버튼과 외곽선이 전부 보이는 것이다. 실제 버튼 오른쪽은 x390.703, 표 외곽 오른쪽은 x374라 약17px가 표 밖에서 잘린다. 첫 Tab 포커스 때 `scrollLeft=0`이지만 Enter/Space 선택은 성공한다. 새 세션에서 표 위로 포인터를 이동한 뒤 가로 wheel 또는 ArrowRight를 보내면 `scrollLeft=30`으로 이동하고 버튼·외곽선이 모두 보인다. baseline에도 같아 밀도 회귀가 아니다. 근거: `recheck-release/390-focus.png`, `recheck-release/390-ArrowRight.png`, 두 `recheck-*/browser.json`, 두 `supplement-*/browser.json`. 작은 완성도 개선으로 기록한다. UI 담당 또는 `ui-visual-refine`이 별도 범위에서 포커스 진입 시 전체 조작영역 노출을 다룰 수 있으며, 이번 허용 범위를 넘어 공통 CSS·행 동작을 수정하도록 요구하지 않는다. 재검사는 두 페이지의 390px Tab 진입→방향키→Enter/Space다.

2. **release compare, 320×800·글자200%·긴 이름: 선택 후 스크롤바 출현으로 오른쪽 테두리 일부 잘림.** 기대는 선택 결과가 길어져도 현재 버튼·외곽선이 전부 보이는 것이다. 실제 초기 표 clientWidth는286px이고, 선택 문구 줄바꿈 후 세로 스크롤바가 생기면271px로 줄지만 가로 위치는1224에 머문다. M-102/M-103 버튼 오른쪽 x290.953이 표 오른쪽 x289를 약2px 넘으며 외곽선도 일부 잘린다. 버튼 텍스트, 포커스 식별과 모든 선택 결과는 유지된다. **ArrowRight 한 번**으로 `scrollLeft=1239`가 되고 M-103 버튼·외곽선이 완전히 보이는 것을 추가 실행·이미지로 확인했다. baseline은 이 조건에서 초기부터 세로 스크롤바가 있어 같은 진입 순서의 잘림은 없었다. 근거: `recheck-release/text200-long320-third-row-selected.png`, `supplement-release/compare200-after-selection-recovered.png`, `supplement-release/browser.json`. 복구 가능한 작은 시각 한계로 기록한다. UI 담당이 별도 범위에서 폭 변경 후 포커스 가시성을 검토할 수 있다. 재검사는 초기→각 행 선택→상태 문구 줄바꿈→방향키 복구를 포함한다.

최초 자동 점검은 506개 관찰 중 488개 true, 18개 false였다. 이를 모두 통과로 바꾸지 않았다. false는 공통 390px의 완전한 버튼 포함 조건 12건, 확대 후 위 가장자리 조건 2건, 초기 390px wheel 관찰 4건이다. wheel은 포인터 위치를 명시적으로 이동하고 300ms를 기다리는 새 세션 입력으로 두 페이지·전후 모두 최대 scrollLeft 도달을 확인했다. 최초 관찰만으로 제품 스크롤 결함이라고 확정하지 않았다. 나머지 14건은 위 비차단 한계의 반복 관찰이다. 원시 결과는 `checks.json`에 그대로 보존했다.

## 실행 명령과 아티팩트

실제로 실행한 주요 명령:

```text
node /tmp/lutriva-cycle6-quality-review-8IbTRT/audit-input.mjs before
node --check baseline/app.js
node --check release/app.js
node /tmp/lutriva-cycle6-quality-review-8IbTRT/browser-review.mjs
node /tmp/lutriva-cycle6-quality-review-8IbTRT/recheck-input.mjs
node /tmp/lutriva-cycle6-quality-review-8IbTRT/summarize-evidence.mjs
node /tmp/lutriva-cycle6-quality-review-8IbTRT/audit-input.mjs after
node /tmp/lutriva-cycle6-quality-review-8IbTRT/supplement.mjs
node /tmp/lutriva-cycle6-quality-review-8IbTRT/audit-input.mjs after-final
```

- 전체 기록·판정: `/tmp/lutriva-cycle6-quality-review-8IbTRT/REPORT.md`
- 파일 범위/문서/스크린샷 바이트 비교: `/tmp/lutriva-cycle6-quality-review-8IbTRT/scope-summary.json`
- 밀도 측정 전후: `/tmp/lutriva-cycle6-quality-review-8IbTRT/comparison.json`
- 최초 관찰: `/tmp/lutriva-cycle6-quality-review-8IbTRT/checks.json`, `baseline/browser.json`, `release/browser.json`
- 추가 입력: `recheck-baseline/browser.json`, `recheck-release/browser.json`, `supplement-baseline/browser.json`, `supplement-release/browser.json` (모두 위 출력 루트 아래)
- 입력 보존: `input-before.json`, `input-after-final.json`, `input-integrity-final.json`. **83개 파일, 306,313바이트가 최종 검사까지 파일별 SHA-256·크기와 경로 목록 모두 동일**하다.
- 직접 열린 이미지 목록: `/tmp/lutriva-cycle6-quality-review-8IbTRT/visual-inspection.md`

모든 제공 입력은 읽기 전용으로 유지했다. 제품 수정, 설치, 사용자 프로필 연결, 업데이트 UI 조작, 외부 데이터 변경, 커밋·푸시는 수행하지 않았다.

## 미검증과 판정의 한계

물리 터치/모바일 장치, 다른 브라우저, 실제 OS 글자 크기와 브라우저 200%/400% zoom, 실물 키보드·IME·스크린리더 발표, 전체 WCAG 적합성·명암비는 검증하지 않았다. CDP viewport/키 이벤트와 임시 텍스트 확대가 해당 검증을 대체한다고 주장하지 않는다. 화면에는 네트워크 저장·재시도·영속성 약속이 없으므로 관련 상태를 만들어 검사하지 않았다. 새 임시 프로필은 사용자 프로필 분리를 제공하지만 네트워크나 Chrome 업데이트의 완전한 격리를 보장하지 않는다.

이 과업이 허용한 표시·데이터 모의 조건에서 필요한 주문 비교·행 작업은 실행됐다. 좁은 밀도 변경을 완료로 판단하는 데 추가 제품 수정은 요구하지 않으며, 위 작은 포커스 한계는 별도 개선 선택 사항으로 전달한다.
