import { readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { withBrowser, claimBrowserEvidence } from '/tmp/lutriva-quality-gate-trial-O6pdDy/harness/browser_harness.mjs';

const root = '/tmp/lutriva-quality-gate-trial-O6pdDy';
const output = '/tmp/lutriva-cycle6-quality-review-8IbTRT';
const cases = [
  { name: 'wide', width: 1280, height: 900 },
  { name: 'narrow390', width: 390, height: 844 },
  { name: 'narrow320', width: 320, height: 800 },
  { name: 'long320', width: 320, height: 800, long: true },
  { name: 'text150-390', width: 390, height: 844, scale: 1.5 },
  { name: 'text200-long320', width: 320, height: 800, scale: 2, long: true },
  { name: 'text200-longwide', width: 1280, height: 900, scale: 2, long: true },
];
const data = [
  ['M-101', '김민지', '머그', '12,000원'],
  ['M-102', '박도윤', '접시', '18,000원'],
  ['M-103', '이서연', '잔', '9,000원'],
];
const longName = '대한민국서울특별시성동구주문담당김민지와함께하는생활도자기공동구매고객';
const snapshotExpr = `(() => {
  const rect = el => { const r = el.getBoundingClientRect(); return { x:r.x,y:r.y,left:r.left,right:r.right,top:r.top,bottom:r.bottom,width:r.width,height:r.height }; };
  const box = document.querySelector('.table-scroll');
  const active = document.activeElement;
  const activeStyle = getComputedStyle(active);
  return {
    viewport: { width:innerWidth,height:innerHeight,devicePixelRatio,scrollX,scrollY },
    documentWidth:document.documentElement.scrollWidth, bodyWidth:document.body.scrollWidth,
    title:document.title, heading:document.querySelector('h1').textContent,
    header:rect(document.querySelector('header')), main:rect(document.querySelector('main')),
    scroll: { ...rect(box),clientWidth:box.clientWidth,scrollWidth:box.scrollWidth,scrollLeft:box.scrollLeft,overflowX:getComputedStyle(box).overflowX },
    table:rect(document.querySelector('table')),
    cells:Array.from(document.querySelectorAll('th,td'), el => ({text:el.textContent.trim(),...rect(el),paddingTop:getComputedStyle(el).paddingTop,paddingBottom:getComputedStyle(el).paddingBottom,fontSize:getComputedStyle(el).fontSize})),
    rows:Array.from(document.querySelectorAll('tbody tr'), row => ({...rect(row),values:Array.from(row.querySelectorAll('td'), el => el.textContent.trim())})),
    buttons:Array.from(document.querySelectorAll('[data-order]'), el => ({order:el.dataset.order,name:el.textContent.trim(),...rect(el),fontSize:getComputedStyle(el).fontSize})),
    detail:{text:document.querySelector('#detail').textContent,role:document.querySelector('#detail').getAttribute('role'),...rect(document.querySelector('#detail'))},
    active:{tag:active.tagName,text:active.textContent.trim(),order:active.dataset.order || null,href:active.getAttribute('href'),...rect(active),focusVisible:active.matches(':focus-visible'),outline:activeStyle.outline,outlineOffset:activeStyle.outlineOffset},
    style:{brand:getComputedStyle(document.documentElement).getPropertyValue('--brand').trim(),ink:getComputedStyle(document.body).color,background:getComputedStyle(document.body).backgroundColor,font:getComputedStyle(document.body).fontFamily,bodyFontSize:getComputedStyle(document.body).fontSize,headerBackground:getComputedStyle(document.querySelector('header')).backgroundColor},
  };
})()`;
const checks = [];
function check(name, okay, detail) { checks.push({ name, okay: !!okay, detail }); }
for (const version of ['baseline', 'release']) {
  const runOutput = path.join(output, version);
  await claimBrowserEvidence(runOutput, []);
  const run = { version, environment:{node:process.version,hostPlatform:process.platform,mode:'Headless Chrome; CDP CSS viewport; desktop input. No OS font settings or physical device.'}, methods:{textScaling:'Temporary per-element inline fontSize from pre-change computed fontSize multiplied by 1.5 or 2. Line-height declarations untouched. This is text-only stress simulation, not actual browser zoom or OS accessibility scaling.',longName:'Temporary customer cell text replacement only; product files and original row actions unchanged.',keyboard:'Provided pressKey Tab/Shift+Tab/Enter/Space; no evaluate().click() or focus() used.',pointer:'CDP wheel and mouse pressed/released at measured target positions.'}, cases:[] };
  await withBrowser(path.join(root, version), runOutput, async ctx => {
    run.browser = await ctx.call('Browser.getVersion');
    for (const route of ['master', 'compare']) {
      for (const scenario of cases) {
        const label = `${version}/${route}/${scenario.name}`;
        const record = { route, scenario, screenshots:[] };
        await ctx.page('Emulation.setDeviceMetricsOverride', {width:scenario.width,height:scenario.height,deviceScaleFactor:1,mobile:false});
        await ctx.page('Page.navigate', {url:`${ctx.origin}/${route}.html`});
        for (let attempt = 0; attempt < 100; attempt++) {
          if (await ctx.evaluate(`document.readyState === 'complete' && document.querySelectorAll('[data-order]').length === 3`)) break;
          if (attempt === 99) throw new Error(`Readiness failed: ${label}`);
          await ctx.pause(30);
        }
        await ctx.evaluate('document.fonts.ready.then(() => true)');
        record.originalRows = await ctx.evaluate(`Array.from(document.querySelectorAll('tbody tr'), row => Array.from(row.querySelectorAll('td')).slice(0,4).map(el => el.textContent.trim()))`);
        check(`${label}: original order data`, JSON.stringify(record.originalRows) === JSON.stringify(data), record.originalRows);
        if (scenario.long) await ctx.evaluate(`document.querySelector('tbody tr td:nth-child(2)').textContent = ${JSON.stringify(longName)}`);
        if (scenario.scale) await ctx.evaluate(`(() => { const entries = Array.from(document.querySelectorAll('body,body *'), element => [element, parseFloat(getComputedStyle(element).fontSize)]); for (const [element, size] of entries) element.style.fontSize = (size * ${scenario.scale}) + 'px'; return entries.length; })()`);
        await ctx.pause(80);
        record.initial = await ctx.evaluate(snapshotExpr);
        check(`${label}: page width stays inside viewport`, record.initial.documentWidth <= scenario.width && record.initial.bodyWidth <= scenario.width, {documentWidth:record.initial.documentWidth,bodyWidth:record.initial.bodyWidth,viewport:scenario.width});
        check(`${label}: row target bounds at least 24x24 CSS px`, record.initial.buttons.every(button => button.width >= 24 && button.height >= 24), record.initial.buttons.map(button => ({order:button.order,width:button.width,height:button.height})));
        const expectedPadding = version === 'release' && route === 'compare' ? '8px' : '16px';
        check(`${label}: computed cell padding`, record.initial.cells.every(cell => cell.paddingTop === expectedPadding && cell.paddingBottom === expectedPadding), expectedPadding);
        const capture = async name => { await ctx.screenshot(name, {captureBeyondViewport:false}); record.screenshots.push(path.join(runOutput,name)); };
        const captureScenario = !scenario.scale && !scenario.long || route === 'compare' && ['text150-390','text200-long320','text200-longwide'].includes(scenario.name);
        if (captureScenario) await capture(`${route}-${scenario.name}-initial.png`);
        record.keyboard = [];
        for (const [index, order] of ['M-101','M-102','M-103'].entries()) {
          const traversed = [];
          let state;
          for (let tab = 0; tab < 10; tab++) {
            await ctx.pressKey('Tab');
            await ctx.pause(25);
            state = await ctx.evaluate(snapshotExpr);
            traversed.push(state.active);
            if (state.active.order === order) break;
          }
          check(`${label}: Tab reaches ${order}`, state.active.order === order, traversed);
          const visible = state.active.left >= Math.max(0,state.scroll.left) && state.active.right <= Math.min(scenario.width,state.scroll.right) && state.active.top >= 0 && state.active.bottom <= scenario.height;
          check(`${label}: focused ${order} is visible and indicated`, visible && state.active.focusVisible && state.active.outline.includes('3px'), {active:state.active,scroll:state.scroll,viewport:state.viewport});
          if (index === 0 && route === 'compare' && ['narrow320','text200-long320'].includes(scenario.name)) await capture(`${route}-${scenario.name}-keyboard-focus.png`);
          const key = index === 1 ? 'Space' : 'Enter';
          await ctx.pressKey(key);
          await ctx.pause(25);
          const outcome = await ctx.evaluate(snapshotExpr);
          check(`${label}: ${key} selects ${order}`, outcome.detail.text === `${order} 주문을 선택했습니다.`, outcome.detail.text);
          record.keyboard.push({order,key,traversed,before:state,after:outcome});
        }
        await ctx.pressKey('Tab', {shift:true});
        record.reverseTab = await ctx.evaluate(snapshotExpr);
        check(`${label}: Shift+Tab returns to M-102`, record.reverseTab.active.order === 'M-102', record.reverseTab.active);
        const box = record.reverseTab.scroll;
        const wheelAt = {x:Math.max(2,Math.min(scenario.width-2,box.left+box.width/2)),y:Math.max(2,Math.min(scenario.height-2,box.top+Math.min(box.height/2,80)))};
        await ctx.page('Input.dispatchMouseEvent', {type:'mouseWheel',...wheelAt,deltaX:-10000,deltaY:0});
        await ctx.pause(80);
        record.scrollLeft = await ctx.evaluate(snapshotExpr);
        check(`${label}: horizontal wheel reaches first columns locally`, record.scrollLeft.scroll.scrollLeft === 0 && record.scrollLeft.viewport.scrollX === 0, record.scrollLeft.scroll);
        await ctx.page('Input.dispatchMouseEvent', {type:'mouseWheel',...wheelAt,deltaX:10000,deltaY:0});
        await ctx.pause(80);
        record.scrollRight = await ctx.evaluate(snapshotExpr);
        const maxScroll = record.scrollRight.scroll.scrollWidth - record.scrollRight.scroll.clientWidth;
        check(`${label}: horizontal wheel reaches row actions locally`, Math.abs(record.scrollRight.scroll.scrollLeft-maxScroll) <= 1 && record.scrollRight.viewport.scrollX === 0, {scroll:record.scrollRight.scroll,viewport:record.scrollRight.viewport});
        if (route === 'compare' && ['narrow320','text200-long320'].includes(scenario.name)) await capture(`${route}-${scenario.name}-scrolled-right.png`);
        const button = record.scrollRight.buttons[0];
        const point = {x:button.left+button.width/2,y:button.top+button.height/2};
        await ctx.page('Input.dispatchMouseEvent',{type:'mousePressed',...point,button:'left',clickCount:1});
        await ctx.page('Input.dispatchMouseEvent',{type:'mouseReleased',...point,button:'left',clickCount:1});
        await ctx.pause(25);
        record.pointerOutcome = await ctx.evaluate(snapshotExpr);
        check(`${label}: pointer selects M-101 after M-103`, record.pointerOutcome.detail.text === 'M-101 주문을 선택했습니다.',record.pointerOutcome.detail.text);
        run.cases.push(record);
        console.log(JSON.stringify({label,tableHeight:record.initial.table.height,tableWidth:record.initial.table.width,pageWidth:record.initial.documentWidth,checks:checks.filter(c=>c.name.startsWith(label)).length,failures:checks.filter(c=>c.name.startsWith(label)&&!c.okay).map(c=>c.name)}));
      }
    }
    run.exceptions = ctx.exceptions;
    check(`${version}: no observed runtime exceptions`, run.exceptions.length === 0, run.exceptions);
  });
  await writeFile(path.join(runOutput,'browser.json'), JSON.stringify(run,null,2)+'\n',{flag:'wx'});
}
const [baseline, release] = await Promise.all(['baseline','release'].map(async version => JSON.parse(await readFile(path.join(output,version,'browser.json'),'utf8'))));
const comparison = baseline.cases.map(before => {
  const after = release.cases.find(item => item.route === before.route && item.scenario.name === before.scenario.name);
  const result = {route:before.route,scenario:before.scenario.name,beforeTableHeight:before.initial.table.height,afterTableHeight:after.initial.table.height,heightReduction:before.initial.table.height-after.initial.table.height,beforeRowHeight:before.initial.rows[0].height,afterRowHeight:after.initial.rows[0].height,brandStyleEqual:JSON.stringify(before.initial.style)===JSON.stringify(after.initial.style)};
  check(`${before.route}/${before.scenario.name}: brand style preserved`,result.brandStyleEqual,result);
  check(`${before.route}/${before.scenario.name}: expected density result`,result.heightReduction===(before.route==='compare'?64:0),result);
  return result;
});
await writeFile(path.join(output,'comparison.json'),JSON.stringify(comparison,null,2)+'\n',{flag:'wx'});
await writeFile(path.join(output,'checks.json'),JSON.stringify({total:checks.length,passed:checks.filter(c=>c.okay).length,failed:checks.filter(c=>!c.okay).length,checks},null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({total:checks.length,passed:checks.filter(c=>c.okay).length,failures:checks.filter(c=>!c.okay)}));
