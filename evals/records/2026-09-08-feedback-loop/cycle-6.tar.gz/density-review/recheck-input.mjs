import { writeFile } from 'node:fs/promises';
import path from 'node:path';
import { withBrowser, claimBrowserEvidence } from '/tmp/lutriva-quality-gate-trial-O6pdDy/harness/browser_harness.mjs';
const root='/tmp/lutriva-quality-gate-trial-O6pdDy';
const output='/tmp/lutriva-cycle6-quality-review-8IbTRT';
const observe=`(() => { const box=document.querySelector('.table-scroll'); const b=box.getBoundingClientRect(); const a=document.activeElement; const r=a.getBoundingClientRect(); return {scrollLeft:box.scrollLeft,scrollWidth:box.scrollWidth,clientWidth:box.clientWidth,box:{left:b.left,right:b.right,top:b.top,bottom:b.bottom},active:{tag:a.tagName,order:a.dataset.order,left:r.left,right:r.right,top:r.top,bottom:r.bottom,focusVisible:a.matches(':focus-visible')},detail:document.querySelector('#detail').textContent,scrollX,scrollY,documentWidth:document.documentElement.scrollWidth,viewport:innerWidth}; })()`;
for(const version of ['baseline','release']) {
  const dir=path.join(output,`recheck-${version}`);
  await claimBrowserEvidence(dir,[]);
  const result={version,scenarios:[]};
  await withBrowser(path.join(root,version),dir,async ctx=>{
    result.browser=await ctx.call('Browser.getVersion');
    for(const scenario of [{name:'390',width:390,height:844},{name:'320',width:320,height:800},{name:'text200-long320',width:320,height:800,scale:2}]) {
      const rec={scenario,events:[]};
      await ctx.page('Emulation.setDeviceMetricsOverride',{width:scenario.width,height:scenario.height,deviceScaleFactor:1,mobile:false});
      await ctx.page('Page.navigate',{url:`${ctx.origin}/compare.html`});
      for(let n=0;n<100;n++){if(await ctx.evaluate(`document.readyState==='complete'&&document.querySelectorAll('[data-order]').length===3`))break;await ctx.pause(30);}
      if(scenario.scale) await ctx.evaluate(`(() => { document.querySelector('tbody tr td:nth-child(2)').textContent='대한민국서울특별시성동구주문담당김민지와함께하는생활도자기공동구매고객'; const entries=Array.from(document.querySelectorAll('body,body *'),el=>[el,parseFloat(getComputedStyle(el).fontSize)]);for(const[el,size]of entries)el.style.fontSize=size*2+'px'; })()`);
      await ctx.pause(250);
      const log=async action=>{const state=await ctx.evaluate(observe);rec.events.push({action,state});return state;};
      await log('initial');
      for(let n=0;n<3;n++)await ctx.pressKey('Tab');
      let state=await log('Tab x3, first row');
      await ctx.screenshot(`${scenario.name}-focus.png`,{captureBeyondViewport:false});
      const wheel={x:100,y:Math.min(state.box.bottom-25,state.box.top+100)};
      await ctx.page('Input.dispatchMouseEvent',{type:'mouseMoved',...wheel});
      for(const deltaX of [40,120,10000]){
        await ctx.page('Input.dispatchMouseEvent',{type:'mouseWheel',...wheel,deltaX,deltaY:0});
        await ctx.pause(300); await log(`mouseMoved then wheel +${deltaX}`);
      }
      await ctx.screenshot(`${scenario.name}-wheel-right.png`,{captureBeyondViewport:false});
      for(const direction of ['ArrowLeft','ArrowRight']){
        for(let n=0;n<(scenario.scale?50:5);n++){
          await ctx.page('Input.dispatchKeyEvent',{type:'keyDown',key:direction,code:direction,windowsVirtualKeyCode:direction==='ArrowLeft'?37:39});
          await ctx.page('Input.dispatchKeyEvent',{type:'keyUp',key:direction,code:direction,windowsVirtualKeyCode:direction==='ArrowLeft'?37:39});
          await ctx.pause(20);
        }
        await ctx.pause(250);await log(`${direction} x${scenario.scale?50:5}; no platform native keycode`);
        await ctx.screenshot(`${scenario.name}-${direction}.png`,{captureBeyondViewport:false});
      }
      await ctx.pressKey('Enter');await ctx.pressKey('Tab');await ctx.pressKey('Space');await ctx.pressKey('Tab');await ctx.pressKey('Enter');
      await ctx.pause(250);await log('Enter M-101, Space M-102, Enter M-103');
      await ctx.screenshot(`${scenario.name}-third-row-selected.png`,{captureBeyondViewport:false});
      state=await ctx.evaluate(observe);
      const bar={x:state.box.right-5,y:state.box.bottom-8};
      await ctx.page('Input.dispatchMouseEvent',{type:'mouseMoved',...bar});
      await ctx.page('Input.dispatchMouseEvent',{type:'mousePressed',...bar,button:'left',clickCount:1});
      await ctx.page('Input.dispatchMouseEvent',{type:'mouseReleased',...bar,button:'left',clickCount:1});
      await ctx.pause(250);await log('Click scrollbar at right edge');
      await ctx.screenshot(`${scenario.name}-scrollbar-right.png`,{captureBeyondViewport:false});
      result.scenarios.push(rec);
      console.log(JSON.stringify({version,scenario:scenario.name,events:rec.events}));
    }
    result.exceptions=ctx.exceptions;
  });
  await writeFile(path.join(dir,'browser.json'),JSON.stringify(result,null,2)+'\n',{flag:'wx'});
}
