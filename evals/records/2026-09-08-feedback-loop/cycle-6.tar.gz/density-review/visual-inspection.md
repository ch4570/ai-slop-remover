# 직접 열린 이미지

아래 27개는 `view_image`로 실제 열어 시각적으로 검토했다. 그 밖의 생성된 PNG는 캡처 증거이며 직접 시각 검토했다고 주장하지 않는다. 모든 경로는 `/tmp/lutriva-cycle6-quality-review-8IbTRT/` 기준이다.

## baseline (9)

- `baseline/compare-wide-initial.png`
- `baseline/master-wide-initial.png`
- `baseline/compare-narrow390-initial.png`
- `baseline/compare-narrow320-initial.png`
- `baseline/compare-text200-long320-initial.png`
- `baseline/compare-text150-390-initial.png`
- `baseline/compare-text200-longwide-initial.png`
- `baseline/master-narrow390-initial.png`
- `baseline/master-narrow320-initial.png`

## release (12)

- `release/compare-wide-initial.png`
- `release/compare-narrow390-initial.png`
- `release/compare-narrow320-keyboard-focus.png`
- `release/compare-text200-long320-keyboard-focus.png`
- `release/master-wide-initial.png`
- `release/compare-narrow320-initial.png`
- `release/compare-text200-long320-initial.png`
- `release/compare-text200-long320-scrolled-right.png`
- `release/compare-text150-390-initial.png`
- `release/compare-text200-longwide-initial.png`
- `release/master-narrow390-initial.png`
- `release/master-narrow320-initial.png`

## 추가 입력 검토 (6)

- `recheck-release/390-focus.png`
- `recheck-release/390-ArrowRight.png`
- `recheck-release/text200-long320-third-row-selected.png`
- `supplement-baseline/master390-recovered.png`
- `supplement-release/master390-recovered.png`
- `supplement-release/compare200-after-selection-recovered.png`

넓은 화면의 열 앵커·녹색 탐색/행동·흰 표면·글꼴이 보존되고 비교 표의 행 간격만 줄었다. master는 같은 모양이다. 좁은 화면·확대·긴 이름에서 표의 일부 열은 의도된 내부 스크롤 밖에 있지만 주변 제목과 상태 문구는 창 안에서 줄바꿈된다. 390px Tab 진입의 버튼 오른쪽 잘림, 200% 선택 후 가장자리 잘림과 방향키/스크롤 후 복구를 직접 확인했다. 실제 선택 결과와 키 입력의 성공은 별도 browser.json 기록에 근거하며 이미지 자체로 주장하지 않는다.
