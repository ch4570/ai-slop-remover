import { readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';
const root='/tmp/lutriva-quality-gate-trial-O6pdDy';
const output='/tmp/lutriva-cycle6-quality-review-8IbTRT';
const manifest=JSON.parse(await readFile(path.join(output,'input-before.json'),'utf8'));
const before=manifest.files.filter(file=>file.path.startsWith('baseline/'));
const after=manifest.files.filter(file=>file.path.startsWith('release/'));
const files=before.map(file=>{const other=after.find(item=>item.path===file.path.replace('baseline/','release/'));return {name:file.path.slice(9),baselineBytes:file.bytes,releaseBytes:other?.bytes,baselineSha256:file.sha256,releaseSha256:other?.sha256,identical:other?.sha256===file.sha256};});
const [beforeDesign,afterDesign,beforeCss,afterCss]=await Promise.all(['baseline/DESIGN.md','release/DESIGN.md','baseline/compare.css','release/compare.css'].map(file=>readFile(path.join(root,file),'utf8')));
const section=/<!-- comparison-exception:start -->([\s\S]*?)<!-- comparison-exception:end -->/;
const blocks=[...afterDesign.matchAll(/```css\n([\s\S]*?)\n```/g)].map(match=>match[1]);
const design={outsideExceptionIdentical:beforeDesign.replace(section,'[EXCEPTION]')===afterDesign.replace(section,'[EXCEPTION]'),cssBlockCount:blocks.length,cssMatchesImplementation:blocks[0]===afterCss.trim(),beforeCss:beforeCss.trim(),afterCss:afterCss.trim(),onlyAllowedPaddingReplacement:beforeCss.replace('padding-block: 16px','padding-block: 8px')===afterCss};
const masterScreenshots=[];
for(const size of ['wide','narrow390','narrow320']) {
  const [a,b]=await Promise.all(['baseline','release'].map(version=>readFile(path.join(output,version,`master-${size}-initial.png`))));
  masterScreenshots.push({size,identicalPngBytes:a.equals(b),baselineBytes:a.length,releaseBytes:b.length});
}
const checks=JSON.parse(await readFile(path.join(output,'checks.json'),'utf8'));
const result={files,design,masterScreenshots,automatedInitial:{total:checks.total,passed:checks.passed,failed:checks.failed,classification:{initialWheelObservationsSupersededByFreshTargetedInputRecheck:4,preexisting390FullButtonContainmentWarnings:12,release200PercentPostStatusFullButtonContainmentWarnings:2}},verdict:'pass',verdictScope:'Only the requested comparison-table vertical padding exception and its design record, on tested desktop Chrome CSS viewports and temporary text/data stress conditions. Recoverable nonblocking focus-edge limitations are documented separately.'};
await writeFile(path.join(output,'scope-summary.json'),JSON.stringify(result,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify(result,null,2));
