import { writeFile } from 'node:fs/promises';
import path from 'node:path';
import { withBrowser, claimBrowserEvidence } from '/tmp/lutriva-quality-gate-trial-O6pdDy/harness/browser_harness.mjs';
const output='/tmp/lutriva-cycle6-quality-review-8IbTRT';
const snapshot=`(() => {const e=document.querySelector('.table-scroll'),b=e.getBoundingClientRect(),a=document.activeElement,r=a.getBoundingClientRect();return {scrollLeft:e.scrollLeft,maxScroll:e.scrollWidth-e.clientWidth,boxLeft:b.left,boxRight:b.right,boxTop:b.top,active:a.dataset.order,activeLeft:r.left,activeRight:r.right,focusVisible:a.matches(':focus-visible'),detail:document.querySelector('#detail').textContent,scrollX};})()`;
for(const version of ['baseline','release']) {
  const dir=path.join(output,`supplement-${version}`);await claimBrowserEvidence(dir,[]);
  const evidence={version,cases:[]};
  await withBrowser(`/tmp/lutriva-quality-gate-trial-O6pdDy/${version}`,dir,async ctx=>{
    evidence.browser=await ctx.call('Browser.getVersion');
    for(const name of version==='release'?['master390','compare200-after-selection']:['master390']) {
      const stress=name!=='master390';const route=stress?'compare':'master';const item={name,events:[]};
      await ctx.page('Emulation.setDeviceMetricsOverride',{width:stress?320:390,height:stress?800:844,deviceScaleFactor:1,mobile:false});
      await ctx.page('Page.navigate',{url:`${ctx.origin}/${route}.html`});
      for(let n=0;n<100;n++){if(await ctx.evaluate(`document.readyState==='complete'&&document.querySelectorAll('[data-order]').length===3`))break;await ctx.pause(30);}
      if(stress) await ctx.evaluate(`(() => {document.querySelector('tbody tr td:nth-child(2)').textContent='대한민국서울특별시성동구주문담당김민지와함께하는생활도자기공동구매고객';const a=Array.from(document.querySelectorAll('body,body *'),e=>[e,parseFloat(getComputedStyle(e).fontSize)]);for(const[e,s]of a)e.style.fontSize=s*2+'px';})()`);
      await ctx.pause(200);
      for(let n=0;n<3;n++)await ctx.pressKey('Tab');
      const log=async action=>{const state=await ctx.evaluate(snapshot);item.events.push({action,state});return state;};
      let state=await log('first row focused by Tab');
      if(stress){await ctx.pressKey('Enter');await ctx.pressKey('Tab');await ctx.pressKey('Space');await ctx.pressKey('Tab');await ctx.pressKey('Enter');await ctx.pause(200);await log('third row selected after status wrapping');}
      else {const point={x:100,y:state.boxTop+100};await ctx.page('Input.dispatchMouseEvent',{type:'mouseMoved',...point});await ctx.page('Input.dispatchMouseEvent',{type:'mouseWheel',...point,deltaX:40,deltaY:0});await ctx.pause(300);await log('pointer moved then horizontal wheel +40');}
      await ctx.page('Input.dispatchKeyEvent',{type:'keyDown',key:'ArrowRight',code:'ArrowRight',windowsVirtualKeyCode:39});
      await ctx.page('Input.dispatchKeyEvent',{type:'keyUp',key:'ArrowRight',code:'ArrowRight',windowsVirtualKeyCode:39});
      await ctx.pause(300);state=await log('ArrowRight once after selection or wheel');
      item.recovered=state.activeLeft>=state.boxLeft+5&&state.activeRight<=state.boxRight-5&&state.scrollLeft===state.maxScroll&&state.scrollX===0;
      await ctx.screenshot(`${name}-recovered.png`,{captureBeyondViewport:false});
      if(!stress){for(const key of ['Enter','Tab','Space','Tab','Enter'])await ctx.pressKey(key);state=await log('M-101 Enter, M-102 Space, M-103 Enter');item.rowOutcomeOkay=state.detail==='M-103 주문을 선택했습니다.';}
      else item.rowOutcomeOkay=state.detail==='M-103 주문을 선택했습니다.';
      evidence.cases.push(item);console.log(JSON.stringify({version,...item}));
    }
    evidence.exceptions=ctx.exceptions;
  });
  await writeFile(path.join(dir,'browser.json'),JSON.stringify(evidence,null,2)+'\n',{flag:'wx'});
}
