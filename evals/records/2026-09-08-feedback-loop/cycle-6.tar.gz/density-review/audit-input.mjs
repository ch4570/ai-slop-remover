import { readdir, readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { createHash } from 'node:crypto';

const input = '/tmp/lutriva-quality-gate-trial-O6pdDy';
const output = '/tmp/lutriva-cycle6-quality-review-8IbTRT';
const phase = process.argv[2];
if (!['before', 'after', 'after-final'].includes(phase)) throw new Error('Expected before, after, or after-final');
const roots = ['TASK.md', 'ORIGINAL-REQUEST.md', 'TOOLS.md', 'baseline', 'release', 'skills', 'harness'];
async function collect(relative) {
  let children;
  try { children = await readdir(path.join(input, relative), { withFileTypes: true }); }
  catch (error) {
    if (error.code !== 'ENOTDIR') throw error;
    const bytes = await readFile(path.join(input, relative));
    return [{ path: relative, bytes: bytes.length, sha256: createHash('sha256').update(bytes).digest('hex') }];
  }
  return (await Promise.all(children.map(entry => collect(path.join(relative, entry.name))))).flat();
}
const files = (await Promise.all(roots.map(collect))).flat().sort((a, b) => a.path.localeCompare(b.path));
const result = { phase, recordedAt: new Date().toISOString(), fileCount: files.length, totalBytes: files.reduce((sum, file) => sum + file.bytes, 0), files };
await writeFile(path.join(output, `input-${phase}.json`), JSON.stringify(result, null, 2) + '\n', { flag: 'wx' });
if (phase !== 'before') {
  const before = JSON.parse(await readFile(path.join(output, 'input-before.json'), 'utf8'));
  const equal = JSON.stringify(before.files) === JSON.stringify(files);
  const comparison = { identical: equal, beforeFileCount: before.fileCount, afterFileCount: files.length, beforeBytes: before.totalBytes, afterBytes: result.totalBytes };
  await writeFile(path.join(output, phase === 'after' ? 'input-integrity.json' : 'input-integrity-final.json'), JSON.stringify(comparison, null, 2) + '\n', { flag: 'wx' });
  console.log(JSON.stringify(comparison));
  if (!equal) process.exitCode = 1;
} else console.log(JSON.stringify({ fileCount: result.fileCount, totalBytes: result.totalBytes }));
