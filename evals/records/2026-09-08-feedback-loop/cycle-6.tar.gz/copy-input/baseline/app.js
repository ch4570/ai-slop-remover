(async () => {
  const locale = new URLSearchParams(location.search).get('lang') === 'en' ? 'en' : 'ko';
  const copy = await (await fetch('locales/' + locale + '.json')).json();
  const el = id => document.getElementById(id);
  const interpolate = (key, values = {}) => copy[key].replace(/\{(\w+)\}/g, (token, name) => String(values[name] ?? token));
  const pause = () => new Promise(resolve => setTimeout(resolve, 120));
  const readNotes = () => JSON.parse(localStorage.getItem('daon-draft-notes') || '[{"id":1,"title":"주말 장보기"},{"id":2,"title":"다음 주 일정"}]');
  const status = (area, state, key, values) => {
    el(area + '-status').dataset.state = state;
    el(area + '-status').textContent = interpolate(key, values);
  };
  el('title').value = readNotes()[0].title;
  el('save').textContent = copy.save_action;
  el('export').textContent = copy.export_action;
  status('save', 'idle', 'save_idle');
  status('export', 'idle', 'export_idle');
  el('editor').addEventListener('submit', async event => {
    event.preventDefault();
    if (el('save').disabled) return;
    const title = el('title').value;
    el('save').disabled = true;
    el('title').disabled = true;
    status('save', 'pending', 'save_pending', { title });
    try {
      await pause();
      if (el('fail-save').checked) throw new Error('Synthetic unclassified save failure');
      const notes = readNotes().map(note => note.id === 1 ? { ...note, title } : note);
      localStorage.setItem('daon-draft-notes', JSON.stringify(notes));
      status('save', 'success', 'save_success', { title });
    } catch {
      status('save', 'error', 'save_failed', { title });
    } finally {
      el('save').disabled = false;
      el('title').disabled = false;
    }
  });
  el('export').addEventListener('click', async () => {
    if (el('export').disabled) return;
    const filename = '개인 메모.csv';
    const notes = readNotes();
    const values = { filename, count: notes.length };
    el('export').disabled = true;
    if (el('download').hasAttribute('href')) URL.revokeObjectURL(el('download').href);
    el('download').hidden = true;
    el('download').removeAttribute('href');
    status('export', 'pending', 'export_pending', values);
    try {
      await pause();
      if (el('fail-export').checked) throw new Error('Synthetic unclassified export failure');
      const csv = ['title', ...notes.map(note => '"' + note.title.replaceAll('"', '""') + '"')].join('\r\n');
      el('download').href = URL.createObjectURL(new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8' }));
      el('download').download = filename;
      el('download').textContent = interpolate('download_action', values);
      el('download').hidden = false;
      status('export', 'ready', 'export_ready', values);
    } catch {
      status('export', 'error', 'export_failed', values);
    } finally {
      el('export').disabled = false;
    }
  });
  document.documentElement.dataset.ready = 'true';
})();
