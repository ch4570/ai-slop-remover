# 메모 저장·파일 내보내기 문구 수정

$ux-writing 개인 메모 화면의 저장과 파일 내보내기 문구가 실제 상태를 잘
설명하도록 한국어만 다듬어 주세요. 지금은 버튼과 완료 안내를 읽어도 어디에
무엇이 저장됐는지 헷갈립니다. 코드와 디자인 기록에서 실제 동작을 확인하고,
실패한 뒤 사용자가 이 화면에서 할 수 있는 행동도 자연스럽게 안내해 주세요.

제품은 `product/`입니다. `locales/ko.json`의 save_action, save_pending,
save_success, save_failed, export_action, export_pending, export_ready,
export_failed, download_action의 문자열 값만 수정할 수 있습니다.
키와 각 문자열별 보간 변수 구성을 유지합니다. 다른 문자열·영어 locale·동작·
HTML·ARIA·스타일·DESIGN·TASK·파일 추가와 삭제는 범위 밖입니다.

과장된 확신이나 예상 시간을 만들지 말고 기존 존댓말을 유지합니다. 실제로
확인한 상태와 표시, 확인하지 못한 다운로드·기기·보조기술 결과를 구분해서
보고하세요. 렌더링할 수 있다면 긴 제목과 320px 화면에서 수정 문구도 확인해
주세요. 범위 밖 문제는 수정하지 말고 알려주세요.
