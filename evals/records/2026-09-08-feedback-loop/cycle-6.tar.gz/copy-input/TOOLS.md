# 제공된 브라우저 도구

`harness/browser_harness.mjs`의 `withBrowser(productDirectory, outputDirectory,
async context => ...)`는 기존 Chrome과 새 임시 프로필, loopback 제품 서버를
사용합니다. 제품 진입점은 `/index.html`이며 helper가 자동으로 이동하거나
페이지 준비 상태·검사 결과를 판단하지는 않습니다. 구현 소스는 읽을 수 있습니다.

context에는 `origin`, 페이지 CDP용 `page(method, params)`, 브라우저 CDP용
`call(method, params)`, `evaluate(expression)`, `pause(milliseconds)`, `exceptions`가
있습니다. `Browser.getVersion`으로 실제 실행 버전을 기록할 수 있습니다.
`pressKey('Tab'|'Enter'|'Escape'|'Space', {shift: boolean})`는 네 키의 down/up
쌍을 보냅니다. 옵션은 생략할 수 있고 다른 키/옵션은 전송 전에 거부합니다.
일반 입력은 이 helper를 우선 사용하고 Windows 숫자를 플랫폼별 native code로
임의 재사용하지 마세요. 합성 값 준비와 실제 브라우저 입력은 구분하세요.

`screenshot(name, {captureBeyondViewport: false})`는 현재 viewport를 캡처합니다.
옵션 생략 시 전체 페이지 범위를 사용할 수 있습니다. 각 재실행은 새 출력
경로를 사용하고, 시각적 주장은 캡처를 직접 열어 확인하세요. 프로필 분리는
네트워크나 전역 브라우저 업데이트까지 격리한다는 보장이 아닙니다.
