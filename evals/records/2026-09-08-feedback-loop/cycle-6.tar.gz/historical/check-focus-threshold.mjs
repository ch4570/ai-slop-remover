import { mkdir, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { claimBrowserEvidence, withBrowser } from './browser_harness.mjs';
const [product, outputArg] = process.argv.slice(2);
const output = path.resolve(outputArg);
await claimBrowserEvidence(output, ['after-800.png', 'after-864.png']);
const observations = [], collectionErrors = [];
let environment;
try {
  await withBrowser(product, output, async ({ origin, page, call, evaluate, pause, screenshot, exceptions }) => {
    environment = { browser: (await call('Browser.getVersion')).product, node: process.version, origin };
    const press = async (key, keyCode) => {
      await page('Input.dispatchKeyEvent', { type: 'keyDown', key, code: key, windowsVirtualKeyCode: keyCode, ...(key === 'Enter' ? { text: '\r', unmodifiedText: '\r' } : {}) });
      await page('Input.dispatchKeyEvent', { type: 'keyUp', key, code: key, windowsVirtualKeyCode: keyCode });
    };
    const measure = () => evaluate(`(() => {
      const button = document.querySelector('button'), table = document.querySelector('.table-scroll');
      const b = button.getBoundingClientRect(), t = table.getBoundingClientRect(), s = getComputedStyle(button);
      const edge = parseFloat(s.outlineWidth) + parseFloat(s.outlineOffset);
      return {
        order: document.activeElement.dataset.order, focusVisible: button.matches(':focus-visible'), outline: s.outline, outlineOffset: s.outlineOffset,
        button: { left: b.left, right: b.right, top: b.top, bottom: b.bottom },
        clip: { left: t.left + table.clientLeft, right: t.left + table.clientLeft + table.clientWidth },
        horizontalFocusFits: b.left - edge >= t.left + table.clientLeft && b.right + edge <= t.left + table.clientLeft + table.clientWidth,
        scrollLeft: table.scrollLeft, scrollMax: table.scrollWidth - table.clientWidth, clientWidth: table.clientWidth,
        documentWidth: document.documentElement.scrollWidth, documentHeight: document.documentElement.scrollHeight, viewportHeight: innerHeight,
        cellPadding: getComputedStyle(document.querySelector('td')).paddingTop,
        status: document.getElementById('detail').textContent
      };
    })()`);
    for (const height of [800, 864]) {
      await page('Emulation.setDeviceMetricsOverride', { width: 320, height, deviceScaleFactor: 1, mobile: false });
      const old = await evaluate('performance.timeOrigin');
      await page('Page.navigate', { url: origin + '/compare.html' });
      let ready = false;
      for (let attempt = 0; attempt < 100; attempt++) {
        try { ready = await evaluate(`location.origin === ${JSON.stringify(origin)} && performance.timeOrigin !== ${old} && document.readyState === 'complete' && !!document.querySelector('[data-order="M-101"]')`); } catch {}
        if (ready) break;
        await pause(40);
      }
      if (!ready) throw Error('Comparison document did not load');
      await evaluate(`(() => { const elements = [...document.querySelectorAll('body, body *')]; const sizes = elements.map(element => parseFloat(getComputedStyle(element).fontSize)); elements.forEach((element, i) => element.style.fontSize = (sizes[i] * 2) + 'px'); })()`);
      for (let step = 0; step < 6; step++) {
        if (await evaluate("document.activeElement.dataset.order === 'M-101'")) break;
        await press('Tab', 9);
      }
      const before = await measure();
      await press('Enter', 13);
      const after = await measure();
      const capture = await page('Page.captureScreenshot', { format: 'png', captureBeyondViewport: false });
      await writeFile(path.join(output, 'after-' + height + '.png'), Buffer.from(capture.data, 'base64'));
      const afterCapture = await measure();
      await page('Input.dispatchMouseEvent', { type: 'mouseWheel', x: 220, y: after.button.top + 20, deltaX: 1000, deltaY: 0 });
      await pause(100);
      const recovered = await measure();
      observations.push({ width: 320, height, fontScale: 2, mobile: false, before, after, afterCapture, recovered });
    }
    if (exceptions.length) collectionErrors.push(...exceptions.map(value => JSON.stringify(value)));
  });
} catch (error) { collectionErrors.push(String(error)); }
await mkdir(output, { recursive: true });
await writeFile(path.join(output, 'browser.json'), JSON.stringify({ environment, observations, collectionErrors, limits: ['CSS-computed text enlargement is not an OS setting or browser zoom test.', 'Focus-fit geometry requires image review.', 'Mouse-wheel recovery does not prove a keyboard-only recovery path.'] }, null, 2) + '\n');
console.log(JSON.stringify({ output, collectionErrors: collectionErrors.length, observations: observations.map(item => ({ height: item.height, before: item.before.horizontalFocusFits, after: item.after.horizontalFocusFits, recovered: item.recovered.horizontalFocusFits, status: item.after.status })) }));
if (collectionErrors.length || observations.length !== 2) process.exitCode = 1;
