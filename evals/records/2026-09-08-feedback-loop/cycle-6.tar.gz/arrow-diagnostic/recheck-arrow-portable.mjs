import { createHash } from 'node:crypto';
import { readFile, readdir, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

const [inputRootArg, newOutputArg, harnessArg] = process.argv.slice(2);
if (!inputRootArg || !newOutputArg || process.argv.length > 5) {
  throw new Error('Usage: node recheck-arrow-portable.mjs INPUT_ROOT NEW_OUTPUT [HARNESS_PATH]');
}
const source = path.resolve(inputRootArg);
const output = path.resolve(newOutputArg);
const harness = path.resolve(harnessArg ?? path.join(source, 'harness', 'browser_harness.mjs'));
const { claimBrowserEvidence, withBrowser } = await import(pathToFileURL(harness).href);
const productPaths = { 'original-product':path.join(source, 'baseline'), product:path.join(source, 'release') };
const priorOutput = null, blindTrial = null, supplement = null;
const longName = '대한민국서울특별시성동구주문담당김민지와함께하는생활도자기공동구매고객';
const cases = [
  { name:'candidate-m101-800', product:'product', height:800, longName:false, selected:'M-101' },
  { name:'candidate-long-m103-800', product:'product', height:800, longName:true, selected:'M-103' },
  { name:'original-m101-864', product:'original-product', height:864, longName:false, selected:'M-101' }
];
const report = {
  output, source, priorOutput, blindTrial, harness, supplement, startedAt:new Date().toISOString(),
  conditions:{ width:320, textScale:2, deviceScaleFactor:1, mobile:false, longName,
    textMethod:'Snapshot computed body and descendant font sizes, then set each inline fontSize to twice the snapshot.',
    selectionSimple:'Tab × 3 → M-101 Enter',
    selectionLong:'Insert long first customer name, CSS font × 2, pause 200ms, Tab × 3, Enter, Tab, Space, Tab, Enter, pause 200ms.',
    recovery:'CDP keyDown and keyUp: key/code ArrowRight, windowsVirtualKeyCode 39, no nativeVirtualKeyCode; pause 300ms.',
    captures:'Viewport PNGs with captureBeyondViewport:false' },
  cases:[], errors:[],
  limits:[
    'CSS text emulation is not native zoom, OS text scaling, a physical keyboard, or a physical-device check.',
    'This tests ArrowRight as a distinct path from the previously unsuccessful Tab → Shift+Tab attempt.',
    'Full-outline fit uses the inner client clipping boundary and computed outline width plus offset.',
    'Partial outline clipping alone does not establish a WCAG failure or a mandatory product-readiness verdict.'
  ]
};
const logs=[];
function log(kind,detail){const entry={time:new Date().toISOString(),kind,...detail};logs.push(JSON.stringify(entry));console.log(JSON.stringify(entry));}
async function digest(file){const bytes=await readFile(file);return{bytes:bytes.length,sha256:createHash('sha256').update(bytes).digest('hex')};}
async function manifest(dir){const files={};for(const entry of(await readdir(dir,{withFileTypes:true})).sort((a,b)=>a.name.localeCompare(b.name))){const full=path.join(dir,entry.name);if(entry.isDirectory()){for(const[k,v]of Object.entries(await manifest(full)))files[path.join(entry.name,k)]=v;}else{if(!entry.isFile())throw Error('Unexpected non-regular input: '+full);files[entry.name]=await digest(full);}}return files;}
async function inputs(){return{
  products:Object.fromEntries(await Promise.all(['original-product','product'].map(async name=>[name,await manifest(productPaths[name])]))),
  harness:await digest(harness)
};}
report.inputBefore=await inputs();
report.portableRun = { inputLayout:'baseline/ and release/', harnessSource:harness, derivedFrom:'recheck-arrow.mjs; only input/output/import mapping and path-dependent provenance fields differ.' };
await claimBrowserEvidence(output,cases.flatMap(c=>[`${c.name}-before-arrow.png`,`${c.name}-after-arrow.png`]));
await writeFile(path.join(output,'inputs-before.json'),JSON.stringify(report.inputBefore,null,2)+'\n',{flag:'wx'});
const measure=`(()=>{
  const table=document.querySelector('.table-scroll'),active=document.activeElement,b=active.getBoundingClientRect(),t=table.getBoundingClientRect(),style=getComputedStyle(active);
  const rect=r=>({left:r.left,right:r.right,top:r.top,bottom:r.bottom,width:r.width,height:r.height});
  const edge=parseFloat(style.outlineWidth)+parseFloat(style.outlineOffset);
  const clip={left:t.left+table.clientLeft,right:t.left+table.clientLeft+table.clientWidth,top:t.top+table.clientTop,bottom:t.top+table.clientTop+table.clientHeight};
  const extent={left:b.left-edge,right:b.right+edge,top:b.top-edge,bottom:b.bottom+edge};
  const margins={left:extent.left-clip.left,right:clip.right-extent.right,top:extent.top-clip.top,bottom:clip.bottom-extent.bottom};
  const horizontalFocusFits=margins.left>=0&&margins.right>=0,verticalFocusFits=margins.top>=0&&margins.bottom>=0;
  return{
    active:{tag:active.tagName,order:active.dataset.order??null,text:active.textContent.trim().slice(0,100),focusVisible:active.matches(':focus-visible')},
    button:rect(b),tableOuter:rect(t),clip,outline:style.outline,outlineWidth:style.outlineWidth,outlineOffset:style.outlineOffset,outlineEdge:edge,outlineExtent:extent,outlineMargins:margins,
    horizontalButtonFits:b.left>=clip.left&&b.right<=clip.right,horizontalFocusFits,verticalFocusFits,fullFocusFits:horizontalFocusFits&&verticalFocusFits,
    viewportFocusFits:extent.left>=0&&extent.right<=document.documentElement.clientWidth&&extent.top>=0&&extent.bottom<=innerHeight,
    scrollLeft:table.scrollLeft,scrollMax:table.scrollWidth-table.clientWidth,tableClientWidth:table.clientWidth,tableClientHeight:table.clientHeight,tableScrollWidth:table.scrollWidth,tableScrollHeight:table.scrollHeight,
    documentClientWidth:document.documentElement.clientWidth,documentHeight:document.documentElement.scrollHeight,viewportWidth:innerWidth,viewportHeight:innerHeight,pageScrollX:scrollX,pageScrollY:scrollY,verticalScrollbarWidth:innerWidth-document.documentElement.clientWidth,devicePixelRatio,
    fontSizes:{body:getComputedStyle(document.body).fontSize,button:style.fontSize,heading:getComputedStyle(document.querySelector('h1')).fontSize},
    customer:document.querySelector('tbody tr td:nth-child(2)').textContent,status:document.getElementById('detail').textContent,events:window.__arrowEvents.slice()
  };
})()`;
try{
  for(const testCase of cases){
    const result={...testCase,stages:[],targetChecks:[]};report.cases.push(result);
    await withBrowser(productPaths[testCase.product],output,async({origin,page,pressKey,call,evaluate,pause,screenshot,exceptions})=>{
      result.origin=origin;result.node=process.version;result.browserBefore=await call('Browser.getVersion');log('browser-before',{name:testCase.name,version:result.browserBefore});
      const initial=(await call('Target.getTargets')).targetInfos.filter(t=>t.type==='page');
      if(initial.length!==2||initial.some(t=>t.url!=='about:blank'))throw Error('Unexpected initial targets: '+JSON.stringify(initial));
      result.initialPageTargets=initial;const ids=initial.map(t=>t.targetId).sort();let controlled;
      const guard=async stage=>{const targets=(await call('Target.getTargets')).targetInfos.filter(t=>t.type==='page');const matches=targets.filter(t=>t.url===origin+'/compare.html');const safe=JSON.stringify(targets.map(t=>t.targetId).sort())===JSON.stringify(ids)&&matches.length===1&&(!controlled||matches[0].targetId===controlled)&&targets.every(t=>t.url==='about:blank'||t.url===origin+'/compare.html');result.targetChecks.push({stage,safe,targets});if(!safe)throw Error('Unexpected page targets: '+JSON.stringify(targets));controlled=matches[0].targetId;};
      const stage=async label=>{const measurement=await evaluate(measure);result.stages.push({stage:label,measurement});return measurement;};
      try{
        await page('Emulation.setDeviceMetricsOverride',{width:320,height:testCase.height,deviceScaleFactor:1,mobile:false});
        await page('Page.navigate',{url:origin+'/compare.html'});
        let ready=false;for(let attempt=0;attempt<100;attempt++){try{ready=await evaluate(`location.href===${JSON.stringify(origin+'/compare.html')}&&document.readyState==='complete'&&document.querySelectorAll('[data-order]').length===3`);}catch{}if(ready)break;await pause(30);}if(!ready)throw Error('Product did not load');
        await guard('loaded');
        await evaluate(`(()=>{
          window.__arrowEvents=[];
          for(const type of ['keydown','keyup','focusin','click'])document.addEventListener(type,event=>window.__arrowEvents.push({type:event.type,key:event.key??null,code:event.code??null,keyCode:event.keyCode??null,shiftKey:event.shiftKey??false,isTrusted:event.isTrusted,tag:event.target.tagName,order:event.target.dataset?.order??null}),true);
          if(${testCase.longName})document.querySelector('tbody tr td:nth-child(2)').textContent=${JSON.stringify(longName)};
          const sizes=Array.from(document.querySelectorAll('body,body *'),element=>[element,parseFloat(getComputedStyle(element).fontSize)]);
          for(const[element,size]of sizes)element.style.fontSize=size*2+'px';
        })()`);
        if(testCase.longName)await pause(200);
        for(let i=0;i<3;i++){await guard('before-initial-tab-'+i);await pressKey('Tab');}
        if(!await evaluate(`document.activeElement.dataset.order==='M-101'`))throw Error('Initial Tab sequence missed M-101');
        await stage('M-101 focused before selection');
        const sequence=testCase.longName?['Enter','Tab','Space','Tab','Enter']:['Enter'];
        for(let i=0;i<sequence.length;i++){await guard(`before-selection-${i}-${sequence[i]}`);await pressKey(sequence[i]);}
        if(testCase.longName)await pause(200);
        const before=await stage('selected before ArrowRight');
        if(before.active.order!==testCase.selected||before.status!==testCase.selected+' 주문을 선택했습니다.')throw Error('Unexpected selected row or result: '+JSON.stringify(before.active));
        await screenshot(testCase.name+'-before-arrow.png',{captureBeyondViewport:false});
        await stage('after before-arrow capture');
        await guard('before-ArrowRight');
        await page('Input.dispatchKeyEvent',{type:'keyDown',key:'ArrowRight',code:'ArrowRight',windowsVirtualKeyCode:39});
        await page('Input.dispatchKeyEvent',{type:'keyUp',key:'ArrowRight',code:'ArrowRight',windowsVirtualKeyCode:39});
        await pause(300);
        const after=await stage('after ArrowRight and 300ms');
        await screenshot(testCase.name+'-after-arrow.png',{captureBeyondViewport:false});
        await stage('after after-arrow capture');
        await guard('after-ArrowRight-capture');
        result.recoveryObserved={startedClipped:!before.horizontalFocusFits,finishedFullOutlineFits:after.fullFocusFits,viewportFocusFits:after.viewportFocusFits,selectedRowPreserved:after.active.order===testCase.selected,statusPreserved:after.status===before.status,atMaxScroll:after.scrollLeft===after.scrollMax,pageHorizontalScrollZero:after.pageScrollX===0};
        log('observation',{name:testCase.name,before:{order:before.active.order,scrollLeft:before.scrollLeft,max:before.scrollMax,clip:before.clip,button:before.button,outlineMargins:before.outlineMargins,fullFocusFits:before.fullFocusFits},after:{order:after.active.order,scrollLeft:after.scrollLeft,max:after.scrollMax,clip:after.clip,button:after.button,outlineMargins:after.outlineMargins,fullFocusFits:after.fullFocusFits},recoveryObserved:result.recoveryObserved});
        if(exceptions.length)report.errors.push(...exceptions.map(value=>JSON.stringify(value)));
      }finally{result.browserAfter=await call('Browser.getVersion');log('browser-after',{name:testCase.name,version:result.browserAfter});}
    });
  }
}catch(error){report.errors.push(String(error.stack??error));log('error',{error:String(error.stack??error)});}
finally{
  report.inputAfter=await inputs();report.inputBytesUnchanged=JSON.stringify(report.inputBefore)===JSON.stringify(report.inputAfter);report.finishedAt=new Date().toISOString();report.helper=await digest(new URL(import.meta.url));
  await writeFile(path.join(output,'inputs-after.json'),JSON.stringify(report.inputAfter,null,2)+'\n',{flag:'wx'});
  await writeFile(path.join(output,'browser.json'),JSON.stringify(report,null,2)+'\n',{flag:'wx'});
  await writeFile(path.join(output,'run.log'),logs.join('\n')+'\n',{flag:'wx'});
  if(report.errors.length||!report.inputBytesUnchanged||report.cases.length!==cases.length||report.cases.some(c=>c.stages.length!==5))process.exitCode=1;
}
