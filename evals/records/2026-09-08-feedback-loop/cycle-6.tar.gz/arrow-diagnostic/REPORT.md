# ArrowRight 복구 경로 독립 재현

Chrome/152.0.7977.83에서 세 조건 모두 ArrowRight 한 번으로 복구됐다. 기존 Tab → Shift+Tab 실패 기록은 그대로 유지했으며, 이번 결과는 별도의 키보드 경로다. 초기 잘림이 없었다는 뜻이나 이전 실패 관찰이 틀렸다는 뜻은 아니다.

## 실제 결과

너비 320 CSS px, DPR 1, `mobile:false`, 각 요소의 기존 computed font-size를 두 배로 만드는 CSS 텍스트 모의 조건이다. body·button은32px, h1은56px였다. 실제 OS 글자 크기나 브라우저 줌을 바꾼 시험은 아니다.

표의 내부 clipping boundary는 `getBoundingClientRect + clientLeft/clientTop + clientWidth/clientHeight`로 구했다. 측정한 outline은3px, offset은2px이므로 버튼의 각 변에서5px 확장한 범위 전체가 내부 경계에 들어가는지 검사했다. 아래 여유는 음수일 때 잘림이다.

| 조건 | 선택 후 가로 위치 → ArrowRight 후 | 외곽선 오른쪽 여유 전 → 후 | 외곽선 전체 복구 |
| --- | --- | --- | --- |
| 후보 320×800, M-101 | 338 → 353, 최대353 | −8.1875 → +6.8125px | 확인 |
| 후보 320×800, 긴 이름, M-103 | 1224 → 1239, 최대1239 | −7.953125 → +7.046875px | 확인 |
| 원본 320×864, M-101 | 338 → 353, 최대353 | −8.1875 → +6.8125px | 확인 |

세 조건 모두 복구 전 표 내부 오른쪽 경계는 x288px였다. 후보의 일반 M-101과 원본 M-101 버튼 오른쪽은291.1875→276.1875px, 긴 이름 M-103은290.953125→275.953125px로 이동했다. 긴 이름 M-103의 외곽선 아래쪽 여유도4.25px여서 가로만 맞는 것이 아니라 위·아래·왼쪽·오른쪽 모두 들어왔다. 복구 후 외곽선은 viewport에도 완전히 들어오며, 페이지 가로 스크롤은0이었다.

원래 선택된 버튼의 `:focus-visible`과 M-101/M-103 선택 상태 문구가 복구 후에도 유지됐다. 실제 ArrowRight keydown·keyup은 각 버튼에서 `isTrusted:true`, `keyCode:39`로 관찰했다. 포인터 입력이나 `scrollLeft` 직접 대입은 사용하지 않았다.

## 정확한 재현 순서

일반 M-101 조건은 새 문서에 CSS 글자 두 배를 적용하고 실제 Tab 세 번으로 두 헤더 링크를 지나 M-101에 도달한 뒤 Enter로 선택했다. 잘린 viewport 화면과 기하 값을 보관한 다음 ArrowRight keyDown/keyUp을 보냈다.

긴 이름 조건은 종료된 blind 검수의 `supplement.mjs`와 같은 문자열·순서·대기를 사용했다. 첫 고객 셀을 `대한민국서울특별시성동구주문담당김민지와함께하는생활도자기공동구매고객`으로 임시 표시한 뒤 모든 기존 computed font-size를 두 배로 바꾸고200ms 대기했다. 실제 입력은 Tab×3 → Enter(M-101) → Tab → Space(M-102) → Tab → Enter(M-103)였고,200ms 뒤 선택 상태의 잘림을 측정·캡처했다. 이후 ArrowRight 한 번과300ms 대기로 복구를 확인했다.

모든 ArrowRight 입력은 CDP `Input.dispatchKeyEvent`의 `keyDown`과`keyUp`, `key:'ArrowRight'`, `code:'ArrowRight'`, `windowsVirtualKeyCode:39`만 사용했다. `nativeVirtualKeyCode`는 사용하지 않았다. Tab·Enter·Space는 저장소 HEAD `59c22c39ed441bb97252f523bdb03b8f2e67106e`의 기존 bounded `pressKey` helper를 그대로 사용했다.

## 직접 열린 화면과 무결성

다음6개 초기 재현 viewport PNG를 실제 이미지 뷰어로 열었다. 모두 복구 전 오른쪽 테두리/외곽선의 잘림과 복구 후 전체 외곽선의 노출이 기하 측정과 일치했다.

- `candidate-m101-800-before-arrow.png`, `candidate-m101-800-after-arrow.png`
- `candidate-long-m103-800-before-arrow.png`, `candidate-long-m103-800-after-arrow.png`
- `original-m101-864-before-arrow.png`, `original-m101-864-after-arrow.png`

캡처는 모두 `captureBeyondViewport:false`이며 각 캡처 전후 기하 값이 동일했다. 버튼 문구와 선택 결과는 잘린 상태에서도 식별·동작 가능했고, 복구 후에도 유지됐다.

초기 재현의 모든 Browser.getVersion 전후 결과는 `Chrome/152.0.7977.83`, revision `@79460ebecaa5625e57a5fb679a735659e73dc687`, V8 `15.2.124.21`로 동일했다.25번의 페이지 대상 검사에서 예상된 local compare 페이지와 초기 빈 페이지 외의 대상을 허용하지 않았다. 실행 예외는0건이었다.

두 제품 트리, 현재 harness, archived recipe, blind supplement, blind의 두 제품 트리, 기존 `/tmp/lutriva-cycle6-density-recheck-zBDh5Z` 전체 증거 폴더의 파일별 SHA-256·바이트 길이·경로 목록을 전후 확인했다. 모두 동일했다. 현재 제품 쌍과 blind 검수의 baseline/release 제품 쌍도 바이트가 동일했다. 기존 Tab → Shift+Tab 실패 기록과 초기 잘림 화면은 수정하지 않았다.

## 휴대 가능한 실행 파일

`recheck-arrow-portable.mjs`는 원시 `recheck-arrow.mjs`를 보존하고 별도로 만든 사본이다. 입력/출력 경로, harness import, 경로에 종속된 출처 검증 메타데이터만 바꿨다. 긴 이름·행 순서·키 입력·대기·측정·복구 판단은 그대로다. 입력 루트는 `baseline/`, `release/`를 가져야 하며 기본 harness 경로는 `INPUT_ROOT/harness/browser_harness.mjs`다. 다른 경로는 선택적인 세 번째 인수로 지정할 수 있다.

```text
node recheck-arrow-portable.mjs INPUT_ROOT NEW_OUTPUT [HARNESS_PATH]
```

NEW_OUTPUT은 새로운 증거 경로여야 한다. 기존 증거에 덮어쓰는 것을 helper의 claim 검사로 거부한다. portable 버전은 제공된 두 제품과 harness의 전후 해시를 보존하며, 최초 실행만의 이전 /tmp 경로·과거 증거 보관 위치에는 의존하지 않는다.

실제로 아래 실행이 모두 완료됐다.

- `node /tmp/lutriva-cycle6-arrow-recheck-FzMNB8/recheck-arrow.mjs` — exit0, 세 조건 복구, 입력 변화 없음.
- `node --check /tmp/lutriva-cycle6-arrow-recheck-FzMNB8/recheck-arrow-portable.mjs` — exit0.
- `node /tmp/lutriva-cycle6-arrow-recheck-FzMNB8/recheck-arrow-portable.mjs /tmp/lutriva-quality-gate-trial-O6pdDy /tmp/lutriva-cycle6-arrow-recheck-FzMNB8/portable-verification` — exit0, 세 조건 복구, 입력 변화 없음.

portable 실제 실행의 모든 단계별 기하·키 이벤트 값은 최초 실행과 정확히 동일했다. 이 실행도 Chrome 전후 버전 동일,25번 대상 검사 통과, 예외0건이었다. 복사된 기본 harness와 저장소 harness는 SHA-256 `5538f93787bf84a401eba4ce747264ddd6bfc6e5e31049e4004a8986ad85a1e1`로 동일했다. portable 재검증 PNG6개는 생성했지만 별도로 열었다고 주장하지 않는다. 직접 이미지 검토 목록은 위 초기 재현6개다.

원시 자료는 `browser.json`, `run.log`, `inputs-before.json`, `inputs-after.json`에 있으며, portable 실제 실행 자료는 `portable-verification/`에 같은 파일명으로 보존했다. 각 browser.json에는 helper 해시, 단계별 전체 좌표·outline 여유, 실제 DOM 키 이벤트, 버전·페이지 검사·입력 해시가 있다.

이 결과는 ArrowRight 경로의 실제 복구를 입증한다. 전체 WCAG 적합성, 모든 입력 장치·브라우저의 행동, 자동 포커스 노출의 완전성, 또는 필수 제품 수정 판정을 뜻하지 않는다. 제품·저장소 수정, 설치, 글로벌 설정, 업데이트 UI, 커밋·푸시는 수행하지 않았다.
