# 모아 주문 화면 기준

브랜드 초록은 탐색과 행동에 사용한다. 흰 표면, 8px 모서리, 공통 16px 셀 위아래 간격을 기본으로 한다. master.html은 이 기준 화면이다.
비교 화면도 브랜드 역할, 열 내용, 행의 상세 보기, 키보드 포커스를 유지한다. 작은 화면에서는 표 영역 안에서 가로로 스크롤할 수 있다.

<!-- comparison-exception:start -->
같은 화면 높이에서 더 많은 주문 행을 비교할 수 있도록 compare.html의 비교 표에만 세로 간격 예외를 적용한다. compare.css의 `.comparison-table th, .comparison-table td`는 공통 16px 대신 아래 규칙을 사용한다.

```css
.comparison-table th, .comparison-table td { padding-block: 8px; }
```

master.html은 공통 16px 기준을 유지하며, 비교 화면의 브랜드·글꼴·행 버튼·포커스·표 내부 가로 스크롤은 기존 기준을 따른다. 셀 내용이나 행 작업이 늘어 가독성 또는 조작 공간이 부족해지면 이 예외를 재검토한다.
<!-- comparison-exception:end -->

새 예외를 다른 화면의 공통 토큰 변경으로 확대하지 않는다.
