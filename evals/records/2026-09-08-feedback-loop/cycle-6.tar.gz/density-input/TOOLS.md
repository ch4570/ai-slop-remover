# 제공된 브라우저 도구

`harness/browser_harness.mjs`는 기존 Chrome을 새 임시 프로필로 실행하고 제품을
loopback 서버로 제공하는 읽기 전용 도구입니다. 설치나 사용자 프로필 연결은
하지 않습니다. 프로필 분리는 네트워크/브라우저 업데이트 격리를 보장하지 않습니다.

`withBrowser(productDirectory, outputDirectory, async context => ...)`의 context:

- `origin`, `page(method, params)`, `call(method, params)`: 페이지/브라우저 CDP 호출.
- `evaluate(expression)`: 해당 페이지에서 표현식 실행. 실제 입력과 임시 준비를 구분하세요.
- `pressKey('Tab'|'Enter'|'Escape'|'Space', {shift: true|false})`: 네 키의 down/up 쌍. 옵션은 생략 가능하며 지원하지 않는 키/옵션은 전송 전에 거부합니다.
- `screenshot(name, {captureBeyondViewport: false})`: 현재 viewport 캡처. 옵션 생략 시 전체 페이지 범위를 사용할 수 있습니다.
- `pause(milliseconds)`, `exceptions`: 관찰 지연과 페이지 런타임 예외 목록.

제품 진입점은 `/master.html`과 `/compare.html`입니다. helper가 페이지를 자동으로
이동시키거나 준비 상태/검사 결과를 판단하지는 않습니다. 도구 소스를 직접 읽을
수 있으며 각 재실행은 새 출력 경로를 사용하세요. 실제 실행 버전은
`Browser.getVersion`으로 기록할 수 있습니다. 일반 입력은 제공된 `pressKey`를
우선 사용하고 Windows 키 숫자를 플랫폼별 native code로 임의 재사용하지 마세요.
화면·동작·수치가 필요한 주장은 해당 결과를 실제로 확인해야 합니다.
