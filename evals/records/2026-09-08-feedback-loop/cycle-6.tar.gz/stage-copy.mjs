import assert from 'node:assert/strict';
import { cp, mkdir, readFile, readdir, lstat, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import path from 'node:path';

// Mechanical exact-copy staging. No product rewriting or archive creation.
const staging = '/tmp/lutriva-cycle6-record-a9tGxP';
const repo = '/Users/rex/Desktop/personal/lutriva';
const mappings = [
  ['/tmp/lutriva-quality-gate-trial-O6pdDy', 'density-input'],
  ['/tmp/lutriva-copy-quality-trial-4lbBdK', 'copy-input'],
  ['/tmp/lutriva-cycle6-quality-review-8IbTRT', 'density-review'],
  ['/tmp/lutriva-cycle6-copy-review-XXqDd0', 'copy-review'],
  ['/tmp/lutriva-cycle6-density-recheck-zBDh5Z', 'density-diagnostic'],
  ['/tmp/lutriva-cycle6-arrow-recheck-FzMNB8', 'arrow-diagnostic'],
  ['/tmp/lutriva-cycle6-copy-parent-f5NyMs', 'copy-parent'],
  ['/tmp/lutriva-cycle6-evidence-audit-KwLk2c', 'artifact-audit'],
  ['/tmp/lutriva-cycle6-final-checks-gpAYXk', 'repository-checks'],
];
const singles = [
  ['/tmp/lutriva-quality-gate-trial-O6pdDy-frozen.json', 'density-frozen.json'],
  ['/tmp/lutriva-copy-quality-trial-4lbBdK-frozen.json', 'copy-frozen.json'],
  ['/tmp/lutriva-cycle6-parent-notes.md', 'PARENT-NOTES.md'],
  ['/tmp/lutriva-cycle6-freeze.mjs', 'freeze-inputs.mjs'],
  ['/tmp/lutriva-cycle6-stage.mjs', 'stage-copy.mjs'],
  ['/tmp/lutriva-cycle6-inventory.mjs', 'inventory-record.mjs'],
  ['/tmp/lutriva-cycle6-density-source-AP4ld8/visual/check-focus-threshold.mjs', 'historical/check-focus-threshold.mjs'],
  [repo + '/scripts/check_evidence_archive.py', 'tools/check_evidence_archive.py'],
];
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
async function inventory(root, prefix = '') {
  const result = {};
  for (const name of (await readdir(root)).sort()) {
    const absolute = path.join(root, name), relative = prefix + name;
    const stat = await lstat(absolute);
    assert(!stat.isSymbolicLink(), 'Unexpected link: ' + absolute);
    assert(!/(^|\/)(\.git|Cache|Code Cache|GPUCache|Crashpad|__pycache__)(\/|$)/.test(relative), 'Unexpected cache: ' + absolute);
    if (stat.isDirectory()) Object.assign(result, await inventory(absolute, relative + '/'));
    else {
      assert(stat.isFile(), 'Unexpected file type: ' + absolute);
      assert(!/(^|\/)profiles\//.test(relative), 'Profile content remains: ' + absolute);
      const bytes = await readFile(absolute);
      result[relative] = { bytes: bytes.length, sha256: hash(bytes) };
    }
  }
  return result;
}
const report = { started: new Date().toISOString(), staging,
  scope: 'Exact copies of finalized raw inputs/reports/observations; no original text or historical absolute path rewritten.',
  omissions: 'No regular files omitted within mapped evidence roots. Empty directories are not inventoried. Old cycle-3 archive/extraction is not duplicated; only original recipe and the two exact input pairs are included.',
  mappings: [], singles: [] };
for (const [source, relative] of mappings) {
  const before = await inventory(source), destination = path.join(staging, relative);
  await cp(source, destination, { recursive: true, errorOnExist: true, force: false, preserveTimestamps: true });
  assert.deepEqual(await inventory(source), before, 'Source changed: ' + source);
  assert.deepEqual(await inventory(destination), before, 'Copy differs: ' + source);
  report.mappings.push({ source, destination: relative, files: Object.keys(before).length,
    bytes: Object.values(before).reduce((sum, file) => sum + file.bytes, 0),
    sourceUnchanged: true, copyExact: true, entries: before });
}
for (const [source, relative] of singles) {
  const before = await readFile(source), destination = path.join(staging, relative);
  await mkdir(path.dirname(destination), { recursive: true });
  await cp(source, destination, { errorOnExist: true, force: false, preserveTimestamps: true });
  assert.deepEqual(await readFile(source), before);
  assert.deepEqual(await readFile(destination), before);
  report.singles.push({ source, destination: relative, bytes: before.length, sha256: hash(before), copyExact: true });
}
report.finished = new Date().toISOString();
await writeFile(path.join(staging, 'STAGING-COPY-MANIFEST.json'), JSON.stringify(report, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify({ staging, mappings: report.mappings.map(({source, destination, files, bytes}) => ({source, destination, files, bytes})), singles: report.singles.length, allCopiesExact: true }, null, 2));
