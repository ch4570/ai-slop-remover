# Cycle 6 evidence map

This is a source-only record of two read-only ui-quality-gate trials, not a shipped
skill change, a model-learning claim or a matched skill-version experiment.
Both reviewers returned bounded product-scope pass and retained observed limits.
The repository source summary is `evals/records/2026-09-08-feedback-loop/cycle-6.md`.

## Exact source mappings

- `density-input/`: `/tmp/lutriva-quality-gate-trial-O6pdDy`, all83 frozen files.
- `copy-input/`: `/tmp/lutriva-copy-quality-trial-4lbBdK`, all81 frozen files.
- `density-frozen.json`, `copy-frozen.json`: external pre-delegation inventories.
- `density-review/`: blind reviewer original report/helpers/JSON/PNGs and integrity records.
- `copy-review/`: separate blind reviewer original report/helper/JSON/PNGs and two actual CSV downloads.
- `density-diagnostic/`: independent known-condition 800/864 diagnostic and unsuccessful Tab→ShiftTab recovery.
- `arrow-diagnostic/`: independent post-review ArrowRight confirmation, portable helper and its separate verification output.
- `copy-parent/`: parent's 20-state-check adapter, current harness and both actual results.
- `artifact-audit/`: read-only file/hash/report-scope audit. Copy-report inspection by its own author is self-review; density inspection is cross-review.
- `repository-checks/`: npm/check/check:js logs on the record/document-only change.
- `historical/check-focus-threshold.mjs`: archived cycle-3 recipe, not substituted for the current diagnostic.
- `tools/check_evidence_archive.py`: exact current read-only strict archive checker.
- `PARENT-NOTES.md`: chronological parent observations, including a withdrawn initial interpretation of CSV escaping coverage and its correction.
- `STAGING-COPY-MANIFEST.json`: exact source-to-staging copy checks at staging time. The external final inventory defines the whole final archive.

The two input snapshots use 65 skill files and the browser harness from
`59c22c39ed441bb97252f523bdb03b8f2e67106e`. The harness SHA-256 is
`5538f93787bf84a401eba4ce747264ddd6bfc6e5e31049e4004a8986ad85a1e1`.
Original report text, failed observations and historical absolute paths are not
rewritten. The old cycle-3 tar/full extraction is not duplicated. Exact task
products are in the two input roots, and its relevant recipe is above. No regular
file under the mapped evidence roots is omitted. Empty cleaned profile directories
may remain, but no profile/cache contents should be present.

## Read results without flattening their scope

- Density initial `checks.json`: 506 observations,488 true,18 false. Twelve are
  shared390 button-inclusion observations, two are the new right-edge stress
  observations, four are the first wheel observations later checked with explicit
  pointer position and longer wait. Initial false records stay unchanged.
- A product pass does not make the 320x800 regression disappear. Label, selection
  action and recognizable focus remain; later ArrowRight restores the full outline.
- Initial density diagnostic is not blind: original800 fits/candidate800 clips,
  original864 clips/candidate864 fits. In the two clipped cases Tab→ShiftTab does
  not repair it. Its `*-recovered.png` names mean after an attempt, not success.
- ArrowRight is a separate route. All three post-review cases restore all four
  outline edges inside the actual client clipping bounds, without pointer or
  scrollLeft assignment. Its portable verification repeats the same measurements.
- master390 supplement uses wheel first, then ArrowRight; it does not prove
  master390 recovery with the arrow alone. compare390 records ArrowLeft then
  ArrowRight separately. Do not merge these sequences.
- Copy review executes baseline16 and release22 checks. The extra release-only
  cases prevent scoring this as16→22 improvement. Parent20 per product uses
  synthetic DOM interactions and Blob reads, not real keyboard download.
- Actual downloaded CSVs each contain168 bytes and the ordinary longTitle,
  SHA-256 `4cd715a7864f9666193242193f6190dc5f403c24a24b45bf2360fad49ea7c495`.
  Embedded double-quote escaping is covered by the separate last release-only
  Blob assertion with savedTitle containing quotes,84 bytes, SHA-256
  `9023c175170d6d4d7dc3bc20b91db8b654b7429b4e03bb14165c92fafc466477`.
  That quoted Blob was not the actual downloaded file. See artifact-audit's hash
  reconstruction against the undoubled82-byte negative expectation.
- Density reviewer opened27 PNGs; copy reviewer opened16 release+9 baseline PNGs
  (four other baseline PNGs captured only). Parent and diagnostic views are
  separate checks, not added to those counts. Capture-time false inspection fields
  in copy JSON are superseded by the explicitly separate final visual-review list.

## Portable reproductions from a new extraction

Existing Node with native WebSocket (these runs used26.8.1) and local Chrome are
required. Do not install/update Chrome or open update UI just to replay this record.
Run from the extracted archive root, with distinct fresh output paths:

```sh
node arrow-diagnostic/recheck-arrow-portable.mjs density-input /tmp/new-cycle6-arrow
node copy-parent/check-copy-states.mjs copy-input/baseline /tmp/new-cycle6-copy-baseline
node copy-parent/check-copy-states.mjs copy-input/release /tmp/new-cycle6-copy-release
```

The first command's exit0 denotes complete collection with no collector errors,
not an automatic product verdict: inspect all `recoveryObserved` fields, full
outline geometry, versions and `inputBytesUnchanged` in browser.json. The other
two require exactly20 passing state assertions and no collection errors, but do
not semantically certify the copy or click the download link. Their full-page
captures are not viewport-focus proof.

Original blind helpers retain historical absolute input/output/import paths. They
are raw provenance, not promised relocation-ready commands. They need explicitly
remapped new input/output/harness paths to rerun; do not execute them at obsolete
locations or replace their old evidence in place. The portable diagnostics above
are separate from a rerun of the blind reviewers' entire28-condition/38-check work.

Actual browser version was Chrome152.0.7977.83. Blind helpers record session-start
version; parent diagnostics record before/after. Text enlargement is specified
per helper (per-element computed CSS scaling versus browser default font sizes),
not OS/page zoom. CDP keys/touch are not physical input/IME/screenreader/device
validation. Fresh profiles and target guards do not guarantee network/updater
isolation. Archive hash/file agreement cannot establish semantic evidence truth
or the independence of conversational contexts.
