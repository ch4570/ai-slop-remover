import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { createHash } from 'node:crypto';
const [root, output] = process.argv.slice(2);
assert(root && output, 'Usage: node inventory.mjs ROOT NEW_INVENTORY');
const files = {};
function walk(directory, prefix = '') {
  for (const name of fs.readdirSync(directory).sort()) {
    const absolute = path.join(directory, name), relative = prefix + name;
    const stat = fs.lstatSync(absolute);
    assert(!stat.isSymbolicLink(), 'Unexpected link: ' + relative);
    if (stat.isDirectory()) walk(absolute, relative + '/');
    else {
      assert(stat.isFile(), 'Unexpected file type: ' + relative);
      const bytes = fs.readFileSync(absolute);
      files[relative] = {bytes: bytes.length, sha256: createHash('sha256').update(bytes).digest('hex')};
    }
  }
}
walk(root);
const inventory = {schema: 1, files};
fs.writeFileSync(output, JSON.stringify(inventory, null, 2) + '\n', {flag: 'wx'});
console.log(JSON.stringify({files: Object.keys(files).length, bytes: Object.values(files).reduce((sum, entry) => sum + entry.bytes, 0)}));
