# 품질 산출물 읽기 전용 하위 감사

이 문서는 저장된 보고서·JSON·수집 스크립트의 일관성 감사다. 새 브라우저 실행, 새 시각 검수, 기존 파일 변경, 설치, 전역 설정 변경, 외부 자료 조회는 수행하지 않았다. 기존 이미지 내용도 열지 않았다. 입력 무결성·원래 제품과 복사본 관계는 부모 감사의 범위다.

감사 대상 루트는 `/tmp/lutriva-cycle6-quality-review-8IbTRT`다. 아래 상대 경로는 이 루트를 기준으로 한다. 별도 참고는 `/tmp/lutriva-cycle6-density-recheck-zBDh5Z/REPORT.md`와 `keyboard-recovery/browser.json` 두 파일뿐이다.

## 일치한 주요 주장

- `checks.json`의 배열 자체를 다시 세면 **506개, true 488개, false 18개**다. 파일 머리의 `total/passed/failed`와 보고서 36행에 일치한다. false는 전후×master/compare×세 행의 390px 버튼 포함 조건 12개, release/compare/text200-long320의 M-102/M-103 포함 조건 2개, 전후×master/compare의 초기 390px 오른쪽 wheel 조건 4개다. 이 숫자는 506개의 독립 사용자 시나리오를 뜻하지 않는다. 수집 코드상 28조건×17점검 + 버전별 예외 점검 2개 + 전후 비교 28개 = 506이다.
- `baseline/browser.json`과 `release/browser.json`은 각각 14개의 `cases`를 가진다. 각 버전에서 master/compare × 7조건 = 전체 28조건이다. 조건은 wide 1280×900, narrow390 390×844, narrow320 320×800, long320 320×800+긴 이름, text150-390 390×844+1.5배, text200-long320 320×800+2배+긴 이름, text200-longwide 1280×900+2배+긴 이름이다.
- 28조건의 `originalRows`는 세 원래 주문 데이터와 일치했다. 84개의 `keyboard` 기록에서 `before.active.order`와 선택 결과 `after.detail.text`가 주문 ID에 맞고, 84개 모두 `focusVisible:true` 및 3px outline 문자열이 있다. 모든 조건에서 `reverseTab.active.order`는 M-102, `pointerOutcome.detail.text`는 M-101 선택 문구다. 원시 초기 document/body 폭이 조건 viewport를 넘는 경우도 없었다. 이는 저장된 DOM 관찰 및 입력 스크립트와 일치한다는 뜻이다.
- 모든 전후 대응 조건에서 compare 표 높이는 정확히 64px 감소하고 master는 동일하다. 기본 compare 높이는 288.375→224.375, 기본 행 높이는 76.59375→60.59375다. 버튼 기본 치수 85.5625×43.59375, 200% 치수 143.703125×69.1875와 전후 불변도 기록에 맞는다.
- 기본·recheck·supplement의 여섯 `browser.json` 모두 `browser.product`가 **Chrome/152.0.7977.83**, `revision`은 **@79460ebecaa5625e57a5fb679a735659e73dc687**, `jsVersion`은 **15.2.124.21**이며 `exceptions`는 빈 배열이다. 기본 두 JSON의 `environment`는 Node v26.8.1, darwin이다. 이는 당시 기록 버전 확인이며 현재 설치된 Chrome 버전을 재조회한 결과가 아니다. 일반화된 User-Agent의 HeadlessChrome/152.0.0.0 문자열보다 Browser.getVersion 기록이 보고서의 정확한 버전 근거다.
- `visual-inspection.md`에 나열된 경로는 **27개, 중복 0개**다. baseline 9 + release 12 + recheck-release 3 + supplement-baseline 1 + supplement-release 2 = 27로 보고서와 일치한다. 디렉터리 파일 목록에서도 해당 이름들이 확인된다. 다만 허용 산출물에는 당시 `view_image` 호출 로그가 없으므로 **실제로 직접 열었다는 행위는 목록 작성자의 진술 수준**이다. 이번 감사가 27개 이미지를 새로 열어 확인했다고 해석하면 안 된다.

## 위치 표현과 검사 범위의 한계

1. `REPORT.md:36`의 “확대 후 위 가장자리 조건 2건”은 위치가 모호하다. 두 원시는 `checks.json:10080`, `checks.json:10152`의 release/compare/text200-long320 M-102/M-103이다. `active.right=290.953125 > scroll.right=289`, `scrollLeft=1224`, 최대값 1239다. 반면 top/bottom은 각각 435.1875/504.375, 521.375/590.5625로 800px viewport 내부다. **상단 잘림이라는 의미라면 불일치**이며, “위”가 앞선 발견 사항을 가리킨다면 위치 오기라고 단정할 수 없다. 명확한 요약은 “확대·긴 이름 조건에서 선택 후 오른쪽 가장자리 포함 조건 2건”이다. 보고서 34행의 상세 설명은 오른쪽이라고 정확히 쓴다.
2. `browser-review.mjs:87`의 `visible`은 버튼 사각형과 viewport/표 외곽의 포함 관계를 비교한다. 3px outline의 존재는 확인하지만 offset 2px까지 포함한 전체 외곽선이 항상 다 보이는지 계산하지 않는다. 따라서 488 true를 전체 포커스 외곽선 적합성 통과로 확대할 수 없다. 보고서는 전체 WCAG 판정을 명시적으로 제외하고 있어 이 제한과 충돌하지 않는다.

## 390px 복구의 정확한 입력 경로

기본 네 조건(전후×두 페이지) 모두 Tab으로 M-101에 도달한 뒤 `scrollLeft=0`, 버튼 right=390.703125, 표 외곽 right=374로 기록된다. 선택 동작은 성공한다.

- **compare, baseline/release:** `recheck-*/browser.json`의 `scenario.name=390`에서 `mouseMoved then wheel +40`은 0→30으로 복구한다. 그 다음 `ArrowLeft x5`가 30→0으로 되돌리고 `ArrowRight x5`가 0→30으로 복구한다. 두 파일 모두 151행과 179행에 이 방향키 관찰이 있다. 복구 상태 버튼 right는360.703125, 표 외곽 right는374다. 따라서 compare에서는 방향키로 다시 복구된 상태를 원시 기록이 뒷받침한다.
- **master, baseline/release:** `supplement-*/browser.json:24`의 wheel이 먼저 0→30으로 복구한다. 40행의 `ArrowRight once after selection or wheel`은 이미 복구된 30→30 상태다. 따라서 **master 390px에서 ArrowRight만으로 잘린 상태가 복구됐다는 독립 관찰은 없다.** `recovered:true` 자체가 그 선행 wheel을 제거하지 않는다. 원시 기록이 직접 뒷받침하는 것은 두 페이지·전후 모두 wheel 복구, compare·전후에서 ArrowLeft 후 ArrowRight 복구다.
- `REPORT.md:32`의 “두 페이지 ... wheel 또는 ArrowRight”를 모든 페이지에서 두 방식 각각을 입증했다는 뜻으로 읽으면 범위가 넓다. 보고서 마지막의 “두 페이지의 390px Tab 진입→방향키→Enter/Space”도 master에서는 실제 기록의 wheel 선행 조건을 함께 남겨야 한다.
- 320px 기본/200%+긴 이름의 ArrowLeft/ArrowRight 왕복 재검사 역시 `recheck-input.mjs`가 compare.html로만 이동하므로 **compare 한정**이다. 전체 28조건을 다룬 기본 실행의 master 기록에는 Tab/Shift+Tab/Enter/Space/wheel/포인터가 있지만 방향키 왕복은 없다.

## 200% ArrowRight 성공과 별도 Tab 복구 실패

`supplement-release/browser.json:76`의 `cases[name=compare200-after-selection]`은 보고서 34행의 주장을 직접 지지한다.

| 기록 단계 | scrollLeft / maxScroll | active | activeRight / boxRight |
| --- | --- | --- | --- |
| 첫 행 Tab 포커스 | 1224 / 1224 | M-101 | 290.953125 / 304 |
| 세 번째 행 선택 후 | 1224 / 1239 | M-103 | 290.953125 / 289 |
| ArrowRight 한 번 후 | 1239 / 1239 | M-103 | 275.953125 / 289 |

수집 코드 `supplement.mjs:21`은 이 stress 분기에서 세 행을 키보드로 선택하고, 23~25행에서 ArrowRight 한 번과 300ms 대기를 수행한다. 이 분기에는 wheel 선행이 없다. 결과 선택 문구가 M-103으로 유지되고 `recovered:true`, `rowOutcomeOkay:true`다. 원시 좌표는 오른쪽 외곽선 공간이 다시 확보됐다는 보고와 맞는다. 이미지 자체의 실제 모습은 이번 감사에서 재판정하지 않았다.

별도 `/tmp/lutriva-cycle6-density-recheck-zBDh5Z/keyboard-recovery/browser.json`은 다른 두 조건(original-product/864, product/800)을 기록한다. 두 조건 모두 `before-enter`는338/338 및 버튼·포커스 포함 true, `after-enter`는338/353 및 둘 다 false다. `after-tab`에서 active가 M-102, `after-shift-tab`에서 M-101로 돌아와도338/353과 false가 유지된다. 해당 after-enter/Tab/Shift+Tab 기록은 첫 조건 313/444/599행, 둘째 조건1279/1410/1565행에 있다. 모든 누적 이벤트의 `isTrusted`는 true다. ArrowRight 입력은 이 파일에 없다.

따라서 **Tab→Shift+Tab 복구 시도 실패**와 **320×800·긴 이름·200% 조건에서 ArrowRight 복구 성공**은 모순이 아니다. 입력·데이터·선택 행·일부 viewport 높이가 다르므로 하나로 합쳐 “모든 키보드 복구 성공/실패”라고 쓸 수 없다. 별도 밀도 REPORT.md:44도 `-recovered.png`는 시도 후 파일명이고 복구 성공을 뜻하지 않는다고 명시한다. 품질 보고서의 ArrowRight 성공은 별도 진단의 Tab 실패를 뒤집는 동일 조건 재실행 결과가 아니다.

## 실제 읽기 명령과 검증 방법

다음 명령은 실제 실행한 파일 탐색·보고서·스크립트 읽기 명령이다. 아래 mjs는 **읽기만** 했으며 실행하지 않았다. 모든 명령은 exit 0이었다.

```sh
rg --files /tmp/lutriva-cycle6-quality-review-8IbTRT /tmp/lutriva-cycle6-density-recheck-zBDh5Z
sed -n '1,260p' /tmp/lutriva-cycle6-quality-review-8IbTRT/REPORT.md
sed -n '1,300p' /tmp/lutriva-cycle6-quality-review-8IbTRT/browser-review.mjs
sed -n '1,260p' /tmp/lutriva-cycle6-quality-review-8IbTRT/recheck-input.mjs
sed -n '1,260p' /tmp/lutriva-cycle6-quality-review-8IbTRT/supplement.mjs
sed -n '1,220p' /tmp/lutriva-cycle6-quality-review-8IbTRT/visual-inspection.md
sed -n '1,230p' /tmp/lutriva-cycle6-density-recheck-zBDh5Z/REPORT.md
sed -n '1,270p' /tmp/lutriva-cycle6-quality-review-8IbTRT/summarize-evidence.mjs
sed -n '1,220p' /tmp/lutriva-cycle6-quality-review-8IbTRT/audit-input.mjs
```

추가 `rg -n`으로 위 보고서·JSON·스크립트의 주장 및 입력 분기 행 번호를 찾았다. JSON 읽기는 `node -e` 인라인 프로그램의 `fs.readFileSync`와 JSON.parse로 수행했다. 체크 배열 재집계, false의 사각형 비교, 28조건 원래 데이터/84개 선택/역방향 Tab/포인터 결과, 전후 높이·버튼 치수·스타일 비교, 여섯 버전/예외, 27개 목록 중복, 각 복구 단계의 필드를 집계했다. 이 프로그램들은 브라우저나 수집용 mjs를 호출하지 않았고 파일을 쓰지 않았다.

핵심 집계와 복구 기록을 마지막으로 다시 확인한 실제 명령은 아래와 같다. 결과는 506/488/18, 14+14조건, 여섯 동일 버전·예외 0, 이미지 목록 27·중복 0, 위 표와 동일한 복구 필드였다.

```sh
node -e 'const fs=require("node:fs"),d="/tmp/lutriva-cycle6-quality-review-8IbTRT/",read=p=>JSON.parse(fs.readFileSync(p,"utf8"));const c=read(d+"checks.json");console.log("checks",c.checks.length,c.checks.filter(x=>x.okay===true).length,c.checks.filter(x=>x.okay===false).length);for(const v of ["baseline","release"]){const r=read(d+v+"/browser.json");console.log("conditions",v,r.cases.length);for(const p of [v,"recheck-"+v,"supplement-"+v]){const b=read(d+p+"/browser.json");console.log("browser",p,b.browser.product,b.browser.revision,b.browser.jsVersion,"exceptions",b.exceptions.length);}const r2=read(d+"supplement-"+v+"/browser.json");for(const k of r2.cases)for(const e of k.events)console.log("supplement",v,k.name,e.action,e.state.scrollLeft,e.state.maxScroll,e.state.activeRight,e.state.boxRight);}const names=fs.readFileSync(d+"visual-inspection.md","utf8").split("\n").filter(x=>x.startsWith("- "));console.log("listed-images",names.length,"unique",new Set(names).size);const q=read("/tmp/lutriva-cycle6-density-recheck-zBDh5Z/keyboard-recovery/browser.json");for(const k of q.cases)for(const s of k.stages){const m=s.measurement;console.log("Tab-recovery",k.name,k.height,s.stage,m.active.order,m.scrollLeft,m.scrollMax,m.horizontalButtonFits,m.horizontalFocusFits);}'
```

브라우저 재현·당시 이미지 열람 행위의 독립 인증·전체 접근성 또는 품질 판정 재실행은 이 감사의 결과가 아니다. 저장된 수치의 주요 집계는 일치하며, 보고서 통합 시 위 위치 표현과 입력 경로 범위를 분명히 남기는 것이 필요하다.
