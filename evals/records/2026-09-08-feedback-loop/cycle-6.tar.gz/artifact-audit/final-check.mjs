import { readFile, readdir, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import path from 'node:path';
const root='/tmp/lutriva-cycle6-evidence-audit-KwLk2c';
const before=JSON.parse(await readFile(root+'/protected-before.json','utf8'));
async function files(directory,prefix=''){
  const result={};
  for(const entry of (await readdir(path.join(directory,prefix),{withFileTypes:true})).sort((a,b)=>a.name.localeCompare(b.name))){
    const p=path.join(prefix,entry.name);
    if(entry.isDirectory())Object.assign(result,await files(directory,p));
    else if(entry.isFile()){const b=await readFile(path.join(directory,p));result[p]={bytes:b.length,sha256:createHash('sha256').update(b).digest('hex')};}
    else result[p]={type:entry.isSymbolicLink()?'symlink':'other'};
  }
  return result;
}
const preserved=[];
for(const [directory,expected]of Object.entries(before)){const current=await files(directory);preserved.push({directory,files:Object.keys(current).length,matches:JSON.stringify(expected)===JSON.stringify(current)});}
const parsed=[];
for(const name of await readdir(root))if(name.endsWith('.json')){JSON.parse(await readFile(root+'/'+name,'utf8'));parsed.push(name);}
const result={preserved,allProtectedRootsUnchanged:preserved.every(p=>p.matches),jsonFilesParsed:parsed.length,parsed,phase:'Final read-only artifact verification before handoff. No subsequent output writes by this auditor are planned.'};
await writeFile(root+'/FINAL-CHECK.json',JSON.stringify(result,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify(result));
if(!result.allProtectedRootsUnchanged)process.exitCode=1;
