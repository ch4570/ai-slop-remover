import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
const root='/tmp/lutriva-cycle6-quality-review-8IbTRT';
const output='/tmp/lutriva-cycle6-evidence-audit-KwLk2c';
const json=async file=>JSON.parse(await readFile(file,'utf8'));
const source=await json(root+'/checks.json');
const falseRows=source.checks.filter(row=>row.okay===false);
const sessions=[];
for(const name of ['baseline','release','recheck-baseline','recheck-release','supplement-baseline','supplement-release']){
  const raw=await json(root+'/'+name+'/browser.json');
  sessions.push({name,path:root+'/'+name+'/browser.json',browser:raw.browser,exceptions:raw.exceptions,caseCount:raw.cases?.length,scenarioCount:raw.scenarios?.length,conditions:raw.cases?.filter(c=>c.scenario).map(c=>({route:c.route,scenario:c.scenario,keyboardActions:c.keyboard.map(k=>({order:k.order,key:k.key,selected:k.after.detail.text})),shiftTabActive:c.reverseTab?.active?.order})),supplementEvents:raw.cases?.filter(c=>c.events).map(c=>({name:c.name,events:c.events,recovered:c.recovered,rowOutcomeOkay:c.rowOutcomeOkay})),recheckScenarios:raw.scenarios?.map(s=>({keys:Object.keys(s),name:s.name??s.scenario,events:s.events}))});
}
const text=await readFile(root+'/visual-inspection.md','utf8');
const imagePaths=[...text.matchAll(/^- `([^`]+\.png)`/gm)].map(match=>match[1]);
const images=[];
for(const p of imagePaths){const bytes=await readFile(root+'/'+p);images.push({path:p,bytes:bytes.length,sha256:createHash('sha256').update(bytes).digest('hex'),width:bytes.readUInt32BE(16),height:bytes.readUInt32BE(20)});}
const diagPath='/tmp/lutriva-cycle6-density-recheck-zBDh5Z/keyboard-recovery/browser.json';
const diag=await json(diagPath);
const result={operation:'Read-only inspection of existing artifacts, without opening screenshots or running browser tests.',initialChecks:{reported:{total:source.total,passed:source.passed,failed:source.failed},recounted:{total:source.checks.length,passed:source.checks.filter(c=>c.okay===true).length,failed:falseRows.length,nonBoolean:source.checks.filter(c=>typeof c.okay!=='boolean').length},falseRows,classification:{narrow390Focus:falseRows.filter(c=>c.name.includes('narrow390: focused')).length,narrow390Wheel:falseRows.filter(c=>c.name.includes('narrow390: horizontal wheel')).length,text200Long320Focus:falseRows.filter(c=>c.name.includes('text200-long320: focused')).length}},sessions,listedImages:{count:images.length,unique:new Set(imagePaths).size,images,limit:'The earlier author recorded direct inspection; this audit verifies listed files and metadata only.'},tabShiftTabDiagnostic:{path:diagPath,cases:diag.cases,errors:diag.errors,limits:diag.limits,inputBytesUnchanged:diag.inputBytesUnchanged}};
await writeFile(output+'/density-report-audit.json',JSON.stringify(result,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({checks:result.initialChecks.recounted,classification:result.initialChecks.classification,sessions:sessions.map(s=>({name:s.name,cases:s.caseCount,scenarios:s.scenarioCount,browser:s.browser.product,exceptions:s.exceptions.length})),listedImages:images.length,tabShiftTabCases:diag.cases.length}));
