import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
const root='/tmp/lutriva-cycle6-copy-review-XXqDd0';
const hash=value=>createHash('sha256').update(value).digest('hex');
const raw=JSON.parse(await readFile(root+'/release/browser.json','utf8'));
const check=raw.checks.find(c=>c.name==='export uses saved title while unsaved editor text is retained');
const stored=JSON.parse(check.observed.stored);
const correct=Buffer.from('\ufefftitle\r\n'+stored.map(n=>'"'+n.title.replaceAll('"','""')+'"').join('\r\n'));
const withoutDoubling=Buffer.from('\ufefftitle\r\n'+stored.map(n=>'"'+n.title+'"').join('\r\n'));
const files=[];
for(const product of ['baseline','release']){
  const bytes=await readFile(root+'/'+product+'/downloads/개인 메모.csv');
  files.push({product,bytes:bytes.length,sha256:hash(bytes),text:bytes.toString('utf8'),containsInternalQuotedProject:bytes.toString('utf8').includes('""프로젝트""')});
}
const result={operation:'Existing-artifact inspection only; expected byte hashes are reconstructed from recorded saved notes without running the product.',releaseLastBlobCheck:{name:check.name,result:check.result,storedNotes:stored,editorValue:check.observed.title.value,recordedBlobSha256:check.blobSha256,expectedWithInternalQuotesDoubled:{bytes:correct.length,sha256:hash(correct),text:correct.toString('utf8')},expectedWithoutInternalQuoteDoubling:{bytes:withoutDoubling.length,sha256:hash(withoutDoubling)},recordedHashMatchesDoubled:check.blobSha256===hash(correct),recordedHashMatchesUndoubled:check.blobSha256===hash(withoutDoubling)},downloadedFiles:files,scope:'Internal double-quote doubling is supported by the release-only final Blob assertion, its saved-title record, and its matching Blob hash. Actual downloaded filesystem files are the earlier long-title export and do not test embedded double quotes. The report CSV-preparation row should cite the final release-only check for the escaping claim.'};
await writeFile('/tmp/lutriva-cycle6-evidence-audit-KwLk2c/quote-escaping-audit.json',JSON.stringify(result,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify(result,null,2));
