# 실제 감사 명령

기계 검증은 아래 네 명령으로 실행했다. 이 mjs들은 이번 감사 출력에 새로 작성한 파일 읽기/해시/JSON 집계 스크립트이며, 기존 제품·브라우저 검사 스크립트를 실행하지 않는다. 상세 알고리즘과 입력 경로는 해당 소스에 있다. 마지막 명령의 결과는 `FINAL-CHECK.json`에 있다.

```sh
node /tmp/lutriva-cycle6-evidence-audit-KwLk2c/audit.mjs
node /tmp/lutriva-cycle6-evidence-audit-KwLk2c/density-audit.mjs
node /tmp/lutriva-cycle6-evidence-audit-KwLk2c/quote-evidence.mjs
node /tmp/lutriva-cycle6-evidence-audit-KwLk2c/final-check.mjs
```

새 출력 생성 명령:

```sh
mktemp -d /tmp/lutriva-cycle6-evidence-audit-XXXXXX
```

git 입력 탐색은 다음 명령으로 수행했다. 이후 기계 검증의 commit 파일 목록은 skills와 harness 경로로 한정했다. 최초 목록에 다른 저장소 파일 이름도 출력됐지만 관련 없는 기록 내용을 열거나 판정에 쓰지 않았다.

```sh
git ls-tree -r --name-only 59c22c39ed441bb97252f523bdb03b8f2e67106e
git ls-tree -r --name-only 59c22c39ed441bb97252f523bdb03b8f2e67106e -- skills scripts/browser_harness.mjs
```

두 번째 명령 및 66개 `git show COMMIT:path`의 **실제 argv와 cwd 전체**는 `executed-git-commands.json`에 기록했다. shell 문자열 보간 없이 execFileSync의 argv로 읽었고 git 상태를 바꾸지 않았다.

주요 원문 읽기 명령은 다음과 같다. REPORT와 JSON을 읽은 후 필요한 필드만 Node readFileSync/JSON.parse로 추출해 구조를 확인했다. 초기 큰 JSON 탐색 출력 일부는 잘렸으므로 최종 판정 숫자는 위 감사 스크립트의 전체 파일 읽기 결과를 사용했다.

```sh
sed -n '1,100p' /tmp/lutriva-quality-gate-trial-O6pdDy-frozen.json
sed -n '1,100p' /tmp/lutriva-copy-quality-trial-4lbBdK-frozen.json
sed -n '1,320p' /tmp/lutriva-cycle6-quality-review-8IbTRT/REPORT.md
rg --files /tmp/lutriva-cycle6-quality-review-8IbTRT -g '*.json' -g '*.mjs'
sed -n '1,320p' /tmp/lutriva-cycle6-copy-parent-f5NyMs/check-copy-states.mjs
sed -n '1,260p' /tmp/lutriva-cycle6-parent-notes.md
sed -n '1,300p' /tmp/lutriva-cycle6-copy-review-XXqDd0/REPORT.md
sed -n '1,240p' /tmp/lutriva-cycle6-copy-review-XXqDd0/visual-review.json
sed -n '1,260p' /tmp/lutriva-cycle6-quality-review-8IbTRT/visual-inspection.md
rg -n 'Browser.getVersion|ArrowRight|ArrowLeft|wheel|okay' /tmp/lutriva-cycle6-quality-review-8IbTRT/browser-review.mjs /tmp/lutriva-cycle6-quality-review-8IbTRT/recheck-input.mjs /tmp/lutriva-cycle6-quality-review-8IbTRT/supplement.mjs /tmp/lutriva-cycle6-quality-review-8IbTRT/summarize-evidence.mjs
rg -n 'savedTitle|storedOnly|export uses saved|expectedCSV|keyboard link activation' /tmp/lutriva-cycle6-copy-review-XXqDd0/review.mjs
sed -n '1,340p' /tmp/lutriva-cycle6-evidence-audit-KwLk2c/quality-sub-audit.md
```

하위 감사자의 실제 읽기·원시 집계 명령은 `quality-sub-audit.md` 끝에 별도로 있다. 이번 감사 산출물 작성에는 apply_patch를 사용했으며 기존 제공 입력이나 검수 산출물의 편집 명령은 없다.
