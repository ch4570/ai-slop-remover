# Cycle 6 증거 기록 감사

입력 무결성과 주요 검증 수치는 원시 기록과 일치합니다. 기존 제품 검수의 `pass` 판정은 종료 상태로 유지합니다. 이번 결과는 새 제품 검수나 브라우저 재현이 아니라 기존 산출물의 읽기 전용 감사입니다. 보고서를 통합할 때 입력 경로·버전 관찰 시점·Blob과 실제 다운로드의 범위를 아래처럼 명시해야 합니다. 원본 보고서와 제품은 수정하지 않았습니다.

독립성: 밀도 보고서는 기존 작성자와 다른 감사자가 점검했고, 별도 하위 감사가 수치·입력 경로를 교차 확인했습니다. **문구 보고서는 이 감사자가 이전 과업에서 작성했으므로 자기검토입니다. 독립된 두 번째 제품 판정으로 세면 안 됩니다.** 이번에는 이미지를 열지 않았습니다.

## 고정 입력 및 기준 커밋

| 입력 | frozen 파일 수 | 현재 파일 수·총 크기 | 경로·크기·SHA-256 대조 |
| --- | --- | --- | --- |
| `/tmp/lutriva-quality-gate-trial-O6pdDy` | 83 | 83 / 306,313 bytes | 모두 일치, 누락·추가·변경 0 |
| `/tmp/lutriva-copy-quality-trial-4lbBdK` | 81 | 81 / 312,867 bytes | 모두 일치, 누락·추가·변경 0 |

각 디렉터리 옆의 `-frozen.json` 전체 파일 목록과 현재 파일을 비교했습니다. 양쪽의 `skills/` 65개 및 `harness/browser_harness.mjs` 1개는 커밋 `59c22c39ed441bb97252f523bdb03b8f2e67106e`의 `skills/` 및 `scripts/browser_harness.mjs`와 크기·SHA-256이 일치합니다. `git show`로 해당 커밋의 blob을 읽었으며 현재 worktree 파일과 혼동하지 않았습니다.

두 입력 디렉터리, 두 검수 산출물 디렉터리, parent copy 산출물 디렉터리까지 총 5개 루트의 감사 전후 파일 목록·크기·SHA-256도 동일합니다. 근거는 `frozen-current-comparison.json`, `commit-skill-harness-comparison.json`, `protected-before.json`, `protected-after.json`, `protected-preservation.json`입니다.

## 수치·이미지·버전 기록

| 기록 | 원시 재집계 | 해석 범위 |
| --- | --- | --- |
| 밀도 최초 `checks.json` | 506개 = 488 true + 18 false | 506개의 독립 사용자 과업이 아니라 28조건의 반복 관찰·버전별 예외·전후 비교 합계입니다. 보고서에 18 false가 명시돼 있고 원시값도 그대로 남아 있습니다. |
| 밀도 기본 실행 | baseline 14조건 + release 14조건 = 28 | 두 페이지 × 7조건 × 전후입니다. 각 조건의 세 주문 선택 결과·역방향 Tab·포인터 결과와 보고서가 일치합니다. |
| 밀도 이미지 목록 | 27개, 중복 0 | 기존 작성자의 직접 검사 목록 27개와 파일 존재가 일치합니다. 이번 감사에서 새로 열어 확인하지 않았고 당시 `view_image` 실행행위 자체를 원시 JSON만으로 독립 인증하지 않습니다. |
| 문구 독립 검수 | baseline 16/16, release 22/22, 예외 0 | 공유된 검사 16개에 release 전용 6개가 더 있습니다. 서로 같은 22개 검사를 통과한 비교라고 쓰면 안 됩니다. |
| 문구 이미지 목록 | baseline 캡처13 중 검사목록9, release 캡처16 중 검사목록16 | 보고서와 `visual-review.json`에 일치합니다. 수집 시 `browser.json`의 false는 이후 별도 검사목록과 구분돼 설명되어 있습니다. 검사목록에 없는 baseline 4개를 직접 검토로 세지 않았습니다. |
| parent 문구 검사 | baseline 20/20, release 20/20, collectionErrors 0 | 합성 값/체크박스/DOM click, 320×900 `mobile:true`, 상태·저장 데이터·CSV 문자열·AX 이름의 검사입니다. 독립 검수의 320×800 키 입력·터치 조건과 다릅니다. |

밀도 6세션과 문구 독립 검수 2세션의 기록은 모두 `Chrome/152.0.7977.83`, revision `@79460ebecaa5625e57a5fb679a735659e73dc687`, JS `15.2.124.21`입니다. 이들 수집 스크립트는 **세션 시작 부근에 Browser.getVersion 한 번을 기록**하며 종료 후 버전 재확인 값은 없습니다. 보고서의 실제 실행 버전 표기는 그 범위에서 맞지만 ‘전후 동일 버전 확인’으로 확장하면 안 됩니다. Node `v26.8.1`, darwin 기록도 일치합니다.

parent 문구 20개 검사는 `environment.browser`와 `browserAfter` 둘 다 .83입니다. 별도 Tab/Shift+Tab 진단 역시 각 case의 browserBefore/After 값이 있습니다. 이것을 다른 수집의 종료 버전 확인 근거로 전용하면 안 됩니다. 감사 중 설치된 브라우저나 전역 환경을 재조회하지 않았습니다.

## 밀도 false 18개와 복구 범위

false 18개는 390px의 버튼 포함 조건 12개, 초기 390px wheel 조건 4개, release compare 320px·200%·긴 이름에서 M-102/M-103 포함 조건 2개입니다. 나중의 성공 관찰로 최초 false를 덮어쓰지 않았습니다.

보고서의 ‘확대 후 위 가장자리 조건 2건’은 ‘위’가 앞서 설명한 사항을 가리킬 수 있어 방향 사실오류로 단정하지 않습니다. 다만 원시 좌표는 `active.right=290.953125 > scroll.right=289`이며 top/bottom은 화면 안에 있습니다. 통합 문구는 **‘확대·긴 이름 조건에서 선택 후 오른쪽 가장자리 포함 조건 2건’**으로 쓰는 편이 명확합니다. 같은 보고서의 자세한 발견 사항은 이미 오른쪽을 정확히 설명합니다.

| 경로 | 실제 원시 변화 | 지원되는 주장 |
| --- | --- | --- |
| compare 390px, 전후 recheck | wheel 0→30, ArrowLeft 5회 30→0, ArrowRight 5회 0→30 | compare는 방향키로 다시 오른쪽 작업 열에 접근한 기록이 있습니다. |
| master 390px, 전후 supplement | wheel 0→30, 이후 ArrowRight 30→30 | wheel 복구는 확인됐습니다. 잘린 상태에서 ArrowRight만 보낸 효과는 분리되지 않았습니다. |
| release compare 320×800, 200%·긴 이름 supplement | 세 번째 행 선택 후1224/1239, 선행 wheel 없이 ArrowRight 한 번 뒤1239/1239 | 해당 조건의 ArrowRight 복구 주장이 직접 뒷받침됩니다. |
| 별도 density 진단 Tab→Shift+Tab | original/864, candidate/800 둘 다 선택 후338/353, Tab 뒤338/353, Shift+Tab 뒤338/353 | 이 경로는 복구에 실패했습니다. ArrowRight 입력을 검사한 파일은 아닙니다. |

따라서 ‘모든 키보드 복구가 성공/실패했다’는 요약은 지원되지 않습니다. 320px 일반/200%·긴 이름의 방향키 왕복 recheck도 compare 한정입니다. master는 기본 Tab·Shift+Tab·선택·wheel·포인터 검사가 있습니다. 제품 데이터·긴 이름·선택 행·일부 높이가 다른 별도 진단의 픽셀 수치를 동일 조건의 전후 비교로 섞으면 안 됩니다.

자동 `visible`은 버튼 box 포함을 검사하며 outline 3px의 존재를 별도로 관찰합니다. offset 2px까지 더한 전체 포커스 외곽선 포함을 자동 판정한 것은 아닙니다. 488 true를 전체 접근성 통과로 해석할 수 없다는 보고서의 한계와 맞습니다. 자세한 raw 경로·필드·행 번호는 `quality-sub-audit.md`, 추출값은 `density-report-audit.json`에 있습니다.

## 문구 검사와 실제 다운로드 구분

parent 20개 검사의 스크립트는 제목 `.value`·실패 `.checked`를 합성으로 설정하고 `.click()`을 호출합니다. 준비된 다운로드 링크는 누르지 않았습니다. CSV는 Blob URL을 `fetch(...).then(response => response.text())`로 읽고 BOM을 제거한 문자열과 비교합니다. 이 결과는 실제 다운로드 파일이나 BOM을 포함한 원본 바이트 동일성 검사가 아닙니다. 양쪽 기존 문구와 수정 문구가 모두 20개 상태 검사를 통과한 사실도 의미 정확성 점수로 바꾸지 않았습니다.

문구 독립 검수는 링크 Enter 입력 뒤 출력 안의 실제 `downloads/개인 메모.csv`를 읽는 별도 검사를 포함합니다. 두 파일 모두 현재 168 bytes, SHA-256 `4cd715a7864f9666193242193f6190dc5f403c24a24b45bf2360fad49ea7c495`이며 당시 JSON의 바이트·해시와 일치합니다. 두 파일은 내부 큰따옴표가 없는 긴 제목의 CSV입니다. 따라서 **이 실제 다운로드 파일로 내부 quote doubling까지 확인했다고 쓰면 안 됩니다.**

내부 큰따옴표 처리는 release 전용 마지막 Blob 검사에서 별도로 실행됐습니다. `review.mjs:235` 이후 `수요일 "프로젝트" 회의, 준비물 확인`을 다시 저장하고, 편집값만 다른 값으로 바꾼 후 CSV Blob 바이트와 기대 바이트를 비교합니다. `release/browser.json`의 마지막 `export uses saved title while unsaved editor text is retained`에 그 저장 제목과 Blob 해시가 남아 있습니다.

이번 감사에서 기록된 저장 제목으로 기대 바이트를 재구성한 결과, 내부 큰따옴표를 두 번 쓴 84 bytes의 SHA-256 `9023c175170d6d4d7dc3bc20b91db8b654b7429b4e03bb14165c92fafc466477`가 기록된 Blob 해시와 일치했습니다. 두 번 쓰지 않은 82 bytes 해시는 일치하지 않았습니다. 이는 **release Blob 검증의 근거**이며 다운로드 파일 검증과 다릅니다. 문구 보고서의 CSV 준비 행은 현재 첫 longTitle 검사 이름만 인용하므로, 통합 시 내부 따옴표 설명에는 이 마지막 release 전용 검사 이름도 연결해야 합니다. 원본 보고서는 그대로 두었습니다.

문구 release 전용 6개는 빈 제목 required 검증, 150% 글자 폭, 200% 글자 폭, 200% 다운로드 키보드 접근, 영어 버튼 값, 미저장 편집과 저장된 CSV 값의 구분입니다. 따라서 baseline16/release22와 parent20을 하나의 같은 검사 수로 합치지 않습니다.

## 한계와 산출물

이번 감사는 파일·스크립트·JSON·목록·저장된 다운로드를 읽었습니다. 제품 테스트 스크립트, Chrome, 설치 도구, 전역 설정을 실행하거나 변경하지 않았습니다. 사용자 프로필·외부 서비스·배포·커밋·푸시는 범위 밖이며 수행하지 않았습니다. 원본 제품 판정, 당시 이미지의 실제 모습, 물리적 입력·스크린리더·전체 접근성은 새로 판정하지 않았습니다.

- 감사 보고서: `/tmp/lutriva-cycle6-evidence-audit-KwLk2c/REVIEW.md`
- 핵심 요약: `/tmp/lutriva-cycle6-evidence-audit-KwLk2c/summary.json`
- 입력/frozen 비교: `/tmp/lutriva-cycle6-evidence-audit-KwLk2c/frozen-current-comparison.json`
- 커밋 비교: `/tmp/lutriva-cycle6-evidence-audit-KwLk2c/commit-skill-harness-comparison.json`
- 밀도 기록 감사: `/tmp/lutriva-cycle6-evidence-audit-KwLk2c/density-report-audit.json`, `quality-sub-audit.md`
- 문구 자기검토: `/tmp/lutriva-cycle6-evidence-audit-KwLk2c/copy-report-audit.json`
- parent20 구분: `/tmp/lutriva-cycle6-evidence-audit-KwLk2c/parent20-audit.json`
- 따옴표/다운로드 범위: `/tmp/lutriva-cycle6-evidence-audit-KwLk2c/quote-escaping-audit.json`
- 감사 전후 보존: `/tmp/lutriva-cycle6-evidence-audit-KwLk2c/protected-preservation.json`
- 실제 검증 명령 및 읽기 범위: `/tmp/lutriva-cycle6-evidence-audit-KwLk2c/COMMANDS.md`, `executed-git-commands.json`
