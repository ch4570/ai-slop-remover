import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { readFile, readdir, writeFile, lstat } from 'node:fs/promises';
import path from 'node:path';

const output='/tmp/lutriva-cycle6-evidence-audit-KwLk2c';
const repo='/Users/rex/Desktop/personal/lutriva';
const commit='59c22c39ed441bb97252f523bdb03b8f2e67106e';
const inputRoots=['/tmp/lutriva-quality-gate-trial-O6pdDy','/tmp/lutriva-copy-quality-trial-4lbBdK'];
const reviewRoots=['/tmp/lutriva-cycle6-quality-review-8IbTRT','/tmp/lutriva-cycle6-copy-review-XXqDd0','/tmp/lutriva-cycle6-copy-parent-f5NyMs'];
const commands=[];
const digest=bytes=>({bytes:bytes.length,sha256:createHash('sha256').update(bytes).digest('hex')});
const readJSON=async file=>JSON.parse(await readFile(file,'utf8'));
const writeJSON=(name,value)=>writeFile(path.join(output,name),JSON.stringify(value,null,2)+'\n',{flag:'wx'});
async function inventory(root,prefix=''){
  const files={};
  for(const entry of (await readdir(path.join(root,prefix),{withFileTypes:true})).sort((a,b)=>a.name.localeCompare(b.name))){
    const relative=path.join(prefix,entry.name);
    if(entry.isDirectory())Object.assign(files,await inventory(root,relative));
    else if(entry.isFile())files[relative]=digest(await readFile(path.join(root,relative)));
    else files[relative]={type:entry.isSymbolicLink()?'symlink':'other'};
  }
  return files;
}
function compare(expected,actual){
  const missing=Object.keys(expected).filter(p=>!Object.hasOwn(actual,p));
  const extra=Object.keys(actual).filter(p=>!Object.hasOwn(expected,p));
  const changed=Object.keys(expected).filter(p=>Object.hasOwn(actual,p)&&(expected[p].bytes!==actual[p].bytes||expected[p].sha256!==actual[p].sha256)).map(p=>({path:p,expected:expected[p],actual:actual[p]}));
  return {matches:!missing.length&&!extra.length&&!changed.length,expectedFiles:Object.keys(expected).length,actualFiles:Object.keys(actual).length,actualBytes:Object.values(actual).reduce((sum,file)=>sum+(file.bytes||0),0),missing,extra,changed};
}
const protectedBefore={};
for(const root of [...inputRoots,...reviewRoots])protectedBefore[root]=await inventory(root);
await writeJSON('protected-before.json',protectedBefore);

const frozenResults=[];
for(const root of inputRoots){
  const frozenPath=root+'-frozen.json';
  const frozen=await readJSON(frozenPath);
  frozenResults.push({root,frozenPath,frozenFile:digest(await readFile(frozenPath)),schema:frozen.schema,declaredCommit:frozen.baseline_commit??frozen.skill_and_harness_commit,...compare(frozen.files,protectedBefore[root]),current:protectedBefore[root]});
}
await writeJSON('frozen-current-comparison.json',frozenResults);
function git(args){commands.push({executable:'git',args,cwd:repo});return execFileSync('git',args,{cwd:repo,maxBuffer:20*1024*1024});}
const sourcePaths=git(['ls-tree','-r','--name-only',commit,'--','skills','scripts/browser_harness.mjs']).toString('utf8').trim().split('\n');
const source={};
for(const p of sourcePaths)source[p]=digest(git(['show',commit+':'+p]));
const commitResults=inputRoots.map(root=>{
  const expected={};
  for(const [p,hash]of Object.entries(source))expected[p.startsWith('skills/')?p:'harness/browser_harness.mjs']=hash;
  const actual=Object.fromEntries(Object.entries(protectedBefore[root]).filter(([p])=>p.startsWith('skills/')||p.startsWith('harness/')));
  return {root,commit,skillFiles:sourcePaths.filter(p=>p.startsWith('skills/')).length,harnessFiles:sourcePaths.filter(p=>p==='scripts/browser_harness.mjs').length,harnessMapping:{input:'harness/browser_harness.mjs',git:'scripts/browser_harness.mjs'},...compare(expected,actual),source,actual};
});
await writeJSON('commit-skill-harness-comparison.json',commitResults);

const copyRoot=reviewRoots[1],parentRoot=reviewRoots[2];
const visual=await readJSON(path.join(copyRoot,'visual-review.json'));
const copy=[];
for(const product of ['baseline','release']){
  const raw=await readJSON(path.join(copyRoot,product,'browser.json'));
  const inspections=visual[product+'Inspected'];
  const screenshots=await Promise.all(raw.screenshots.map(async shot=>{
    const bytes=await readFile(path.join(copyRoot,product,shot.name));
    return {name:shot.name,collectionTimeVisuallyInspected:shot.visuallyInspected,laterInspectionListed:inspections.includes(product+'/'+shot.name),pngSignature:bytes.subarray(0,8).toString('hex'),width:bytes.readUInt32BE(16),height:bytes.readUInt32BE(20),...digest(bytes)};
  }));
  const downloaded=raw.checks.find(check=>check.name==='keyboard link activation downloads matching CSV to isolated directory');
  const actualDownload=digest(await readFile(downloaded.path));
  copy.push({product,checks:raw.checks.length,pass:raw.checks.filter(c=>c.result==='pass').length,other:raw.checks.filter(c=>c.result!=='pass'),completed:raw.completed,browser:raw.browser,runtimeExceptions:raw.runtimeExceptions,names:raw.checks.map(c=>c.name),captured:screenshots.length,declaredInspected:inspections.length,unlistedCaptures:screenshots.filter(s=>!s.laterInspectionListed).map(s=>s.name),invalidListedImages:inspections.filter(p=>!raw.screenshots.some(s=>product+'/'+s.name===p)),screenshots,download:{recorded:downloaded,actual:actualDownload,matches:downloaded.bytes===actualDownload.bytes&&downloaded.sha256===actualDownload.sha256},viewports:[...new Set(raw.screenshots.map(s=>JSON.stringify(s.observed.viewport)))].map(v=>JSON.parse(v))});
}
const releaseOnly=copy[1].names.filter(name=>!copy[0].names.includes(name));
const baselineOnly=copy[0].names.filter(name=>!copy[1].names.includes(name));
const copySource=await readFile(path.join(copyRoot,'review.mjs'),'utf8');
await writeJSON('copy-report-audit.json',{reviewerRelationship:'self-review: this auditor authored the copy report in the previous completed task; not an independent second opinion',browserObservation:'Browser.getVersion called once near the start of each collection; there is no after-run browser-version value in these two raw browser.json records.',sourceBrowserVersionCalls:copySource.split('\n').map((line,index)=>({line:index+1,text:line})).filter(row=>row.text.includes('Browser.getVersion')),copy,sharedChecks:copy[0].names.filter(name=>copy[1].names.includes(name)).length,releaseOnly,baselineOnly,visualEvidenceBoundary:'Artifact inspection only in this audit. The named earlier inspection record and PNG files are present; this audit does not independently recreate or certify the prior act of visual inspection.'});

const parent=[];
for(const product of ['baseline','release']){
  const raw=await readJSON(path.join(parentRoot,product,'browser.json'));
  parent.push({product,environment:raw.environment,checks:raw.checks.length,pass:raw.checks.filter(c=>c.status==='pass').length,fail:raw.checks.filter(c=>c.status==='fail'),collectionErrors:raw.collectionErrors,limits:raw.limits,names:raw.checks.map(c=>c.id),semanticExamples:{savePending:raw.states.savePending.save.status,saveSuccess:raw.states.saveSucceeded.save.status,exportReady:raw.states.exportReady.export.status},preparedLink:raw.checks.find(c=>c.id==='prepared-link-not-clicked'),preparedCSV:raw.checks.find(c=>c.id==='prepared-csv-has-saved-notes')});
}
const parentSource=await readFile(path.join(parentRoot,'check-copy-states.mjs'),'utf8');
await writeJSON('parent20-audit.json',{parent,sourceEvidence:parentSource.split('\n').map((line,index)=>({line:index+1,text:line})).filter(row=>/Emulation.setDeviceMetricsOverride|\.value =|\.checked =|\.click\(\)|prepared-link-not-clicked|const csv =|Browser.getVersion|No download link/.test(row.text)),scope:'Both 20-check sets use synthetic DOM values/checkbox settings/clicks and 320x900 mobile:true emulation. They fetch the prepared Blob with response.text(); neither activates the download link nor verifies a downloaded filesystem artifact. This is separate from the blind copy review with baseline16/release22 and an isolated filesystem download.'});

const protectedAfter={};
for(const root of [...inputRoots,...reviewRoots])protectedAfter[root]=await inventory(root);
await writeJSON('protected-after.json',protectedAfter);
const preservation=Object.keys(protectedBefore).map(root=>({root,...compare(protectedBefore[root],protectedAfter[root])}));
await writeJSON('protected-preservation.json',preservation);
await writeJSON('executed-git-commands.json',commands);
await writeJSON('summary.json',{operation:'Read-only artifact audit; no browser/product script execution',frozen:frozenResults.map(({root,matches,expectedFiles,actualFiles,actualBytes,missing,extra,changed})=>({root,matches,expectedFiles,actualFiles,actualBytes,missing,extra,changed})),commit:commitResults.map(({root,matches,skillFiles,harnessFiles})=>({root,matches,skillFiles,harnessFiles})),copy:copy.map(({product,checks,pass,captured,declaredInspected,browser,download})=>({product,checks,pass,captured,declaredInspected,browser:browser.product,downloadMatches:download.matches})),parent:parent.map(({product,checks,pass,environment})=>({product,checks,pass,environment})),protectedRootsUnchanged:preservation.every(item=>item.matches)});
console.log(JSON.stringify(await readJSON(path.join(output,'summary.json')),null,2));
