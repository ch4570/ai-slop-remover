import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';

const [root, output, commit, repo] = process.argv.slice(2);
assert(root && output && /^[0-9a-f]{7,40}$/.test(commit) && repo,
  'Usage: node freeze.mjs ROOT NEW_INVENTORY SKILL_TOOL_COMMIT REPOSITORY');
const files = {}, hash = bytes => createHash('sha256').update(bytes).digest('hex');
const walk = (directory, prefix = '') => {
  for (const name of fs.readdirSync(directory).sort()) {
    const absolute = path.join(directory, name), relative = prefix + name, stat = fs.lstatSync(absolute);
    assert(!stat.isSymbolicLink(), 'Unexpected link: ' + relative);
    if (stat.isDirectory()) walk(absolute, relative + '/');
    else {
      assert(stat.isFile(), 'Unexpected type: ' + relative);
      const bytes = fs.readFileSync(absolute);
      files[relative] = { bytes: bytes.length, sha256: hash(bytes) };
      if (relative.startsWith('skills/') || relative.startsWith('harness/')) {
        const source = relative.startsWith('harness/') ? 'scripts/browser_harness.mjs' : relative;
        assert.equal(hash(execFileSync('git', ['show', commit + ':' + source], {cwd: repo})), files[relative].sha256, source);
      }
    }
  }
};
walk(root);
const inventory = { schema: 1, skill_and_harness_commit: commit, files };
fs.writeFileSync(output, JSON.stringify(inventory, null, 2) + '\n', {flag:'wx'});
console.log(JSON.stringify({ files: Object.keys(files).length, skills: Object.keys(files).filter(name => name.startsWith('skills/')).length, skillAndHarnessCommit: commit, verified: true }));
