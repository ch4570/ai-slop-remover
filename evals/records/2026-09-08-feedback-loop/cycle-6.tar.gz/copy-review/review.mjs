import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { mkdir, readFile, readdir, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { withBrowser, claimBrowserEvidence } from '/tmp/lutriva-copy-quality-trial-4lbBdK/harness/browser_harness.mjs';

const input = '/tmp/lutriva-copy-quality-trial-4lbBdK';
const output = '/tmp/lutriva-cycle6-copy-review-XXqDd0';
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const json = (name, value) => writeFile(path.join(output, name), JSON.stringify(value, null, 2) + '\n', { flag: 'wx' });
async function inventory(directory, prefix = '') {
  const files = [];
  for (const entry of (await readdir(directory, { withFileTypes: true })).sort((a,b) => a.name.localeCompare(b.name))) {
    const relative = path.join(prefix, entry.name);
    if (entry.isDirectory()) files.push(...await inventory(path.join(directory, entry.name), relative));
    else if (entry.isFile()) {
      const bytes = await readFile(path.join(directory, entry.name));
      files.push({ path: relative, bytes: bytes.length, sha256: sha(bytes) });
    } else throw new Error('Unexpected input entry: ' + relative);
  }
  return files;
}

const allowed = ['save_action','save_pending','save_success','save_failed','export_action','export_pending','export_ready','export_failed','download_action'];
const ko = JSON.parse(await readFile(path.join(input, 'release/locales/ko.json'), 'utf8'));
const before = await inventory(input);
await json('input-before.json', before);
const base = await inventory(path.join(input, 'baseline'));
const candidate = await inventory(path.join(input, 'release'));
assert.deepEqual(base.map(file => file.path), candidate.map(file => file.path));
const changedFiles = base.filter((file,i) => file.sha256 !== candidate[i].sha256).map(file => file.path);
assert.deepEqual(changedFiles, ['locales/ko.json']);
const baselineCopy = JSON.parse(await readFile(path.join(input, 'baseline/locales/ko.json'), 'utf8'));
assert.deepEqual(Object.keys(ko), Object.keys(baselineCopy));
const changedKeys = Object.keys(ko).filter(key => ko[key] !== baselineCopy[key]);
assert.deepEqual(changedKeys, allowed);
const variables = text => [...text.matchAll(/\{(\w+)\}/g)].map(match => match[1]).sort();
for (const key of Object.keys(ko)) {
  assert.equal(typeof ko[key], 'string');
  assert.deepEqual(variables(ko[key]), variables(baselineCopy[key]));
}
await json('static-scope.json', { node: process.version, platform: process.platform, arch: process.arch, changedFiles, changedKeys, placeholdersPreserved: true, otherFilesByteIdentical: true, fileManifests: { baseline: base, release: candidate } });
await mkdir(path.join(output, 'profiles'));
process.env.TMPDIR = path.join(output, 'profiles');

const longTitle = '다음 주 가족 여행 준비와 회의 일정 확인을 위한 아주 긴 한국어 메모 제목 및 챙겨야 할 준비물 목록';
const savedTitle = '수요일 "프로젝트" 회의, 준비물 확인';
const notes = [{id:1,title:'주말 장보기'},{id:2,title:'다음 주 일정'}];
const expectedCSV = title => '\ufefftitle\r\n"' + title.replaceAll('"','""') + '"\r\n"다음 주 일정"';
const render = (copy,key,values={}) => copy[key].replace(/\{(\w+)\}/g, (token,name) => String(values[name] ?? token));

async function run(product, complete) {
  const runOutput = path.join(output, product);
  await mkdir(runOutput);
  await claimBrowserEvidence(runOutput, []);
  const downloadPath = path.join(runOutput, 'downloads');
  await mkdir(downloadPath);
  const copy = product === 'baseline' ? baselineCopy : ko;
  const observations = { product, screenshots: [], checks: [], prep: [
    'Isolated Chrome profile under output/profiles; loopback server serves original product files.',
    'Synthetic two-note localStorage seed via Runtime.evaluate; product DOM values remain unmodified except checkbox and explicit form-input preparation stated per check.',
    'Input.insertText and provided pressKey helper perform ordinary form entry and keyboard activation.',
    'Download directory explicitly restricted to this run output/downloads.',
    'For pending images only, hold the existing 120ms timer in memory with a temporary wrapper; product source remains unchanged.'
  ] };
  try {
    await withBrowser(path.join(input, product), runOutput, async c => {
      observations.browser = await c.call('Browser.getVersion');
      await c.call('Browser.setDownloadBehavior', { behavior: 'allow', downloadPath });
      const wait = async expression => {
        for(let i=0;i<150;i++) { if (await c.evaluate(expression)) return; await c.pause(20); }
        throw new Error('Timed out: ' + expression);
      };
      const state = async () => c.evaluate(`(() => {
        const ids=['title','save','save-status','export','export-status','download'];
        const result={viewport:{width:innerWidth,height:innerHeight},scroll:{x:scrollX,y:scrollY},documentWidth:document.documentElement.scrollWidth,focus:document.activeElement?.id,stored:localStorage.getItem('daon-draft-notes')};
        for(const id of ids){const e=document.getElementById(id),r=e.getBoundingClientRect(),s=getComputedStyle(e);result[id]={text:e.textContent,value:e.value,disabled:e.disabled,hidden:e.hidden,state:e.dataset.state,href:e.getAttribute('href'),download:e.getAttribute('download'),rect:{x:r.x,y:r.y,width:r.width,height:r.height,bottom:r.bottom,right:r.right},fontSize:s.fontSize,scrollWidth:e.scrollWidth,clientWidth:e.clientWidth};}
        return result;
      })()`);
      const check = async (name, assertion, detail) => { const observed=await state(); assertion(observed); observations.checks.push({name,result:'pass',...(detail?{detail}:{}),observed}); return observed; };
      const capture = async name => { await c.screenshot(name, {captureBeyondViewport:false}); observations.screenshots.push({name,observed:await state(),visuallyInspected:false}); };
      const navigate = async (query='') => {
        await c.page('Page.navigate', {url:c.origin+'/index.html'+query});
        await wait("document.documentElement.dataset.ready === 'true'");
      };
      const focus = async id => { await c.evaluate(`document.getElementById(${JSON.stringify(id)}).focus()`); };
      const type = async value => { await focus('title'); await c.evaluate("document.getElementById('title').select()"); await c.page('Input.insertText',{text:value}); };
      const activate = async id => { await focus(id); await c.pressKey('Enter'); };
      const toggle = async id => { await focus(id); await c.pressKey('Space'); };
      const hold = async () => c.evaluate("window.__nativeTimeout=window.setTimeout;window.__pending=[];window.setTimeout=(fn,ms,...args)=>ms===120?(window.__pending.push(()=>fn(...args)),-1):window.__nativeTimeout(fn,ms,...args)");
      const release = async () => c.evaluate("window.setTimeout=window.__nativeTimeout;window.__pending.splice(0).forEach(fn=>fn())");
      const settle = async (area,expected) => wait(`document.getElementById('${area}-status').dataset.state === '${expected}'`);
      const tap = async id => {
        await c.evaluate(`document.getElementById('${id}').scrollIntoView({block:'center'})`);
        const rect = await c.evaluate(`(() => {const r=document.getElementById('${id}').getBoundingClientRect();return {x:r.x+r.width/2,y:r.y+r.height/2};})()`);
        await c.page('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{x:rect.x,y:rect.y}]});
        await c.page('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});
      };
      await navigate();
      await c.evaluate(`localStorage.setItem('daon-draft-notes',${JSON.stringify(JSON.stringify(notes))})`);
      await navigate();
      await capture('01-wide-idle.png');
      await type(savedTitle);
      await hold();
      await activate('save');
      await settle('save','pending');
      await check('save pending retains old stored data and disables title/save',s => {
        assert.equal(s['save-status'].text,render(copy,'save_pending',{title:savedTitle}));
        assert.equal(s.title.disabled,true);assert.equal(s.save.disabled,true);assert.deepEqual(JSON.parse(s.stored),notes);
      },'Existing pause intercepted in temporary page memory for observation.');
      await capture('02-wide-save-pending.png');
      await release();
      await settle('save','success');
      await check('save success changes first note only',s=>{
        assert.equal(s['save-status'].text,render(copy,'save_success',{title:savedTitle}));
        assert.deepEqual(JSON.parse(s.stored),[{id:1,title:savedTitle},notes[1]]);assert.equal(s.title.disabled,false);assert.equal(s.save.disabled,false);
      });
      await capture('03-wide-save-success.png');
      await navigate();
      await check('saved title survives same-profile page reload',s=>assert.equal(s.title.value,savedTitle));
      await type(longTitle);
      await toggle('fail-save');
      await activate('save');
      await settle('save','error');
      await check('failed save preserves editable draft and old stored record',s=>{
        assert.equal(s['save-status'].text,render(copy,'save_failed',{title:longTitle}));
        assert.equal(s.title.value,longTitle);assert.equal(s.title.disabled,false);assert.equal(s.save.disabled,false);assert.equal(JSON.parse(s.stored)[0].title,savedTitle);
      },'Failure checkbox activated with provided Space helper; unclassified supplied synthetic failure.');
      await capture('04-wide-save-failed-long.png');
      await toggle('fail-save');
      await activate('save');
      await settle('save','success');
      await check('save retry succeeds and retains second note',s=>assert.deepEqual(JSON.parse(s.stored),[{id:1,title:longTitle},notes[1]]));
      await hold();
      await activate('export');
      await settle('export','pending');
      await check('export pending has correct count and no download link',s=>{assert.equal(s['export-status'].text,render(copy,'export_pending',{count:2,filename:'개인 메모.csv'}));assert.equal(s.export.disabled,true);assert.equal(s.download.hidden,true);assert.equal(s.download.href,null);});
      await capture('05-wide-export-pending.png');
      await release();
      await settle('export','ready');
      await check('export ready provides named Blob download without file creation',s=>{assert.equal(s['export-status'].text,render(copy,'export_ready',{filename:'개인 메모.csv',count:2}));assert.equal(s.download.text,render(copy,'download_action',{filename:'개인 메모.csv',count:2}));assert.equal(s.download.hidden,false);assert.equal(s.download.download,'개인 메모.csv');assert.match(s.download.href,/^blob:/);});
      const blob = await c.evaluate("(async()=>Array.from(new Uint8Array(await (await fetch(document.getElementById('download').href)).arrayBuffer())))()");
      assert.deepEqual(Buffer.from(blob),Buffer.from(expectedCSV(longTitle)));
      observations.checks.push({name:'ready Blob has UTF-8 BOM and both stored titles',result:'pass',bytes:blob.length,sha256:sha(Buffer.from(blob))});
      assert.deepEqual(await readdir(downloadPath),[]);
      observations.checks.push({name:'no file downloaded before link activation',result:'pass',downloadDirectory:downloadPath});
      await capture('06-wide-export-ready.png');
      await activate('download');
      let files=[];
      for(let i=0;i<150;i++){files=await readdir(downloadPath);if(files.includes('개인 메모.csv')&&!files.some(name=>name.endsWith('.crdownload')))break;await c.pause(20);}
      assert.deepEqual(files,['개인 메모.csv']);
      const downloaded=await readFile(path.join(downloadPath,'개인 메모.csv'));
      assert.deepEqual(downloaded,Buffer.from(expectedCSV(longTitle)));
      observations.checks.push({name:'keyboard link activation downloads matching CSV to isolated directory',result:'pass',path:path.join(downloadPath,'개인 메모.csv'),bytes:downloaded.length,sha256:sha(downloaded)});
      await toggle('fail-export');
      await activate('export');
      await settle('export','error');
      await check('export failure ends pending and removes prior link',s=>{assert.equal(s['export-status'].text,render(copy,'export_failed',{filename:'개인 메모.csv',count:2}));assert.equal(s.export.disabled,false);assert.equal(s.download.hidden,true);assert.equal(s.download.href,null);});
      await capture('07-wide-export-failed.png');
      await toggle('fail-export');
      await activate('export');
      await settle('export','ready');
      await check('export retry returns ready link',s=>{assert.equal(s.download.hidden,false);assert.match(s.download.href,/^blob:/);});

      await c.page('Emulation.setDeviceMetricsOverride',{width:320,height:800,deviceScaleFactor:1,mobile:false});
      await c.page('Emulation.setTouchEmulationEnabled',{enabled:true,maxTouchPoints:1});
      await c.evaluate('scrollTo(0,0)');
      await hold();
      await tap('save');
      await settle('save','pending');
      await capture('08-narrow-save-pending-long.png');
      await release();
      await settle('save','success');
      await c.evaluate('scrollTo(0,0)');
      await capture('09-narrow-save-success-long.png');
      await toggle('fail-save');
      await tap('save');
      await settle('save','error');
      await c.evaluate('scrollTo(0,0)');
      await capture('10-narrow-save-failed-long.png');
      await check('320px long-title save error wraps within viewport',s=>{assert.ok(s.documentWidth<=320);assert.ok(s['save-status'].rect.right<=320);assert.equal(s.title.value,longTitle);assert.equal(s.save.disabled,false);});
      await toggle('fail-save');
      await tap('save');
      await settle('save','success');
      await check('narrow touch save retry stores long title',s=>assert.equal(JSON.parse(s.stored)[0].title,longTitle));
      await c.evaluate("document.getElementById('export').scrollIntoView({block:'center'})");
      await hold();
      await tap('export');
      await settle('export','pending');
      await capture('11-narrow-export-pending.png');
      await release();
      await settle('export','ready');
      await c.evaluate("document.getElementById('download').scrollIntoView({block:'center'})");
      await focus('download');
      await c.pressKey('Tab',{shift:true});
      await c.pressKey('Tab');
      await check('narrow keyboard reaches visible download link',s=>{assert.equal(s.focus,'download');assert.ok(s.download.rect.x>=0&&s.download.rect.right<=320);assert.ok(s.download.rect.y>=0&&s.download.rect.bottom<=800);});
      await capture('12-narrow-export-ready-focused.png');
      await toggle('fail-export');
      await tap('export');
      await settle('export','error');
      await capture('13-narrow-export-failed.png');
      await toggle('fail-export');
      await tap('export');
      await settle('export','ready');
      await check('narrow touch export retry restores link',s=>assert.equal(s.download.hidden,false));

      if(complete){
        await type('');
        await activate('save');
        await c.pause(180);
        const invalid=await c.evaluate("({valid:document.getElementById('title').checkValidity(),message:document.getElementById('title').validationMessage,focus:document.activeElement.id,state:document.getElementById('save-status').dataset.state,stored:localStorage.getItem('daon-draft-notes')})");
        assert.equal(invalid.valid,false);assert.equal(invalid.focus,'title');assert.equal(JSON.parse(invalid.stored)[0].title,longTitle);
        observations.checks.push({name:'empty title uses existing required validation and does not write',result:'pass',observed:invalid});
        await type(longTitle);
        await c.page('Page.setFontSizes',{fontSizes:{standard:24}});
        await c.pause(100);
        await toggle('fail-save');await activate('save');await settle('save','error');
        await c.evaluate("document.getElementById('save').scrollIntoView({block:'start'})");
        await capture('14-narrow-text150-save-error.png');
        await check('150% browser default font keeps changed copy within page width',s=>{assert.ok(s.documentWidth<=320);assert.equal(s['save-status'].fontSize,'24px');});
        await c.page('Page.setFontSizes',{fontSizes:{standard:32}});await c.pause(100);
        await c.evaluate("document.getElementById('save').scrollIntoView({block:'start'})");
        await capture('15-narrow-text200-save-error.png');
        await check('200% browser default font keeps changed copy within page width',s=>{assert.ok(s.documentWidth<=320);assert.equal(s['save-status'].fontSize,'32px');});
        await c.evaluate("document.getElementById('download').scrollIntoView({block:'center'})");
        await focus('download');await c.pressKey('Tab',{shift:true});await c.pressKey('Tab');
        await capture('16-narrow-text200-export-ready-focused.png');
        await check('200% text keyboard download remains reachable',s=>{assert.equal(s.focus,'download');assert.ok(s.download.rect.x>=0&&s.download.rect.right<=320);assert.ok(s.download.rect.y>=0&&s.download.rect.bottom<=800);});
        await c.page('Page.setFontSizes',{fontSizes:{standard:16}});
        await navigate('?lang=en');
        await check('English locale still renders its original action values',s=>{assert.equal(s.save.text,'Save draft');assert.equal(s.export.text,'Create file');assert.equal(s.title.value,longTitle);});
        await c.page('Emulation.setDeviceMetricsOverride',{width:1280,height:900,deviceScaleFactor:1,mobile:false});
        await navigate();
        await type(savedTitle);
        await activate('save');await settle('save','success');
        await type('저장 전 편집 중인 제목');
        await activate('export');await settle('export','ready');
        const storedOnly=await c.evaluate("(async()=>Array.from(new Uint8Array(await (await fetch(document.getElementById('download').href)).arrayBuffer())))()");
        assert.deepEqual(Buffer.from(storedOnly),Buffer.from(expectedCSV(savedTitle)));
        observations.checks.push({name:'export uses saved title while unsaved editor text is retained',result:'pass',observed:await state(),blobSha256:sha(Buffer.from(storedOnly))});
      }
      observations.runtimeExceptions=c.exceptions;
      assert.deepEqual(c.exceptions,[]);
    });
    observations.completed=true;
  } catch(error) {
    observations.completed=false;
    observations.error={message:error.message,stack:error.stack};
    throw error;
  } finally {
    await writeFile(path.join(runOutput,'browser.json'),JSON.stringify(observations,null,2)+'\n',{flag:'wx'});
  }
}

try {
  await run('baseline',false);
  await run('release',true);
} finally {
  const after=await inventory(input);
  await json('input-after.json',after);
  const unchanged=JSON.stringify(before)===JSON.stringify(after);
  await json('input-integrity.json',{unchanged,fileCount:before.length,before:'input-before.json',after:'input-after.json'});
  assert.equal(unchanged,true);
}
console.log('Static scope, baseline journey, release journey, and input byte integrity checks passed.');
