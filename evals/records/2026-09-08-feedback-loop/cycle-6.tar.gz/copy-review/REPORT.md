# 메모 저장·파일 내보내기 한국어 문구 검수

판정: **pass — 제공된 개인 메모 화면의 한국어 9개 문자열 수정 범위에서 완료로 볼 수 있습니다.** 저장 위치·대기/완료·다운로드 준비 상태·실패 후 가능한 행동이 직접 실행한 동작과 맞습니다. 범위 내 필수 수정은 발견하지 못했습니다. 전체 앱이나 모든 브라우저·기기의 품질 인증은 아닙니다.

## 범위와 실행 환경

- 입력: `/tmp/lutriva-copy-quality-trial-4lbBdK/TASK.md`, `ORIGINAL-REQUEST.md`, `TOOLS.md`, `baseline/`, `release/`, `skills/`, `harness/`만 사용했습니다. 기존 작성자 보고서나 외부 평가 기록은 보지 않았습니다.
- 출력: `/tmp/lutriva-cycle6-copy-review-XXqDd0`.
- 적용한 스킬: 제공된 `skills/ui-quality-gate/SKILL.md`, principles, evidence-verdict, verification, web, ux-foundations, interaction-recipes 참조. 실제 상태·데이터·직접 연 캡처와 미검증 범위를 분리했습니다.
- Node `v26.8.1`, `darwin`, `arm64`.
- 실제 실행 Chrome: `Chrome/152.0.7977.83`, revision `@79460ebecaa5625e57a5fb679a735659e73dc687`, JS `15.2.124.21`. baseline과 release 모두 같은 버전입니다. 버전은 `Browser.getVersion` 결과이며 user-agent의 축약 버전으로 추정하지 않았습니다.
- 경로 `/index.html`, 대표 viewport 1280×900 및 320×800 CSS px, DPR 1. 320px는 데스크톱 Chrome viewport와 CDP 터치 에뮬레이션입니다.
- 각 제품을 새 Chrome 임시 프로필과 loopback 서버에서 실행했습니다. 프로필 경로는 출력의 `profiles/` 아래로 제한했고 harness가 종료 후 정리했습니다. 실제 사용자 프로필에 연결하지 않았습니다.

## 정적 범위와 입력 보존

`diff -ru baseline release`와 자체 JSON/파일 검사를 수행했습니다. 제품의 파일 추가·삭제가 없고 `locales/ko.json`만 변경됐습니다. 변경된 키는 요청한 `save_action`, `save_pending`, `save_success`, `save_failed`, `export_action`, `export_pending`, `export_ready`, `export_failed`, `download_action` 9개와 정확히 일치합니다. 전체 키 순서·구성과 각 문자열의 `{title}`, `{count}`, `{filename}` 변수 구성을 보존했습니다. 나머지 한국어 문자열, 영어 locale, JS, HTML/ARIA, CSS, DESIGN은 baseline/release 사이에 바이트가 동일합니다.

실행 전후 제공 입력 81개 파일의 경로·바이트 수·SHA-256이 모두 동일했습니다. 자세한 결과는 `static-scope.json`, `input-before.json`, `input-after.json`, `input-integrity.json`에 있습니다. baseline의 한국어 파일은 790 bytes, SHA-256 `d71fcb645fd1e37afca0522332aa29f0fd09b2798ee8f21837280ef861021e29`, release는 967 bytes, SHA-256 `1f33d9d0898259f6d2deced294263efdc23b0a1145bb31772d2066a3d8fe455f`이며 검수 중 바꾸지 않았습니다.

## 실제 검증 결과

실행 명령:

```sh
node --check /tmp/lutriva-cycle6-copy-review-XXqDd0/review.mjs
node --check release/app.js
node --check baseline/app.js
node /tmp/lutriva-cycle6-copy-review-XXqDd0/review.mjs
```

모두 exit 0으로 완료했습니다. 첫 세 명령은 구문 검사이며 빌드나 UI 통과 주장에 사용하지 않았습니다. 마지막 명령은 제공 harness로 baseline 16개, release 22개 결과 검사를 실행했습니다. 수집한 예외는 둘 다 0개입니다. baseline 검사 통과는 기존 동작과 기존 locale 값이 관찰됐다는 의미이고, 기존 문구가 사실이라는 판정은 아닙니다.

| 시나리오 | 기대와 실제 관찰 | 근거 |
| --- | --- | --- |
| 저장 전/대기 | 버튼이 브라우저 임시 저장을 명시합니다. 대기 중에는 이전 저장 데이터가 그대로 있고 제목·저장 버튼이 잠깁니다. release는 진행 중이라고 안내하며 완료를 주장하지 않습니다. | `release/browser.json`, `01-wide-idle.png`, `02-wide-save-pending.png` |
| 저장 성공·유지 | localStorage의 첫 메모 제목만 바뀌고 두 번째 메모는 유지됩니다. 같은 프로필에서 페이지를 새로 열어 저장된 제목을 확인했습니다. 성공 문구는 이 브라우저의 임시 저장으로 한정됩니다. | `save success changes first note only`, `saved title survives same-profile page reload`, `03-wide-save-success.png` |
| 저장 실패·회복 | 실패 모사 후 입력한 긴 제목과 기존 저장 데이터가 각각 보존됩니다. 입력과 저장 버튼이 다시 활성화됩니다. 모사 조건 해제 후 같은 화면의 저장 버튼으로 성공하여 긴 제목이 실제 저장됩니다. 로그인·네트워크 복구·자동 재시도를 주장하지 않습니다. | `failed save preserves editable draft and old stored record`, `save retry succeeds and retains second note`, `04-wide-save-failed-long.png`, `10-narrow-save-failed-long.png` |
| CSV 대기 | 저장된 메모 2개라는 count가 맞습니다. 대기 중 내보내기 버튼은 잠기고 다운로드 링크와 href가 없습니다. 임의 완료 시간이나 자동 다운로드를 약속하지 않습니다. | `export pending has correct count and no download link`, `05-wide-export-pending.png`, `11-narrow-export-pending.png` |
| CSV 준비 | 완료 상태는 Blob과 `개인 메모.csv` 링크를 제공합니다. Blob의 UTF-8 BOM, CSV 헤더, 두 저장 제목과 따옴표 이스케이프를 바이트로 확인했습니다. 링크 실행 전 지정한 다운로드 디렉터리는 비어 있었습니다. ‘파일이 준비됐어요’와 링크 행동 안내가 실제 상태와 일치합니다. | `ready Blob has UTF-8 BOM and both stored titles`, `no file downloaded before link activation`, `06-wide-export-ready.png` |
| 다운로드 | 실제 Enter 키로 링크를 실행한 뒤 해당 실행의 임시 다운로드 디렉터리에 `개인 메모.csv`가 생겼습니다. 파일 바이트가 준비된 CSV와 일치합니다. 이 테스트 환경의 실제 파일 생성만 확인한 것으로, 앱이 기기의 다운로드 완료를 감지한다는 뜻은 아닙니다. | `keyboard link activation downloads matching CSV to isolated directory`, `release/downloads/개인 메모.csv` |
| CSV 실패·회복 | 이전 다운로드 링크를 숨기고 href를 제거하며 버튼이 다시 활성화됩니다. 모사 조건 해제 후 안내된 ‘CSV 파일 만들기’ 버튼으로 다시 준비됩니다. 원인 미분류 오류를 서버 차단이나 관리자 권한 문제로 단정하지 않습니다. | `export failure ends pending and removes prior link`, `export retry returns ready link`, `07-wide-export-failed.png`, `13-narrow-export-failed.png` |
| 320px 행동 | CDP 터치 입력으로 저장/내보내기 재시도가 실제 성공합니다. Tab·Shift+Tab으로 다운로드 링크에 도달하고, 링크의 경계가 viewport 안에 있는 것을 확인했습니다. | `narrow touch save retry stores long title`, `narrow touch export retry restores link`, `narrow keyboard reaches visible download link`, `12-narrow-export-ready-focused.png` |
| 관련 보존 | 빈 제목은 기존 required 검증에 막혀 저장 데이터를 바꾸지 않습니다. 영어 버튼 값이 원문대로 렌더링됩니다. 편집 중인 미저장 제목과 별개로 CSV는 저장된 제목을 담습니다. | release의 마지막 관련 검사들과 Blob 해시 |

baseline에서 직접 본 ‘클라우드’, 대기 중 ‘동기화가 완료됐어요’, ‘모든 기기’, 준비 직후 ‘기기에 저장됐어요’, 로그인/관리자 요청은 위 동작과 맞지 않았습니다. release는 같은 데이터·브라우저·크기의 실행에서 이 불일치를 없앴습니다. 두 버전의 결과를 대조했지만 사용자의 이해 속도나 실수율을 측정한 A/B 연구는 아닙니다.

## 직접 연 화면의 시각 검수

release 16개 캡처 전부와 baseline 9개를 `view_image`로 직접 열었습니다. 정확한 목록과 관찰은 `visual-review.json`에 있습니다. 나머지 baseline 4개는 캡처만 했으며 시각 검수로 세지 않았습니다. `browser.json`의 `visuallyInspected:false`는 캡처 시점의 초기값이고, 이후 직접 열어 본 결과는 별도 기록으로 남겼습니다.

- 1280×900에서 저장/내보내기의 대기·성공/준비·실패 안내가 버튼과 겹치지 않고 읽힙니다.
- 긴 한국어 제목은 `다음 주 가족 여행 준비와 회의 일정 확인을 위한 아주 긴 한국어 메모 제목 및 챙겨야 할 준비물 목록`을 사용했습니다. 320×800에서 상태 문구가 카드 안에서 줄바꿈되고, 필요한 행동은 세로 스크롤로 접근됩니다. 문서 가로 폭이 320 CSS px를 넘지 않는 것을 함께 검사했습니다.
- 320px 다운로드 링크의 주황색 키보드 포커스 표시를 직접 확인했습니다. 입력란은 기존 한 줄 입력이어서 긴 제목 일부만 보이지만, 변경된 상태 문구에서는 전체 제목이 줄바꿈으로 표시됩니다.
- Chrome 기본 글자 크기를 16→24→32px로 설정하고 계산된 상태 글자 크기도 확인했습니다. 150%·200%에서 오류 문구가 세로로 길어지며, 200% 준비 안내와 다운로드 링크는 겹치지 않고 읽고 접근할 수 있습니다. 이는 브라우저 기본 글자 확대 검사이며 페이지 줌·OS 확대·모든 폰트 설정을 대신하지 않습니다.

## 필수 수정과 선택 의견

필수 수정: 없습니다. 요청한 문자열 범위·상태 설명·실패 뒤 행동·대표 폭에서 과업을 막는 구체적 결함을 확인하지 못했습니다.

선택 의견: 긴 제목을 그대로 포함하는 저장 실패 안내는 320px, 특히 200% 글자 설정에서 길어집니다. 현재는 전부 읽을 수 있고 저장 버튼도 접근 가능합니다. 향후 문구를 더 짧게 다듬는다면 `{title}`와 입력 보존·재시도 의미를 유지하는 선에서 검토할 수 있습니다. 또한 320px 대기 안내의 ‘있어요’ 마지막 음절이 다음 줄로 내려가는 장면이 있으나 메시지나 행동을 숨기지 않는 줄바꿈 취향 수준입니다. 이 의견을 반영하기 위한 제품 수정은 하지 않았고 완료 조건으로 삼지 않았습니다.

## 검사 준비와 한계

- 두 메모의 초기 localStorage 값은 임시 프로필에서 `Runtime.evaluate`로 합성 주입했습니다. 실제 사용자 데이터가 아닙니다. 제목 입력은 `Input.insertText`, 일반 키는 제공된 `pressKey`로 보냈습니다. `.focus()`와 `.select()`는 검사 위치 준비에 사용했으므로 전체 시작 화면부터의 탭 순서를 완주했다고 주장하지 않습니다.
- 실패는 제공된 체크박스를 Space로 켜는 합성 오류를 사용했습니다. 재시도 성공은 체크박스를 해제하여 실패 조건이 해소된 뒤 검증했습니다. 실제 디스크 부족·브라우저 정책·저장소 손상·운영체제 권한 실패까지 재현하지 않았습니다.
- 대기 상태를 놓치지 않도록 기존 120ms 타이머만 페이지 메모리에서 일시 보류하고 캡처 후 해제했습니다. 원본 JS와 제품 파일은 변경하지 않았습니다. 따라서 캡처된 대기 지속시간은 실제 성능 수치가 아닙니다. 일반 실패·재시도는 원래 타이머로 실행됐습니다.
- 다운로드 경로는 Browser 설정으로 각 실행의 `downloads/`에 지정했습니다. 전역 다운로드 폴더에는 쓰지 않았습니다. headless Chrome에서 실제 파일 생성을 확인했으며, 사용자의 기기·파일 선택 UI·모바일 다운로드·다른 브라우저는 확인하지 않았습니다.
- 스크린리더 발화, 실제 한국어 IME 조합, 물리적 터치 기기, OS 텍스트 크기, 전체 WCAG 적합성, 대비 수치, 성능, 브라우저를 종료한 뒤의 장기 보존은 미검증입니다. ARIA/HTML/CSS 보존은 바이트 비교로 확인했으며 보조기술 실행으로 확대하지 않았습니다.
- 설치·제품 수정·업데이트 UI 조작·외부 계정/서비스 변경·배포·커밋·푸시는 수행하지 않았습니다. 프로필 분리가 브라우저의 모든 배경 네트워크를 완전히 격리했다는 주장도 하지 않습니다.

## 아티팩트

- 검수 보고서: `/tmp/lutriva-cycle6-copy-review-XXqDd0/REPORT.md`
- 직접 실행한 검사: `/tmp/lutriva-cycle6-copy-review-XXqDd0/review.mjs`
- 정적 범위·버전·제품 해시: `/tmp/lutriva-cycle6-copy-review-XXqDd0/static-scope.json`
- 입력 전후 바이트 기록: `/tmp/lutriva-cycle6-copy-review-XXqDd0/input-before.json`, `/tmp/lutriva-cycle6-copy-review-XXqDd0/input-after.json`, `/tmp/lutriva-cycle6-copy-review-XXqDd0/input-integrity.json`
- baseline 실행 결과: `/tmp/lutriva-cycle6-copy-review-XXqDd0/baseline/browser.json`
- release 실행 결과: `/tmp/lutriva-cycle6-copy-review-XXqDd0/release/browser.json`
- 직접 연 이미지 목록과 판단: `/tmp/lutriva-cycle6-copy-review-XXqDd0/visual-review.json`
- 대표 긴 제목 오류: `/tmp/lutriva-cycle6-copy-review-XXqDd0/release/10-narrow-save-failed-long.png`
- 대표 다운로드 포커스: `/tmp/lutriva-cycle6-copy-review-XXqDd0/release/12-narrow-export-ready-focused.png`
- 200% 글자 다운로드 포커스: `/tmp/lutriva-cycle6-copy-review-XXqDd0/release/16-narrow-text200-export-ready-focused.png`
- 실제 임시 다운로드: `/tmp/lutriva-cycle6-copy-review-XXqDd0/release/downloads/개인 메모.csv`
