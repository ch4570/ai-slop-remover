package example.solbit

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import java.io.IOException
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

data class Profile(val name: String, val email: String)

interface ProfileRepository {
    suspend fun save(profile: Profile)
}

// Synthetic service for code review. This fixture has no backend or build project.
class ExampleRepository(private val rejectSave: Boolean) : ProfileRepository {
    override suspend fun save(profile: Profile) {
        delay(200)
        if (rejectSave) throw IOException("Simulated connection failure")
    }
}

@Composable
fun ProfileEditor(
    initial: Profile,
    repository: ProfileRepository,
    onClose: () -> Unit,
) {
    var name by rememberSaveable { mutableStateOf(initial.name) }
    var email by rememberSaveable { mutableStateOf(initial.email) }
    var saving by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("프로필 수정")
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("이름") },
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("연락 이메일") },
                    modifier = Modifier.fillMaxWidth(),
                )
                Button(
                    enabled = !saving,
                    onClick = {
                        if (name.isBlank() || email.isBlank()) {
                            status = "이름과 연락 이메일을 입력해 주세요."
                        } else {
                            val submitted = Profile(name, email)
                            saving = true
                            status = "저장 중입니다."
                            scope.launch {
                                try {
                                    repository.save(submitted)
                                } catch (error: IOException) {
                                    name = initial.name
                                    email = initial.email
                                    status = "저장하지 못했습니다. 연결을 확인하고 다시 시도해 주세요."
                                } finally {
                                    saving = false
                                    status = "프로필을 저장했습니다."
                                    onClose()
                                }
                            }
                        }
                    },
                ) { Text(if (saving) "저장 중" else "저장") }
                if (status.isNotEmpty()) Text(status)
            }
        }
        TextButton(onClick = onClose) { Text("닫기") }
    }
}
