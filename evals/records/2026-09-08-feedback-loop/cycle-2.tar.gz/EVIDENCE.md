# 두 번째 피드백 사이클의 고정 자료

2026-09-08 23:51부터 2026-09-09 00시대 KST까지, 기준 소스 `fb256bc`에서
확인한 문제와 정적 진단 실행 자료다. 이 압축의 브라우저 결과는 수집기 회귀
재현이며 스킬을 적용한 제품 개선 시험이 아니다. 모든 데이터는 합성 자료다.

## 브라우저 수집 중단

`browser-product/`는 원래 search-editor fixture에 검색 결과와 count 노드를
제거하는 이벤트를 추가한 것이다. 검색 실패 기록이 만들어진 다음 count 읽기가
예외를 던진다. `browser-before-tools/`는 `fb256bc`에서 고정했고,
`browser-after-tools/`는 완료 관찰 전달과 활성 검사 묶음 제한을 적용했다.

- `browser-before-evidence/browser.json`: 0 pass / 0 fail / 16 not-run,
  수집 오류 1개, 명령 종료 1. 이미 확인했던 검색 실패가 소실됐다.
- `browser-intermediate-evidence/browser.json`: 0 pass / 1 fail / 15 not-run.
  완료 관찰 전달 후, 활성 묶음 제한 전의 중간 결과를 따로 보존했다.
- `browser-after-evidence/browser.json`: 최종 고정 도구로 부모가 실행한 결과.
  0 pass / 1 fail / 15 not-run, 수집 오류 1개, 명령 종료 1.

압축 루트에서 기존 Chrome과 Node 22+로 재현한다. 매번 새 출력 경로가 필요하다.

```sh
node browser-before-tools/scripts/run_browser_checks.mjs browser-product /tmp/cycle2-new-before
node browser-after-tools/scripts/run_browser_checks.mjs browser-product /tmp/cycle2-new-after
```

두 명령 모두 의도된 수집 오류 때문에 종료 1이다. 성공/실패/미실행 구분은
JSON을 확인한다. 포함된 wide.png는 오류 전에 수집한 자료이며 이 사이클에서
화면 품질을 판정하는 데 사용하지 않았다. 스크린샷 존재는 시각 통과가 아니다.
16개 suite 기준과 버전은 바꾸지 않았다.

`batch-before-json/`과 `batch-after-json/`은 같은 배치에서 예외 또는 실제
페이지 이동이 발생하는 일곱 하위 사례의 전후 JSON이다. 후자는 최종 29개
검색 회귀 실행에서 복사했다. 잘못된 기록과 검사 시작 전 기록의 최종 결과도
후자에 따로 담았다. `browser-after-tools/tests/test_browser_checks.py`와
원래 fixture를 함께 고정했으므로 해당 도구 디렉터리에서 다음으로 재현한다.

`stream-startup-before-guard.json`은 완료 콜백 도입 후 활성 묶음 제한 전의
중간 구현에서 초기화 전 기록으로 ordinary-save 1 pass / 15 not-run이 된
자료다. 기준 `fb256bc`의 결과가 아니며 최종 결과와 섞어 집계하지 않는다.

```sh
AI_SLOP_BROWSER_TESTS=1 python3 -m unittest discover -s tests -p test_browser_checks.py -v
```

## CLI 계획 예산

`cli-workflow-before.json`은 별도 검토자가 수정 전 합성 프로젝트에서 실행한
81개 CLI 명령의 인자·종료 코드·JSON이다. 최소 6회가 필요한 계획을 한도 5로,
최소 8회가 필요한 계획을 한도 6으로 제출해도 후보 생성은 성공하고 실행 기록을
제출한 뒤에야 예산 초과로 `incomplete`가 됐다.

부모는 같은 새 회귀 검사에 수정 전 snapshot의 CLI를 지정해 두 초과 조건의
실패를 다시 확인했다. 수정 후 CLI로는 네 조건 모두 통과했다. 정확히 6/6,
8/8인 계획은 합성 보고서의 적격 판정까지 확인하고 자동 채택하지 않는다.
초과한 계획은 후보 목록과 활성 포인터를 변경하지 않는다. 종료 출력의 마지막
부분은 `cli-budget-before.txt`와 `cli-budget-after.txt`에 보존했다.

수정 후 검사의 고정 사본은 `cli-after-tools/`에 있다. Python 3.9+에서 다음을
실행하면 1개 테스트의 네 하위 조건이 통과한다.

```sh
cd cli-after-tools
PYTHONPATH=tests python3 -B -m unittest test_local_learning.LocalLearningLifecycleTests.test_proposal_run_budget_matches_all_planned_baseline_candidate_runs -v
```

같은 테스트의 `test_local_learning.SCRIPT`만
`native-audit/skills/ui-craft-bundle/scripts/local_learning.py`의 절대 경로로
바꾸면 기준 CLI의 두 초과 조건에서 실패한다. 경계 판정과 저장소 동작의
합성 회귀 검사이지 모델의 실제 실행·비용·품질을 검증한 것은 아니다.

## 네이티브 읽기 전용 진단

`native-audit/`는 합성 Kotlin 소스, TASK, DESIGN, 읽힌 스킬 snapshot과
완료된 원문 응답을 보존한다. 별도 새 문맥 `/root/native_audit_trial`에
`ui-slop-audit` 진입점을 지정한 `snapshot-direct` 실행이다. 모델과 reasoning은
부모 설정을 상속했고 별도 모델 식별자·비공개 sampling 값은 추정하지 않았다.
설치된 호스트의 자동 발견이나 호출은 실행하지 않았다.

부모는 작성자가 반환한 다음 진단을 소스와 대조했다.

1. `finally`의 성공 상태 대입과 `onClose()` 호출은 실패/취소에서도 실행된다.
2. `IOException` 처리의 초기값 재대입은 사용자가 작성한 입력을 지운다.
3. 저장 중 필드를 계속 수정할 수 있지만 repository에는 클릭 시점 값을 넘긴다.

보고서는 실제 표시·화면 닫힘·영속 저장을 확인하지 않았음을 구분했고,
카드·브랜드·필드 순서를 유지하는 좁은 수정 방향과 미실행 확인 방법을 제시했다.
이 과업에는 저장 중 편집 유지 요구가 없어 필드 잠금 제안은 요청과 충돌하지
않는다. 첫 웹 과업의 추가 입력 보존 요구를 이 과업에 소급하지 않았다.

TASK/DESIGN/Kotlin의 실행 전후 SHA-256은 각각 다음과 같아 최종 바이트가 같다.

```
a5cd8ce0696acf4903ffb9a18752329553c5c7d1691bf827120e775a3b079c73  TASK.md
299d36f3bbc1581eddc74893dbde215146cc65fcdfe6c283f1b511163fa97c2f  DESIGN.md
98d5922db2b2e6434526bcfd3a610bc97b69e74efb06ecdf9884d7b2f74b7555  ProfileEditor.kt
```

snapshot의 65개 파일도 기준 `fb256bc`와 모두 일치했다. 최종 해시는 중간의
임시 쓰기 부재를 증명하지 않는다. 에이전트의 도구 사용 전체 transcript는
포함하지 않는다. 원문 응답의 링크는 당시 임시 절대 경로를 그대로 보존했다.
Android SDK·Gradle 프로젝트·에뮬레이터·기기·실제 저장 서비스가 없으며
빌드·실행·기기 접근성·사용자 성과는 미검증이다. 부모 검토는 답변 작성자와
별도 문맥의 AI 소스 검토이나 fixture 결함을 알고 있어 맹검이 아니다.

이 한 번의 진단에서 추가할 스킬 규칙의 실패 근거를 찾지 못했다.
스킬 버전 간 비교·반복·전이 평가나 일반적인 스킬 개선을 주장하지 않는다.
