import * as service from './service.js';

const list = document.querySelector('#queue-list');
const filter = document.querySelector('#queue-filter');
const count = document.querySelector('#queue-count');
const saveStatus = document.querySelector('#save-status');
const emptyState = document.querySelector('#empty-state');
const failButton = document.querySelector('#fail-next-save');
const demoStatus = document.querySelector('#demo-status');

let jobs = [];
let order = [];

function render() {
  const query = filter.value.trim().toLocaleLowerCase('ko');
  const visibleJobs = order
    .map((id) => jobs.find((job) => job.id === id))
    .filter((job) => `${job.id} ${job.title} ${job.route}`.toLocaleLowerCase('ko').includes(query));

  list.replaceChildren();
  for (const job of visibleJobs) {
    const position = order.indexOf(job.id);
    const row = document.createElement('li');
    row.className = 'job-row';
    row.dataset.jobId = job.id;

    const rank = document.createElement('span');
    rank.className = 'job-rank';
    rank.textContent = String(position + 1).padStart(2, '0');
    rank.setAttribute('aria-label', `전체 순서 ${position + 1}`);

    const description = document.createElement('div');
    const title = document.createElement('h3');
    title.className = 'job-title';
    title.textContent = job.title;
    const meta = document.createElement('p');
    meta.className = 'job-meta';
    meta.textContent = `${job.id} · ${job.route} · ${job.timeWindow} · ${job.packageLabel}`;
    description.append(title, meta);

    const controls = document.createElement('div');
    controls.className = 'job-controls';
    for (const [action, label, disabled] of [
      ['up', '↑ 위로', position === 0],
      ['down', '↓ 아래로', position === order.length - 1],
    ]) {
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'move-button';
      button.dataset.action = action;
      button.dataset.jobId = job.id;
      button.textContent = label;
      button.setAttribute('aria-label', `${job.title} ${action === 'up' ? '위로' : '아래로'} 이동`);
      button.disabled = disabled;
      controls.append(button);
    }
    row.append(rank, description, controls);
    list.append(row);
  }
  count.textContent = `전체 ${jobs.length}건 · 표시 ${visibleJobs.length}건`;
  emptyState.hidden = visibleJobs.length !== 0;
}

async function moveJob(id, direction) {
  const index = order.indexOf(id);
  const target = index + direction;
  if (index < 0 || target < 0 || target >= order.length) return;

  const beforeMove = [...order];
  [order[index], order[target]] = [order[target], order[index]];
  render();
  saveStatus.textContent = '순서를 저장하는 중…';

  try {
    await service.commit(order);
    saveStatus.textContent = '이 브라우저에 순서를 저장했어요.';
    demoStatus.textContent = '저장 실패를 한 번 시험할 수 있어요.';
  } catch (error) {
    order = beforeMove;
    render();
    saveStatus.textContent = '저장하지 못했어요. 순서를 이전 상태로 되돌렸습니다.';
    demoStatus.textContent = error.message;
  }
}

list.addEventListener('click', (event) => {
  const button = event.target.closest('button[data-action]');
  if (!button || button.disabled) return;
  void moveJob(button.dataset.jobId, button.dataset.action === 'up' ? -1 : 1);
});

filter.addEventListener('input', render);
failButton.addEventListener('click', () => {
  service.armNextCommitFailure();
  demoStatus.textContent = '다음 저장 한 번은 실패합니다. 작업 순서를 이동해 보세요.';
});

try {
  const snapshot = await service.read();
  jobs = snapshot.jobs;
  order = snapshot.order;
  render();
  saveStatus.textContent = '저장된 순서를 불러왔어요.';
} catch (error) {
  saveStatus.textContent = `순서를 불러오지 못했어요. ${error.message}`;
}
