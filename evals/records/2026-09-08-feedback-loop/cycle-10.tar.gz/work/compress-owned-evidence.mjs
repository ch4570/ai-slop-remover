import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { createReadStream, createWriteStream } from 'node:fs';
import { appendFile, lstat, readdir, unlink } from 'node:fs/promises';
import { pipeline } from 'node:stream/promises';
import { createGzip, createGunzip } from 'node:zlib';
import path from 'node:path';

// Only completed, parent-owned historical collector outputs; never source or user data.
const roots = [
  '/tmp/lutriva-queue-observer-RAcypp/baseline-attempt-02',
  '/tmp/lutriva-queue-observer-RAcypp/baseline-attempt-03',
];
const journal = '/tmp/lutriva-cycle10-work-NpakUR/evidence-compression.jsonl';
const mode = process.argv[2];
assert.ok(['--plan', '--compress'].includes(mode));
async function digest(stream) {
  const hash = createHash('sha256'); let bytes = 0;
  for await (const chunk of stream) { hash.update(chunk); bytes += chunk.length; }
  return { bytes, sha256: hash.digest('hex') };
}
for (const root of roots) {
  for (const name of (await readdir(root)).sort().filter((name) => name === 'browser.json' || name.endsWith('.jsonl'))) {
    const source = path.join(root, name);
    const info = await lstat(source, { bigint: true });
    assert.ok(info.isFile() && !info.isSymbolicLink(), source);
    if (mode === '--plan') { console.log(JSON.stringify({ source, bytes: String(info.size) })); continue; }
    const compressed = source + '.gz';
    const original = await digest(createReadStream(source));
    await pipeline(createReadStream(source), createGzip({ level: 6 }), createWriteStream(compressed, { flags: 'wx' }));
    const restored = await digest(createReadStream(compressed).pipe(createGunzip()));
    assert.deepEqual(restored, original, source + ': compression verification');
    assert.deepEqual(await digest(createReadStream(source)), original, source + ': original changed');
    const container = await digest(createReadStream(compressed));
    const record = { source, compressed, original, gzip: container, originalMtimeNs: String(info.mtimeNs),
      originalMode: Number(info.mode & 0o777n), verifiedAt: new Date().toISOString() };
    await appendFile(journal, JSON.stringify({ ...record, status: 'verified-before-removal' }) + '\n');
    await unlink(source); // Exact verified original is recoverable from its adjacent gzip.
    await appendFile(journal, JSON.stringify({ source, compressed, status: 'uncompressed-copy-removed-recoverable' }) + '\n');
    console.log(JSON.stringify({ source, beforeBytes: original.bytes, gzipBytes: container.bytes, sha256: original.sha256 }));
  }
}
