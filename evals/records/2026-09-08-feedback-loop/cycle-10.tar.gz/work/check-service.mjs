import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const work = path.dirname(fileURLToPath(import.meta.url));
const source = path.join(work, 'original/product/service.js');
const bytes = readFileSync(source);
const sha = (value) => createHash('sha256').update(value).digest('hex');
const values = new Map();
let denied = false;
Object.defineProperty(globalThis, 'localStorage', { value: {
  getItem: (key) => values.get(key) ?? null,
  setItem: (key, value) => { if (denied) throw new Error('Synthetic storage rejection'); values.set(key, String(value)); },
}, configurable: true });
const moduleUrl = 'data:text/javascript;base64,' + bytes.toString('base64');
const service = await import(moduleUrl);
const initial = service.resetDemo();
const ids = Array.from({ length: 6 }, (_, index) => 'JOB-' + (1041 + index));
assert.deepEqual(initial.order, ids);
assert.deepEqual(initial.jobs.map((job) => job.id), ids);
const originalJobs = structuredClone(initial.jobs);
const checks = [];
async function check(id, operation) {
  const started = new Date().toISOString();
  try { await operation(); checks.push({ id, status: 'pass', started, finished: new Date().toISOString() }); }
  catch (error) { checks.push({ id, status: 'fail', started, finished: new Date().toISOString(), error: String(error.stack) }); }
}
const moved = [...ids]; [moved[1], moved[2]] = [moved[2], moved[1]];
await check('ordinary-commit-and-copy-isolation', async () => {
  const submitted = [...moved];
  const pending = service.commit(submitted);
  submitted.reverse();
  const saved = await pending;
  assert.deepEqual(saved.order, moved);
  saved.jobs[0].payload.tags.push('not-durable');
  saved.order.reverse();
  assert.deepEqual(await service.read(), { jobs: originalJobs, order: moved });
});
await check('out-of-order-completion-is-real', async () => {
  service.resetDemo();
  const completed = [];
  const older = service.commit(moved).then(() => completed.push('older'));
  const newer = service.commit([...ids].reverse()).then(() => completed.push('newer'));
  await Promise.all([older, newer]);
  assert.deepEqual(completed, ['newer', 'older']);
  assert.deepEqual((await service.read()).order, moved);
});
await check('invalid-order-does-not-consume-one-shot-failure', async () => {
  service.resetDemo();
  service.armNextCommitFailure();
  service.armNextCommitFailure();
  await assert.rejects(service.commit([ids[0]]), { code: 'INVALID_ORDER' });
  await assert.rejects(service.commit(moved), { code: 'DEMO_SAVE_FAILED' });
  assert.deepEqual((await service.read()).order, ids);
  assert.deepEqual((await service.commit(moved)).order, moved);
});
await check('reset-invalidates-pending-write', async () => {
  service.resetDemo();
  const old = service.commit(moved);
  const rejected = assert.rejects(old, { code: 'DEMO_RESET' });
  const replacement = [...ids].reverse();
  service.resetDemo({ order: replacement });
  await rejected;
  assert.deepEqual((await service.read()).order, replacement);
});
await check('storage-rejection-preserves-committed-order', async () => {
  service.resetDemo();
  denied = true;
  try { await assert.rejects(service.commit(moved), { code: 'LOCAL_STORAGE_FAILED' }); }
  finally { denied = false; }
  assert.deepEqual((await service.read()).order, ids);
  assert.deepEqual(JSON.parse(values.get('charye.dispatch.order.v1')), ids);
});
await check('fresh-module-load-reads-committed-order', async () => {
  await service.commit(moved);
  const reloaded = await import(moduleUrl + '#fresh-module');
  assert.deepEqual(await reloaded.read(), { jobs: originalJobs, order: moved });
});
const unchanged = readFileSync(source).equals(bytes);
const result = { checks, source, sourceSha256: sha(bytes), sourceUnchanged: unchanged,
  runtime: process.version, limits: 'Node process with in-memory localStorage stand-in; not browser, UI, reload-navigation or assistive-technology proof.' };
writeFileSync(path.join(work, 'service-checks.json'), JSON.stringify(result, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify(result));
process.exitCode = unchanged && checks.every((entry) => entry.status === 'pass') ? 0 : 1;
