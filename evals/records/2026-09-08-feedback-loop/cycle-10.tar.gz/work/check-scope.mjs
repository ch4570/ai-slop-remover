import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { lstatSync, readFileSync, readdirSync, writeFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const work = path.dirname(fileURLToPath(import.meta.url));
const [mode, output] = process.argv.slice(2);
assert.ok(['freeze', 'verify'].includes(mode) && output, 'Usage: check-scope.mjs freeze|verify NEW_OUTPUT_JSON');
const roots = ['original', 'trial', 'author-tools'];
const allowed = new Set(['trial/product/app.js', 'trial/index.html', 'trial/styles.css', 'trial/DESIGN.md']);
function inventory(root, relative = '') {
  const full = path.join(work, root, relative);
  const info = lstatSync(full, { bigint: true });
  const key = path.join(root, relative);
  const entry = { mode: Number(info.mode & 0o777n), mtimeNs: String(info.mtimeNs) };
  if (info.isSymbolicLink()) return { [key]: { ...entry, type: 'symlink' } };
  if (info.isDirectory()) return Object.assign({ [key]: { ...entry, type: 'directory' } },
    ...readdirSync(full).sort().map((name) => inventory(root, path.join(relative, name))));
  assert.ok(info.isFile(), 'Unexpected file type: ' + key);
  const data = readFileSync(full);
  return { [key]: { ...entry, type: 'file', bytes: data.length, sha256: createHash('sha256').update(data).digest('hex') } };
}
const current = Object.assign({}, ...roots.map((root) => inventory(root)));
let report = { schema: 1, paths: current, allowed: [...allowed] };
if (mode === 'verify') {
  const before = JSON.parse(readFileSync(path.join(work, 'input-paths-before.json'), 'utf8')).paths;
  const failures = [], changes = [];
  for (const key of [...new Set([...Object.keys(before), ...Object.keys(current)])].sort()) {
    const old = before[key], now = current[key];
    if (!old || !now) { failures.push({ path: key, reason: old ? 'removed path' : 'added path' }); continue; }
    if (old.type !== now.type || old.mode !== now.mode) { failures.push({ path: key, reason: 'type or mode changed' }); continue; }
    if (old.type === 'directory' && [...allowed].some((name) => name.startsWith(key + '/'))) continue;
    if (JSON.stringify(old) === JSON.stringify(now)) continue;
    if (allowed.has(key)) changes.push(key);
    else failures.push({ path: key, reason: 'immutable content or modification time changed', before: old, after: now });
  }
  report = { ...report, verified: failures.length === 0, changes, failures,
    limits: 'Final path/type/mode/content/mtime comparison, not a complete tool transcript or proof of enforced isolation. Directory mtimes above editable files may change during normal edits.' };
  process.exitCode = report.verified ? 0 : 1;
}
writeFileSync(output, JSON.stringify(report, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify({ mode, paths: Object.keys(current).length, verified: report.verified, changes: report.changes, failures: report.failures }));
