# Queue flow implementation handoff

Used the explicitly supplied `trial/skills/ux-flow-refine/SKILL.md`, its principles and state-recovery reference, and the shared interaction-design, web and relevant interaction-recipes guidance. This is task-supplied skill use, not a claim of automatic host discovery.

Changed product files only: `trial/product/app.js`, `trial/index.html`, `trial/styles.css`, `trial/DESIGN.md`.

The application now owns a current full-order draft and revision counters. It allows one adapter commit at a time and commits the latest full draft after an earlier request succeeds. It never applies save responses to the draft. A failure preserves all edits, ends pending feedback, and offers retry. Further edits in the failure state remain unsaved until explicit retry. Retry uses the current draft and still allows moves. Successful feedback appears only once the final revision has committed. All order writes continue through the supplied adapter.

After keyboard movement, focus follows the acted job and direction, falling back to that job's available direction at the boundary. Search still only hides jobs, full ranks remain visible, and movement swaps the full-queue neighbor. The existing brand and complete job data remain in use. Move and retry controls have a 44 CSS px minimum height. No animations were introduced.

## Executed checks

- `node /tmp/lutriva-cycle10-work-NpakUR/author-evidence/check-flow.mjs baseline`: exit 1 as expected before implementation, 3/12 checks passed. It reproduced 9 failures, including stale persisted order, incorrect early success, draft loss and lost keyboard focus. Full results: `baseline/browser.json`.
- `node /tmp/lutriva-cycle10-work-NpakUR/author-evidence/check-flow.mjs final`: exit 0, 33/33 passed. Covers rapid latest-order persistence and reload, pending controls, draft preservation after failure, retry with new edits, case-insensitive filtering and hidden neighbors, empty-result recovery, complete payload preservation, Enter/Space focus and boundary behavior, narrow layout, reduced-motion media and mobile focus visibility. Full results: `final/browser.json`.
- `node /tmp/lutriva-cycle10-work-NpakUR/author-evidence/check-recovery.mjs`: exit 0, 13/13 passed. Covers repeated retry activation, another failure during retry with newer edits, subsequent final-order persistence and reload, a synthetic browser-storage denial and recovery, emulated touch activation, and a 320 CSS px overflow probe. Full results: `recovery/browser.json`.
- `node --input-type=module --check < product/app.js`: exit 0.

Both browser runs used the supplied read-only Chrome helper, a temporary isolated profile and an ephemeral loopback server. No dependency installation, external service, existing browser profile or user settings were used. Browser exception lists were empty in both passing runs.

## Inspected screenshots

- `final/desktop-error.png`: desktop failure message, retained draft and visible retry action.
- `final/mobile-error.png`: 375 CSS px full-page error view; long titles wrap, controls remain separate and readable.
- `final/mobile-focus.png`: 375 CSS px viewport capture; focused up control remains visibly outlined on the moved job with reduced-motion preference enabled.
- `final/desktop-retrying.png`: desktop pending retry view. The original capture filename was `desktop-saved.png`, but inspection showed it captured pending state; it has been renamed accurately.
- `recovery/desktop-saved.png`: desktop saved state after the adapter completed the final revision.
- `recovery/mobile-touch.png`: 375 CSS px viewport after touch movement and confirmed persistence.

## Limits

Checks used installed headless Chrome, DOM keyboard events through CDP and emulated touch. Physical devices, screen-reader announcements, other browser engines, real IME composition and cross-tab editing were not evaluated. The product promises local persistence only. A refresh during pending/failed work reads the last committed order; the failure text explicitly explains that unsaved changes would be lost. No backend behavior is implied or tested.
