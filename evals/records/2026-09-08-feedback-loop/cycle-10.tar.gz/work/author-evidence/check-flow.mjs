import assert from 'node:assert/strict';
import { writeFile } from 'node:fs/promises';
import { withBrowser, claimBrowserEvidence } from '../author-tools/browser_harness.mjs';

const mode = process.argv[2] || 'baseline';
const root = '/tmp/lutriva-cycle10-work-NpakUR/trial';
const output = `/tmp/lutriva-cycle10-work-NpakUR/author-evidence/${mode}`;
const failures = [];
const checks = [];
const check = (name, actual, expected) => {
  try { assert.deepEqual(actual, expected); checks.push({ name, passed: true }); }
  catch { failures.push(name); checks.push({ name, passed: false, actual, expected }); }
};
await claimBrowserEvidence(output, []);
await withBrowser(root, output, async ({ origin, page, evaluate, pause, pressKey, screenshot, exceptions }) => {
  const get = () => evaluate(`({ order: [...document.querySelectorAll('#queue-list > li')].map(row => row.dataset.jobId), status: document.querySelector('#save-status').textContent, state: document.querySelector('.save-line').dataset.state, focus: { id: document.activeElement.dataset.jobId, action: document.activeElement.dataset.action }, retry: (() => {const b=document.querySelector('[data-action="retry-save"]'); return b && { hidden: b.hidden, disabled: b.disabled };})() })`);
  const seed = async () => {
    await evaluate(`(async () => { const service = await import('/product/service.js'); service.resetDemo(); })()`);
    await page('Page.reload'); await pause(100);
  };
  const move = (id, action) => evaluate(`document.querySelector('button[data-job-id="${id}"][data-action="${action}"]').click()`);
  const persisted = () => evaluate(`(async () => (await (await import('/product/service.js')).read()).order)()`);
  const base = ['JOB-1041','JOB-1042','JOB-1043','JOB-1044','JOB-1045','JOB-1046'];
  await page('Page.navigate', { url: origin }); await pause(130);
  await seed();
  const originalJobs = await evaluate(`(async () => (await (await import('/product/service.js')).read()).jobs)()`);
  await move('JOB-1043','up'); await pause(20); await move('JOB-1043','up');
  const rapidOrder = ['JOB-1043','JOB-1041','JOB-1042','JOB-1044','JOB-1045','JOB-1046'];
  check('rapid moves immediately show the latest full order', (await get()).order, rapidOrder);
  await pause(150);
  check('an earlier completion must not announce latest draft saved', (await get()).status.includes('저장했어요'), false);
  check('pending allows every non-boundary move', await evaluate(`Array.from(document.querySelectorAll('#queue-list > li')).every((row,i,rows) => row.querySelector('[data-action="up"]').disabled === (i === 0) && row.querySelector('[data-action="down"]').disabled === (i === rows.length - 1))`), true);
  await pause(450);
  check('rapid latest order is persisted', await persisted(), rapidOrder);
  await page('Page.reload'); await pause(100);
  check('rapid latest order survives reload', (await get()).order, rapidOrder);

  await seed();
  await evaluate(`document.querySelector('#fail-next-save').click()`);
  await move('JOB-1043','up'); await pause(20); await move('JOB-1043','up');
  await pause(450);
  check('failure preserves all moves including newer draft', (await get()).order, rapidOrder);
  check('failed save leaves committed order unchanged', await persisted(), base);
  check('failure offers a working retry', (await get()).retry, {hidden:false,disabled:false});

  await seed();
  await evaluate(`document.querySelector('button[data-job-id="JOB-1043"][data-action="up"]').focus()`);
  await pressKey('Enter');
  check('keyboard move keeps same job and direction', (await get()).focus, {id:'JOB-1043',action:'up'});
  await pressKey('Space');
  check('boundary keeps focus on the available direction', (await get()).focus, {id:'JOB-1043',action:'down'});
  await pause(500);
  check('keyboard result is persisted', await persisted(), rapidOrder);

  if (mode !== 'baseline') {
    await seed();
    await evaluate(`document.querySelector('#fail-next-save').click()`);
    await move('JOB-1042','down'); await pause(400);
    const failedDraft = ['JOB-1041','JOB-1043','JOB-1042','JOB-1044','JOB-1045','JOB-1046'];
    check('single failure is explicit', (await get()).state, 'error');
    check('single failure keeps edited order', (await get()).order, failedDraft);
    await screenshot('desktop-error.png');
    await move('JOB-1042','down'); await pause(120);
    const adjustedDraft = ['JOB-1041','JOB-1043','JOB-1044','JOB-1042','JOB-1045','JOB-1046'];
    check('failed draft remains editable', (await get()).order, adjustedDraft);
    check('additional edit keeps unsaved warning', (await get()).state, 'error');
    check('no automatic commit hides failure', await persisted(), base);
    await evaluate(`document.querySelector('[data-action="retry-save"]').focus()`);
    await pressKey('Enter');
    await evaluate(`document.querySelector('[data-action="retry-save"]').click()`);
    await move('JOB-1042','down');
    const retriedDraft = ['JOB-1041','JOB-1043','JOB-1044','JOB-1045','JOB-1042','JOB-1046'];
    check('retry with new input remains pending', (await get()).state, 'saving');
    await pause(150);
    check('retry does not announce an older snapshot as saved', (await get()).state, 'saving');
    await pause(350);
    check('retry plus newer input persists final draft', await persisted(), retriedDraft);
    check('retry settles to saved', (await get()).state, 'saved');
    await page('Page.reload'); await pause(100);
    check('retried order survives reload', (await get()).order, retriedDraft);

    await seed();
    await evaluate(`document.querySelector('#queue-filter').value='job-1043';document.querySelector('#queue-filter').dispatchEvent(new Event('input', {bubbles:true}));`);
    check('search is case insensitive', (await get()).order, ['JOB-1043']);
    await move('JOB-1043','up');
    check('filtered move uses full-queue rank', await evaluate(`document.querySelector('.job-rank').textContent`), '02');
    await pause(400);
    check('filtered move preserves hidden neighbors', await persisted(), ['JOB-1041','JOB-1043','JOB-1042','JOB-1044','JOB-1045','JOB-1046']);
    await evaluate(`document.querySelector('#queue-filter').value='no matches';document.querySelector('#queue-filter').dispatchEvent(new Event('input', {bubbles:true}));`);
    check('no results explains recovery', await evaluate(`document.querySelector('#empty-state').hidden`), false);
    await evaluate(`document.querySelector('#queue-filter').value='';document.querySelector('#queue-filter').dispatchEvent(new Event('input', {bubbles:true}));`);
    check('clearing search restores six complete jobs', (await get()).order.length, 6);
    check('all job objects including payloads are preserved', await evaluate(`(async () => (await (await import('/product/service.js')).read()).jobs)()`), originalJobs);

    await page('Emulation.setDeviceMetricsOverride', {width:375,height:812,deviceScaleFactor:1,mobile:true});
    await page('Emulation.setEmulatedMedia', {features:[{name:'prefers-reduced-motion',value:'reduce'}]});
    await seed();
    await evaluate(`document.querySelector('button[data-job-id="JOB-1046"][data-action="up"]').focus()`);
    await pressKey('Enter');
    check('mobile reduced-motion keyboard focus follows job', (await get()).focus, {id:'JOB-1046',action:'up'});
    check('focused button is visible after move', await evaluate(`(() => { const r=document.activeElement.getBoundingClientRect(); return r.top>=0 && r.bottom<=innerHeight; })()`), true);
    await screenshot('mobile-focus.png', {captureBeyondViewport:false});
    await pause(400);
    check('reduced-motion move persists', await persisted(), ['JOB-1041','JOB-1042','JOB-1043','JOB-1044','JOB-1046','JOB-1045']);
    await evaluate('window.scrollTo(0,0)');
    await evaluate(`document.querySelector('#fail-next-save').click()`);
    await move('JOB-1041','down'); await pause(400);
    check('mobile has no horizontal page overflow', await evaluate('document.documentElement.scrollWidth <= innerWidth'), true);
    check('mobile move targets are at least 44px high', await evaluate(`Array.from(document.querySelectorAll('.move-button')).every(b=>b.getBoundingClientRect().height >= 44)`), true);
    await screenshot('mobile-error.png');
    await page('Emulation.setDeviceMetricsOverride', {width:1280,height:900,deviceScaleFactor:1,mobile:false});
    await evaluate(`document.querySelector('[data-action="retry-save"]').click()`); await pause(150);
    await screenshot('desktop-retrying.png');
  }
  check('no uncaught browser exceptions', exceptions.length, 0);
});
await writeFile(`${output}/browser.json`, JSON.stringify({mode,checks,failures},null,2));
console.log(JSON.stringify({mode,total:checks.length,passed:checks.length-failures.length,failures},null,2));
if (failures.length) process.exitCode=1;
