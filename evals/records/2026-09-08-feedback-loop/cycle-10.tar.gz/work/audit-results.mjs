import assert from 'node:assert/strict';
import { readFileSync, readdirSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const work = path.dirname(fileURLToPath(import.meta.url));
const roots = { original: '/tmp/lutriva-queue-observer-RAcypp/baseline-attempt-05', candidate: path.join(work, 'candidate-observer-01') };
const sha = b => createHash('sha256').update(b).digest('hex');
const condensed = t => ({ sequence:t.sequence, label:t.label, time:t.time, intended:t.intended, order:t.order, storedOrder:t.storedOrder,
  status:t.status.text, semantic:t.semantic, retry:t.retry, viewport:t.viewport,
  active:{tag:t.active.tag,jobId:t.active.jobId,action:t.active.action,disabled:t.active.disabled,rect:t.active.rect,focusVisible:t.active.focusVisible,outline:t.active.style?.outline,outlineOffset:t.active.style?.outlineOffset} });
const result = { schema:1, generatedAt:new Date().toISOString(), note:'Read-only derivation of final frozen reports, not a new browser run or replacement verdict.', runs:{} };
for(const [name, root] of Object.entries(roots)) {
  const bytes=readFileSync(path.join(root,'browser.json')); const r=JSON.parse(bytes);
  assert.equal(r.scenarios.length,8); assert.deepEqual(r.errors,[]); assert.deepEqual(r.runtimeErrors,[]); assert.equal(r.sourceUnchanged,true);
  const run={reportSha256:sha(bytes),startedAt:r.startedAt,completedAt:r.completedAt,rawVerdicts:r.scenarioResults,scenarios:[],screenshots:[]};
  for(const s of r.scenarios) {
    const lines=readFileSync(path.join(root,s.name+'.jsonl'),'utf8').trim().split('\n').map(x=>JSON.parse(x));
    assert.deepEqual(lines,s.timeline,s.name+': redundant report and JSONL samples agree');
    assert.deepEqual(s.errors,[]);
    for(const [index,t] of s.documentTransitions.entries()) {
      assert.ok(t.newToken && t.previousToken!==t.newToken);
      if(t.previousToken===null) assert.ok(s===r.scenarios[0] && index===0, 'Only first navigation may have no previous document token');
      else assert.equal(typeof t.previousToken,'string');
    }
    const distinct=[];
    for(const t of s.timeline) {
      const previous=distinct.at(-1);
      if(!previous || JSON.stringify([t.order,t.storedOrder,t.status.text,t.active.tag,t.active.jobId,t.active.action])!==JSON.stringify([previous.order,previous.storedOrder,previous.status,previous.active.tag,previous.active.jobId,previous.active.action]) || /reload|boundary/.test(t.label)) distinct.push(condensed(t));
    }
    run.scenarios.push({name:s.name,samples:s.timeline.length,jsonlMatches:true,documentTransitions:s.documentTransitions,keyboardPaintWaits:s.keyboardPaintWaits,transitions:distinct});
  }
  for(const file of readdirSync(root).filter(x=>x.endsWith('.png')).sort()) {
    const b=readFileSync(path.join(root,file)); assert.equal(b.subarray(1,4).toString(),'PNG');
    run.screenshots.push({file,bytes:b.length,sha256:sha(b),width:b.readUInt32BE(16),height:b.readUInt32BE(20)});
  }
  result.runs[name]=run;
}
writeFileSync(path.join(work,'parent-raw-audit.json'),JSON.stringify(result,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify(Object.fromEntries(Object.entries(result.runs).map(([k,r])=>[k,{reportSha256:r.reportSha256,scenarios:r.scenarios.length,samples:r.scenarios.reduce((n,s)=>n+s.samples,0),screenshots:r.screenshots.length,jsonlMatches:true,allRecordedReloadTokensChanged:true}]))));
