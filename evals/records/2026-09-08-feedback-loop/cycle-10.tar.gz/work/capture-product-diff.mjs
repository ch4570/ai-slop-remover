import { spawnSync } from 'node:child_process';
import { writeFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root=path.dirname(fileURLToPath(import.meta.url));
const records=[];let patch='';
for(const name of ['DESIGN.md','index.html','styles.css','product/app.js']){
  const args=['diff','--no-index','--','original/'+name,'trial/'+name];
  const r=spawnSync('git',args,{cwd:root,encoding:'utf8'});
  records.push({executable:'git',args,cwd:root,exit:r.status,stderr:r.stderr});
  if(r.status!==1) throw new Error('Expected content diff exit1 for '+name);
  patch+=r.stdout;
}
writeFileSync(path.join(root,'product.patch'),patch,{flag:'wx'});
writeFileSync(path.join(root,'product-diff-commands.json'),JSON.stringify(records,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({files:records.length,expectedDiffExits:records.map(r=>r.exit),bytes:Buffer.byteLength(patch)}));
