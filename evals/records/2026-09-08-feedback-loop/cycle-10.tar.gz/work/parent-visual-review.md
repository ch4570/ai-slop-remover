# Parent visual and task review

Actually opened all seven final baseline05 and all seven candidate-observer-01 PNGs on 2026-09-09 KST. Earlier baseline02 images are not substituted for this inspection. This is a manual reading, not a browser replay or accessibility certification.

Both preserve the warm background, teal brand, quiet six-row queue, full-order labels and long Korean job titles. The viewport screenshots at 1280x900 and 375x900 show readable labels and separate controls, with narrow controls below their job text. No overlap is apparent in these viewport captures.

Baseline wide and narrow before-keyboard captures have a visible teal focus ring. The corresponding post-movement screenshots lose it; raw activeElement is BODY. Candidate wide top-boundary and narrow top-boundary captures retain the ring on JOB-1042's operable down button. Sequential raw observations show the same-job direction retained and boundary fallback, without evaluator refocusing after each action.

Residual issue: candidate wide-bottom-boundary-focus.png clips the lower edge of JOB-1045's up-button focus outline at the viewport bottom. Scenario07 sequence5 records button bottom900.453125 in a 900px viewport; outline is solid3px with offset3px. The automatic box check's 1px tolerance passes, but it does not prove the whole focus indicator is visible. The label, most of the button/ring and continued keyboard action remain visible/operable. Do not turn this into an unqualified visual pass or silently repair this one-author trial. A later distinct task may address clearance around the indicator.

The narrow full-page PNGs are 360px wide and show right-edge clipping unlike their 375px viewport captures. Raw narrow scrollWidth/clientWidth both360 and row right345 do not demonstrate live horizontal overflow. Full-page capture framing is therefore a limitation, not proof that all footer/card pixels were visible in the viewport. No complete narrow full-page visual-pass claim is made.

The frozen collector returns five candidate scenario passes, one failure and two human-review-or-not-run outcomes. The keyboard outcomes have no automated failures but retain their original manual-review markers. This note supplements, never rewrites, those outcomes.

Task versus scenario04: TASK requires preserved intent and a way to retry after failure, including further adjustments; it does not require auto-retry on another move. Candidate intentionally leaves a clear failed state with the latest draft and a visible explicit retry. The fixed scenario04 skips that retry and reloads, which necessarily restores only the last committed order. Its six failure assertions remain in raw evidence. A post-handoff independent supplemental recovery test is separate evidence, not a retroactively changed frozen score.

No screen reader, physical touch, real IME, other OS/browser engine, contrast measurement, user account or real dispatch was evaluated by this parent review. Source review establishes one-at-a-time adapter commits and no applying completion responses back into the draft; finite browser observations do not prove every interleaving.
