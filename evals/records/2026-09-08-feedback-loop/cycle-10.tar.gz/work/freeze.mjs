import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { copyFileSync, lstatSync, mkdirSync, readFileSync, readdirSync, writeFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const work = path.dirname(fileURLToPath(import.meta.url));
const repo = '/Users/rex/Desktop/personal/lutriva';
const fixture = '/tmp/lutriva-queue-fixture-rfSkYK';
const names = ['DESIGN.md', 'SERVICE_CONTRACT.md', 'TASK.md', 'index.html', 'styles.css', 'product/app.js', 'product/service.js'];
const hash = (data) => createHash('sha256').update(data).digest('hex');
const manifest = JSON.parse(readFileSync(path.join(repo, 'manifest.json'), 'utf8'));
const sources = [];
function copy(source, destination, expected) {
  const info = lstatSync(source);
  assert.ok(info.isFile() && !info.isSymbolicLink());
  const before = readFileSync(source);
  if (expected) assert.equal(hash(before), expected, source);
  mkdirSync(path.dirname(destination), { recursive: true });
  copyFileSync(source, destination);
  assert.deepEqual(readFileSync(destination), before);
  assert.deepEqual(readFileSync(source), before);
  sources.push({ source, destination, bytes: before.length, sha256: hash(before) });
}
for (const directory of ['original', 'trial', 'author-tools', 'author-evidence']) mkdirSync(path.join(work, directory));
for (const name of names) {
  copy(path.join(fixture, name), path.join(work, 'original', name));
  copy(path.join(fixture, name), path.join(work, 'trial', name));
}
for (const [name, expected] of Object.entries(manifest.files).filter(([name]) => name.startsWith('skills/'))) {
  copy(path.join(repo, name), path.join(work, 'trial', name), expected);
}
copy(path.join(repo, 'scripts/browser_harness.mjs'), path.join(work, 'author-tools/browser_harness.mjs'));
function inventory(root, prefix = '') {
  return Object.fromEntries(readdirSync(path.join(root, prefix)).sort().flatMap((name) => {
    const relative = path.join(prefix, name), absolute = path.join(root, relative);
    const info = lstatSync(absolute);
    assert.ok(!info.isSymbolicLink());
    if (info.isDirectory()) return Object.entries(inventory(root, relative));
    assert.ok(info.isFile());
    const bytes = readFileSync(absolute);
    return [[relative, { bytes: bytes.length, sha256: hash(bytes), mode: info.mode & 0o777 }]];
  }));
}
for (const name of ['original', 'trial', 'author-tools']) {
  const files = inventory(path.join(work, name));
  writeFileSync(path.join(work, name + '-before.json'), JSON.stringify({ schema: 1, files }, null, 2) + '\n', { flag: 'wx' });
}
writeFileSync(path.join(work, 'copy-provenance.json'), JSON.stringify({ created: new Date().toISOString(), base: 'b41221444af14d6a7526ca9a3b5258151efb65c6', copies: sources }, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify({ originalFiles: names.length, trialFiles: Object.keys(inventory(path.join(work, 'trial'))).length, taskSha: hash(readFileSync(path.join(work, 'trial/TASK.md'))) }));
