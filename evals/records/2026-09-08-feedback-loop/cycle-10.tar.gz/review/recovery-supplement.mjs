import { readFile, writeFile, mkdir, readdir, realpath, lstat, readlink } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { withBrowser, claimBrowserEvidence } from '/tmp/lutriva-queue-observer-RAcypp/browser_harness.mjs';

const here = path.dirname(fileURLToPath(import.meta.url));
const [productArg, outputArg] = process.argv.slice(2);
if (!productArg || !outputArg || process.argv.length !== 4) throw new Error('Usage: node recovery-supplement.mjs PRODUCT_ROOT NEW_OUTPUT_ROOT');
const product = await realpath(productArg), output = path.resolve(outputArg);
const sha = value => createHash('sha256').update(value).digest('hex');
const equal = (a,b) => JSON.stringify(a) === JSON.stringify(b);
const ids = a => a.map(n => `JOB-104${n}`);
const DEFAULT = ids([1,2,3,4,5,6]), FIRST = ids([1,3,2,4,5,6]), LATEST = ids([1,3,4,2,5,6]);
const frozen = JSON.parse(await readFile(path.join(here,'supplement-freeze.json'),'utf8'));
for (const [name,hash] of Object.entries(frozen.files)) if (sha(await readFile(path.join(here,name))) !== hash) throw new Error(`Supplement changed: ${name}`);
const originalFreeze = JSON.parse(await readFile('/tmp/lutriva-queue-observer-RAcypp/freeze.json','utf8'));
for (const [name,hash] of Object.entries(originalFreeze.observerFiles)) if (sha(await readFile(path.join('/tmp/lutriva-queue-observer-RAcypp',name))) !== hash) throw new Error(`Original evaluator changed: ${name}`);
const expectedJobs = JSON.parse(await readFile('/tmp/lutriva-queue-observer-RAcypp/expected-jobs.json','utf8'));
const manifest = async () => {
  const entries = [];
  const walk = async relative => {
    const target = path.join(product,relative), stat = await lstat(target);
    if (stat.isDirectory()) for (const name of (await readdir(target)).sort()) await walk(path.join(relative,name));
    else if (stat.isFile()) entries.push([relative,{bytes:stat.size,sha256:sha(await readFile(target))}]);
    else if (stat.isSymbolicLink()) entries.push([relative,{symlink:await readlink(target)}]);
    else entries.push([relative,{type:'other'}]);
  };
  await walk(''); return Object.fromEntries(entries);
};
await mkdir(output); await claimBrowserEvidence(output,[]);
const report = {kind:'post-author task-guided supplement',startedAt:new Date().toISOString(),command:{executable:process.execPath,args:process.argv.slice(1)},product,output,frozen,sourceBefore:await manifest(),sourceAfter:null,checks:[],states:[],adapterReads:[],transitions:[],polls:[],errors:[],runtimeErrors:[]};
const check = (name,condition,evidence=null,status) => report.checks.push({name,status:status || (condition?'pass':'fail'),evidence});
const errorData = error => ({name:error.name,message:error.message,stack:error.stack});
const save = () => writeFile(path.join(output,'report.json'),JSON.stringify(report,null,2));
try {
  for (const [name,hash] of Object.entries(originalFreeze.fixtureContract)) if (report.sourceBefore[name]?.sha256 !== hash) throw new Error(`Immutable contract changed: ${name}`);
  await withBrowser(product,output,async ({origin,page,evaluate,pause,exceptions}) => {
    report.browserExceptions=exceptions;
    await page('Page.addScriptToEvaluateOnNewDocument',{source:`window.__supplementToken=crypto.randomUUID();window.__supplementErrors=[];addEventListener('error',e=>window.__supplementErrors.push({kind:'error',message:e.message}));addEventListener('unhandledrejection',e=>window.__supplementErrors.push({kind:'unhandledrejection',message:String(e.reason)}));`});
    const token = () => evaluate('window.__supplementToken || null');
    const ready = async previous => {
      const start=Date.now();
      while(Date.now()-start<3000){try{const r=await evaluate(`({token:window.__supplementToken,ready:document.readyState!=='loading'&&document.querySelectorAll('#queue-list li[data-job-id]').length===6&&Boolean(document.querySelector('#save-status'))})`);if(r.token&&r.token!==previous&&r.ready){report.transitions.push({previous,current:r.token});return;}}catch{}await pause(25);}
      throw new Error('Fresh document and six ready rows not observed within 3000ms');
    };
    const reload = async () => {const previous=await token();await page('Page.reload',{ignoreCache:true});await ready(previous);};
    const capture = async (label,intended) => {
      const s=await evaluate(`(() => {const button=e=>({jobId:e.dataset.jobId,action:e.dataset.action,text:e.innerText,disabled:e.disabled,visible:e.getClientRects().length>0&&getComputedStyle(e).visibility!=='hidden'});const status=document.querySelector('#save-status');const rows=Array.from(document.querySelectorAll('#queue-list li[data-job-id]')).filter(e=>e.getClientRects().length>0).map(e=>({id:e.dataset.jobId,text:e.innerText,buttons:Array.from(e.querySelectorAll('button')).map(button)}));const raw=localStorage.getItem('charye.dispatch.order.v1');let stored;try{stored=JSON.parse(raw);}catch{stored=null;}return {time:performance.now(),documentToken:window.__supplementToken,order:rows.map(r=>r.id),rows,rawStorage:raw,storedOrder:stored,status:status?.innerText,queueBusy:document.querySelector('#queue-list')?.getAttribute('aria-busy'),statusBusy:status?.getAttribute('aria-busy'),retry:Array.from(document.querySelectorAll('[data-action="retry-save"]')).map(button),runtimeErrors:window.__supplementErrors||[]};})()`);
      s.label=label;s.intended=intended;s.sequence=report.states.length;
      s.semantic={pending:/저장\s*중|저장하고|저장하는\s*중|저장\s*대기|saving|pending|동기화\s*중/i.test(s.status||'')||s.statusBusy==='true'||s.queueBusy==='true',failure:/실패|오류|저장하지\s*못|저장.*못|retry|failed|error/i.test(s.status||''),success:/저장.*완료|저장\s*(?:됨|했|하였|됐|되었)|\bsaved\b/i.test(s.status||'')};
      s.semantic.unknown=!s.semantic.pending&&!s.semantic.failure&&!s.semantic.success;
      report.states.push(s);return s;
    };
    const settle = async (label,intended) => {
      const start=Date.now();let stable=null,previous=null,s;
      do{s=await capture(label,intended);const terminal=!s.semantic.pending&&(s.semantic.failure||(equal(s.order,intended)&&equal(s.storedOrder,intended)));const key=JSON.stringify({order:s.order,stored:s.storedOrder,status:s.status,semantic:s.semantic});if(terminal&&previous===key)stable??=Date.now();else stable=null;previous=key;if(Date.now()-start>=850&&stable&&Date.now()-stable>=450)break;await pause(25);}while(Date.now()-start<3000);
      report.polls.push({label,elapsedMs:Date.now()-start,boundedTimeout:Date.now()-start>=3000,stableMs:stable?Date.now()-stable:0});return s;
    };
    const click = async (selector,label) => {
      const target=await evaluate(`(() => {const e=document.querySelector(${JSON.stringify(selector)});if(!e||e.disabled||!e.getClientRects().length||getComputedStyle(e).visibility==='hidden')return null;e.scrollIntoView({block:'center',inline:'nearest'});const r=e.getBoundingClientRect();return {x:r.x+r.width/2,y:r.y+r.height/2,width:r.width,height:r.height};})()`);
      check(`${label}: visible operable control`,Boolean(target?.width&&target?.height),target);
      if(!target?.width||!target?.height)throw new Error(`Required visible operable control absent: ${selector}`);
      await page('Input.dispatchMouseEvent',{type:'mousePressed',x:target.x,y:target.y,button:'left',clickCount:1});await page('Input.dispatchMouseEvent',{type:'mouseReleased',x:target.x,y:target.y,button:'left',clickCount:1});
    };
    const payload = async label => {const value=await evaluate(`(async () => (await import('/product/service.js')).read())()`);report.adapterReads.push({label,value});check(`${label}: immutable full payloads`,equal(value.jobs,expectedJobs));return value;};
    const data = (label,s,expected) => {check(`${label}: intended complete DOM order`,equal(s.order,expected),{expected,actual:s.order});check(`${label}: complete displayed fields`,expectedJobs.every(j=>['title','route','timeWindow','packageLabel'].every(f=>s.rows.find(r=>r.id===j.id)?.text.includes(j[f]))));check(`${label}: committed storage order`,equal(s.storedOrder,expected),s.storedOrder);};
    await page('Page.navigate',{url:origin+'/'});await ready(null);await evaluate(`(async () => (await import('/product/service.js')).resetDemo())()`);await reload();
    data('reset',await capture('reset',DEFAULT),DEFAULT);await payload('reset');
    await click('#fail-next-save','arm failure');await click('button[data-job-id="JOB-1043"][data-action="up"]','job3 up');
    check('first intended draft immediate',equal((await capture('first move',FIRST)).order,FIRST));
    const failed=await settle('first failure',FIRST);
    check('first failure keeps intended draft',equal(failed.order,FIRST),failed.order);check('rejection leaves committed order unchanged',equal(failed.storedOrder,DEFAULT),failed.storedOrder);check('actual failure understandable and pending ended',failed.semantic.failure&&!failed.semantic.pending,failed.status,failed.semantic.unknown?'not-run':undefined);await payload('first failure');
    if(!failed.semantic.failure||failed.semantic.pending){check('newer edit recovery and reload',false,'No settled failure was observed','not-run');return;}
    await click('button[data-job-id="JOB-1044"][data-action="up"]','job4 up after failure');
    const newerStart=report.states.length;
    check('newer edit keeps complete latest draft immediately',equal((await capture('newer move',LATEST)).order,LATEST));
    let final=await settle('newer recovery',LATEST);
    if(final.semantic.failure){
      const hasRetry=final.retry.some(r=>r.visible&&!r.disabled);check('failed recovery offers retry',hasRetry,final.retry);
      if(!hasRetry){check('retry completion and fresh reload',false,'Required retry is absent or inoperable','not-run');return;}
      await click('[data-action="retry-save"]','retry latest draft');await capture('immediately after retry',LATEST);
      const retryStart=report.states.length-1;final=await settle('retry completion',LATEST);
      check('retry pending actually observed',report.states.slice(retryStart).some(s=>s.semantic.pending),report.states.slice(retryStart).map(s=>({sequence:s.sequence,status:s.status})));
      report.recovery='explicit retry';
    }else report.recovery='automatic recovery';
    const newerStates=report.states.slice(newerStart);
    check('latest draft retained throughout recovery',newerStates.every(s=>equal(s.order,LATEST)),newerStates.filter(s=>!equal(s.order,LATEST)).map(s=>s.sequence));
    const unresolved=newerStates.filter(s=>!equal(s.storedOrder,LATEST));const unclear=unresolved.filter(s=>!s.semantic.pending&&!s.semantic.failure);
    check('uncommitted draft accurately described',unclear.length===0,unclear.map(s=>({sequence:s.sequence,status:s.status})),unclear.length&&unclear.every(s=>s.semantic.unknown)?'not-run':undefined);
    const disabled=newerStates.flatMap(s=>s.rows.flatMap(r=>r.buttons.filter(b=>b.disabled&&['up','down'].includes(b.action)&&(b.action==='up'?s.order.indexOf(r.id)>0:s.order.indexOf(r.id)<s.order.length-1)).map(b=>({sequence:s.sequence,id:r.id,action:b.action}))));check('feasible moves remain enabled',disabled.length===0,disabled);
    data('settled',final,LATEST);check('settled success grounded in committed latest draft',final.semantic.success&&!final.semantic.failure&&!final.semantic.pending&&equal(final.order,LATEST)&&equal(final.storedOrder,LATEST),final.status,final.semantic.unknown?'not-run':undefined);check('settled adapter latest order',equal((await payload('settled')).order,LATEST));
    await reload();data('fresh reload',await capture('fresh reload',LATEST),LATEST);check('fresh reload adapter latest order',equal((await payload('fresh reload')).order,LATEST));
  });
}catch(error){report.errors.push(errorData(error));check('collection completed',false,errorData(error));check('remaining dependent observations',false,'Collection exception; prior evidence retained','not-run');}
finally{report.sourceAfter=await manifest();report.sourceUnchanged=equal(report.sourceBefore,report.sourceAfter);check('all source paths unchanged',report.sourceUnchanged);report.runtimeErrors=[...new Map([...(report.browserExceptions||[]),...report.states.flatMap(s=>s.runtimeErrors||[])].map(e=>[JSON.stringify(e),e])).values()];check('no observed runtime errors',report.runtimeErrors.length===0,report.runtimeErrors);report.completedAt=new Date().toISOString();report.exitCode=report.errors.length?2:report.checks.some(c=>c.status==='fail')?1:0;await save();}
console.log(JSON.stringify({output,sourceUnchanged:report.sourceUnchanged,recovery:report.recovery,errors:report.errors,failed:report.checks.filter(c=>c.status==='fail').map(c=>c.name),notRun:report.checks.filter(c=>c.status==='not-run'),exitCode:report.exitCode},null,2));
process.exitCode=report.exitCode;
