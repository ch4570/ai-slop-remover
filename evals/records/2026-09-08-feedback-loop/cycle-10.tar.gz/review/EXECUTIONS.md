# Supplement execution record

Before either browser run, `node --check /tmp/lutriva-cycle10-independent-review-kjFzHR/recovery-supplement.mjs` exited 0. Protocol/script SHA256 were written to `supplement-freeze.json` and sent to parent before execution. The script verifies those hashes and the unchanged original evaluator hashes at startup.

Exact sequential commands:

```sh
node /tmp/lutriva-cycle10-independent-review-kjFzHR/recovery-supplement.mjs /tmp/lutriva-cycle10-work-NpakUR/original /tmp/lutriva-cycle10-independent-review-kjFzHR/supplement-original-01
```

Process exit 1. Report timestamps: 2026-09-08T20:00:15.857Z to 2026-09-08T20:00:20.812Z. Product outcome failures; no collection/runtime errors. Sources unchanged.

```sh
node /tmp/lutriva-cycle10-independent-review-kjFzHR/recovery-supplement.mjs /tmp/lutriva-cycle10-work-NpakUR/trial /tmp/lutriva-cycle10-independent-review-kjFzHR/supplement-trial-01
```

Process exit 0. Report timestamps: 2026-09-08T20:00:27.438Z to 2026-09-08T20:00:30.954Z. No failed/not-run checks or collection/runtime errors. Sources unchanged.

Neither attempt was patched or rerun. Full command argv, before/after file manifests, observations, assertions, transitions, errors, timestamps and exit codes remain in each report.json. Frozen original collector outcomes remain in their original output directories.
