# Independent observer handoff — stopped before author launch

Final CLI: `node /tmp/lutriva-queue-observer-RAcypp/observer.mjs PRODUCT_ROOT NEW_OUTPUT_ROOT`

Keep `observer.mjs`, `browser_harness.mjs`, `expected-jobs.json`, `CRITERIA.md`, and `freeze.json` together for portable archival execution. Node 22+ with WebSocket and an installed Chrome are required. Output directories cannot be reused. All observer files are outside the repository and fixture; no fixing agent was launched, no repository/fixture file was edited, and no candidate implementation or CONSTRUCTION.md was read.

Final frozen SHA-256:

- observer.mjs: `3f9907dba10275715e8781917e50fffffd6b620b4f2663787ae947321a81e894`
- CRITERIA.md: `e9d804ed61438b0ba10af9c696a2caff18bbe9b9ab9648c84763a8da3aa56392`
- freeze.json: `75b4bcc21a696a3f5721741ea907d15bb470dbef066f37dbbe8595d925dd84a9`
- Original and archived browser_harness.mjs: `5538f93787bf84a401eba4ce747264ddd6bfc6e5e31049e4004a8986ad85a1e1`

Final pre-author smoke: `/tmp/lutriva-queue-observer-RAcypp/baseline-attempt-03/browser.json`, against `/tmp/lutriva-cycle10-work-NpakUR/original`, ran 2026-09-08T19:38:23.196Z–19:38:48.348Z, CLI exit 0, zero runtime/collection errors, source hashes unchanged. Exit 0 means collection completed, not product acceptance. All eight scenarios ran. Per-scenario JSONL preserves every collected sample; seven PNGs preserve wide/narrow full and focused viewport observations. Document UUID transitions confirm actual reloads; all six keyboard activations completed the two-frame allowance without timeout.

Observed original behavior, IDs abbreviated 1–6:

- Ordinary [1,3,2,4,5,6] and hidden-neighbor filtered [1,2,4,3,5,6] persisted and reloaded correctly with all six immutable payloads.
- Rapid intended [1,4,3,2,6,5] first appeared committed around document 283ms, then older completions overwrote it; final storage/reload was [1,4,3,2,5,6]. At 223ms and after 439ms, status already said “이 브라우저에 순서를 저장했어요.” while storage differed from the latest intent.
- Failure reverted intended order to default and exposed no retry button. Actual retry persistence/reload is explicitly not-run because the required control was absent.
- A new move after failure began from reverted state and therefore lost the earlier user intent. An old in-flight failure also reset DOM to default after newer [1,3,4,2,5,6] had already committed; reload later recovered the newer committed order, but the visible intent was overwritten before reload.
- Actual Space/Enter reordering lost active focus to BODY at both boundary scenarios, including narrow375; repeated unrefocused keyboard actions consequently failed. This is preserved as a sequential scenario failure, not replaced with evaluator focus repairs.

Collector correction history is in freeze.json and all earlier evidence is preserved:

1. `baseline-attempt-01/browser.json`: setup-only SyntaxError from top-level await import in CDP Runtime.evaluate; no task actions ran. Old source and freeze are `observer-attempt-01.mjs` / `freeze-attempt-01.json`. Corrected only the two adapter expressions to async IIFEs.
2. `baseline-attempt-02/browser.json`: all eight scenarios ran without collection errors. Old source, freeze, and criteria are `observer-attempt-02.mjs`, `freeze-attempt-02.json`, and `CRITERIA-attempt-02.md`. Before candidate access, recognized natural Korean success inflections and padded 03 ranks; unknown semantics became human-review/not-run. Parent-requested collector validity changes added unique-document readiness and a bounded two-animation-frame focus allowance. Scenario actions, expected permutations, and persistence/payload criteria did not change.

Visual review performed on final baseline `wide-full.png`, `narrow-before-keyboard.png`, and `narrow-top-boundary-focus.png`: controls and visible long titles were readable in these captures; the narrow pre-activation button had a clear teal focus ring. The moved job had no visible focus ring afterward, consistent with recorded BODY focus. The automatic report retains its visual-review not-run markers; this separate note records only these three inspected images. Parent should review all candidate screenshots independently.

Limits: 25ms polling pauses plus CDP/serialization overhead can miss briefer transitions. Status language outside frozen recognition requires human review, never an automatic pass. Adapter writes are observed via public read and raw storage, not intercepted. The filtered poll intentionally runs to its 3000ms bound because only one row is visible; the separately asserted full storage order and subsequent unfiltered/reloaded order determine acceptance. Screenshot/geometry evidence is not screen-reader, touch-user, contrast, or comprehensive accessibility proof. No assertion-success percentage is reported; missing controls leave explicit dependent coverage gaps.
