import { readFile, writeFile, appendFile, mkdir, realpath } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import { withBrowser, claimBrowserEvidence } from './browser_harness.mjs';

const here = path.dirname(fileURLToPath(import.meta.url));
const [productArg, outputArg] = process.argv.slice(2);
if (!productArg || !outputArg || process.argv.length !== 4) throw new Error('Usage: node observer.mjs PRODUCT_ROOT NEW_OUTPUT_ROOT');
const product = await realpath(productArg);
const output = path.resolve(outputArg);
await mkdir(output); // Exclusive fresh output: never replace an earlier attempt.
await claimBrowserEvidence(output, []);
const sha = data => createHash('sha256').update(data).digest('hex');
const frozen = JSON.parse(await readFile(path.join(here, 'freeze.json'), 'utf8'));
const sourceFiles = ['TASK.md', 'SERVICE_CONTRACT.md', 'product/service.js', 'product/app.js', 'index.html', 'styles.css', 'DESIGN.md'];
const sourceHashes = async () => Object.fromEntries(await Promise.all(sourceFiles.map(async name => {
  try { return [name, sha(await readFile(path.join(product, name)))]; }
  catch (error) { return [name, { error: error.code || error.message }]; }
})));
const expectedJobs = JSON.parse(await readFile(path.join(here, 'expected-jobs.json'), 'utf8'));
const ids = numbers => numbers.map(number => `JOB-104${number}`);
const DEFAULT = ids([1,2,3,4,5,6]);
const ORDINARY = ids([1,3,2,4,5,6]);
const NEWER = ids([1,3,4,2,5,6]);
const RAPID = [ids([1,2,4,3,5,6]), ids([1,4,2,3,5,6]), ids([1,4,3,2,5,6]), ids([1,4,3,2,6,5])];
const FILTERED = ids([1,2,4,3,5,6]);
const equal = (a,b) => JSON.stringify(a) === JSON.stringify(b);
const errorData = error => ({ name: error.name, message: error.message, stack: error.stack });
const report = { schema: 1, startedAt: new Date().toISOString(), product, output, frozen, sourceBefore: await sourceHashes(), sourceAfter: null, scenarios: [], errors: [], runtimeErrors: [], limitations: ['Finite polling can miss brief transitions.', 'Geometry/screenshots are not assistive-technology or contrast proof.', 'Declared status wording classifier may need human review of retained raw text.', 'Adapter commits are not intercepted; public adapter reads and raw storage are observed.'] };
const save = async () => writeFile(path.join(output, 'browser.json'), JSON.stringify(report, null, 2));
await save();
try {
  for (const [name, expected] of Object.entries(frozen.observerFiles)) {
    const actual = sha(await readFile(path.join(here, name)));
    if (actual !== expected) throw new Error(`Frozen evaluator changed: ${name}: ${actual}`);
  }
  for (const name of ['TASK.md', 'SERVICE_CONTRACT.md', 'product/service.js']) {
    if (report.sourceBefore[name] !== frozen.fixtureContract[name]) throw new Error(`Immutable fixture contract changed: ${name}`);
  }
  await withBrowser(product, output, async ({ origin, page, evaluate, pressKey, screenshot, pause, exceptions }) => {
    report.browserExceptions = exceptions;
    let current;
    const check = (name, condition, evidence = null, status) => {
      current.checks.push({ name, status: status || (condition ? 'pass' : 'fail'), evidence });
    };
    const snapshotExpression = `(() => {
      const rect = el => { const r = el.getBoundingClientRect(); return { x:r.x,y:r.y,width:r.width,height:r.height,right:r.right,bottom:r.bottom }; };
      const describe = el => {
        if (!el) return null;
        const cs = getComputedStyle(el);
        return { tag:el.tagName,id:el.id,jobId:el.dataset.jobId || el.closest('[data-job-id]')?.dataset.jobId,action:el.dataset.action,text:el.innerText,ariaLabel:el.getAttribute('aria-label'),disabled:Boolean(el.disabled),tabIndex:el.tabIndex,rect:rect(el),focusVisible:el.matches(':focus-visible'),style:{outline:cs.outline,outlineOffset:cs.outlineOffset,boxShadow:cs.boxShadow,border:cs.border,backgroundColor:cs.backgroundColor,color:cs.color,fontSize:cs.fontSize,overflow:cs.overflow,whiteSpace:cs.whiteSpace,textOverflow:cs.textOverflow,lineClamp:cs.webkitLineClamp,display:cs.display,visibility:cs.visibility}};
      };
      const status = document.querySelector('#save-status');
      const storage = Object.fromEntries(Array.from({length:localStorage.length},(_,i)=>localStorage.key(i)).sort().map(k=>[k,localStorage.getItem(k)]));
      let storedOrder; try { storedOrder=JSON.parse(storage['charye.dispatch.order.v1']); } catch { storedOrder=null; }
      const titles=${JSON.stringify(expectedJobs.map(j=>j.title))};
      const allRows=Array.from(document.querySelectorAll('#queue-list li[data-job-id]')).map(el=>({id:el.dataset.jobId,visible:el.getClientRects().length>0 && getComputedStyle(el).visibility!=='hidden',text:el.innerText,html:el.outerHTML,rect:rect(el),controls:Array.from(el.querySelectorAll('button')).map(describe),textGeometry:Array.from(el.querySelectorAll('*')).filter(node=>titles.includes(node.innerText?.trim()) || node.matches('h1,h2,h3,h4,p,.job-rank')).map(node=>({text:node.innerText,rect:rect(node),clientWidth:node.clientWidth,scrollWidth:node.scrollWidth,clientHeight:node.clientHeight,scrollHeight:node.scrollHeight,style:{whiteSpace:getComputedStyle(node).whiteSpace,overflow:getComputedStyle(node).overflow,lineClamp:getComputedStyle(node).webkitLineClamp,textOverflow:getComputedStyle(node).textOverflow}}))}));
      const rows=allRows.filter(r=>r.visible);
      return {time:performance.now(),url:location.href,viewport:{width:innerWidth,height:innerHeight,scrollX,scrollY,scrollWidth:document.documentElement.scrollWidth,clientWidth:document.documentElement.clientWidth},order:rows.map(r=>r.id),rows,allRows,storage,storedOrder,status:status?{text:status.innerText,html:status.outerHTML,role:status.getAttribute('role'),live:status.getAttribute('aria-live'),busy:status.getAttribute('aria-busy'),state:status.dataset.state,attributes:Object.fromEntries(Array.from(status.attributes).map(a=>[a.name,a.value]))}:null,queueBusy:document.querySelector('#queue-list')?.getAttribute('aria-busy'),active:describe(document.activeElement),retry:Array.from(document.querySelectorAll('[data-action="retry-save"]')).map(describe),failureControl:describe(document.querySelector('#fail-next-save')),filter:describe(document.querySelector('#queue-filter')),runtimeErrors:window.__queueObserverErrors || []};
    })()`;
    const classify = state => {
      const text = state.status?.text || '';
      const hint = `${state.status?.state || ''} ${state.status?.busy || ''} ${state.queueBusy || ''}`;
      const semantic = { pending:/저장\s*중|저장하고|저장하는\s*중|저장\s*대기|saving|pending|동기화\s*중/i.test(text) || /pending|saving|true/.test(hint), failure:/실패|오류|저장하지\s*못|저장.*못|retry|failed|error/i.test(text), success:/저장.*완료|저장됨|저장했습니다|저장되었습니다|saved|모든.*저장/i.test(text) };
      return {...semantic,unknown:!semantic.pending && !semantic.failure && !semantic.success};
    };
    const capture = async (label, intended = null) => {
      const state = await evaluate(snapshotExpression);
      state.label = label;
      state.intended = intended;
      state.semantic = classify(state);
      state.sequence = current.timeline.length;
      current.timeline.push(state);
      await appendFile(path.join(output, `${current.name}.jsonl`), JSON.stringify(state)+'\n');
      return state;
    };
    const adapter = async label => {
      const value = await evaluate(`(await import('/product/service.js')).read()`);
      current.adapterReads.push({label,value});
      check(`${label}: immutable six job payloads`, equal(value.jobs,expectedJobs), value.jobs);
      return value;
    };
    const ready = async () => {
      const started=Date.now();
      while (Date.now()-started < 3000) {
        try { if (await evaluate(`Boolean(document.querySelector('#queue-list li[data-job-id]') && document.querySelector('#save-status'))`)) return; } catch {}
        await pause(25);
      }
      throw new Error('Required queue/status UI not ready within 3000ms');
    };
    const reload = async () => { await page('Page.reload',{ignoreCache:true}); await pause(40); await ready(); };
    const reset = async () => {
      await page('Page.navigate',{url:origin+'/'}); await pause(40); await ready();
      await evaluate(`(await import('/product/service.js')).resetDemo()`);
      await reload();
      const state=await capture('reset',DEFAULT);
      check('reset full DOM order',equal(state.order,DEFAULT),state.order);
      await adapter('reset');
    };
    const click = async (selector, label) => {
      const target=await evaluate(`(() => {const e=document.querySelector(${JSON.stringify(selector)});if(!e)return {error:'missing'};if(e.disabled)return {error:'disabled'};e.scrollIntoView({block:'center',inline:'nearest'});const r=e.getBoundingClientRect();return {x:r.x+r.width/2,y:r.y+r.height/2,width:r.width,height:r.height};})()`);
      if (target.error || !target.width || !target.height) { check(`${label}: operable control`,false,target); throw new Error(`${label}: control ${target.error || 'has no geometry'} (${selector})`); }
      await page('Input.dispatchMouseEvent',{type:'mousePressed',x:target.x,y:target.y,button:'left',clickCount:1});
      await page('Input.dispatchMouseEvent',{type:'mouseReleased',x:target.x,y:target.y,button:'left',clickCount:1});
      check(`${label}: operable control`,true,target);
    };
    const moveSelector = (job,direction) => `button[data-job-id="JOB-104${job}"][data-action="${direction}"]`;
    const move = async (job,direction,expected,label) => {
      await click(moveSelector(job,direction),label);
      const state=await capture(label,expected);
      check(`${label}: immediate intended order`,equal(state.order,expected),{expected,actual:state.order});
      return state;
    };
    const pendingIntegrity = (states,label) => {
      const unresolved = states.filter(s=>s.intended && !equal(s.storedOrder,s.intended));
      const premature = unresolved.filter(s=>s.semantic.success && !s.semantic.failure);
      const untruthful = unresolved.filter(s=>!s.semantic.pending && !s.semantic.failure);
      check(`${label}: no premature success while latest order unresolved`,premature.length===0,premature.map(s=>s.sequence));
      check(`${label}: unresolved latest order described as pending or failed`,untruthful.length===0,untruthful.map(s=>({sequence:s.sequence,text:s.status?.text})));
      const disabled=states.flatMap(s=>s.rows.flatMap(row=>row.controls.filter(c=>['up','down'].includes(c.action)).filter(c=>{
        const i=s.intended?.indexOf(c.jobId);return i>=0 && c.disabled && (c.action==='up'?i>0:i<s.intended.length-1);
      }).map(c=>({sequence:s.sequence,job:c.jobId,action:c.action}))));
      check(`${label}: feasible moves stay operable`,disabled.length===0,disabled);
    };
    const settle = async (expected,label,{allowFailure=false}={}) => {
      const start=Date.now(); let stableSince=null, previousKey=null, state;
      do {
        state=await capture(`${label}: poll`,expected);
        const outcome = equal(state.order,expected) && equal(state.storedOrder,expected) && !state.semantic.pending;
        const failed = allowFailure && state.semantic.failure && !state.semantic.pending;
        const key=JSON.stringify({order:state.order,stored:state.storedOrder,semantic:state.semantic,text:state.status?.text});
        if ((outcome || failed) && key===previousKey) stableSince ??= Date.now(); else stableSince=null;
        previousKey=key;
        if (Date.now()-start>=850 && stableSince && Date.now()-stableSince>=450) break;
        await pause(25);
      } while(Date.now()-start<3000);
      return state;
    };
    const verifyFull = async (label,expected,state) => {
      check(`${label}: complete intended DOM order`,equal(state.order,expected),{expected,actual:state.order});
      check(`${label}: complete committed storage order`,equal(state.storedOrder,expected),{expected,actual:state.storedOrder,raw:state.storage});
      check(`${label}: pending ended`,!state.semantic.pending,state.status);
      check(`${label}: success reflects committed outcome`,state.semantic.success && !state.semantic.failure,state.status);
      const value=await adapter(label);
      check(`${label}: adapter committed order`,equal(value.order,expected),value.order);
      const missing=expectedJobs.flatMap(job=>{
        const row=state.rows.find(r=>r.id===job.id);return ['title','route','timeWindow','packageLabel'].filter(field=>!row?.text.includes(job[field])).map(field=>({id:job.id,field,value:job[field]}));
      });
      check(`${label}: complete visible job information`,missing.length===0,missing);
    };
    const persisted = async (expected,label) => {
      const final=await settle(expected,label);
      pendingIntegrity(current.timeline.filter(s=>s.intended && s.label!=='reset'),label);
      await verifyFull(`${label}: settled`,expected,final);
      await reload();
      const restored=await capture(`${label}: reload`,expected);
      // A pristine page may use a neutral initial message; reload is checked for data/order, not forced success copy.
      check(`${label}: reload full DOM order`,equal(restored.order,expected),{expected,actual:restored.order});
      check(`${label}: reload committed storage order`,equal(restored.storedOrder,expected),restored.storage);
      const value=await adapter(`${label}: reload`);
      check(`${label}: reload adapter order`,equal(value.order,expected),value.order);
      return restored;
    };
    const failedState = async (expected,label) => {
      const failed=await settle(expected,label,{allowFailure:true});
      check(`${label}: intended order retained`,equal(failed.order,expected),{expected,actual:failed.order});
      check(`${label}: failed commit did not write`,equal(failed.storedOrder,DEFAULT),failed.storage);
      check(`${label}: failure understandable`,failed.semantic.failure,failed.status);
      check(`${label}: pending ended`,!failed.semantic.pending,failed.status);
      check(`${label}: actual retry is available`,failed.retry.some(r=>!r.disabled && r.rect.width>0 && r.rect.height>0),failed.retry);
      await adapter(label);
      return failed;
    };
    const retry = async (expected,label) => {
      const state=await capture(`${label}: before retry`,expected);
      if (!state.retry.some(r=>!r.disabled && r.rect.width>0 && r.rect.height>0)) {
        check(`${label}: retry activation`,false,state.retry);
        check(`${label}: retry persistence and reload`,false,'Required retry control is absent or inoperable','not-run');
        return false;
      }
      await click('[data-action="retry-save"]',`${label}: retry activation`);
      await capture(`${label}: immediately after retry`,expected);
      await persisted(expected,`${label}: retried`);
      return true;
    };
    const scenario=async (name,run) => {
      current={name,checks:[],timeline:[],adapterReads:[],errors:[],screenshots:[]}; report.scenarios.push(current); await save();
      try {await reset();await run();} catch(error){current.errors.push(errorData(error));check('scenario completed',false,errorData(error));check('remaining dependent observations',false,'Scenario collection stopped after the retained error','not-run');}
      await save();
    };
    const focusByTab = async selector => {
      for(let i=0;i<40;i++){
        if(await evaluate(`document.activeElement?.matches(${JSON.stringify(selector)}) || false`)) return i;
        await pressKey('Tab');
      }
      throw new Error(`Could not reach ${selector} using 40 Tab events`);
    };
    const keyboardMove = async (key,expected,focusJob,focusAction,label) => {
      await pressKey(key);
      const state=await capture(label,expected);
      check(`${label}: key changes intended order`,equal(state.order,expected),{expected,actual:state.order});
      check(`${label}: acted job keeps operable focus`,state.active?.jobId===`JOB-104${focusJob}` && state.active?.action===focusAction && !state.active.disabled,state.active);
      check(`${label}: focused control in viewport`,state.active?.rect.width>0 && state.active.rect.height>0 && state.active.rect.x>=0 && state.active.rect.right<=state.viewport.width+1 && state.active.rect.y>=0 && state.active.rect.bottom<=state.viewport.height+1,state.active);
      return state;
    };
    const shot=async (name,viewport=false) => {await screenshot(name,{captureBeyondViewport:!viewport});current.screenshots.push(name);};
    const geometry=async (label,expected) => {
      const state=await capture(label,expected);
      check(`${label}: no horizontal document overflow`,state.viewport.scrollWidth<=state.viewport.clientWidth+1,state.viewport);
      const bad=state.rows.flatMap(row=>row.controls.filter(c=>['up','down'].includes(c.action) && !c.disabled).filter(c=>c.rect.width<=0 || c.rect.height<=0 || c.rect.x<0 || c.rect.right>state.viewport.width+1 || !(c.ariaLabel || c.text)?.trim()).map(c=>({job:row.id,control:c})));
      check(`${label}: readable enabled move control geometry and name`,bad.length===0,bad);
      const clipped=state.rows.flatMap(row=>row.textGeometry.filter(t=>expectedJobs.some(j=>j.id===row.id && t.text.includes(j.title))).filter(t=>(t.style.lineClamp && t.style.lineClamp!=='none') || (t.style.whiteSpace==='nowrap' && t.scrollWidth>t.clientWidth+1) || (t.style.overflow==='hidden' && t.scrollHeight>t.clientHeight+1)).map(t=>({job:row.id,text:t})));
      check(`${label}: long titles are not clamped or clipped`,clipped.length===0,clipped);
      check(`${label}: all complete titles have geometry`,state.rows.every(row=>row.textGeometry.some(t=>t.rect.width>0 && t.rect.height>0 && expectedJobs.some(j=>j.id===row.id && t.text.includes(j.title)))),state.rows.map(row=>({id:row.id,textGeometry:row.textGeometry})));
      check(`${label}: both direction controls are present`,state.rows.every(row=>['up','down'].every(action=>row.controls.some(c=>c.action===action && c.jobId===row.id))),state.rows.map(row=>({id:row.id,actions:row.controls.map(c=>c.action)})));
      check(`${label}: visible focus screenshot review`,false,'Raw screenshot and focus styles recorded; subjective visual inspection is required','not-run');
      return state;
    };
    await page('Page.addScriptToEvaluateOnNewDocument',{source:`window.__queueObserverErrors=[]; addEventListener('error',e=>window.__queueObserverErrors.push({kind:'error',message:e.message,filename:e.filename,line:e.lineno,column:e.colno})); addEventListener('unhandledrejection',e=>window.__queueObserverErrors.push({kind:'unhandledrejection',message:String(e.reason),stack:e.reason?.stack}));`});

    await scenario('01-ordinary',async()=>{
      await move(3,'up',ORDINARY,'ordinary 3 up'); await persisted(ORDINARY,'ordinary');
    });
    await scenario('02-rapid',async()=>{
      for(const [i,[job,direction]] of [[4,'up'],[4,'up'],[2,'down'],[6,'up']].entries()){
        await move(job,direction,RAPID[i],`rapid ${i+1}: ${job} ${direction}`);if(i<3)await pause(30);
      }
      await persisted(RAPID[3],'rapid');
    });
    await scenario('03-failure-retry',async()=>{
      await click('#fail-next-save','arm failure');await move(3,'up',ORDINARY,'failure 3 up');
      await failedState(ORDINARY,'failed save');await retry(ORDINARY,'failed save');
    });
    await scenario('04-failure-then-newer',async()=>{
      await click('#fail-next-save','arm failure');await move(3,'up',ORDINARY,'failure 3 up');
      const state=await failedState(ORDINARY,'failed before newer move');
      if(!state.semantic.failure || state.semantic.pending) throw new Error('First failure did not settle; post-failure action is not-run');
      await move(4,'up',NEWER,'newer 4 up');await persisted(NEWER,'newer after failure');
    });
    await scenario('05-inflight-failure-newer',async()=>{
      await click('#fail-next-save','arm failure');await move(3,'up',ORDINARY,'inflight failure 3 up');await pause(30);
      await move(4,'up',NEWER,'inflight newer 4 up');
      const final=await settle(NEWER,'inflight failure settlement',{allowFailure:true});
      const newerIndex=current.timeline.findIndex(s=>s.label==='inflight newer 4 up');
      const overwritten=current.timeline.slice(newerIndex).filter(s=>!equal(s.order,NEWER));
      check('older failure never overwrites newer intended DOM order',overwritten.length===0,overwritten.map(s=>({sequence:s.sequence,order:s.order})));
      pendingIntegrity(current.timeline.filter(s=>s.intended && s.label!=='reset'),'inflight failure');
      if(final.semantic.failure && !equal(final.storedOrder,NEWER)) await retry(NEWER,'inflight failure');
      else await persisted(NEWER,'inflight newer');
    });
    await scenario('06-filtered-hidden-neighbor',async()=>{
      await click('#queue-filter','focus search');await page('Input.insertText',{text:'job-1044'});
      const filtered=await capture('filter matches only job 4',DEFAULT);
      check('case-insensitive ID filter shows only job 4',equal(filtered.order,ids([4])),filtered.order);
      await click(moveSelector(4,'up'),'filtered 4 up');
      const moved=await capture('filtered moved visible job',FILTERED);
      check('filtered move retains exactly the matching row',equal(moved.order,ids([4])),moved.order);
      check('filtered row displays full-queue rank 3',/\b3\b/.test((moved.rows[0]?.text || '').replace(/JOB-1044/g,'')),moved.rows[0]?.text);
      await settle(FILTERED,'filtered persistence');
      const beforeClear=await capture('filtered persisted',FILTERED);
      check('hidden neighbor swap committed in full queue',equal(beforeClear.storedOrder,FILTERED),beforeClear.storage);
      await evaluate(`(() => {const e=document.querySelector('#queue-filter');e.value='';e.dispatchEvent(new Event('input',{bubbles:true}));})()`);
      await capture('filter cleared',FILTERED);await persisted(FILTERED,'filtered full queue');
    });
    await scenario('07-keyboard-wide',async()=>{
      await page('Emulation.setDeviceMetricsOverride',{width:1280,height:900,deviceScaleFactor:1,mobile:false});
      await focusByTab(moveSelector(2,'up'));await capture('wide before keyboard',DEFAULT);await shot('wide-before-keyboard.png',true);
      await keyboardMove('Space',ids([2,1,3,4,5,6]),2,'down','Space top boundary fallback');await shot('wide-top-boundary-focus.png',true);
      await keyboardMove('Enter',DEFAULT,2,'down','Enter same-job same-direction');
      await keyboardMove('Space',ids([1,3,2,4,5,6]),2,'down','Space repeated same-job');
      await focusByTab(moveSelector(5,'down'));
      await keyboardMove('Enter',ids([1,3,2,4,6,5]),5,'up','Enter bottom boundary fallback');await shot('wide-bottom-boundary-focus.png',true);
      await keyboardMove('Space',ids([1,3,2,4,5,6]),5,'up','Space from bottom fallback');
      await geometry('wide layout',ids([1,3,2,4,5,6]));await shot('wide-full.png');
      await persisted(ids([1,3,2,4,5,6]),'wide keyboard');
    });
    await scenario('08-keyboard-narrow',async()=>{
      await page('Emulation.setDeviceMetricsOverride',{width:375,height:900,deviceScaleFactor:1,mobile:false});
      await focusByTab(moveSelector(2,'up'));await geometry('narrow before keyboard',DEFAULT);await shot('narrow-before-keyboard.png',true);
      await keyboardMove('Space',ids([2,1,3,4,5,6]),2,'down','narrow Space top boundary fallback');
      await geometry('narrow after keyboard',ids([2,1,3,4,5,6]));await shot('narrow-top-boundary-focus.png',true);await shot('narrow-full.png');
      await persisted(ids([2,1,3,4,5,6]),'narrow keyboard');
    });
    report.runtimeErrors=[...exceptions,...report.scenarios.flatMap(s=>s.timeline.flatMap(t=>t.runtimeErrors || []))];
  });
} catch(error) {report.errors.push(errorData(error));}
finally {
  report.runtimeErrors=[...new Map([...(report.browserExceptions || []),...report.scenarios.flatMap(s=>s.timeline.flatMap(t=>t.runtimeErrors || []))].map(error=>[JSON.stringify(error),error])).values()];
  report.sourceAfter=await sourceHashes();
  report.sourceUnchanged=equal(report.sourceBefore,report.sourceAfter);
  report.completedAt=new Date().toISOString();
  report.scenarioResults=report.scenarios.map(s=>({name:s.name,pass:s.checks.filter(c=>c.status==='pass').length,fail:s.checks.filter(c=>c.status==='fail').length,notRun:s.checks.filter(c=>c.status==='not-run').length,errors:s.errors.length}));
  await save();
}
console.log(JSON.stringify({output,sourceUnchanged:report.sourceUnchanged,collectionErrors:report.errors,scenarioResults:report.scenarioResults},null,2));
process.exitCode=report.errors.length || report.scenarios.some(s=>s.errors.length) ? 2 : 0;
