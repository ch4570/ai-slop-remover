import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const here = path.dirname(fileURLToPath(import.meta.url));
const output = process.argv[2];
if (!output || process.argv.length !== 3) throw new Error('Usage: node classifier-sensitivity.mjs NEW_OUTPUT_JSON');
const source = await readFile(path.join(here, 'observer.mjs'), 'utf8');
const start = source.indexOf('    const classify = state => {');
const end = source.indexOf('    const capture = ', start);
if (start < 0 || end <= start) throw new Error('Frozen observer classifier was not found');
// Exercise the exact classifier declaration from observer.mjs, not a duplicate implementation.
const classify = new Function(source.slice(start, end) + '\nreturn classify;')();
const cases = [
  ['natural Korean completed', '이 브라우저에 순서를 저장했어요.', { pending:false, failure:false, success:true, unknown:false }],
  ['natural Korean pending', '순서를 저장하는 중…', { pending:true, failure:false, success:false, unknown:false }],
  ['all orders still pending', '모든 순서를 저장하는 중', { pending:true, failure:false, success:false, unknown:false }],
  ['unsaved substring', 'unsaved changes', { pending:false, failure:false, success:false, unknown:true }],
  ['explicit English completed', 'Saved successfully', { pending:false, failure:false, success:true, unknown:false }],
  ['known failure', '저장하지 못했어요.', { pending:false, failure:true, success:false, unknown:false }],
  ['unknown wording', '처리 상태 안내', { pending:false, failure:false, success:false, unknown:true }],
];
const results = cases.map(([name,text,expected]) => {
  const actual = classify({status:{text}});
  return {name,text,expected,actual,pass:JSON.stringify(actual)===JSON.stringify(expected)};
});
const evidence = {observerSha256:createHash('sha256').update(source).digest('hex'),purpose:'Bounded sensitivity examples only; not general semantic correctness proof',results};
await writeFile(output, JSON.stringify(evidence,null,2)+'\n', {flag:'wx'});
console.log(JSON.stringify(evidence,null,2));
process.exitCode = results.every(result=>result.pass) ? 0 : 1;
