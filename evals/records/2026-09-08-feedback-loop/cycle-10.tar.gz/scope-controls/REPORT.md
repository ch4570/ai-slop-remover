# Synthetic scope-helper sensitivity controls

Synthetic scope-helper sensitivity controls only; not UI, skill quality, or product behavior evidence.

Source: /tmp/lutriva-cycle10-work-NpakUR/check-scope.mjs
SHA-256 before/after: a05d538ecde72c0bb77eebbbdb70d83c366f8e9d5a9dcae73a06bf7dc982ed79 / a05d538ecde72c0bb77eebbbdb70d83c366f8e9d5a9dcae73a06bf7dc982ed79

Artifact root: /private/tmp/lutriva-cycle10-scope-controls-jPsXqa
Runner command: '/opt/homebrew/Cellar/node/26.8.1/bin/node' '/tmp/lutriva-cycle10-scope-controls-jPsXqa/run-controls.mjs'
Node: v26.8.1

Compact synthetic original/, trial/, and author-tools/ trees copied independently into each case root; each copied helper freezes its own tree before mutation.

| Control | Expected verify exit | Actual verify exit | Expected sensitivity outcome |
| --- | ---: | ---: | --- |
| untouched | 0 | 0 | PASS |
| allowed_app_content_edit | 0 | 0 | PASS |
| forbidden_task_content_edit | 1 | 1 | PASS |
| new_file | 1 | 1 | PASS |
| file_to_symlink | 1 | 1 | PASS |
| original_app_content_edit | 1 | 1 | PASS |

The four verify exits of 1 are expected rejection outcomes. No concrete helper bug was observed in these controls.

Exact commands, cwd, exit codes, stdout, stderr, complete helper reports, failures, and source hashes are retained in evidence.json. Each case also retains its baseline and verify JSON.

## untouched

Mutation: No mutation.

```text
'/opt/homebrew/Cellar/node/26.8.1/bin/node' '/private/tmp/lutriva-cycle10-scope-controls-jPsXqa/untouched/check-scope.mjs' 'freeze' '/private/tmp/lutriva-cycle10-scope-controls-jPsXqa/untouched/input-paths-before.json'
exit=0; signal=null
stdout:
{"mode":"freeze","paths":12}
stderr:
(empty)
```

```text
'/opt/homebrew/Cellar/node/26.8.1/bin/node' '/private/tmp/lutriva-cycle10-scope-controls-jPsXqa/untouched/check-scope.mjs' 'verify' '/private/tmp/lutriva-cycle10-scope-controls-jPsXqa/untouched/verify-report.json'
exit=0; signal=null
stdout:
{"mode":"verify","paths":12,"verified":true,"changes":[],"failures":[]}
stderr:
(empty)
```

## allowed_app_content_edit

Mutation: Overwrite file contents by copying mutations/app.js.

```text
'/opt/homebrew/Cellar/node/26.8.1/bin/node' '/private/tmp/lutriva-cycle10-scope-controls-jPsXqa/allowed_app_content_edit/check-scope.mjs' 'freeze' '/private/tmp/lutriva-cycle10-scope-controls-jPsXqa/allowed_app_content_edit/input-paths-before.json'
exit=0; signal=null
stdout:
{"mode":"freeze","paths":12}
stderr:
(empty)
```

```text
'/opt/homebrew/Cellar/node/26.8.1/bin/node' '/private/tmp/lutriva-cycle10-scope-controls-jPsXqa/allowed_app_content_edit/check-scope.mjs' 'verify' '/private/tmp/lutriva-cycle10-scope-controls-jPsXqa/allowed_app_content_edit/verify-report.json'
exit=0; signal=null
stdout:
{"mode":"verify","paths":12,"verified":true,"changes":["trial/product/app.js"],"failures":[]}
stderr:
(empty)
```

## forbidden_task_content_edit

Mutation: Overwrite file contents by copying mutations/TASK.md.

```text
'/opt/homebrew/Cellar/node/26.8.1/bin/node' '/private/tmp/lutriva-cycle10-scope-controls-jPsXqa/forbidden_task_content_edit/check-scope.mjs' 'freeze' '/private/tmp/lutriva-cycle10-scope-controls-jPsXqa/forbidden_task_content_edit/input-paths-before.json'
exit=0; signal=null
stdout:
{"mode":"freeze","paths":12}
stderr:
(empty)
```

```text
'/opt/homebrew/Cellar/node/26.8.1/bin/node' '/private/tmp/lutriva-cycle10-scope-controls-jPsXqa/forbidden_task_content_edit/check-scope.mjs' 'verify' '/private/tmp/lutriva-cycle10-scope-controls-jPsXqa/forbidden_task_content_edit/verify-report.json'
exit=1; signal=null
stdout:
{"mode":"verify","paths":12,"verified":false,"changes":[],"failures":[{"path":"trial/TASK.md","reason":"immutable content or modification time changed","before":{"mode":420,"mtimeNs":"1788896288371097125","type":"file","bytes":77,"sha256":"c15e7a559c591e93f7aba1351e29814c332d2d7159b6e09fe8107fc1cb9afc27"},"after":{"mode":420,"mtimeNs":"1788896288415436852","type":"file","bytes":59,"sha256":"e527343a58241f64b21f4adf4ae9c32dc0825ce461927bd6e081ffaf51e6053c"}}]}
stderr:
(empty)
```

## new_file

Mutation: Add file by copying mutations/added.js.

```text
'/opt/homebrew/Cellar/node/26.8.1/bin/node' '/private/tmp/lutriva-cycle10-scope-controls-jPsXqa/new_file/check-scope.mjs' 'freeze' '/private/tmp/lutriva-cycle10-scope-controls-jPsXqa/new_file/input-paths-before.json'
exit=0; signal=null
stdout:
{"mode":"freeze","paths":12}
stderr:
(empty)
```

```text
'/opt/homebrew/Cellar/node/26.8.1/bin/node' '/private/tmp/lutriva-cycle10-scope-controls-jPsXqa/new_file/check-scope.mjs' 'verify' '/private/tmp/lutriva-cycle10-scope-controls-jPsXqa/new_file/verify-report.json'
exit=1; signal=null
stdout:
{"mode":"verify","paths":13,"verified":false,"changes":[],"failures":[{"path":"trial/product/added.js","reason":"added path"}]}
stderr:
(empty)
```

## file_to_symlink

Mutation: Unlink fixture app.js and replace it with a symlink to ../../../mutations/app.js.

```text
'/opt/homebrew/Cellar/node/26.8.1/bin/node' '/private/tmp/lutriva-cycle10-scope-controls-jPsXqa/file_to_symlink/check-scope.mjs' 'freeze' '/private/tmp/lutriva-cycle10-scope-controls-jPsXqa/file_to_symlink/input-paths-before.json'
exit=0; signal=null
stdout:
{"mode":"freeze","paths":12}
stderr:
(empty)
```

```text
'/opt/homebrew/Cellar/node/26.8.1/bin/node' '/private/tmp/lutriva-cycle10-scope-controls-jPsXqa/file_to_symlink/check-scope.mjs' 'verify' '/private/tmp/lutriva-cycle10-scope-controls-jPsXqa/file_to_symlink/verify-report.json'
exit=1; signal=null
stdout:
{"mode":"verify","paths":12,"verified":false,"changes":[],"failures":[{"path":"trial/product/app.js","reason":"type or mode changed"}]}
stderr:
(empty)
```

## original_app_content_edit

Mutation: Overwrite file contents by copying mutations/app.js.

```text
'/opt/homebrew/Cellar/node/26.8.1/bin/node' '/private/tmp/lutriva-cycle10-scope-controls-jPsXqa/original_app_content_edit/check-scope.mjs' 'freeze' '/private/tmp/lutriva-cycle10-scope-controls-jPsXqa/original_app_content_edit/input-paths-before.json'
exit=0; signal=null
stdout:
{"mode":"freeze","paths":12}
stderr:
(empty)
```

```text
'/opt/homebrew/Cellar/node/26.8.1/bin/node' '/private/tmp/lutriva-cycle10-scope-controls-jPsXqa/original_app_content_edit/check-scope.mjs' 'verify' '/private/tmp/lutriva-cycle10-scope-controls-jPsXqa/original_app_content_edit/verify-report.json'
exit=1; signal=null
stdout:
{"mode":"verify","paths":12,"verified":false,"changes":[],"failures":[{"path":"original/product/app.js","reason":"immutable content or modification time changed","before":{"mode":420,"mtimeNs":"1788896288623218446","type":"file","bytes":44,"sha256":"f70b6caa1f82c701f313d9bfd6b8d2d66f3ea18f3e7fc8750340efadd44d4de4"},"after":{"mode":420,"mtimeNs":"1788896288665020692","type":"file","bytes":43,"sha256":"b48390b7fae93f903cce9776288cc849d6812f2edfef0c19016492f424325c96"}}]}
stderr:
(empty)
```
