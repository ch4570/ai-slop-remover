import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { copyFileSync, cpSync, mkdirSync, readFileSync, symlinkSync, unlinkSync, writeFileSync } from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const artifactRoot = path.dirname(fileURLToPath(import.meta.url));
const source = '/tmp/lutriva-cycle10-work-NpakUR/check-scope.mjs';
const sha256 = (file) => createHash('sha256').update(readFileSync(file)).digest('hex');
const sourceSha256 = sha256(source);
const quote = (value) => "'" + value.replaceAll("'", "'\\''") + "'";
const invocation = [process.execPath, ...process.argv.slice(1)].map(quote).join(' ');
const cases = [
  { name: 'untouched', expectedExit: 0, target: null, operation: 'No mutation.' },
  { name: 'allowed_app_content_edit', expectedExit: 0, target: 'trial/product/app.js', replacement: 'app.js', operation: 'Overwrite file contents by copying mutations/app.js.' },
  { name: 'forbidden_task_content_edit', expectedExit: 1, target: 'trial/TASK.md', replacement: 'TASK.md', operation: 'Overwrite file contents by copying mutations/TASK.md.' },
  { name: 'new_file', expectedExit: 1, target: 'trial/product/added.js', replacement: 'added.js', operation: 'Add file by copying mutations/added.js.' },
  { name: 'file_to_symlink', expectedExit: 1, target: 'trial/product/app.js', symlink: '../../../mutations/app.js', operation: 'Unlink fixture app.js and replace it with a symlink to ../../../mutations/app.js.' },
  { name: 'original_app_content_edit', expectedExit: 1, target: 'original/product/app.js', replacement: 'app.js', operation: 'Overwrite file contents by copying mutations/app.js.' },
];

function command(argv, cwd) {
  const result = spawnSync(argv[0], argv.slice(1), { cwd, encoding: 'utf8' });
  return {
    argv, command: argv.map(quote).join(' '), cwd,
    exitCode: result.status, signal: result.signal,
    stdout: result.stdout ?? '', stderr: result.stderr ?? '',
    error: result.error ? String(result.error) : null,
  };
}

const outcomes = [];
for (const control of cases) {
  const root = path.join(artifactRoot, control.name);
  mkdirSync(root);
  for (const tree of ['original', 'trial', 'author-tools']) {
    cpSync(path.join(artifactRoot, 'fixture', tree), path.join(root, tree), { recursive: true });
  }
  const helper = path.join(root, 'check-scope.mjs');
  copyFileSync(source, helper);
  const copiedSourceSha256 = sha256(helper);
  const freeze = command([process.execPath, helper, 'freeze', path.join(root, 'input-paths-before.json')], root);
  if (freeze.exitCode !== 0) {
    outcomes.push({ ...control, root, copiedSourceSha256, freeze, sensitivityPassed: false });
    continue;
  }
  if (control.replacement) {
    copyFileSync(path.join(artifactRoot, 'mutations', control.replacement), path.join(root, control.target));
  } else if (control.symlink) {
    unlinkSync(path.join(root, control.target));
    symlinkSync(control.symlink, path.join(root, control.target));
  }
  const verify = command([process.execPath, helper, 'verify', path.join(root, 'verify-report.json')], root);
  const report = JSON.parse(readFileSync(path.join(root, 'verify-report.json'), 'utf8'));
  let contentOutcomeCorrect;
  if (control.name === 'untouched') {
    contentOutcomeCorrect = report.verified && report.changes.length === 0 && report.failures.length === 0;
  } else if (control.expectedExit === 0) {
    contentOutcomeCorrect = report.verified && JSON.stringify(report.changes) === JSON.stringify([control.target]) && report.failures.length === 0;
  } else {
    contentOutcomeCorrect = !report.verified && report.failures.some((failure) => failure.path === control.target);
  }
  outcomes.push({ ...control, root, copiedSourceSha256, freeze, verify,
    report,
    sensitivityPassed: copiedSourceSha256 === sourceSha256 && verify.exitCode === control.expectedExit && contentOutcomeCorrect });
}

const evidence = {
  schema: 1,
  label: 'Synthetic scope-helper sensitivity controls only; not UI, skill quality, or product behavior evidence.',
  artifactRoot, invocation, source, sourceSha256, sourceSha256After: sha256(source),
  nodeVersion: process.version,
  fixture: 'Compact synthetic original/, trial/, and author-tools/ trees copied independently into each case root; each copied helper freezes its own tree before mutation.',
  outcomes,
  allSensitivityControlsPassed: outcomes.every((entry) => entry.sensitivityPassed),
};
writeFileSync(path.join(artifactRoot, 'evidence.json'), JSON.stringify(evidence, null, 2) + '\n', { flag: 'wx' });
const lines = [
  '# Synthetic scope-helper sensitivity controls', '',
  evidence.label, '',
  `Source: ${source}`, `SHA-256 before/after: ${sourceSha256} / ${evidence.sourceSha256After}`, '',
  `Artifact root: ${artifactRoot}`, `Runner command: ${invocation}`, `Node: ${process.version}`, '',
  evidence.fixture, '',
  '| Control | Expected verify exit | Actual verify exit | Expected sensitivity outcome |',
  '| --- | ---: | ---: | --- |',
  ...outcomes.map((entry) => `| ${entry.name} | ${entry.expectedExit} | ${entry.verify?.exitCode ?? 'not run'} | ${entry.sensitivityPassed ? 'PASS' : 'FAIL'} |`), '',
  'The four verify exits of 1 are expected rejection outcomes. No concrete helper bug was observed in these controls.', '',
  'Exact commands, cwd, exit codes, stdout, stderr, complete helper reports, failures, and source hashes are retained in evidence.json. Each case also retains its baseline and verify JSON.', '',
];
for (const entry of outcomes) {
  lines.push(`## ${entry.name}`, '', `Mutation: ${entry.operation}`, '');
  for (const run of [entry.freeze, entry.verify].filter(Boolean)) {
    lines.push('```text', run.command, `exit=${run.exitCode}; signal=${run.signal}`, 'stdout:', run.stdout.trimEnd(), 'stderr:', run.stderr.trimEnd() || '(empty)', '```', '');
  }
}
writeFileSync(path.join(artifactRoot, 'REPORT.md'), lines.join('\n'), { flag: 'wx' });
console.log(JSON.stringify({ artifactRoot, sourceSha256, sourceSha256After: evidence.sourceSha256After, allSensitivityControlsPassed: evidence.allSensitivityControlsPassed, results: outcomes.map((entry) => ({ name: entry.name, expectedExit: entry.expectedExit, actualExit: entry.verify?.exitCode, sensitivityPassed: entry.sensitivityPassed, failures: entry.report?.failures })) }, null, 2));
assert.equal(evidence.sourceSha256After, sourceSha256, 'Original helper source changed during controls');
assert.ok(evidence.allSensitivityControlsPassed, 'One or more sensitivity controls did not match expectations');
