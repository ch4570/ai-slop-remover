# Fixture construction notes — evaluator only

This document is intentionally outside the future trial agent's supplied input. Do not copy or expose it to the trial workspace. The trial input consists of TASK.md, SERVICE_CONTRACT.md, DESIGN.md, index.html, styles.css, product/app.js, and product/service.js. The source is a synthetic local UI fixture, not repository work or a real dispatch system.

Seeded baseline defects:

- Every move starts a new persistence call immediately. Alternating 350 ms / 80 ms service delays cause two quick valid writes to finish out of order, leaving an older order in storage even while the optimistic UI shows the newer one.
- The first completed call claims the queue was saved even if other calls remain pending. No actual aggregate pending state is tracked.
- Every failing call restores its own pre-move snapshot. An older failure can replace more recent optimistic choices, and a later failure may restore an order never successfully saved.
- There is no explicit retry path retaining the most recently intended full order after a failure.
- Each render replaces all job DOM nodes. Keyboard focus on an acted button is lost after reordering.

An ordinary single reorder and save succeeds and survives reload. The existing filter derives visible rows from the full order and moves against that full order. Boundary disabling uses the full queue. All job and nested payload data lives in the immutable service. The visible demo failure is deterministic, one-shot, and resettable with the documented adapter API.

Construction validation is limited to JavaScript syntax and adapter contract smoke checks with an in-memory browser-storage substitute. No trial/fixing agent was run and no assertions or evaluator hooks were added to product files. Browser appearance and actual assistive-technology behavior were not exercised during construction.
