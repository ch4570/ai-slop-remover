# Cycle10 archive map and replay boundaries

work/ contains the complete parent-owned working tree at archive time, including original/, trial/ (seven product/task files plus65 skill files), launch metadata, author evidence, candidate observer output, scope/service checks, parent raw/visual audits and readable product.patch.
observer/ contains the complete evaluator-owned tree, including calibration versions/attempts01–05, exact final frozen tools, final baseline and partial ENOSPC output. Completed historical02/03 raw JSON/JSONL were losslessly compressed to adjacent .gz; work/evidence-compression.jsonl records their hashes and recoverability. Decode without modifying archived originals. Invalid partial04 JSON is deliberately not repaired.
review/ contains the independent source/visual review, post-author supplemental protocol/freeze/script and original/candidate reports. scope-controls/ includes only REPORT.md, evidence.json and run-controls.mjs. Synthetic control directory trees (including an intentional symlink) are not included; their descriptions and raw case results are in those records. construction/CONSTRUCTION.md is evaluator-only seed documentation excluded from the author launch.
archive-tools/ contains this note, the exact archive builder and original-path provenance map. The separate repository inventory covers all archived regular files including provenance. No browser profiles or user data are part of these owned input roots.

The builder streams the exact regular files directly into tar with a declared path-prefix map, without a second large uncompressed staging copy. It hashes originals before and after, preserves failed/partial evidence, and does not change source content. Archive integrity is checked separately against the exact file inventory; it is not proof of every observation or the unavailable full agent transcript.

First verify cycle-10-inventory.json and cycle-10.tar.gz using the repository's check_evidence_archive.py and its separately recorded archive SHA. Extract only into a NEW owned directory, never over the historical paths.

From the extracted root, the final observer uses relative frozen tool paths and can be invoked with existing Node22+ and isolated existing Chrome:

    node observer/observer.mjs work/original /tmp/NEW-original-output
    node observer/observer.mjs work/trial /tmp/NEW-candidate-output

Choose real new output paths instead of these illustrative names. Exit0 means completed collection; inspect scenarioResults, errors, notRun and actual screenshots. The frozen recovery-policy mismatch and clipped focus outline are documented, not fixed in this archive. An archive-relocated browser replay was NOT performed during this cycle.

Historical scripts/metadata retain original absolute paths, not fabricated portable command histories. In particular review/recovery-supplement.mjs imports the original /tmp/lutriva-queue-observer-RAcypp path and validates its files. Its original-source hashes are preserved; a future relocation requires an explicitly recorded adapter/new freeze, not silent editing or extraction over existing originals. Parent audit/smoke/control scripts also have historical bindings. Only the final observer portability described above follows its inspected relative implementation; do not generalize it to every helper.
