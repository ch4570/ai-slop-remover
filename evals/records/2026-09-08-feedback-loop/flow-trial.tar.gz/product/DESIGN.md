# Haneul notes

This synthetic local notes editor helps an operator find and revise Korean notes.
Preserve a compact list beside the editor and stack them below 640px.

| Role | CSS token | Value | Use |
| --- | --- | --- | --- |
| Canvas | `--canvas` | `#f4f7fb` | Page |
| Surface | `--surface` | `#ffffff` | List and editor |
| Text | `--text` | `#172b45` | Headings and body |
| Action | `--action` | `#245ab5` | Primary button and focus |
| Error | `--error` | `#a52b25` | Failed save feedback |
| Gap | `--gap` | `16px` | Related control spacing |

Use the platform system font, visible labels and focus, and wrapping Korean text.
Preserve drafts during failed saves. Success means localStorage has been updated;
there is no server or synchronization. Do not invent either.

The current note uses `li button[aria-current="true"]` in `style.css`, with the
existing canvas background and action-colored leading border. Labels, system
type, visible focus, and the compact responsive layout remain the same.

| Trigger | State and feedback | Recovery | Persistence boundary |
| --- | --- | --- | --- |
| Edit a search | Filter saved notes; replace the current URL's `q`; composition commits before filtering | Clear or revise the query; Back/Forward restores the URL query | URL only; preserve unrelated parameters |
| Save | Capture this note's draft and revision; disable only its save action while pending | Keep editing and selecting notes available | Success follows `localStorage.setItem` using `haneul-eval-notes` |
| Save fails | Preserve the latest draft; display an error and “다시 저장” | Turn off the practice failure checkbox when applicable, then retry the current draft | Failed data is not reported as saved |
| Edit during save | The submitted snapshot is saved; later edits stay in the draft with explicit unsaved feedback | Save again to persist the later changes | Drafts remain in page memory until explicitly saved |
| Select another note | Restore that note's draft and its own status; completed work belongs to the original note | Return to continue the earlier draft or retry its save | Selection does not save or discard a draft |

Enter that confirms title composition is not a save command. The next deliberate
Enter submits with native required-title validation; textarea Enter keeps its
normal newline behavior. Drafts survive note switching within this page, but
unsaved edits do not survive closing or reloading it. No motion was introduced.
