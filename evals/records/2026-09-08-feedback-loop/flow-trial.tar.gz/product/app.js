const storageKey = 'haneul-eval-notes';
const initialNotes = [
  { id: 1, title: '배송 확인', body: '금요일 배송 일정을 확인합니다.' },
  { id: 2, title: '고객 요청', body: '긴 한국어 안내 문구를 검토합니다.' },
  { id: 3, title: '다음 회의', body: '다음 주 회의 내용을 정리합니다.' },
];
const el = id => document.getElementById(id);
let notes = JSON.parse(localStorage.getItem(storageKey) || 'null') || initialNotes;
let selectedId = 1;
const drafts = new Map(notes.map(note => [note.id, {
  value: { ...note },
  revision: 0,
  pending: null,
  feedback: { state: 'idle', message: '' },
}]));
const composing = new Set();
el('query').value = new URL(location.href).searchParams.get('q') || '';

function showStatus(state, message) {
  el('status').dataset.state = state;
  el('status').textContent = message;
}
function renderFeedback() {
  const draft = drafts.get(selectedId);
  el('save').disabled = Boolean(draft.pending);
  el('save').textContent = draft.feedback.state === 'error' && !draft.pending ? '다시 저장' : '메모 저장';
  if (draft.pending) {
    const laterEdits = draft.revision !== draft.pending.revision;
    showStatus('pending', laterEdits
      ? '저장 중… 이후 변경사항은 아직 저장하지 않았습니다.'
      : '저장 중…');
  } else {
    showStatus(draft.feedback.state, draft.feedback.message);
  }
}
function captureDraft() {
  const draft = drafts.get(selectedId);
  if (draft.value.title !== el('title').value || draft.value.body !== el('body').value) {
    draft.value = { id: selectedId, title: el('title').value, body: el('body').value };
    draft.revision += 1;
    if (draft.feedback.state !== 'error') {
      draft.feedback = { state: 'dirty', message: '아직 저장하지 않은 변경사항이 있습니다.' };
    }
  }
}
function openNote(id) {
  captureDraft();
  selectedId = id;
  const note = drafts.get(id).value;
  el('title').value = note.title;
  el('body').value = note.body;
  renderFeedback();
  renderNotes();
}
function renderNotes() {
  const query = el('query').value.trim();
  const matches = notes.filter(note => `${note.title} ${note.body}`.includes(query));
  const existing = new Map([...el('notes').children].map(item => [Number(item.dataset.noteId), item]));
  const matchingIds = new Set(matches.map(note => note.id));
  for (const [id, item] of existing) {
    if (!matchingIds.has(id)) item.remove();
  }
  for (const note of matches) {
    let item = existing.get(note.id);
    if (!item) {
      item = document.createElement('li');
      item.dataset.noteId = note.id;
      const button = document.createElement('button');
      button.type = 'button';
      button.addEventListener('click', () => openNote(note.id));
      item.append(button);
      // Keep result order without replacing controls that may own keyboard focus.
      const next = [...el('notes').children].find(child =>
        matches.findIndex(match => match.id === Number(child.dataset.noteId)) > matches.indexOf(note));
      el('notes').insertBefore(item, next || null);
    }
    const button = item.firstElementChild;
    button.textContent = note.title;
    if (note.id === selectedId) button.setAttribute('aria-current', 'true');
    else button.removeAttribute('aria-current');
  }
  el('count').textContent = matches.length ? `${matches.length}개 메모` : '일치하는 메모가 없습니다. 검색어를 바꿔보세요.';
}
function updateSearch() {
  const url = new URL(location.href);
  if (el('query').value) url.searchParams.set('q', el('query').value);
  else url.searchParams.delete('q');
  history.replaceState(history.state, '', url);
  renderNotes();
}
el('query').addEventListener('compositionstart', () => composing.add('query'));
el('query').addEventListener('compositionend', () => {
  composing.delete('query');
  updateSearch();
});
el('query').addEventListener('input', event => {
  if (!event.isComposing && !composing.has('query')) updateSearch();
});
window.addEventListener('popstate', () => {
  el('query').value = new URL(location.href).searchParams.get('q') || '';
  renderNotes();
});
for (const id of ['title', 'body']) {
  el(id).addEventListener('compositionstart', () => composing.add(id));
  el(id).addEventListener('compositionend', () => {
    composing.delete(id);
    captureDraft();
    renderFeedback();
  });
  el(id).addEventListener('input', () => {
    captureDraft();
    renderFeedback();
  });
}
el('title').addEventListener('keydown', event => {
  if (event.key === 'Enter') {
    if (event.isComposing || composing.has('title') || event.keyCode === 229) return;
    event.preventDefault();
    el('editor').requestSubmit();
  }
});
el('editor').addEventListener('submit', async event => {
  event.preventDefault();
  if (composing.has('title') || composing.has('body')) return;
  const owner = drafts.get(selectedId);
  if (owner.pending) return;
  captureDraft();
  const snapshot = { ...owner.value };
  const revision = owner.revision;
  owner.pending = { revision };
  const shouldFail = el('fail-save').checked;
  renderFeedback();
  try {
    // Yield to input and navigation without an artificial loading delay.
    await new Promise(resolve => setTimeout(resolve, 0));
    if (shouldFail) throw new Error('연습용 저장 실패');
    const updated = notes.map(note => note.id === snapshot.id ? snapshot : note);
    localStorage.setItem(storageKey, JSON.stringify(updated));
    notes = updated;
    owner.feedback = owner.revision === revision
      ? { state: 'success', message: `“${snapshot.title}” 메모를 이 브라우저에 저장했습니다.` }
      : { state: 'dirty', message: '저장을 시작할 때의 내용은 이 브라우저에 저장했습니다. 이후 변경사항은 아직 저장하지 않았습니다.' };
    renderNotes();
  } catch {
    owner.feedback = {
      state: 'error',
      message: shouldFail
        ? '저장하지 못했습니다. 입력한 내용은 유지됩니다. 실패시키기를 해제한 뒤 다시 저장해 주세요.'
        : '이 브라우저에 저장하지 못했습니다. 입력한 내용은 유지됩니다. 브라우저 저장 공간을 확인한 뒤 다시 저장해 주세요.',
    };
  } finally {
    owner.pending = null;
    if (selectedId === snapshot.id) renderFeedback();
  }
});
const firstDraft = drafts.get(selectedId).value;
el('title').value = firstDraft.title;
el('body').value = firstDraft.body;
renderFeedback();
renderNotes();
