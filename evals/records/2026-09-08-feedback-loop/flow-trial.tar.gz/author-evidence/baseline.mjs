import { withBrowser } from '/tmp/lutriva-flow-trial-CEGUMD/browser_harness.mjs';

await withBrowser('/tmp/lutriva-flow-trial-CEGUMD/product', '/tmp/haneul-flow-evidence-8jndT5', async ({origin, page, evaluate, screenshot, pause}) => {
  await page('Page.navigate', {url: origin});
  await pause(100);
  await screenshot('baseline-desktop.png');
  const history = await evaluate(`(() => {
    const before = history.length;
    for (const q of ['배', '배송', '배송 확']) {
      document.getElementById('query').value = q;
      document.getElementById('query').dispatchEvent(new Event('input', {bubbles:true}));
    }
    return {added: history.length - before, count: document.getElementById('count').textContent};
  })()`);
  await evaluate(`(() => {
    document.getElementById('title').value = '실패해도 남아야 하는 초안';
    document.getElementById('fail-save').checked = true;
    document.getElementById('editor').requestSubmit();
  })()`);
  await pause(100);
  const failure = await evaluate(`({title:document.getElementById('title').value, state:document.getElementById('status').dataset.state, status:document.getElementById('status').textContent, storage:localStorage.getItem('haneul-eval-notes')})`);
  await evaluate(`(() => {
    document.getElementById('fail-save').checked = false;
    document.getElementById('title').value = '서울';
    document.getElementById('title').dispatchEvent(new KeyboardEvent('keydown', {key:'Enter', isComposing:true, bubbles:true, cancelable:true}));
  })()`);
  await pause(100);
  const composition = await evaluate(`({state:document.getElementById('status').dataset.state, storage:localStorage.getItem('haneul-eval-notes')})`);
  console.log(JSON.stringify({history, failure, composition}, null, 2));
});
