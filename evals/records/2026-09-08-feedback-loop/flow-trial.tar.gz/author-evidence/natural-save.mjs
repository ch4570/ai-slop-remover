import assert from 'node:assert/strict';
import { withBrowser } from '/tmp/lutriva-flow-trial-CEGUMD/browser_harness.mjs';

await withBrowser('/tmp/lutriva-flow-trial-CEGUMD/product','/tmp/haneul-flow-evidence-8jndT5',async ({origin,page,evaluate,pause}) => {
  await page('Page.navigate',{url:origin});
  await pause(100);
  await evaluate(`document.getElementById('title').focus()`);
  await page('Input.dispatchKeyEvent',{type:'keyDown',key:'a',code:'KeyA',windowsVirtualKeyCode:65,modifiers:4});
  await page('Input.dispatchKeyEvent',{type:'keyUp',key:'a',code:'KeyA',windowsVirtualKeyCode:65,modifiers:4});
  await page('Input.insertText',{text:'실제 타이머로 저장한 메모'});
  await evaluate(`document.getElementById('save').click()`);
  await pause(100);
  assert.equal(await evaluate(`document.getElementById('status').dataset.state`),'success');
  const savedTitle = await evaluate(`document.getElementById('title').value`);
  assert.equal(await evaluate(`JSON.parse(localStorage.getItem('haneul-eval-notes'))[0].title`),savedTitle);
  await page('Page.reload');
  await pause(100);
  assert.equal(await evaluate(`document.getElementById('title').value`),savedTitle);
  console.log('PASS: native Chrome input, unmodified timers, successful localStorage write and reload persistence.');
});
