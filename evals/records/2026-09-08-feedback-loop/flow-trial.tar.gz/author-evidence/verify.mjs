import assert from 'node:assert/strict';
import { withBrowser } from '/tmp/lutriva-flow-trial-CEGUMD/browser_harness.mjs';

await withBrowser('/tmp/lutriva-flow-trial-CEGUMD/product', '/tmp/haneul-flow-evidence-8jndT5', async ({origin, page, evaluate, screenshot, pause, exceptions}) => {
  const checks = [];
  const check = (name, actual, expected) => { assert.deepEqual(actual, expected, name); checks.push(name); };
  const run = code => evaluate(`(() => { const el = id => document.getElementById(id); ${code} })()`);
  const type = (id, value) => run(`el(${JSON.stringify(id)}).value = ${JSON.stringify(value)}; el(${JSON.stringify(id)}).dispatchEvent(new Event('input', {bubbles:true}));`);
  const select = id => run(`document.querySelector('[data-note-id="${id}"] button').click();`);
  const state = () => run(`return {title:el('title').value,body:el('body').value,state:el('status').dataset.state,status:el('status').textContent,disabled:el('save').disabled,button:el('save').textContent};`);
  const stored = () => evaluate(`JSON.parse(localStorage.getItem('haneul-eval-notes'))`);
  const queue = async () => {
    await evaluate(`window.__saves = []; window.__nativeTimeout = window.setTimeout; window.setTimeout = (callback, delay, ...args) => {
      if (delay === 0 || delay === 30) { window.__saves.push(() => callback(...args)); return window.__saves.length; }
      return window.__nativeTimeout(callback, delay, ...args);
    };`);
  };
  const queued = () => evaluate('window.__saves.length');
  const save = () => run(`el('save').click();`);
  const release = index => evaluate(`window.__saves[${index}]()`);
  const ready = async () => {
    for (let i=0; i<100; i++) {
      if (await evaluate(`document.readyState === 'complete' && !!document.getElementById('title')?.value`)) return;
      await pause(20);
    }
    throw new Error('Page did not become ready');
  };

  await page('Page.navigate', {url: `${origin}/?context=keep`});
  await ready();
  await screenshot('final-desktop.png');
  await queue();
  const before = await evaluate('history.length');
  await run(`el('query').focus();`);
  for (const text of ['배', '송', ' 확']) await page('Input.insertText', {text});
  check('Typing search creates no history entries', await evaluate('history.length'), before);
  check('Search result and count agree', await run(`return [el('notes').children.length,el('count').textContent];`), [1, '1개 메모']);
  check('Query preserves unrelated URL parameters', await evaluate(`new URL(location.href).searchParams.get('context')`), 'keep');
  check('Search focus survives filtering', await evaluate('document.activeElement.id'), 'query');
  await type('query', '결과 없음');
  check('Empty search is truthful', await run(`return [el('notes').children.length,el('count').textContent.includes('없습니다')];`), [0,true]);
  await type('query', '');
  check('Clearing search restores notes', await run(`return el('notes').children.length;`), 3);
  await evaluate(`history.pushState({}, '', '?context=keep&q=고객'); dispatchEvent(new PopStateEvent('popstate'));`);
  check('URL query updates input and results', await run(`return [el('query').value,el('notes').children.length];`), ['고객',1]);
  await evaluate('history.back()'); await pause(60);
  check('Back restores search', await run(`return [el('query').value,el('notes').children.length];`), ['',3]);
  await evaluate('history.forward()'); await pause(60);
  check('Forward restores search', await run(`return [el('query').value,el('notes').children.length];`), ['고객',1]);
  await type('query', '');

  await type('title', '실패 중 편집');
  await type('body', '저장을 시작할 때의 본문');
  await run(`el('fail-save').checked = true;`);
  await save();
  check('Pending only disables saving', await run(`return [el('save').disabled, el('title').disabled, el('body').disabled, [...el('notes').querySelectorAll('button')].some(button => button.disabled)];`), [true,false,false,false]);
  await run(`el('editor').requestSubmit();`);
  check('Duplicate submit is ignored', await queued(), 1);
  await type('title', '실패해도 남아야 하는 최신 초안');
  await type('body', '저장 중에도 바꾼 내용이 유지됩니다.');
  await release(0);
  const failed = await state();
  check('Failed save preserves latest title', failed.title, '실패해도 남아야 하는 최신 초안');
  check('Failed save preserves latest body', failed.body, '저장 중에도 바꾼 내용이 유지됩니다.');
  check('Failed save is an error with retry', [failed.state,failed.disabled,failed.button], ['error',false,'다시 저장']);
  check('Failed save has no persisted data', await stored(), null);
  check('Failure checkbox remains checked', await run(`return el('fail-save').checked;`), true);
  await screenshot('failure-desktop.png');
  await page('Emulation.setDeviceMetricsOverride', {width:375,height:850,deviceScaleFactor:1,mobile:false});
  await screenshot('failure-narrow.png');
  check('Narrow error layout has no horizontal overflow', await evaluate('document.documentElement.scrollWidth <= innerWidth'), true);
  await page('Emulation.setDeviceMetricsOverride', {width:1280,height:900,deviceScaleFactor:1,mobile:false});
  await run(`el('fail-save').checked = false;`);
  await save(); await release(1);
  check('Retry persists latest draft', (await stored())[0].title, failed.title);
  check('Retry reports success only after write', (await state()).state, 'success');
  await page('Page.reload'); await ready();
  check('Successful local save survives reload', (await state()).body, failed.body);
  await queue();

  await type('title', '저장한 스냅샷'); await save();
  await type('title', '아직 저장하지 않은 제목'); await type('body', '아직 저장하지 않은 본문');
  await release(0);
  check('In-flight save persists its snapshot', (await stored())[0].title, '저장한 스냅샷');
  const later = await state();
  check('Later edits remain editable and unsaved', [later.title,later.body,later.state,later.disabled], ['아직 저장하지 않은 제목','아직 저장하지 않은 본문','dirty',false]);
  check('Feedback identifies the earlier saved version', later.status.includes('저장을 시작할 때의 내용') && later.status.includes('이후 변경사항'), true);
  await screenshot('later-edits-desktop.png');
  await save(); await release(1);
  check('Follow-up save persists later changes', (await stored())[0].body, later.body);

  await type('title', '다른 메모를 보는 동안 저장'); await save();
  await select(2); await type('title', '고객 요청의 유지할 초안');
  await run(`document.querySelector('[data-note-id="2"] button').focus();`);
  const currentBefore = await state();
  await release(2);
  check('Other note completion leaves current draft and feedback intact', await state(), currentBefore);
  check('Background save preserves selected note keyboard focus', await evaluate(`document.activeElement.closest('li')?.dataset.noteId`), '2');
  await select(1);
  check('Returning to saved note shows its own result', [(await state()).title,(await state()).state], ['다른 메모를 보는 동안 저장','success']);
  await select(2);
  check('Switching restores unsaved note draft', (await state()).title, '고객 요청의 유지할 초안');
  await run(`el('fail-save').checked = true;`); await save();
  await type('body', '실패 대기 중의 최신 본문'); await select(3);
  const thirdBefore = await state(); await release(3);
  check('Background failure leaves current feedback intact', await state(), thirdBefore);
  await select(2);
  check('Returning to failed note preserves draft and retry', [(await state()).body,(await state()).state], ['실패 대기 중의 최신 본문','error']);
  await run(`el('fail-save').checked = false;`);

  await select(1); await type('title','동시 저장 A'); await save();
  await select(2); await type('title','동시 저장 B'); await save();
  await release(5); await release(4);
  check('Reverse completion keeps both notes persisted', (await stored()).slice(0,2).map(note => note.title), ['동시 저장 A','동시 저장 B']);

  const imeStart = await queued();
  await type('title','서울');
  await run(`el('title').dispatchEvent(new KeyboardEvent('keydown', {key:'Enter',isComposing:true,bubbles:true,cancelable:true}));`);
  check('isComposing Enter does not submit', await queued(), imeStart);
  await run(`el('title').dispatchEvent(new CompositionEvent('compositionstart',{bubbles:true})); el('title').dispatchEvent(new KeyboardEvent('keydown',{key:'Enter',bubbles:true,cancelable:true})); el('editor').requestSubmit();`);
  check('Composition lifecycle prevents shortcut and submit', await queued(), imeStart);
  await run(`el('title').dispatchEvent(new CompositionEvent('compositionend',{bubbles:true,data:'서울'})); el('title').dispatchEvent(new KeyboardEvent('keydown',{key:'Enter',keyCode:229,bubbles:true,cancelable:true}));`);
  check('Legacy composition key does not submit', await queued(), imeStart);
  await run(`el('title').focus();`);
  await page('Input.dispatchKeyEvent',{type:'keyDown',key:'Enter',code:'Enter',windowsVirtualKeyCode:13,text:'\r'});
  await page('Input.dispatchKeyEvent',{type:'keyUp',key:'Enter',code:'Enter',windowsVirtualKeyCode:13});
  check('Deliberate keyboard Enter saves once', await queued(), imeStart + 1);
  await release(imeStart);
  check('Deliberate Enter persists composed title', (await stored())[1].title, '서울');
  await type('body','첫 줄'); await run(`el('body').focus(); el('body').setSelectionRange(el('body').value.length,el('body').value.length);`);
  await page('Input.dispatchKeyEvent',{type:'keyDown',key:'Enter',code:'Enter',windowsVirtualKeyCode:13,text:'\r'});
  await page('Input.dispatchKeyEvent',{type:'keyUp',key:'Enter',code:'Enter',windowsVirtualKeyCode:13});
  check('Textarea Enter inserts a newline', (await state()).body, '첫 줄\n');
  check('Textarea Enter does not save', await queued(), imeStart + 1);
  await type('title',''); await save();
  check('Required title prevents invalid persistence', await queued(), imeStart + 1);
  check('Invalid submission preserves body', (await state()).body, '첫 줄\n');

  await type('title','실제 저장 예외');
  await evaluate(`window.__setItem = Storage.prototype.setItem; Storage.prototype.setItem = function() { throw new DOMException('full','QuotaExceededError'); };`);
  await save(); const quotaIndex = (await queued())-1; await release(quotaIndex);
  check('Storage exception is a recoverable error', [(await state()).state,(await state()).title], ['error','실제 저장 예외']);
  await evaluate('Storage.prototype.setItem = window.__setItem');
  await save(); await release(quotaIndex + 1);
  check('Retry after storage exception persists', (await stored())[1].title, '실제 저장 예외');

  await run(`el('query').dispatchEvent(new CompositionEvent('compositionstart',{bubbles:true}));`);
  await type('query','동시');
  check('Search composition keeps interim text out of URL', await evaluate(`new URL(location.href).searchParams.get('q')`), null);
  await run(`el('query').dispatchEvent(new CompositionEvent('compositionend',{bubbles:true,data:'동시'}));`);
  check('Search composition end commits query', await evaluate(`new URL(location.href).searchParams.get('q')`), '동시');
  await type('query','');
  await page('Emulation.setEmulatedMedia',{features:[{name:'prefers-reduced-motion',value:'reduce'}]});
  await page('Emulation.setDeviceMetricsOverride',{width:375,height:850,deviceScaleFactor:1,mobile:false});
  await screenshot('final-narrow.png');
  check('Narrow final layout has no horizontal overflow', await evaluate('document.documentElement.scrollWidth <= innerWidth'), true);
  check('Visible labels keep their associations', await run(`return ['query','title','body'].every(id => !!document.querySelector('label[for="'+id+'"]'));`), true);
  check('No uncaught browser exceptions', exceptions.length, 0);
  console.log(JSON.stringify({passed:checks.length, checks, limitations:['Korean IME events were synthetic; no physical Korean IME or mobile device was exercised.','Pending saves were held by a test-only timer queue; normal successful persistence was also observed in Chrome.']},null,2));
});
