import { mkdir, writeFile } from 'node:fs/promises';
import { withBrowser } from './browser_harness.mjs';

const [product, output] = process.argv.slice(2);
const observations = [];
const checks = [];
const errors = [];
const assert = { equal(actual, expected) {
  checks.push({ case: observations.at(-1)?.case, actual, expected, status: actual === expected ? 'pass' : 'fail' });
} };
try { await withBrowser(product, output, async ({ origin, page, evaluate, pause, screenshot }) => {
  const state = () => evaluate(`({
    title: document.getElementById('title').value,
    body: document.getElementById('body').value,
    status: document.getElementById('status').dataset.state,
    feedback: document.getElementById('status').textContent,
    disabled: document.getElementById('save').disabled,
    notes: JSON.parse(localStorage.getItem('haneul-eval-notes'))
  })`);
  const reset = async () => {
    await page('Page.navigate', { url: origin });
    for (let i = 0; i < 100; i++) {
      try { if (await evaluate(`location.origin === ${JSON.stringify(origin)} && !!document.getElementById('save')`)) break; } catch {}
      await pause(50);
    }
    await evaluate(`localStorage.removeItem('haneul-eval-notes')`);
    await page('Page.reload', { ignoreCache: true });
    await pause(200);
  };
  const settle = async () => {
    // A different note may remain editable before the old note's save finishes.
    // Match the fixture suite's bounded 150ms observation for its 30ms save.
    await pause(150);
    for (let i = 0; i < 100; i++) {
      const observed = await state();
      if (!observed.disabled && observed.status !== 'pending') return observed;
      await pause(20);
    }
    throw new Error('Save did not settle within 2 seconds');
  };
  const edit = `(id, value) => {
    const input = document.getElementById(id);
    input.value = value;
    input.dispatchEvent(new Event('input', { bubbles: true }));
  }`;

  await reset();
  const editingStart = await evaluate(`(() => {
    const edit = ${edit};
    edit('title', '저장 요청한 제목'); edit('body', '저장 요청한 본문');
    document.getElementById('save').click();
    const pending = document.getElementById('status').dataset.state;
    edit('title', '저장 대기 중 새 제목'); edit('body', '저장 대기 중 새 본문');
    return { pending, titleDisabled: document.getElementById('title').disabled,
      bodyDisabled: document.getElementById('body').disabled };
  })()`);
  const editing = await settle();
  observations.push({ case: 'edit-during-save', before: editingStart, after: editing });
  assert.equal(editingStart.titleDisabled, false);
  assert.equal(editingStart.bodyDisabled, false);
  assert.equal(editing.title, '저장 대기 중 새 제목');
  assert.equal(editing.body, '저장 대기 중 새 본문');
  assert.equal(editing.notes.length, 3);
  assert.equal(editing.notes.find(note => note.id === 1).title, '저장 요청한 제목');
  assert.equal(editing.notes.find(note => note.id === 1).body, '저장 요청한 본문');
  await screenshot('edit-during-save.png');
  await evaluate(`document.getElementById('save').click()`);
  const editingSaved = await settle();
  observations.push({ case: 'save-later-edit', after: editingSaved });
  assert.equal(editingSaved.notes.find(note => note.id === 1).title, '저장 대기 중 새 제목');
  assert.equal(editingSaved.notes.find(note => note.id === 1).body, '저장 대기 중 새 본문');

  for (const failure of [false, true]) {
    await reset();
    const switched = await evaluate(`(() => {
      const edit = ${edit};
      edit('title', '첫 메모 저장'); edit('body', '첫 메모 저장 본문');
      document.getElementById('fail-save').checked = ${failure};
      document.getElementById('save').click();
      const pending = document.getElementById('status').dataset.state;
      const second = [...document.querySelectorAll('#notes button')].find(button => button.textContent === '고객 요청');
      const navigationDisabled = second.disabled;
      second.click();
      edit('title', '두 번째 메모 작업'); edit('body', '두 번째 메모 초안');
      return { pending, navigationDisabled };
    })()`);
    const after = await settle();
    observations.push({ case: failure ? 'switch-before-failure' : 'switch-before-success', before: switched, after });
    assert.equal(switched.navigationDisabled, false);
    assert.equal(after.title, '두 번째 메모 작업');
    assert.equal(after.body, '두 번째 메모 초안');
    if (!failure) {
      assert.equal(after.notes.length, 3);
      assert.equal(after.notes.find(note => note.id === 1).title, '첫 메모 저장');
      assert.equal(after.notes.find(note => note.id === 2).title, '고객 요청');
    }
    await screenshot(failure ? 'switch-before-failure.png' : 'switch-before-success.png');
  }
}); } catch (error) { errors.push(String(error)); }
await mkdir(output, { recursive: true });
await writeFile(output + '/interruption.json', JSON.stringify({ observations, checks, errors,
  limits: ['Synthetic input events and bounded local waits.', 'Feedback meaning requires separate review.',
    'This is one product trial, not a skill-version comparison or evidence of general improvement.'] }, null, 2) + '\n');
console.log(JSON.stringify({ observations: observations.length, passed: checks.filter(check => check.status === 'pass').length,
  failed: checks.filter(check => check.status === 'fail').length, errors, output }));
if (errors.length || checks.some(check => check.status === 'fail')) process.exitCode = 1;
