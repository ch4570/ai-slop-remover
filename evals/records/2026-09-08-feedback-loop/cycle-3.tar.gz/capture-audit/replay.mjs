import { writeFile } from 'node:fs/promises';
import path from 'node:path';
import { claimBrowserEvidence, withBrowser } from '../visual/browser_harness.mjs';

const trial = path.resolve(process.argv[2]);
const root = path.resolve(process.argv[3]);
for (const [label, product] of [['original', 'original-product'], ['result', 'product']]) {
  const output = path.join(root, label);
  const heights = [800, 864];
  await claimBrowserEvidence(output, heights.flatMap(height => ['viewport-before', 'full-page', 'viewport-after'].map(mode => `${height}-${mode}.png`)));
  const observations = [];
  await withBrowser(path.join(trial, product), output, async ({ origin, page, call, evaluate, pause, exceptions }) => {
    const environment = { browser: (await call('Browser.getVersion')).product, node: process.version, origin };
    const measure = () => evaluate(`(() => {
      const button = document.querySelector('button'), table = document.querySelector('.table-scroll');
      const b = button.getBoundingClientRect(), t = table.getBoundingClientRect(), s = getComputedStyle(button);
      return { active: document.activeElement.dataset.order, focusVisible: button.matches(':focus-visible'),
        button: { left:b.left, right:b.right, top:b.top, bottom:b.bottom },
        outline:s.outline, outlineOffset:s.outlineOffset,
        clip:{ left:t.left + table.clientLeft, right:t.left + table.clientLeft + table.clientWidth },
        scrollLeft:table.scrollLeft, scrollMax:table.scrollWidth - table.clientWidth,
        documentWidth:document.documentElement.scrollWidth, documentHeight:document.documentElement.scrollHeight,
        viewport:{ width:innerWidth, height:innerHeight }, scrollY,
        status:document.getElementById('detail').textContent };
    })()`);
    const press = async (key, keyCode) => {
      await page('Input.dispatchKeyEvent', {type:'keyDown', key, code:key, windowsVirtualKeyCode:keyCode, ...(key === 'Enter' ? {text:'\r', unmodifiedText:'\r'} : {})});
      await page('Input.dispatchKeyEvent', {type:'keyUp', key, code:key, windowsVirtualKeyCode:keyCode});
    };
    for (const height of heights) {
      await page('Emulation.setDeviceMetricsOverride', {width:320, height, deviceScaleFactor:1, mobile:false});
      const old = await evaluate('performance.timeOrigin');
      await page('Page.navigate', {url:origin + '/compare.html'});
      let ready = false;
      for (let attempt = 0; attempt < 100; attempt++) {
        try { ready = await evaluate(`location.origin === ${JSON.stringify(origin)} && performance.timeOrigin !== ${old} && document.readyState === 'complete' && !!document.querySelector('[data-order="M-101"]')`); } catch {}
        if (ready) break;
        await pause(40);
      }
      if (!ready) throw Error('Comparison document did not load');
      await evaluate(`(() => { const elements = [...document.querySelectorAll('body, body *')]; const sizes = elements.map(element => parseFloat(getComputedStyle(element).fontSize)); elements.forEach((element, i) => element.style.fontSize = (sizes[i] * 2) + 'px'); })()`);
      for (let step = 0; step < 6; step++) {
        if (await evaluate("document.activeElement.dataset.order === 'M-101'")) break;
        await press('Tab', 9);
      }
      await press('Enter', 13);
      const before = await measure();
      const captures = [];
      for (const [mode, captureBeyondViewport] of [['viewport-before', false], ['full-page', true], ['viewport-after', false]]) {
        const result = await page('Page.captureScreenshot', {format:'png', captureBeyondViewport});
        const png = Buffer.from(result.data, 'base64');
        const filename = `${height}-${mode}.png`;
        await writeFile(path.join(output, filename), png);
        captures.push({ mode, captureBeyondViewport, filename, png:{width:png.readUInt32BE(16),height:png.readUInt32BE(20)}, after:await measure() });
      }
      observations.push({width:320, height, fontScale:2, mobile:false, before, captures});
    }
    await writeFile(path.join(output, 'browser.json'), JSON.stringify({environment, observations, exceptions}, null, 2) + '\n');
    console.log(JSON.stringify({output, observations:observations.map(observation => ({height:observation.height, captures:observation.captures.map(capture => ({mode:capture.mode, png:capture.png, geometryUnchanged:JSON.stringify(observation.before) === JSON.stringify(capture.after)}))})), exceptions}));
  });
}
