확인 결과, 이번 조건에서 `captureBeyondViewport:true` 이미지는 실제 viewport의 포커스 잘림을 가립니다.

- 원본 320×864와 결과물 320×800: `button.right=291.1875`, outline·offset 합계 5px, clipping 경계 `288px`로 오른쪽 포커스 선이 넘칩니다. viewport PNG에는 잘림이 보이고 full-page PNG에는 온전한 선이 보입니다.
- 같은 상태에서 `viewport → full-page → viewport`를 연속 촬영해도 동일합니다. 두 문제 조건 모두 전후 측정값이 같고, 처음·마지막 viewport PNG의 SHA-256도 같습니다. 실행 간 차이로 설명할 수 없는 캡처 결과 차이입니다.
- 추가 관찰: 원본 320×800에서는 첫 viewport까지 `scrollLeft=353`으로 포커스가 들어맞았지만, full-page 캡처 직후 `338`로 바뀌었고 마지막 viewport에 잘림이 생겼습니다. 캡처 직후 측정의 필요성을 보여주지만 Chrome 내부 원인은 확인하지 않았습니다.

새 독립 재현 자료:

- [helper](/tmp/lutriva-capture-audit-uaNEiD/capture-sequence.mjs)
- [원본 JSON](/tmp/lutriva-capture-audit-uaNEiD/original/browser.json), [결과물 JSON](/tmp/lutriva-capture-audit-uaNEiD/result/browser.json)
- 원본: [viewport](/tmp/lutriva-capture-audit-uaNEiD/original/864-viewport-before.png), [full-page](/tmp/lutriva-capture-audit-uaNEiD/original/864-full-page.png)
- 결과물: [viewport](/tmp/lutriva-capture-audit-uaNEiD/result/800-viewport-before.png), [full-page](/tmp/lutriva-capture-audit-uaNEiD/result/800-full-page.png)

실행 명령은 `node /tmp/lutriva-capture-audit-uaNEiD/capture-sequence.mjs`였으며 exit 0, browser exceptions 0입니다. 기존 출력 보존 때문에 재실행에는 helper의 output root를 새 경로로 지정해야 합니다.

저장소 영향은 좁게 표현하는 것이 맞습니다. [공통 helper](/Users/rex/Desktop/personal/lutriva/scripts/browser_harness.mjs:114)는 모든 이미지를 full-page로 찍고, [search-editor keyboard.png](/Users/rex/Desktop/personal/lutriva/scripts/run_browser_checks.mjs:152)와 [scope keyboard.png](/Users/rex/Desktop/personal/lutriva/scripts/run_scope_checks.mjs:155)가 이를 사용합니다. [기존 테스트](/Users/rex/Desktop/personal/lutriva/tests/test_browser_checks.py:58)는 동작 JSON과 증거 보존을 검사하지만 PNG 픽셀·포커스 clipping을 검증하지 않습니다. 다만 현재 기본 375×844 시나리오의 keyboard.png가 실제로 틀렸다는 재현은 수행하지 않았습니다.

좁은 권고: 포커스·잘림 판정용 이미지는 viewport 캡처를 명시하고 캡처 직전·직후 geometry를 함께 저장하세요. full-page는 문서 전체 참고 이미지로 구분하는 편이 타당합니다. 이번 결과는 Chrome 152.0.7977.76, `mobile:false`, CSS computed font-size 2배 조건이며 실제 브라우저 줌·OS 글자 크기나 다른 브라우저까지 일반화하지 않습니다. 제품·저장소·스킬·기존 evidence는 수정하지 않았습니다.
