import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import http from 'node:http';
import path from 'node:path';
import { spawn } from 'node:child_process';

const trial = '/tmp/lutriva-copy-state-trial-Sn1Klr';
const evidence = '/tmp/lutriva-copy-state-check-eBjX9x';
const product = path.join(trial, 'product');
const pause = ms => new Promise(resolve => setTimeout(resolve, ms));
const report = { checks: [], snapshots: [], limitations: ['No download link activation or OS download completion test.', 'No physical mobile device or screen-reader test.', 'Text scaling uses a temporary root font-size override in the isolated browser.'] };
const pass = name => { report.checks.push(name); process.stdout.write(`PASS ${name}\n`); };
const files = async dir => (await Promise.all((await fs.readdir(dir, { withFileTypes: true })).map(async entry => entry.isDirectory() ? (await files(path.join(dir, entry.name))).map(name => path.join(entry.name, name)) : [entry.name]))).flat().sort();
const original = path.join(trial, 'original-product');
const fileNames = await files(product);
assert.deepEqual(fileNames, await files(original));
const allowedKeys = ['save_action', 'save_pending', 'save_success', 'save_failed', 'export_action', 'export_pending', 'export_ready', 'export_failed', 'download_action'];
for (const name of fileNames) {
  if (name !== 'locales/ko.json') assert.equal(await fs.readFile(path.join(product, name), 'utf8'), await fs.readFile(path.join(original, name), 'utf8'), name);
}
const before = JSON.parse(await fs.readFile(path.join(original, 'locales/ko.json'), 'utf8'));
const copy = JSON.parse(await fs.readFile(path.join(product, 'locales/ko.json'), 'utf8'));
assert.deepEqual(Object.keys(copy), Object.keys(before));
const changed = Object.keys(copy).filter(key => copy[key] !== before[key]);
assert.deepEqual(changed, allowedKeys);
for (const key of Object.keys(copy)) {
  assert.equal(typeof copy[key], 'string');
  assert.deepEqual(copy[key].match(/\{\w+\}/g) || [], before[key].match(/\{\w+\}/g) || [], key);
}
pass('Only the nine authorized Korean values changed; all keys, interpolation variables, other values and files preserved');

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, 'http://localhost');
    const relative = decodeURIComponent(url.pathname === '/' ? '/index.html' : url.pathname);
    const file = path.resolve(product, '.' + relative);
    if (!file.startsWith(product + path.sep)) { res.writeHead(403); return res.end(); }
    const body = await fs.readFile(file);
    res.setHeader('Content-Type', ({ '.html': 'text/html', '.js': 'text/javascript', '.json': 'application/json', '.css': 'text/css' })[path.extname(file)] || 'application/octet-stream');
    res.end(body);
  } catch { res.writeHead(404); res.end(); }
});
await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
const base = `http://127.0.0.1:${server.address().port}`;
const profile = await fs.mkdtemp(path.join(evidence, 'chrome-profile-'));
const chrome = spawn('/Applications/Google Chrome.app/Contents/MacOS/Google Chrome', [
  '--headless=new', '--remote-debugging-port=0', `--user-data-dir=${profile}`, '--no-first-run', '--no-default-browser-check',
  '--disable-background-networking', '--disable-component-update', '--disable-sync', '--disable-default-apps', '--disable-extensions',
  '--safebrowsing-disable-auto-update', '--host-resolver-rules=MAP * ~NOTFOUND, EXCLUDE localhost, EXCLUDE 127.0.0.1', 'about:blank'
], { stdio: ['ignore', 'ignore', 'pipe'] });
let browserLog = '';
chrome.stderr.on('data', data => { browserLog += data; });
let socket;
try {
  let devtools;
  for (let i = 0; i < 150; i++) {
    try { devtools = (await fs.readFile(path.join(profile, 'DevToolsActivePort'), 'utf8')).trim().split('\n'); break; } catch { await pause(100); }
  }
  assert.ok(devtools, browserLog);
  socket = new WebSocket(`ws://127.0.0.1:${devtools[0]}${devtools[1]}`);
  await new Promise((resolve, reject) => { socket.addEventListener('open', resolve, { once: true }); socket.addEventListener('error', reject, { once: true }); });
  let nextId = 1;
  const pending = new Map();
  const runtimeErrors = [];
  socket.addEventListener('message', event => {
    const message = JSON.parse(event.data);
    if (message.method === 'Runtime.exceptionThrown') runtimeErrors.push(message.params.exceptionDetails);
    if (message.id) {
      const task = pending.get(message.id);
      if (!task) return;
      pending.delete(message.id);
      clearTimeout(task.timer);
      if (message.error) task.reject(new Error(JSON.stringify(message.error))); else task.resolve(message.result);
    }
  });
  const send = (method, params = {}, sessionId) => new Promise((resolve, reject) => {
    const id = nextId++;
    const timer = setTimeout(() => { pending.delete(id); reject(new Error(`CDP timeout: ${method}`)); }, 10000);
    pending.set(id, { resolve, reject, timer });
    socket.send(JSON.stringify({ id, method, params, ...(sessionId ? { sessionId } : {}) }));
  });
  report.browser = await send('Browser.getVersion');
  await send('Browser.setDownloadBehavior', { behavior: 'deny' });
  const { targetId } = await send('Target.createTarget', { url: 'about:blank' });
  const { sessionId } = await send('Target.attachToTarget', { targetId, flatten: true });
  const page = (method, params = {}) => send(method, params, sessionId);
  const evaluate = async expression => {
    const result = await page('Runtime.evaluate', { expression, awaitPromise: true, returnByValue: true });
    if (result.exceptionDetails) throw new Error(JSON.stringify(result.exceptionDetails));
    return result.result.value;
  };
  const until = async expression => {
    for (let i = 0; i < 100; i++) { if (await evaluate(expression)) return; await pause(20); }
    const debug = await evaluate(`({ url: location.href, title: document.title, body: document.body?.innerText, html: document.documentElement.outerHTML.slice(0, 5000) })`);
    throw new Error(`Condition timeout: ${expression}\n${JSON.stringify({debug, runtimeErrors})}`);
  };
  await page('Page.enable');
  await page('Runtime.enable');
  const resize = async width => page('Emulation.setDeviceMetricsOverride', { width, height: 900, deviceScaleFactor: 1, mobile: false });
  const capture = async name => {
    const metrics = await page('Page.getLayoutMetrics');
    const size = metrics.cssContentSize;
    const screenshot = await page('Page.captureScreenshot', { format: 'png', captureBeyondViewport: true, clip: { x: 0, y: 0, width: size.width, height: size.height, scale: 1 } });
    await fs.writeFile(path.join(evidence, `${name}.png`), Buffer.from(screenshot.data, 'base64'));
    const snapshot = await evaluate(`(() => {
      const ids = ['save', 'save-status', 'export', 'export-status', 'download'];
      return { viewport: innerWidth, scrollWidth: document.documentElement.scrollWidth, rootFontSize: getComputedStyle(document.documentElement).fontSize,
        items: ids.map(id => { const el = document.getElementById(id); const box = el.getBoundingClientRect(); const range = document.createRange(); range.selectNodeContents(el); return { id, text: el.textContent, hidden: el.hidden, state: el.dataset.state || null, width: box.width, height: box.height, textRects: [...range.getClientRects()].map(rect => ({left: rect.left, right: rect.right, top: rect.top, bottom: rect.bottom})), box: {left: box.left, right: box.right, top: box.top, bottom: box.bottom} }; }) };
    })()`);
    assert.ok(snapshot.scrollWidth <= snapshot.viewport, `${name}: page overflow`);
    for (const item of snapshot.items.filter(item => !item.hidden)) {
      for (const rect of item.textRects) {
        assert.ok(rect.left >= item.box.left - 1 && rect.right <= item.box.right + 1, `${name}: ${item.id} horizontal clipping`);
        assert.ok(rect.top >= item.box.top - 1 && rect.bottom <= item.box.bottom + 1, `${name}: ${item.id} vertical clipping`);
      }
    }
    report.snapshots.push({ name, ...snapshot });
    return snapshot;
  };
  await resize(1000);
  report.navigation = await page('Page.navigate', { url: base });
  await until(`document.documentElement.dataset.ready === 'true'`);
  assert.equal(await evaluate(`document.getElementById('save').textContent`), copy.save_action);
  assert.equal(await evaluate(`document.getElementById('export').textContent`), copy.export_action);
  await capture('desktop-idle');
  pass('Desktop initial action labels rendered from the changed locale');

  const savedTitle = '가족과 함께 떠날 가을 여행의 준비물과 주말 장보기 계획을 정리하는 긴 메모 제목 — "준비물" <확인> ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  const failedTitle = savedTitle + ' — 아직 저장하지 못한 수정 내용';
  await resize(320);
  const initialStore = await evaluate(`localStorage.getItem('daon-draft-notes')`);
  assert.equal(initialStore, null);
  const savePending = await evaluate(`(() => { const input = document.getElementById('title'); input.value = ${JSON.stringify(savedTitle)}; document.getElementById('save').click(); return { state: document.getElementById('save-status').dataset.state, text: document.getElementById('save-status').textContent, disabled: [input.disabled, document.getElementById('save').disabled], stored: localStorage.getItem('daon-draft-notes') }; })()`);
  assert.equal(savePending.state, 'pending');
  assert.equal(savePending.text, copy.save_pending.replace('{title}', savedTitle));
  assert.deepEqual(savePending.disabled, [true, true]);
  assert.equal(savePending.stored, null);
  report.savePending = savePending;
  await until(`document.getElementById('save-status').dataset.state === 'success'`);
  const savedNotes = await evaluate(`JSON.parse(localStorage.getItem('daon-draft-notes'))`);
  assert.deepEqual(savedNotes, [{ id: 1, title: savedTitle }, { id: 2, title: '다음 주 일정' }]);
  assert.equal(await evaluate(`document.getElementById('save-status').textContent`), copy.save_success.replace('{title}', savedTitle));
  await capture('320-save-success-long-title');
  pass('Save pending accurately precedes localStorage update; success stores only the first title and retains the second note');

  await evaluate(`document.getElementById('title').value = ${JSON.stringify(failedTitle)}; document.getElementById('fail-save').checked = true; document.getElementById('save').click();`);
  await until(`document.getElementById('save-status').dataset.state === 'error'`);
  assert.equal(await evaluate(`document.getElementById('save-status').textContent`), copy.save_failed.replace('{title}', failedTitle));
  assert.equal(await evaluate(`document.getElementById('title').value`), failedTitle);
  assert.deepEqual(await evaluate(`[document.getElementById('title').disabled, document.getElementById('save').disabled]`), [false, false]);
  assert.deepEqual(await evaluate(`JSON.parse(localStorage.getItem('daon-draft-notes'))`), savedNotes);
  await capture('320-save-failed-long-title');
  pass('Synthetic save failure preserves the edited title, enables editing and retry, and leaves saved data unchanged');

  const exportPending = await evaluate(`(() => { document.getElementById('export').click(); return { state: document.getElementById('export-status').dataset.state, text: document.getElementById('export-status').textContent, disabled: document.getElementById('export').disabled, linkHidden: document.getElementById('download').hidden }; })()`);
  assert.equal(exportPending.state, 'pending');
  assert.equal(exportPending.text, copy.export_pending.replace('{count}', '2'));
  assert.equal(exportPending.disabled, true);
  assert.equal(exportPending.linkHidden, true);
  report.exportPending = exportPending;
  await until(`document.getElementById('export-status').dataset.state === 'ready'`);
  const preparedFile = await evaluate(`(async () => { const a = document.getElementById('download'); const response = await fetch(a.href); const blob = await response.blob(); const bytes = Array.from(new Uint8Array(await blob.arrayBuffer())); return { href: a.href, filename: a.download, linkText: a.textContent, hidden: a.hidden, type: blob.type, bytes }; })()`);
  assert.ok(preparedFile.href.startsWith('blob:'));
  assert.equal(preparedFile.filename, '개인 메모.csv');
  assert.equal(preparedFile.hidden, false);
  assert.equal(preparedFile.linkText, copy.download_action.replace('{filename}', preparedFile.filename));
  assert.deepEqual(preparedFile.bytes.slice(0, 3), [239, 187, 191]);
  const csv = Buffer.from(preparedFile.bytes).toString('utf8');
  const expectedCsv = '\ufefftitle\r\n' + savedNotes.map(note => '"' + note.title.replaceAll('"', '""') + '"').join('\r\n');
  assert.equal(csv, expectedCsv);
  assert.ok(!csv.includes('아직 저장하지 못한 수정 내용'));
  assert.equal(await evaluate(`document.getElementById('export-status').textContent`), copy.export_ready.replace('{filename}', preparedFile.filename));
  report.preparedFile = { ...preparedFile, bytes: preparedFile.bytes.length, utf8Bom: true, csv };
  await fs.writeFile(path.join(evidence, 'prepared-file-bytes.csv'), Buffer.from(preparedFile.bytes));
  await capture('320-export-ready-save-failed');
  const tree = await page('Accessibility.getFullAXTree');
  report.accessibleControls = tree.nodes.filter(node => ['button', 'link', 'status'].includes(node.role?.value)).map(node => ({ role: node.role.value, name: node.name?.value || '', ignored: node.ignored }));
  for (const label of [copy.save_action, copy.export_action, preparedFile.linkText]) assert.ok(report.accessibleControls.some(node => node.name === label && !node.ignored), label);
  pass('Export prepares an exposed, named CSV link and UTF-8 BOM bytes from saved titles, excluding the failed edit; download was not activated');

  await evaluate(`document.getElementById('fail-export').checked = true; document.getElementById('export').click();`);
  await until(`document.getElementById('export-status').dataset.state === 'error'`);
  assert.equal(await evaluate(`document.getElementById('export-status').textContent`), copy.export_failed.replace('{filename}', preparedFile.filename));
  assert.deepEqual(await evaluate(`[document.getElementById('download').hidden, document.getElementById('download').hasAttribute('href'), document.getElementById('export').disabled]`), [true, false, false]);
  await capture('320-both-failures-long-title');
  await evaluate(`document.documentElement.style.fontSize = '200%'`);
  await capture('320-both-failures-long-title-200percent-text');
  await evaluate(`document.documentElement.style.fontSize = ''`);
  pass('Synthetic export failure hides the old link and enables retry; both long failure messages fit at 320px and simulated 200% text');

  await evaluate(`document.getElementById('fail-save').checked = false; document.getElementById('title').value = ${JSON.stringify(savedTitle + ' — 수정 후 재시도')}; document.getElementById('save').focus();`);
  assert.equal(await evaluate(`document.activeElement.id`), 'save');
  await page('Input.dispatchKeyEvent', { type: 'keyDown', key: 'Enter', code: 'Enter', text: '\r', unmodifiedText: '\r', windowsVirtualKeyCode: 13, nativeVirtualKeyCode: 36 });
  await page('Input.dispatchKeyEvent', { type: 'keyUp', key: 'Enter', code: 'Enter', windowsVirtualKeyCode: 13, nativeVirtualKeyCode: 36 });
  await until(`document.getElementById('save-status').dataset.state === 'success'`);
  assert.equal(await evaluate(`JSON.parse(localStorage.getItem('daon-draft-notes'))[0].title`), savedTitle + ' — 수정 후 재시도');
  await evaluate(`document.getElementById('fail-export').checked = false; document.getElementById('export').click();`);
  await until(`document.getElementById('export-status').dataset.state === 'ready'`);
  const retryCsv = await evaluate(`(async () => await (await fetch(document.getElementById('download').href)).text())()`);
  assert.ok(retryCsv.includes('수정 후 재시도'));
  await capture('320-save-and-export-retry-success');
  await evaluate(`document.documentElement.style.fontSize = '200%'`);
  await capture('320-ready-long-title-200percent-text');
  await evaluate(`document.documentElement.style.fontSize = ''`);
  pass('Editing and retrying save using Enter succeeds after clearing the synthetic failure; export retry prepares the updated title');

  await page('Page.reload');
  await until(`document.documentElement.dataset.ready === 'true'`);
  assert.equal(await evaluate(`document.getElementById('title').value`), savedTitle + ' — 수정 후 재시도');
  assert.equal(await evaluate(`document.getElementById('download').hidden`), true);
  pass('Same-browser reload restores the saved title; the temporary download link is not restored');
  assert.deepEqual(runtimeErrors, []);
  pass('No runtime exceptions observed in the exercised normal, synthetic-failure, and recovery flows');
  await fs.writeFile(path.join(evidence, 'report.json'), JSON.stringify(report, null, 2) + '\n');
  process.stdout.write(`EVIDENCE ${evidence}\n`);
  await send('Browser.close').catch(() => {});
} catch (error) {
  report.failure = error.stack;
  await fs.writeFile(path.join(evidence, 'report.json'), JSON.stringify(report, null, 2) + '\n');
  throw error;
} finally {
  socket?.close();
  chrome.kill('SIGTERM');
  await new Promise(resolve => server.close(resolve));
}
