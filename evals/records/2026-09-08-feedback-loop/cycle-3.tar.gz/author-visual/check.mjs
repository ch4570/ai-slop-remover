import fs from 'node:fs/promises';
import assert from 'node:assert/strict';

const evidence = '/tmp/lutriva-visual-density-evidence-2Qk5jT';
const product = '/tmp/lutriva-visual-density-trial-jTupaf/product';
const phase = process.argv[2] ?? 'before';
const socket = new WebSocket('ws://127.0.0.1:62364/devtools/browser/6e24c219-9806-48b6-a012-4ab787274628');
await new Promise(resolve => socket.addEventListener('open', resolve, { once: true }));
let sequence = 0;
const pending = new Map();
socket.addEventListener('message', event => {
  const response = JSON.parse(event.data);
  if (!response.id) return;
  const entry = pending.get(response.id);
  pending.delete(response.id);
  if (response.error) entry.reject(new Error(JSON.stringify(response.error)));
  else entry.resolve(response.result);
});
function send(method, params = {}, sessionId) {
  return new Promise((resolve, reject) => {
    const id = ++sequence;
    pending.set(id, { resolve, reject });
    socket.send(JSON.stringify({ id, method, params, ...(sessionId ? { sessionId } : {}) }));
  });
}
const { targetId } = await send('Target.createTarget', { url: 'about:blank' });
const { sessionId } = await send('Target.attachToTarget', { targetId, flatten: true });
const command = (method, params = {}) => send(method, params, sessionId);
async function evaluate(expression) {
  const response = await command('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true });
  if (response.exceptionDetails) throw new Error(JSON.stringify(response.exceptionDetails));
  return response.result.value;
}
async function key(key, code, windowsVirtualKeyCode, modifiers = 0) {
  await command('Input.dispatchKeyEvent', { type: 'keyDown', key, code, windowsVirtualKeyCode, modifiers, ...(key === 'Enter' ? { text: '\r', unmodifiedText: '\r' } : key === ' ' ? { text: ' ', unmodifiedText: ' ' } : {}) });
  await command('Input.dispatchKeyEvent', { type: 'keyUp', key, code, windowsVirtualKeyCode, modifiers });
}
async function screenshot(name) {
  const { data } = await command('Page.captureScreenshot', { format: 'png' });
  await fs.writeFile(`${evidence}/${phase}-${name}.png`, Buffer.from(data, 'base64'));
}
await command('Page.enable');
const reports = [];
const scenarios = phase === 'before'
  ? [{ width: 1280 }, { width: 320 }]
  : [{ width: 1280 }, { width: 390 }, { width: 320 }, { width: 320, long: true }, { width: 320, scale: 1.5 }, { width: 320, scale: 2 }, { width: 1280, scale: 2 }];
try {
  for (const page of ['master', 'compare']) {
    for (const scenario of scenarios) {
      const name = `${page}-${scenario.width}${scenario.long ? '-long-customer' : ''}${scenario.scale ? `-text-${scenario.scale * 100}` : ''}`;
      await command('Emulation.setDeviceMetricsOverride', { width: scenario.width, height: 800, deviceScaleFactor: 1, mobile: false });
      await command('Page.navigate', { url: `file://${product}/${page}.html` });
      await evaluate(`new Promise(resolve => { if (document.readyState === 'complete') resolve(); else window.addEventListener('load', resolve, { once: true }); })`);
      if (scenario.long) await evaluate(`document.querySelector('tbody tr td:nth-child(2)').textContent = '김민지 · 모아생활용품 서울특별시 성동구 성수동 고객지원 공동구매 담당자';`);
      if (scenario.scale) await evaluate(`{ const elements = [...document.querySelectorAll('body, body *')]; const sizes = elements.map(element => parseFloat(getComputedStyle(element).fontSize)); elements.forEach((element, index) => element.style.fontSize = (sizes[index] * ${scenario.scale}) + 'px'); }`);
      const dimensions = await evaluate(`(() => {
        const scroll = document.querySelector('.table-scroll');
        const button = document.querySelector('button');
        const bodyCell = document.querySelector('tbody td');
        const style = getComputedStyle(bodyCell);
        return { width: innerWidth, documentWidth: document.documentElement.scrollWidth, scrollWidth: scroll.scrollWidth, clientWidth: scroll.clientWidth, overflowX: getComputedStyle(scroll).overflowX, cellPadding: style.paddingBlockStart, bodyRowHeight: document.querySelector('tbody tr').getBoundingClientRect().height, tableHeight: document.querySelector('table').getBoundingClientRect().height, fontSize: style.fontSize, buttonWidth: button.getBoundingClientRect().width, buttonHeight: button.getBoundingClientRect().height, headerCount: document.querySelectorAll('th').length, rowCount: document.querySelectorAll('tbody tr').length };
      })()`);
      assert.equal(dimensions.headerCount, 5);
      assert.equal(dimensions.rowCount, 3);
      assert.equal(dimensions.overflowX, 'auto');
      assert.equal(dimensions.cellPadding, page === 'compare' && phase === 'after' ? '8px' : '16px');
      assert.ok(dimensions.buttonHeight >= 24 && dimensions.buttonWidth >= 24);
      await screenshot(name);
      const focus = [];
      for (let step = 0; step < 9; step++) {
        await key('Tab', 'Tab', 9);
        const active = await evaluate(`(() => { const element = document.activeElement; const rectangle = element.getBoundingClientRect(); const container = document.querySelector('.table-scroll').getBoundingClientRect(); const style = getComputedStyle(element); return { tag: element.tagName, text: element.textContent, order: element.dataset.order ?? null, focusVisible: element.matches(':focus-visible'), outlineStyle: style.outlineStyle, outlineWidth: style.outlineWidth, outlineColor: style.outlineColor, scrollLeft: document.querySelector('.table-scroll').scrollLeft, left: rectangle.left, right: rectangle.right, top: rectangle.top, bottom: rectangle.bottom, containerLeft: container.left, containerRight: container.right }; })()`);
        if (!active.order) continue;
        assert.equal(active.focusVisible, true);
        assert.equal(active.outlineWidth, '3px');
        assert.equal(active.outlineStyle, 'solid');
        await key('Enter', 'Enter', 13);
        const status = await evaluate(`document.querySelector('#detail').textContent`);
        assert.equal(status, `${active.order} 주문을 선택했습니다.`);
        focus.push({ ...active, status });
        if (focus.length === 1) await screenshot(`${name}-focus`);
        if (focus.length === 3) break;
      }
      assert.deepEqual(focus.map(entry => entry.order), ['M-101', 'M-102', 'M-103']);
      await key('Tab', 'Tab', 9, 8);
      assert.equal(await evaluate(`document.activeElement.dataset.order`), 'M-102');
      await key(' ', 'Space', 32);
      assert.equal(await evaluate(`document.querySelector('#detail').textContent`), 'M-102 주문을 선택했습니다.');
      const scrollCoverage = await evaluate(`(() => { const scroll = document.querySelector('.table-scroll'); scroll.scrollLeft = 0; const left = scroll.scrollLeft; scroll.scrollLeft = scroll.scrollWidth; const right = scroll.scrollLeft; const box = scroll.getBoundingClientRect(); const cells = [...document.querySelectorAll('tbody tr:first-child td')].map(cell => { const rect = cell.getBoundingClientRect(); return { text: cell.textContent, left: rect.left, right: rect.right, width: rect.width }; }); return { left, right, maximum: scroll.scrollWidth - scroll.clientWidth, boxLeft: box.left, boxRight: box.right, cells }; })()`);
      assert.equal(scrollCoverage.right, scrollCoverage.maximum);
      const report = { name, dimensions, focus, reverseTabAndSpace: 'passed', scrollCoverage };
      reports.push(report);
      console.log(JSON.stringify({ name, dimensions, focusOrder: focus.map(entry => entry.order), reverseTabAndSpace: 'passed', scrollLeftOnFirstFocus: focus[0].scrollLeft, maxScroll: scrollCoverage.maximum }));
    }
  }
  await fs.writeFile(`${evidence}/${phase}-report.json`, JSON.stringify(reports, null, 2) + '\n');
} finally {
  await send('Target.closeTarget', { targetId });
  socket.close();
}
