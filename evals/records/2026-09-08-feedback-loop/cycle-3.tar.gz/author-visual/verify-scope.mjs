import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
const root = '/tmp/lutriva-visual-density-trial-jTupaf';
const evidence = '/tmp/lutriva-visual-density-evidence-2Qk5jT';
const originalFiles = (await fs.readdir(`${root}/original-product`)).sort();
const files = (await fs.readdir(`${root}/product`)).sort();
assert.deepEqual(files, originalFiles);
const changed = [];
for (const name of files) {
  const before = await fs.readFile(`${root}/original-product/${name}`, 'utf8');
  const after = await fs.readFile(`${root}/product/${name}`, 'utf8');
  if (before !== after) changed.push(name);
  if (name === 'compare.css') {
    assert.equal(after, before.replace('padding-block: 16px', 'padding-block: 8px'));
  } else if (name === 'DESIGN.md') {
    const strip = text => text.replace(/(?<=<!-- comparison-exception:start -->)[\s\S]*?(?=<!-- comparison-exception:end -->)/, '');
    assert.equal(strip(before), strip(after));
    const region = after.match(/<!-- comparison-exception:start -->([\s\S]*?)<!-- comparison-exception:end -->/)[1];
    assert.equal((region.match(/```css/g) ?? []).length, 1);
    const css = region.match(/```css\n([\s\S]*?)\n```/)[1];
    assert.equal(css, (await fs.readFile(`${root}/product/compare.css`, 'utf8')).trim());
  } else {
    assert.equal(after, before, `${name} must remain unchanged`);
  }
}
assert.deepEqual(changed, ['DESIGN.md', 'compare.css']);
const sameMasterCaptures = [];
for (const width of [1280, 320]) {
  const digest = async phase => createHash('sha256').update(await fs.readFile(`${evidence}/${phase}-master-${width}.png`)).digest('hex');
  const before = await digest('before');
  const after = await digest('after');
  assert.equal(before, after, `master ${width}px screenshot changed`);
  sameMasterCaptures.push({ width, sha256: after });
}
const report = { status: 'passed', changed, productFilesUnchangedExceptAllowedScope: true, designOutsideMarkersUnchanged: true, documentedRuleMatchesCode: true, sameMasterCaptures };
await fs.writeFile(`${evidence}/scope-report.json`, JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify(report, null, 2));
