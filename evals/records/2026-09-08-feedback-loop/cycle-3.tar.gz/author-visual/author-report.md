# 주문 비교 화면 밀도 예외 작업 보고

제품 경로: `/tmp/lutriva-visual-density-trial-jTupaf/product`

`ui-visual-refine`의 범위 유지·페이지 예외 기록·실제 화면 검증 지침을 적용했다. 비교 표의 셀 세로 여백만 줄이고 기존 표 구조와 공통 토큰을 유지했다.

## 최종 변경 범위

- `product/compare.css`: 기존 `.comparison-table th, .comparison-table td` 규칙의 `padding-block: 16px` 값만 `8px`로 변경했다.
- `product/DESIGN.md`: `comparison-exception:start`와 `comparison-exception:end` 사이에 예외 이유, 적용 페이지·선택자, 실제 CSS 규칙 한 블록, 공통 기준 상속 및 재검토 조건을 기록했다.
- 새 제품 파일·선택자·선언은 없다. `master.html`, `compare.html`, `tokens.css`, `components.css`, `app.js`와 DESIGN의 마커 밖 내용은 원본과 동일하다.
- TASK, skills, original-product는 수정하지 않았다. 커밋·push·PR·패키지 설치·글로벌 설정 변경 명령을 수행하지 않았다.

## 확인한 결과

Chrome의 기본 글꼴 16px 조건에서 비교 표 본문 행 높이는 76.59375px에서 60.59375px로 16px 줄었다. 머리글과 본문 3행을 합친 표 높이는 288.375px에서 224.375px로 64px 줄었다. 행 버튼은 85.5625×43.59375px로 유지됐다. 실제 데이터는 3행이므로 많은 행이 추가된 화면은 만들지 않았다.

기본 주문 표는 16px 셀 여백과 기존 행 높이를 유지했다. 기본 화면 1280×800 및 320×800의 변경 전후 PNG는 각각 SHA-256이 일치했다.

기본·비교 화면 각각 1280×800, 390×800, 320×800에서 실제 렌더링과 키보드 동작을 실행했다. 두 화면의 세 버튼 모두 Tab으로 순서대로 접근해 Enter로 선택 상태 문구를 확인했고, 마지막 버튼에서 Shift+Tab 후 Space로 두 번째 주문 선택을 확인했다. 기본 글꼴에서 주황색 3px 포커스 선이 보이며 좁은 화면에서는 포커스 이동 시 표가 오른쪽으로 스크롤된다.

320px에서 기본·비교 표의 내용 너비는 386px, 표 내부 가용 너비는 286px이다. 표 내부에서 0부터 100px까지 가로 스크롤되며 열과 행 작업에 접근할 수 있다. 페이지 전체 너비는 320px이다.

긴 고객명은 브라우저 DOM에서 첫 고객 셀만 임시로 `김민지 · 모아생활용품 서울특별시 성동구 성수동 고객지원 공동구매 담당자`로 교체했다. 제품 데이터는 바꾸지 않았다. 두 화면의 표 내용 너비가 811px로 늘고 표 내부 최대 스크롤은 525px가 됐다. 세 행의 키보드 선택은 계속 동작했다. 기존 `white-space: nowrap` 때문에 긴 이름을 한 번에 볼 수 없어 수평 이동이 필요하다.

150%·200% 글꼴 확대는 실제 브라우저의 텍스트 확대 설정이 아니라 각 요소의 기존 computed fontSize를 읽고 DOM 인라인 스타일로 각각 1.5배·2배 지정한 스트레스 검사다. 320px에서 두 배율을, 1280px에서 200%를 검사했다. 텍스트 확대 상태의 세 행 선택과 역방향 Tab·Space 동작은 통과했으나, 아래 포커스 노출 문제를 발견했다.

## 해결하지 않은 포커스 노출 문제

320×800, deviceScaleFactor: 1, mobile: false, 200% 임시 글꼴 확대라는 **동일한 조건에서는 원본의 첫 버튼 포커스가 온전히 보이고 수정본은 Enter 실행 후 오른쪽이 일부 가려진다.** 이번 밀도 변경으로 이 조건에서 새로 드러난 한계이며, 포커스 회귀가 없다고 판정할 수 없다.

수정본에서 최초 문서 높이는 800px이고 Enter로 상태 문구가 길어지면 806px로 늘어난다. 그때 세로 스크롤바가 생겨 표의 가용 너비는 286→271px, 최대 가로 스크롤은 338→353px로 바뀌지만 현재 scrollLeft는 338px에 남는다. 첫 버튼의 오른쪽 좌표 291.1875px가 표 오른쪽 289px보다 약 2.19px 바깥에 있어 버튼 테두리와 포커스 선 일부가 잘린다. 버튼의 키보드 실행과 상태 문구는 정상이다.

원본도 화면 높이 864px에서 같은 메커니즘을 재현한다(문서 864→870px, 표 286→271px, scrollLeft 338/max 353). 이는 원래 레이아웃에도 존재하는 스크롤바 발생 메커니즘의 근거이며, 원본 800px 조건과 수정본 800px 조건이 동일하다는 뜻은 아니다. 수정본 864px 조건에서는 문제가 재현되지 않는다.

네 조건 모두 표 위에서 실제 CDP mouseWheel 수평 입력을 보내 오른쪽 끝까지 이동하면 버튼과 포커스가 온전히 복구됐다. 허용 범위는 셀 padding 값과 문서 예외 구역뿐이므로 스크롤·행 로직이나 공통 CSS를 수정하지 않았다. 특정 화면 높이에서만 현상을 피하려고 padding을 다시 고르지 않았다.

## 실행 명령과 증거

다음 명령은 해당 제품 스냅샷에서 실행됐다. 스크립트와 PNG·JSON은 모두 이 증거 폴더에 있고 제품·스킬 폴더에는 없다.

```sh
node /tmp/lutriva-visual-density-evidence-2Qk5jT/check.mjs before
node /tmp/lutriva-visual-density-evidence-2Qk5jT/check.mjs after
node /tmp/lutriva-visual-density-evidence-2Qk5jT/probe.mjs
node /tmp/lutriva-visual-density-evidence-2Qk5jT/verify-scope.mjs
diff -ru original-product product
```

- `check.mjs before`: 4조건 통과, `before-report.json`.
- `check.mjs after`: 14조건의 치수·행 선택·역방향 키보드 검사 통과, `after-report.json`. 이 스크립트의 최초 포커스 치수는 Enter 이전 값이므로 실행 후 가림 현상의 통과 근거가 아니다.
- `probe.mjs`: 원본·수정본 × 화면 높이 800·864의 네 조건에서 Enter 전후와 수평 휠 복구 치수를 기록, 복구 검사 통과, `probe-report.json`.
- `verify-scope.mjs`: 허용된 두 위치만 변경, 문서 CSS와 실제 CSS 일치, 기본 화면 두 캡처 동일 검사 통과, `scope-report.json`.
- `diff -ru`: 위 CSS 값과 DESIGN 마커 내부 차이만 출력했다. 종료코드 1은 차이가 있다는 diff의 정상 반환이다.
- 최초 `check.mjs before` 실행은 CDP Enter 이벤트에 CR 텍스트가 빠져 상세 선택 assertion이 실패했다. 검증 보조 스크립트의 keyDown에 `text`와 `unmodifiedText`를 CR로 지정한 후 변경 전 검사를 다시 실행해 통과했고, 그 뒤 제품을 수정했다.

직접 열어 본 PNG: `before-compare-1280.png`, `before-compare-320-focus.png`, `before-master-1280.png`, `after-compare-1280.png`, `after-compare-320.png`, `after-compare-320-focus.png`, `after-compare-320-long-customer.png`, `after-compare-320-long-customer-focus.png`, `after-compare-320-text-150-focus.png`, `after-compare-320-text-200.png`, `after-compare-320-text-200-focus.png`, `after-master-320-focus.png`, `after-master-320-text-200-focus.png`, `probe-product-800-recovered.png`.

## 정확한 재현 조건

사용 브라우저: `Google Chrome 152.0.7977.76` (`--version`으로 확인). Node: `v26.8.1`.

Chrome 실행 명령:

```sh
'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome' --headless=new --disable-gpu --disable-background-networking --disable-component-update --disable-default-apps --disable-sync --no-first-run --no-default-browser-check --remote-debugging-port=0 --remote-allow-origins=http://localhost --user-data-dir=/tmp/lutriva-visual-density-evidence-2Qk5jT/chrome-profile about:blank
```

서버는 띄우지 않았다. `file:///tmp/lutriva-visual-density-trial-jTupaf/product/{master,compare}.html`과 좁은 포커스 문제 재현용 original-product/compare.html을 열었다. CDP WebSocket은 `ws://127.0.0.1:62364/devtools/browser/6e24c219-9806-48b6-a012-4ab787274628`였다. 스크립트를 재실행할 때는 새 Chrome의 WebSocket 주소로 갱신해야 한다.

포커스 문제의 Emulation 설정은 `{ width: 320, height: 800, deviceScaleFactor: 1, mobile: false }`이다. 원본 메커니즘 재현에는 height만 864로 바꿨다. 페이지 로드 완료 후 실행한 임시 글꼴 확대:

```js
const elements = [...document.querySelectorAll('body, body *')];
const sizes = elements.map(element => parseFloat(getComputedStyle(element).fontSize));
elements.forEach((element, index) => element.style.fontSize = (sizes[index] * 2) + 'px');
```

키 순서는 Tab(모아 주문) → Tab(비교) → Tab(`button[data-order="M-101"]`) → Enter다. 각 키는 CDP `Input.dispatchKeyEvent`의 keyDown/keyUp으로 전송했다. Enter는 key/code=`Enter`, windowsVirtualKeyCode: 13, keyDown text/unmodifiedText=`\r`로 보냈다. 복구에는 `Input.dispatchMouseEvent` type=`mouseWheel`, x: 220, y=`buttonTop+20`, deltaX: 1000, deltaY: 0을 사용했다.

이 Chrome은 `Browser.close`로 종료했고 최초 실행 세션의 종료코드 0을 확인했다. 원래 사용 중인 브라우저 프로필은 사용하지 않았다. 임시 chrome-profile은 남아 있지만 증거로 필요한 파일은 위 명시한 스크립트·보고서·PNG·JSON이며 프로필을 보관할 필요는 없다.

## 미검증 및 실행 환경 한계

실제 모바일 기기·터치, 다른 브라우저, 브라우저 자체 텍스트 확대/페이지 400% 확대, 스크린리더 읽기는 미검증이다. 임시 글꼴 확대와 CSS viewport 검사를 실제 기기 검증이나 전체 WCAG 준수 판정으로 간주하지 않았다. 제품에 빌드·테스트 스크립트는 없으며 새 패키지를 설치하지 않았다.

외부 검색이나 외부 서비스 API를 호출하지 않았다. 다만 위 Chrome 플래그는 외부 네트워크 격리의 증거가 아니다. Chrome 종료 시 수집된 stderr에는 GCM 등록의 `DEPRECATED_ENDPOINT` 오류와 GoogleUpdater 자동 실행/종료 로그가 있었다. 이 브라우저의 백그라운드 네트워크 및 전역 자동 동작 전체가 차단됐다고 주장하지 않는다.
