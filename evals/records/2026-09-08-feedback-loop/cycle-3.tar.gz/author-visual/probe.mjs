import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
const evidence = '/tmp/lutriva-visual-density-evidence-2Qk5jT';
const socket = new WebSocket('ws://127.0.0.1:62364/devtools/browser/6e24c219-9806-48b6-a012-4ab787274628');
await new Promise(resolve => socket.addEventListener('open', resolve, { once: true }));
let id = 0;
const pending = new Map();
socket.addEventListener('message', ({ data }) => { const response = JSON.parse(data); if (!response.id) return; const entry = pending.get(response.id); pending.delete(response.id); response.error ? entry.reject(response.error) : entry.resolve(response.result); });
function send(method, params = {}, sessionId) { return new Promise((resolve, reject) => { const sequence = ++id; pending.set(sequence, { resolve, reject }); socket.send(JSON.stringify({ id: sequence, method, params, ...(sessionId ? { sessionId } : {}) })); }); }
const { targetId } = await send('Target.createTarget', { url: 'about:blank' });
const { sessionId } = await send('Target.attachToTarget', { targetId, flatten: true });
const command = (method, params) => send(method, params ?? {}, sessionId);
const evaluate = async expression => (await command('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true })).result.value;
const press = async (key, code, windowsVirtualKeyCode) => { await command('Input.dispatchKeyEvent', { type: 'keyDown', key, code, windowsVirtualKeyCode, ...(key === 'Enter' ? { text: '\r', unmodifiedText: '\r' } : {}) }); await command('Input.dispatchKeyEvent', { type: 'keyUp', key, code, windowsVirtualKeyCode }); };
const measure = () => evaluate(`(() => { const element = document.querySelector('button'); const box = element.getBoundingClientRect(); const scroll = document.querySelector('.table-scroll'); const area = scroll.getBoundingClientRect(); return { focusedOrder: document.activeElement.dataset.order, focusVisible: element.matches(':focus-visible'), buttonLeft: box.left, buttonRight: box.right, buttonTop: box.top, buttonBottom: box.bottom, scrollLeft: scroll.scrollLeft, maximum: scroll.scrollWidth - scroll.clientWidth, areaLeft: area.left, areaRight: area.right, scrollClient: scroll.clientWidth, documentWidth: document.documentElement.scrollWidth, documentHeight: document.documentElement.scrollHeight, viewportHeight: innerHeight, status: document.querySelector('#detail').textContent }; })()`);
const reports = [];
await command('Page.enable');
try {
  for (const directory of ['product', 'original-product']) {
    for (const height of [800, 864]) {
      await command('Emulation.setDeviceMetricsOverride', { width: 320, height, deviceScaleFactor: 1, mobile: false });
      await command('Page.navigate', { url: `file:///tmp/lutriva-visual-density-trial-jTupaf/${directory}/compare.html` });
      await evaluate(`new Promise(resolve => { if (document.readyState === 'complete') resolve(); else window.addEventListener('load', resolve, { once: true }); })`);
      await evaluate(`{ const elements = [...document.querySelectorAll('body, body *')]; const sizes = elements.map(element => parseFloat(getComputedStyle(element).fontSize)); elements.forEach((element, index) => element.style.fontSize = (sizes[index] * 2) + 'px'); }`);
      for (let step = 0; step < 6 && await evaluate(`document.activeElement.dataset.order`) !== 'M-101'; step++) await press('Tab', 'Tab', 9);
      const before = await measure();
      await press('Enter', 'Enter', 13);
      const after = await measure();
      assert.equal(after.status, 'M-101 주문을 선택했습니다.');
      await command('Input.dispatchMouseEvent', { type: 'mouseWheel', x: 220, y: after.buttonTop + 20, deltaX: 1000, deltaY: 0 });
      await evaluate(`new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve)))`);
      const recovered = await measure();
      assert.equal(recovered.scrollLeft, recovered.maximum);
      assert.ok(recovered.buttonLeft - 5 > recovered.areaLeft);
      assert.ok(recovered.buttonRight + 5 < recovered.areaRight);
      const { data } = await command('Page.captureScreenshot', { format: 'png' });
      await fs.writeFile(`${evidence}/probe-${directory}-${height}-recovered.png`, Buffer.from(data, 'base64'));
      const report = { directory, height, before, after, recovered };
      console.log(JSON.stringify(report));
      reports.push(report);
    }
  }
  await fs.writeFile(`${evidence}/probe-report.json`, JSON.stringify(reports, null, 2) + '\n');
} finally { await send('Target.closeTarget', { targetId }); socket.close(); }
