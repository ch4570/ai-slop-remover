# 세 번째 피드백 사이클 고정 자료

기준 소스는 `1fe742d`, 실행일은 2026-09-09 KST다. 현재 스킬을 별도 새
문맥에서 실제 합성 과업에 적용하고 결과를 부모가 재검증했다. 두 에이전트는
각 과업의 TASK·원본 제품·스킬 snapshot만 받았으며 예상 답이나 부모의 검사
소스는 제공하지 않았다. 모델·reasoning은 부모 설정 상속, 별도 모델 식별자와
비공개 sampling 값은 추정하지 않았다. 실행은 `snapshot-direct`이며 설치된
호스트 명시 호출·자동 발견·스킬 버전 비교·반복 평가는 아니다.

`copy/skills/`와 `visual/skills/`는 각각 65개 파일이며 `1fe742d`와 바이트가
일치했다. 제품의 원본/결과 및 TASK는 각 폴더에 있고, 부모의 범위 검사와
해시는 `copy-scope.json`, `visual-scope.json`이다. 최종 바이트 비교는 중간의
임시 쓰기 부재를 인증하지 않는다. 전체 에이전트 transcript는 포함하지 않는다.

## 문구 과업

`copy/`는 브라우저 임시 저장과 CSV 링크 준비를 하는 합성 메모 화면이다.
작성자 `/root/copy_state_trial`은 허용한 한국어 값 9개만 바꾸고 키·문자열별
변수·나머지 locale·원본 동작/스타일/접근성 연결을 유지했다. 부모의 별도
`check-copy-states.mjs`는 원본과 결과 모두 20개 상태/데이터 단언 통과,
수집 오류 0개를 기록했다. 원본의 잘못된 문구도 이 단언은 통과하므로 자동
상태 검사를 문구 정확성의 근거로 세지 않았다.

부모는 source, 상태별 실제 문자열, 접근 가능한 행동 이름, 원본 넓은 화면과
결과의 320px 실패·파일 준비 화면을 대조했다. 결과는 클라우드/다른 기기
저장 약속, 진행 중의 완료 단정, 1초 예상, 로그인/관리자 권한/실패 원인
추측을 제거했다. 브라우저에 제목을 임시 저장하는 범위, 입력 유지와 재시도,
CSV 생성과 아직 누르지 않은 다운로드 링크를 정확히 구분한다. 긴 제목을
포함한 핵심 안내와 다운로드 행동은 확인한 이미지에서 잘리지 않고 줄바꿈됐다.
단일 행 입력의 전체 제목이 한 화면에 동시에 보인다는 뜻은 아니다.

작성자 자체 보고와 9개 검사 묶음은 `copy/author-report.md`, `author-copy/`에
별도로 보존했다. 자체 검사 수를 부모의 20개에 더하지 않는다. CSV 자료는
Blob을 읽어 보존한 바이트이며 다운로드 링크는 누르지 않았다. 기기 파일 저장,
실물 기기·스크린리더, 오류를 내는 모든 저장소 조건은 미검증이다. 브라우저
확대와 구분한 작성자의 임시 200% 글자 확대는 기존 CSS의 단어 중간 줄바꿈도
보고했다. 현재 지침에서 추가할 실패 근거가 없어 범용 문구 규칙을 늘리지 않았다.

## 밀도 과업과 남은 회귀

`visual/`은 기존 master-page-consistency TASK에 320px·긴 고객명·큰 글자
확인을 추가한 과업이다. `/root/visual_density_trial`은 compare.css의
padding-block 16→8px와 DESIGN의 허용 예외 구역만 수정했다. 부모 범위 검사와
기존 collector의 최종 두 행동 검사는 통과했다. 부모가 넓은 전후 이미지에서
브랜드·열 정렬·행 행동을 유지한 밀도 변화를 확인했다. 작성자 측정에서 본문
행 높이는 약 76.6→60.6px이고 기본 화면의 두 전후 캡처는 동일했다.

추가 조건에서는 전체 보존 통과가 아니다. 부모가 별도 Chrome에서 측정한
Tab→첫 행 Enter 이후 상태는 다음과 같다. 같은 열은 같은 실행 조건이다.

| 제품 | 320×800, CSS 글자 200% | 320×864, CSS 글자 200% |
| --- | --- | --- |
| 원본 | 오른쪽 포커스 보임 | 일부 잘림 |
| 결과 | 일부 잘림 | 오른쪽 포커스 보임 |

글자 확대는 모든 요소의 기존 computed fontSize를 한 번 읽고 각각 2배로
지정했다. deviceScaleFactor 1, mobile false다. 상태 문구 증가로 세로 스크롤바가
생기면 표 가용 너비가 286→271px로 줄어든다. 가로 scrollLeft는 338px인데
최대치는 353px가 되고, 버튼 오른쪽 291.1875px 및 포커스 외곽선이 clipping
경계 288px를 넘는다. 표의 수평 휠 이동은 복구됐으나 키보드만으로 복구하는
경로까지 검증한 것은 아니다.

작성자는 이 문제를 먼저 발견했다. 부모는 다른 높이의 원본 재현을 같은
조건의 보존 근거로 쓰면 안 된다는 비교 기준을 피드백했고, 최종 보고서는
800px 조건에서 새로 드러난 회귀를 명시했다. 이 뒤 제품은 더 수정하지 않았다.
허용된 padding 값을 한 높이의 실패만 피해 고르거나 범위 밖 공통 CSS/행 동작을
고치지 않았다. 밀도 개선은 관찰했지만 결과를 회귀 없는 향상으로 채택하지 않는다.

`visual/*-focus-evidence/`는 첫 전체 페이지 캡처 시도이고,
`visual/*-focus-viewport-evidence/`는 viewport 캡처로 교정한 최종 자료다.
두 방식의 helper를 모두 보존했다. 부모가 실제 viewport PNG에서 위 잘림과
정상 조건을 확인했다. 첫 전체 페이지 PNG를 최종 포커스 판정으로 쓰지 않는다.

## 피드백에서 찾은 수집기 결함

전체 페이지 캡처는 이 사례의 잘린 포커스를 온전하게 그렸다. 별도 검토자
`/root/capture_viewport_audit`가 같은 상태에서 viewport→full-page→viewport를
연속 촬영했다. 원본 864px·결과 800px의 geometry는 모든 단계에서 같고 첫/끝
viewport PNG 해시도 같았으나 full-page PNG만 잘림을 가렸다. 원본 800px에서는
full-page 촬영 후 scrollLeft가 353→338px로 바뀌어 다음 viewport가 잘리기도
했다. Chrome 내부 원인을 단정하지 않는다.

`capture-audit/`에는 원문 보고와 원본 helper·JSON·PNG가 있다. `replay.mjs`는
원래 helper에서 import 경로와 입력/출력 root 세 줄만 이식 가능한 인자로
바꾼 사본이다. 일반적인 스크린샷의 진위·모든 브라우저 동작을 증명하지 않는다.

실제 저장소 수정은 두 드라이버의 keyboard.png만 viewport 모드로 바꾸고
공통 helper에 선택 인자를 추가한다. 기존 전체 페이지 overview는 유지한다.
키보드 이미지를 찍는 시점의 실제 화면 영역을 보존하는 수정이지, 모든 overview
부작용·포커스 결함·접근성 적합성을 해결하거나 인증하는 수정은 아니다.

`keyboard-regression/`의 수정 전 검색 키보드 PNG는 375×1100, scope 키보드
PNG는 375×1332였다. 수정 후 둘 다 375×844다. overview의 전후 크기는 그대로다.
새 검사는 실제 PNG IHDR을 읽으며 모든 픽셀의 의미나 포커스 가시성을 자동
판정하지 않는다. `before-tools/`는 새 회귀 검사에 기준 버전의 세 수집기
파일을 놓은 것, `final-tools/`는 최종 수정 수집기와 같은 검사다.

## 재현

기존 Chrome·Node 22+·Python 3.9+가 필요하다. 출력은 매번 새 임시 경로를 쓴다.
압축 루트에서 다음은 모두 종료 0이었다.

```sh
node check-trial-scope.mjs copy copy
node check-trial-scope.mjs visual visual
node copy/check-copy-states.mjs copy/original-product /tmp/new-copy-before
node copy/check-copy-states.mjs copy/product /tmp/new-copy-after
node visual/check-focus-threshold.mjs visual/original-product /tmp/new-focus-before
node visual/check-focus-threshold.mjs visual/product /tmp/new-focus-after
node capture-audit/replay.mjs visual /tmp/new-capture-audit
```

focus helper의 종료 0은 관찰 수집 완료다. 위 회귀는 JSON과 viewport 이미지로
확인해야 한다. 다음 명령은 final-tools에서 두 검사가 통과하고, before-tools에서
키보드 PNG의 높이 때문에 둘 다 실패한다.

```sh
PYTHONPATH=tests AI_SLOP_BROWSER_TESTS=1 python3 -B -m unittest test_browser_checks.BrowserCheckTests.test_keyboard_capture_preserves_viewport_on_tall_page test_scope_browser_checks.ScopeBrowserTests.test_keyboard_capture_preserves_viewport_on_tall_page -v
```

작성자 helper들은 당시 절대 경로와 CDP 주소를 원문 그대로 보존했다. 그대로
재실행할 수 있는 일반 도구가 아니며, 재현에는 위 부모/이식 helper를 사용한다.
임시 브라우저 프로필·캐시는 압축에 넣지 않았다. 작성자 Chrome/서버는 종료를
확인했다. 시각 작성자의 Chrome 종료 로그에는 GCM·updater 관련 출력이 있어
플래그만으로 완전한 네트워크 격리나 백그라운드 전역 동작 차단을 주장하지
않는다. 외부 게시·PR·레지스트리 설치·기기 테스트는 수행하지 않았다.
