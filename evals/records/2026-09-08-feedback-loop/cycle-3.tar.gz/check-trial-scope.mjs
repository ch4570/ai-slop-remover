import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
const [kind, root] = process.argv.slice(2);
const inventory = directory => {
  const files = {};
  const visit = folder => {
    for (const entry of fs.readdirSync(folder, { withFileTypes: true }).sort((a, b) => a.name.localeCompare(b.name, 'en'))) {
      const file = path.join(folder, entry.name);
      if (entry.isDirectory()) visit(file);
      else {
        assert.ok(entry.isFile(), 'Non-regular entry: ' + file);
        files[path.relative(directory, file)] = crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
      }
    }
  };
  visit(directory);
  return files;
};
const before = inventory(path.join(root, 'original-product'));
const after = inventory(path.join(root, 'product'));
assert.deepEqual(Object.keys(after), Object.keys(before), 'Product file inventory changed');
const changed = Object.keys(before).filter(key => before[key] !== after[key]);
const read = (directory, file) => fs.readFileSync(path.join(root, directory, file), 'utf8');
let detail;
if (kind === 'copy') {
  assert.deepEqual(changed, ['locales/ko.json']);
  const oldCopy = JSON.parse(read('original-product', 'locales/ko.json'));
  const copy = JSON.parse(read('product', 'locales/ko.json'));
  assert.deepEqual(Object.keys(copy), Object.keys(oldCopy));
  const allowed = ['save_action', 'save_pending', 'save_success', 'save_failed', 'export_action', 'export_pending', 'export_ready', 'export_failed', 'download_action'];
  const variables = text => [...text.matchAll(/\{[^{}]+\}/g)].map(match => match[0]).sort();
  const changedKeys = Object.keys(copy).filter(key => copy[key] !== oldCopy[key]);
  for (const key of Object.keys(copy)) {
    assert.equal(typeof copy[key], 'string');
    assert.deepEqual(variables(copy[key]), variables(oldCopy[key]), 'Interpolation changed for ' + key);
    assert.ok(allowed.includes(key) || copy[key] === oldCopy[key], 'Unexpected copy change: ' + key);
  }
  detail = { changedKeys, variables: Object.fromEntries(Object.keys(copy).map(key => [key, variables(copy[key])])) };
} else if (kind === 'visual') {
  assert.deepEqual(changed, ['compare.css', 'DESIGN.md'].sort((a, b) => a.localeCompare(b, 'en')));
  const css = read('product', 'compare.css');
  const match = css.match(/^\.comparison-table th, \.comparison-table td \{ padding-block: (8|9|10|11|12)px; \}\n$/);
  assert.ok(match, 'CSS exceeds padding-only boundary');
  const strip = text => text.replace(/(<!-- comparison-exception:start -->)[\s\S]*?(<!-- comparison-exception:end -->)/, '$1$2');
  const design = read('product', 'DESIGN.md');
  assert.equal(strip(design), strip(read('original-product', 'DESIGN.md')));
  const blocks = [...design.matchAll(/```css\n([\s\S]*?)```/g)];
  assert.equal(blocks.length, 1);
  assert.equal(blocks[0][1], css);
  detail = { paddingBlock: Number(match[1]), designOutsideExceptionPreserved: true };
} else throw Error('Use copy or visual');
console.log(JSON.stringify({ kind, changed, before, after, detail, result: 'pass', limits: ['Final byte comparison does not establish absence of transient writes.', 'Source scope checks do not grade copy or visual quality.'] }, null, 2));
