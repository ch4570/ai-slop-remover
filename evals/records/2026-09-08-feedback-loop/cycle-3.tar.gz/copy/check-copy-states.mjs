import { mkdir, readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { claimBrowserEvidence, withBrowser } from './browser_harness.mjs';

const [product, outputArg] = process.argv.slice(2);
const output = path.resolve(outputArg);
await claimBrowserEvidence(output, ['initial-wide.png', 'save-error-320.png', 'export-error-320.png', 'export-ready-320.png']);
const checks = [], states = {}, collectionErrors = [];
let environment;
const record = (id, pass, observed) => checks.push({ id, status: pass ? 'pass' : 'fail', observed });
const title = '장보기 & 도시락 준비 — “가족 모임 전에 확인할 구체적인 긴 메모 제목”';
try {
  await withBrowser(product, output, async ({ origin, page, call, evaluate, pause, screenshot, exceptions }) => {
    environment = { origin, browser: (await call('Browser.getVersion')).product, node: process.version };
    const navigate = async (relative = '') => {
      const old = await evaluate('performance.timeOrigin');
      await page('Page.navigate', { url: origin + '/' + relative });
      for (let attempt = 0; attempt < 100; attempt++) {
        try {
          if (await evaluate(`location.origin === ${JSON.stringify(origin)} && performance.timeOrigin !== ${old} && document.documentElement.dataset.ready === 'true'`)) return;
        } catch {}
        await pause(40);
      }
      throw Error('Ready document unavailable');
    };
    const state = async () => evaluate(`(() => {
      const el = id => document.getElementById(id);
      return {
        title: el('title').value, titleDisabled: el('title').disabled,
        save: { text: el('save').textContent, disabled: el('save').disabled, state: el('save-status').dataset.state, status: el('save-status').textContent },
        export: { text: el('export').textContent, disabled: el('export').disabled, state: el('export-status').dataset.state, status: el('export-status').textContent },
        download: { hidden: el('download').hidden, href: el('download').getAttribute('href'), filename: el('download').download, text: el('download').textContent },
        storage: localStorage.getItem('daon-draft-notes'), width: innerWidth, documentWidth: document.documentElement.scrollWidth,
        roles: ['save-status', 'export-status'].map(id => el(id).getAttribute('role'))
      };
    })()`);
    await navigate();
    states.initial = await state();
    record('initial-idle', states.initial.save.state === 'idle' && states.initial.export.state === 'idle' && states.initial.download.hidden, states.initial);
    await screenshot('initial-wide.png');
    await page('Emulation.setDeviceMetricsOverride', { width: 320, height: 900, deviceScaleFactor: 1, mobile: true });
    await evaluate(`(() => { document.getElementById('title').value = ${JSON.stringify(title)}; document.getElementById('fail-save').checked = true; document.getElementById('save').click(); })()`);
    states.savePending = await state();
    record('save-pending-locks', states.savePending.save.state === 'pending' && states.savePending.save.disabled && states.savePending.titleDisabled, states.savePending);
    record('pending-does-not-persist', states.savePending.storage === states.initial.storage, states.savePending.storage);
    await pause(220);
    states.saveFailed = await state();
    record('failed-save-preserves-draft', states.saveFailed.title === title && states.saveFailed.storage === states.initial.storage, states.saveFailed);
    record('failed-save-retry-available', states.saveFailed.save.state === 'error' && !states.saveFailed.save.disabled && !states.saveFailed.titleDisabled, states.saveFailed);
    record('failed-copy-fits-320', states.saveFailed.documentWidth <= 320, states.saveFailed.documentWidth);
    await screenshot('save-error-320.png');
    await evaluate("document.getElementById('fail-save').checked = false; document.getElementById('save').click()");
    await pause(220);
    states.saveSucceeded = await state();
    const expected = [{ id: 1, title }, { id: 2, title: '다음 주 일정' }];
    record('retry-persists-all-notes', JSON.stringify(JSON.parse(states.saveSucceeded.storage)) === JSON.stringify(expected), states.saveSucceeded.storage);
    record('save-success-unlocks', states.saveSucceeded.save.state === 'success' && !states.saveSucceeded.save.disabled && !states.saveSucceeded.titleDisabled, states.saveSucceeded);
    await navigate();
    states.reload = await state();
    record('same-browser-reload-restores', states.reload.title === title && states.reload.storage === states.saveSucceeded.storage, states.reload);
    await evaluate("document.getElementById('fail-export').checked = true; document.getElementById('export').click()");
    states.exportPending = await state();
    record('export-pending-no-download', states.exportPending.export.state === 'pending' && states.exportPending.export.disabled && states.exportPending.download.hidden && !states.exportPending.download.href, states.exportPending);
    await pause(220);
    states.exportFailed = await state();
    record('export-failure-retry-available', states.exportFailed.export.state === 'error' && !states.exportFailed.export.disabled && states.exportFailed.download.hidden && !states.exportFailed.download.href, states.exportFailed);
    record('export-failure-keeps-storage', states.exportFailed.storage === states.saveSucceeded.storage, states.exportFailed.storage);
    record('export-error-fits-320', states.exportFailed.documentWidth <= 320, states.exportFailed.documentWidth);
    await screenshot('export-error-320.png');
    await evaluate("document.getElementById('fail-export').checked = false; document.getElementById('export').click()");
    await pause(220);
    states.exportReady = await state();
    record('prepared-link-not-clicked', states.exportReady.export.state === 'ready' && !states.exportReady.export.disabled && !states.exportReady.download.hidden && states.exportReady.download.href?.startsWith('blob:') && states.exportReady.download.filename === '개인 메모.csv', states.exportReady);
    const csv = await evaluate("fetch(document.getElementById('download').href).then(response => response.text())");
    const expectedCSV = ['title', ...expected.map(note => '"' + note.title.replaceAll('"', '""') + '"')].join('\r\n');
    record('prepared-csv-has-saved-notes', csv.replace(/^\uFEFF/, '') === expectedCSV, csv);
    record('ready-copy-fits-320', states.exportReady.documentWidth <= 320, states.exportReady.documentWidth);
    record('status-roles-preserved', states.exportReady.roles.every(role => role === 'status'), states.exportReady.roles);
    const ax = await page('Accessibility.getFullAXTree');
    states.accessibility = ax.nodes.filter(node => !node.ignored && ['button', 'link'].includes(node.role?.value)).map(node => ({ role: node.role.value, name: node.name?.value }));
    record('action-accessible-names', ['save', 'export'].every(id => states.accessibility.some(node => node.role === 'button' && node.name === states.exportReady[id].text)) && states.accessibility.some(node => node.role === 'link' && node.name === states.exportReady.download.text), states.accessibility);
    await screenshot('export-ready-320.png');
    await navigate('?lang=en');
    states.english = await state();
    const english = JSON.parse(await readFile(path.join(product, 'locales/en.json'), 'utf8'));
    record('english-actions-preserved', states.english.save.text === english.save_action && states.english.export.text === english.export_action, states.english);
    record('browser-exceptions', exceptions.length === 0, exceptions);
  });
} catch (error) { collectionErrors.push(String(error)); }
await mkdir(output, { recursive: true });
await writeFile(path.join(output, 'browser.json'), JSON.stringify({ environment, checks, states, collectionErrors, limits: ['State/data assertions do not semantically judge copy.', 'No download link was clicked; Blob bytes are not a verified device download.', 'Screenshots and AX data are not a physical-device or screen-reader test.'] }, null, 2) + '\n');
const summary = { output, pass: checks.filter(check => check.status === 'pass').length, fail: checks.filter(check => check.status === 'fail').length, collectionErrors: collectionErrors.length };
console.log(JSON.stringify(summary));
if (summary.fail || summary.collectionErrors || checks.length !== 20) process.exitCode = 1;
