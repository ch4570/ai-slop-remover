import { spawn } from 'node:child_process';
import { copyFile, mkdir, readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

if (process.argv.length !== 3) throw new Error('Usage: node scope-replay.mjs NEW_OUTPUT_DIRECTORY');
const root = fileURLToPath(new URL('final-tools/', import.meta.url));
const original = fileURLToPath(new URL('scope-before/', import.meta.url));
const output = path.resolve(process.argv[2]);
await mkdir(output);
const trials = [
  { name: 'unavailable', caseId: 'audit-read-only', unavailable: true },
  { name: 'good', caseId: 'audit-read-only' },
  { name: 'observed-fail', caseId: 'narrow-spacing' },
  { name: 'navigation-503', caseId: 'audit-read-only', preload: 'inject-navigation-503.mjs' },
  { name: 'fail-then-reload-503', caseId: 'narrow-spacing', preload: 'inject-reload-503.mjs' },
];
const run = (command, args, env = process.env) => new Promise((resolve, reject) => {
  const child = spawn(command, args, { cwd: root, env, stdio: ['ignore', 'pipe', 'pipe'] });
  let stdout = '', stderr = '';
  child.stdout.on('data', data => { stdout += data; });
  child.stderr.on('data', data => { stderr += data; });
  child.once('error', reject);
  child.once('close', (exitCode, signal) => resolve({ command: [command, ...args], exitCode, signal, stdout, stderr }));
});
const persist = async (base, result) => {
  await writeFile(base + '.stdout.log', result.stdout);
  await writeFile(base + '.stderr.log', result.stderr);
  await writeFile(base + '.json', JSON.stringify(result, null, 2) + '\n');
};
const inspectCode = `import json, sys
from pathlib import Path
sys.path.insert(0, str(Path(sys.argv[1]) / 'scripts'))
import check_scope as scope
case, product = sys.argv[2], Path(sys.argv[3])
source = scope.inventory(scope.fixture_root(case) / 'product')
observed = scope.inventory(product)
print(json.dumps({'source_inventory': source, 'product_inventory': observed, 'product_matches_source': source == observed, 'source_checks': scope.inspect_source(case, product)}, ensure_ascii=False, indent=2))`;

const hashes = {};
for (const name of ['inject-navigation-503.mjs', 'inject-reload-503.mjs']) {
  await copyFile(path.join(original, name), path.join(output, name));
  hashes[name] = createHash('sha256').update(await readFile(path.join(output, name))).digest('hex');
}
for (const name of ['scripts/run_scope_checks.mjs', 'scripts/run_browser_checks.mjs', 'scripts/browser_harness.mjs', 'scripts/check_scope.py']) {
  hashes[name] = createHash('sha256').update(await readFile(path.join(root, name))).digest('hex');
}
await writeFile(path.join(output, 'source-hashes.json'), JSON.stringify(hashes, null, 2) + '\n');

const results = [];
for (const trial of trials) {
  const directory = path.join(output, trial.name);
  const prepare = await run('python3', ['scripts/check_scope.py', 'prepare', trial.caseId, directory]);
  await persist(path.join(output, trial.name + '-prepare'), prepare);
  if (prepare.exitCode !== 0) throw new Error('Prepare failed: ' + trial.name);
  const before = await run('python3', ['-c', inspectCode, root, trial.caseId, path.join(directory, 'product')]);
  await persist(path.join(directory, 'inventory-before'), before);
  if (before.exitCode !== 0) throw new Error('Inventory failed: ' + trial.name);
  const args = [...(trial.preload ? ['--import', path.join(output, trial.preload)] : []),
    'scripts/run_scope_checks.mjs', trial.caseId, path.join(directory, 'product'), directory];
  const env = { ...process.env };
  if (trial.unavailable) env.AI_SLOP_CHROME = path.join(output, 'absent-chrome');
  const driver = await run('node', args, env);
  await persist(path.join(directory, 'driver'), driver);
  const after = await run('python3', ['-c', inspectCode, root, trial.caseId, path.join(directory, 'product')]);
  await persist(path.join(directory, 'inventory-after'), after);
  if (after.exitCode !== 0) throw new Error('Inventory failed after collection: ' + trial.name);
  const initialInventory = JSON.parse(before.stdout), finalInventory = JSON.parse(after.stdout);
  const browser = JSON.parse(await readFile(path.join(directory, 'browser.json'), 'utf8'));
  const result = {
    name: trial.name, caseId: trial.caseId, exitCode: driver.exitCode,
    checks: Object.fromEntries(browser.checks.map(check => [check.id, check.status])),
    facts: browser.checks.map(check => check.evidence ? JSON.parse(check.evidence.text) : null),
    collectionErrors: browser.observations.collectionErrors,
    exceptions: browser.observations.exceptions || [],
    environment: browser.environment,
    images: browser.observations.images, focusCount: browser.observations.focus.length,
    sourceChecks: finalInventory.source_checks.checks.map(check => ({ id: check.id, status: check.status })),
    productMatchedSourceBefore: initialInventory.product_matches_source,
    productMatchesSourceAfter: finalInventory.product_matches_source,
    productInventoryUnchanged: JSON.stringify(initialInventory.product_inventory) === JSON.stringify(finalInventory.product_inventory),
    sourceInventoryUnchanged: JSON.stringify(initialInventory.source_inventory) === JSON.stringify(finalInventory.source_inventory),
    stderr: driver.stderr,
  };
  results.push(result);
  await writeFile(path.join(output, 'results.json'), JSON.stringify(results, null, 2) + '\n');
  console.log(JSON.stringify(result));
}
if (!results.every(result => result.exitCode === 0 && result.productMatchedSourceBefore && result.productMatchesSourceAfter && result.productInventoryUnchanged && result.sourceInventoryUnchanged)) {
  throw new Error('Replay did not preserve scope exit-zero or product inventory contract.');
}
const byName = Object.fromEntries(results.map(result => [result.name, result]));
if (byName.good.collectionErrors.length || byName['observed-fail'].collectionErrors.length ||
    byName['navigation-503'].checks['audit-observation'] !== 'not-run' ||
    byName['fail-then-reload-503'].checks['spacing-and-state'] !== 'fail' ||
    !byName['navigation-503'].collectionErrors.some(error => error.includes('Observation audit-observation: Error: Fixture did not finish loading')) ||
    !byName['fail-then-reload-503'].collectionErrors.some(error => error.includes('Observation spacing-and-state: Error: Fixture did not finish loading'))) {
  throw new Error('Replay did not meet collection-error aggregation expectations.');
}
