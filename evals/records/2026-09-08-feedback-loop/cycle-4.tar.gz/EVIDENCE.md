# Cycle 4: collection-error summaries and archive verification

Baseline repository revision: a3daf5c. Executed on 2026-09-09 KST with
Python 3.9.6, Node 26.8.1 and existing Chrome 152.0.7977.76 on macOS.
These are synthetic evaluator/tool controls, not new skill-quality trials.
No skill instructions, installed payload tools, product fixtures, suite criteria
or comparator schema were changed. No images were visually reviewed this cycle.

## Observation regressions

`before-tools/` contains baseline collectors and the new regression tests.
`final-tools/` differs only in the two collector scripts. Both retain the same
evaluator checks and source fixture bytes. `regression/before/` preserves the
initial three runs, `before-history/` the following three, and `after/` all six
after the fix. Scope driver logs are included where produced by the test helper;
the search helper records browser JSON/images but not a separate CLI transcript.

The first cycle-4 draft passed exact file-inventory verification but independent
test replay exposed a missing transitive import: summarize_scope_trials.py was
absent from both tool snapshots. Both scope test imports failed before any scope
observation could run. The unchanged baseline helper was added to both snapshots
before repacking; the original draft tar and inventory were kept separately in
temporary storage. Module imports were then verified from each isolated tool
root. Exact byte inventories alone do not establish a runnable evidence bundle.

The initial/late scope navigation assertions failed because collectionErrors was
empty. Shared-document search navigation failed its expected exit 1 assertion
(actual 0). History timeout failed the same exit assertion; failure followed by
state-read exception failed the aggregate-error assertion. The trusted wrong
history-entry negative control already passed. After the fix all six passed:
scope still exits 0 under its explicitly documented record-only contract, search
interruptions exit 1, and ordinary observed failures alone do not become errors.

From either `before-tools/` or `final-tools/`, with a new evidence directory:

```sh
AI_SLOP_BROWSER_TESTS=1 AI_SLOP_BROWSER_EVIDENCE=/tmp/new-cycle4-regressions PYTHONPATH=tests python3 -B -m unittest test_scope_browser_checks.ScopeBrowserTests.test_initial_navigation_failure_is_in_collection_error_summary test_scope_browser_checks.ScopeBrowserTests.test_later_navigation_failure_preserves_prior_concrete_failure test_browser_checks.BrowserCheckTests.test_unavailable_shared_document_keeps_prior_failures test_browser_checks.BrowserCheckTests.test_unobserved_popstate_cannot_pass_or_erase_later_checks test_browser_checks.BrowserCheckTests.test_history_failure_before_state_read_error_keeps_both_observations test_browser_checks.BrowserCheckTests.test_trusted_wrong_history_entry_is_behavior_failure_not_collection_error -v
```

Expected baseline: five failed tests, one passing negative control. Expected final:
six passing tests. Existing per-check fail/not-run decisions and evidence remain
unchanged; the root driver aggregates errors independently of final check status.
The history getter exception is a one-shot synthetic state-read error; it is
caught inside the evaluator and does not depend on runtime exception telemetry.

## Independent original HTTP-fault replay

`scope-before/diagnosis.md` is the original independent read-only diagnosis with
five actual direct runs and unmodified products. `scope-after/review.md` and
`results.json` preserve the independent current-tool replay of the same matrix.
All five scope invocations exited 0. Good and ordinary-fail rows retained empty
collectionErrors. Initial HTTP 503 and a later HTTP 503 after concrete spacing
failure now expose their interruption in that aggregate list. Unavailable Chrome
still reports not-run and a collection error. All five check arrays matched the
baseline arrays; before/after product and source inventories matched.

The original agent's `scope-after/replay.mjs` retains its historical absolute
paths. `scope-replay.mjs` is a portable copy changing only imports and the three
input/output roots plus exclusive creation of the requested output directory:

```sh
node scope-replay.mjs /tmp/new-cycle4-scope-replay
```

It uses `final-tools/`, copies the two original evaluator-side HTTP preloads,
prepares five fresh product copies, collects results and checks error aggregation
and product/source preservation. It never edits repository fixtures. The output
directory must not already exist. This creates browser evidence, not visual or
accessibility verdicts. Entire interactive tool transcripts are unavailable;
the command logs explicitly present in this archive are actual retained output.

## Archive checks and historical limitations

`checker/scripts/check_evidence_archive.py` and its dedicated test module preserve
the new read-only verifier. From `checker/`:

```sh
python3 -B -m unittest discover -s tests -v
```

The final dedicated suite has 24 passing tests. Independent inspection first
reproduced oversized PAX/GNU metadata headers yielding OverflowError tracebacks.
The added regression failed for all three header types before the fix; the final
CLI reports invalid JSON, exit 1 and empty stderr for each. The verifier catches
this parse error without attempting to allocate or extract the declared payload.
`independent-review/` preserves the initial read-only review and suffix control;
its 23-test result predates this final regression and fix.

`checker/archive-results.json` contains exact CLI outputs/codes and pre/post
SHA-256 plus byte counts for the first three preserved archives/inventories.
No historical input changed. The flow archive has 159 additional regular files:
136 AppleDouble files and 23 other unlisted artifacts. Cycle 2 has 175 additional
AppleDouble files. Their inventoried payload hashes match, but their file sets
are not exact, so the strict verifier correctly rejects both. This qualifies
earlier validation of inventoried or extracted files; it is not evidence that
their observed trial results were fabricated or their archived bytes changed.
Cycle 3 is exact: 405 regular files and 5,120,548 uncompressed bytes.

`checker/rejected-cycle3-metadata.json` records rejection of the first, separately
preserved cycle-3 tar: 532 extra AppleDouble files. That temporary bad tar is not
duplicated here. The corrected historical cycle-3 tar remains in the repository,
with its original recorded hash. New archives use COPYFILE_DISABLE=1 and the new
verifier; no old archive or published checksum is silently rewritten.

This verifies logical file membership and matching bytes, not provenance or the
truth of observations. Verify the separately recorded archive SHA-256 as well:
bzip2/xz readers can ignore physical non-stream suffixes. Directory headers are
not inventoried; no extraction or general hostile-archive security audit is
performed. See the repository cycle-4 record for final whole-suite results and
independent review findings after these controls were assembled.
