# Independent initial cycle-4 archive replay

Archive SHA-256 reviewed:
`cf68a980ef28700c88334c511bdc10285af37e596abc451952cd8f193e466ec0`.

The archive exactly matched its separately recorded inventory: 349 regular
files, 2,508,046 uncompressed bytes, and 94 zero-payload directory headers.
Independent inspection before extraction found no duplicate logical paths,
ambiguous or escaping paths, links, sparse files, or other member types.
After extraction beneath this fresh review directory, every regular file's
size and SHA-256 matched the inventory. The same comparison passed again after
the replay below; no extracted input changed or additional file appeared.

The archived checker script and tests, both final collector scripts, and both
relevant browser test modules matched the current repository bytes.
`before-tools/` and `final-tools/` had identical relative file lists, with byte
differences only in `scripts/run_browser_checks.mjs` and
`scripts/run_scope_checks.mjs`.

The archived checker suite passed all 24 tests in 4.554 seconds. Additional
direct CLI controls using 1,536-byte raw tar fixtures with PAX extended, PAX
global, or GNU long-name headers declaring `2 ** 80` bytes each returned
exit 1, parseable `verdict: invalid` JSON, and empty stderr. The previously
identified OverflowError reporting problem is fixed.

The exact six-test command documented in EVIDENCE.md was executed from
`extracted/final-tools`, with PYTHONDONTWRITEBYTECODE=1 and fresh browser
evidence outside the extraction. It failed with two import errors in 32.525
seconds. All four search/browser tests passed; neither scope test could run.
The import path was:

`test_scope_browser_checks` → `test_scope_checks` → `summarize_scope_trials`.

The last helper was absent from both archived tool snapshots. The repository
helper imports only `compare_evals` plus standard library modules; the former
is already archived. Root was notified to include the unchanged missing helper
in both snapshots and repack this unpublished draft. This frozen extraction
and failed replay evidence were left unchanged for that comparison.

The four generated browser JSON files contain behavior checks only, with the
expected concrete fail and not-run observations retained. No visual checks
or visual passes were recorded, and screenshots were not visually assessed.

## Retained actual outputs

- `before-replay-inventory.json`, `after-replay-inventory.json`: exact inventory,
  archive hash, and code comparison results.
- `checker-command-result.json`: archived 24-test command and complete output.
- `final-regressions-command-result.json`: documented six-test command and
  complete output, including both missing-helper import tracebacks.
- `oversized-metadata-control-result.json`: three direct malformed metadata
  CLI results after the fix.
- `final-regression-evidence/`: new outputs from the four executed browser tests.
- `verify_record.py`: independent raw/member/extracted inventory checks.

This report is outside the extraction and repository. No repository files or
historical archives were modified. The findings concern logical file inventory
and isolated replay completeness, not evidence truth, provenance, or a general
hostile-archive extraction security audit.
