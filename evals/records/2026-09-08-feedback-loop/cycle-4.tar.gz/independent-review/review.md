# Independent archive checker review

Reviewed repository: `/Users/rex/Desktop/personal/lutriva`

Scope: read-only review of `scripts/check_evidence_archive.py` and
`tests/test_evidence_archive.py`, with synthetic inputs written only beneath
temporary directories. No repository or historical archive modifications.

Runtime: Python 3.9.6.

## Dedicated suite

Executed command:

```sh
python3 -B -m unittest discover -s tests -p test_evidence_archive.py -v
```

Observed: 23 tests ran in 4.475 seconds; all passed.

## Physical compression suffix limitation

Built valid four-file archives from the existing test helper, in plain tar,
gzip, bzip2, and xz modes. Appended the same 16-byte suffix,
`b'trailing garbage'`, after each complete archive. Invoked the real CLI for
each input against the unchanged matching schema-1 inventory.

| Archive mode | CLI exit | Observed result |
| --- | --- | --- |
| `w` | 1 | invalid; `archive: nonzero data after the last tar member` |
| `w:gz` | 1 | invalid; `Not a gzipped file (b'tr')` |
| `w:bz2` | 0 | verified; 4 files, 63 bytes |
| `w:xz` | 0 | verified; 4 files, 63 bytes |

All four invocations produced parseable JSON and empty stderr. These results
do not defeat regular-file inventory equality: the accepted bzip2/xz suffix
bytes are outside the decompressed tar stream. They demonstrate that the
checker does not provide strict validation of every physical byte in a
compressed envelope. Proposed disposition agreed with root: clarify this
limit in documentation, keep the separate archive SHA-256 check, and do not
add a general compressed-envelope scanner to this task.

Reproduction, run from the repository root (writes only temporary fixtures):

```python
import importlib.util, json, pathlib, subprocess, sys

root = pathlib.Path.cwd()
spec = importlib.util.spec_from_file_location(
    'test_archive', root / 'tests/test_evidence_archive.py')
tests = importlib.util.module_from_spec(spec)
spec.loader.exec_module(tests)
for mode in ('w', 'w:gz', 'w:bz2', 'w:xz'):
    case = tests.EvidenceArchiveTests()
    case.setUp()
    try:
        case.write_inventory()
        case.write_archive(mode=mode)
        case.archive_path.write_bytes(
            case.archive_path.read_bytes() + b'trailing garbage')
        run = subprocess.run(
            [sys.executable, '-B', str(tests.SCRIPT),
             str(case.inventory_path), str(case.archive_path)],
            capture_output=True, text=True)
        print(mode, run.returncode, run.stdout, run.stderr)
    finally:
        case.doCleanups()
```

## Oversized metadata header parse error

Built raw tar input consisting of one GNU-format header with a size field
of `2 ** 80`, followed by 1,024 zero bytes. Total input size: 1,536 bytes.
Used an empty matching schema-1 inventory.

| Header type | CLI exit | stdout | Last stderr line |
| --- | --- | --- | --- |
| PAX extended header `x` | 1 | empty | `OverflowError: cannot fit 'int' into an index-sized integer` |
| PAX global header `g` | 1 | empty | `OverflowError: cannot fit 'int' into an index-sized integer` |
| GNU long name `L` | 1 | empty | `OverflowError: cannot fit 'int' into an index-sized integer` |
| Regular file `0` | 1 | JSON invalid: `unexpected end of data` | empty |

The metadata cases reject the archive, but bypass the CLI's structured JSON
invalid-result behavior. Suggested correction: catch `OverflowError` in the
existing CLI parse-error handler, with a metadata-header regression test.
This is a bounded error-reporting finding; no claim about extraction safety,
provenance, authenticity, or inventory mismatch acceptance is made.

Header construction used:

```python
header = tarfile.TarInfo('oversized')
header.type = tarfile.XHDTYPE  # also tested XGLTYPE, GNUTYPE_LONGNAME, REGTYPE
header.size = 2 ** 80
case.archive_path.write_bytes(
    header.tobuf(format=tarfile.GNU_FORMAT) + b'\0' * 1024)
```

All synthetic temporary fixtures were cleaned up by `case.doCleanups()`.
This report preserves the controls and observed outcomes for later replay.
