// Synthetic collector fault: leave all product bytes unchanged and replace only
// the loopback HTTP response for the initial document with an HTTP 503 page.
import http from 'node:http';
import { syncBuiltinESMExports } from 'node:module';

const originalCreateServer = http.createServer;
http.createServer = function (listener) {
  return originalCreateServer.call(this, (request, response) => {
    if (request.url === '/') {
      console.error('Synthetic evaluator injection: GET / -> HTTP 503');
      response.writeHead(503, { 'Content-Type': 'text/html; charset=utf-8' });
      response.end('<!doctype html><title>Synthetic navigation outage</title><p>Temporarily unavailable</p>');
      return;
    }
    return listener(request, response);
  });
};
syncBuiltinESMExports();
