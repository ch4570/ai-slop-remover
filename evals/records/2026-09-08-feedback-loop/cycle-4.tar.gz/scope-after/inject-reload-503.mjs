// Synthetic collector fault on the second document only. Product files remain
// unchanged; the original narrow fixture records its real 24px spacing first.
import http from 'node:http';
import { syncBuiltinESMExports } from 'node:module';

const originalCreateServer = http.createServer;
let documentRequests = 0;
http.createServer = function (listener) {
  return originalCreateServer.call(this, (request, response) => {
    if (request.url === '/' && ++documentRequests === 2) {
      console.error('Synthetic evaluator injection: second GET / -> HTTP 503');
      response.writeHead(503, { 'Content-Type': 'text/html; charset=utf-8' });
      response.end('<!doctype html><title>Synthetic reload outage</title><p>Temporarily unavailable</p>');
      return;
    }
    return listener(request, response);
  });
};
syncBuiltinESMExports();
