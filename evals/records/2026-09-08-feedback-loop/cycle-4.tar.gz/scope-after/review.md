# Independent scope collector replay

Executed the original five-trial matrix with the current collector on 2026-09-09.
The collector and helper source SHA-256 values are recorded in source-hashes.json.
The exact original HTTP fault-injection preloads were copied into this fresh
temporary directory. The replay script used fresh prepare outputs for all trials.

Command: `node /tmp/lutriva-scope-exit-replay.iHdUDu/replay.mjs` (exit 0).

| Trial | Check result | collectionErrors | Driver exit |
| --- | --- | --- | --- |
| good | audit-observation=pass | [] | 0 |
| unavailable | audit-observation=not-run | One Chrome unavailable error | 0 |
| observed-fail | spacing-and-state=fail | [] | 0 |
| navigation-503 | audit-observation=not-run | Observation audit-observation: Error: Fixture did not finish loading | 0 |
| fail-then-reload-503 | spacing-and-state=fail | Observation spacing-and-state: Error: Fixture did not finish loading | 0 |

The late HTTP 503 preserves both preceding facts: the concrete 24px spacing
failure and successful save. It retains fail while aggregating the later reload
interruption. The initial HTTP 503 retains zero observed facts and not-run.
Both injected HTTP 503 responses are also confirmed in the trial stderr logs.
For all five trials, the complete checks arrays were JSON-identical to the
original archived browser.json checks. Only the initial/late HTTP 503 rows gained
the newly expected collectionErrors entries; the other three arrays were equal.

Every trial retained the original prepared product inventory: file content,
types, and modes all matched the repository fixture before and after collection.
Repository fixture inventories were unchanged. All three audit source checks
passed. The two unchanged narrow fixtures remain intentional baseline failures
in their source check and observed 24px-versus-16px spacing check.

Installed runtime: Chrome/152.0.7977.76 and Node v26.8.1. Browser exception arrays
were empty in all browser-launched trials. Good and ordinary-fail trials captured
wide/narrow/keyboard images; injected-navigation trials captured wide/narrow.
No image was visually reviewed, and no visual or accessibility pass is claimed.

Raw browser.json, driver stdout/stderr/command results, preparation logs,
before/after inventory results, aggregate results.json, copied injection preloads,
and replay.mjs are retained here. No repository files or fixtures were edited by
this independent replay. Read-only review of the four requested changed files
found no material code issue: scope exit-zero behavior remains unchanged,
history timeouts/read exceptions are aggregated even alongside a retained fail,
and trusted unexpected destinations remain ordinary behavior failures.
