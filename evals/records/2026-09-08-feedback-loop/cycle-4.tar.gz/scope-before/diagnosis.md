# Scope collector exit-status diagnosis

This is a read-only diagnosis of the repository implementation on 2026-09-09,
plus five direct synthetic collector executions. No repository file or product
fixture was edited. Only fresh prepared trial copies and two evaluator-side HTTP
fault-injection preloads were created under this temporary directory. All five
copied product inventories still exactly match their repository source fixtures.
No package/browser installation, external service, PR, push or visual verdict was
performed. Local Chrome used a fresh profile and loopback HTTP for each execution.

## Contract and implication

The current scope exit-zero behavior is explicitly documented and tested, not an
accidental disagreement between implementation and its scope-specific contract:

- `evals/README.md:316-323` says unavailable Chrome/navigation writes `not-run`,
  preserves a concrete `fail`, and exit zero means collection was **recorded**.
- `tests/test_scope_browser_checks.py:49` requires zero for every `run_product`,
  including unavailable Chrome at lines 179-183 and later navigation failure at
  lines 195-204. Lines 100-126 explicitly require zero for prepared trials with
  unavailable Chrome, while repeats exit 2 and preserve existing evidence.
- `scripts/run_scope_checks.mjs:15-21` exits 2 for bad usage/reserved output.
  Lines 161-168 catch collection failures, write the artifact and print statuses;
  there is no final collection-error exit assignment.
- The search-driver section instead describes collection **finished** and exit 1
  for interruption (`evals/README.md:219-232`). Its actual final guard is
  `exceptions.length || collectionErrors.length` in
  `scripts/run_browser_checks.mjs:172`. This is not proof that every search
  `not-run` returns 1: independent navigation catches at lines 103-108 also do not
  append collectionErrors. This diagnosis did not execute search controls.

A caller following the scope-specific documented contract must parse the JSON
and use the comparator. Existing structured evidence does not falsely mark
unavailable observations pass. A normal process-status-only automation caller,
or a caller assuming the search-driver completion contract, receives success
even when Chrome never starts or a fixture never loads. The stdout includes
individual statuses, so this is not a claim that the errors are wholly hidden.
The narrow problem is that process status cannot signal collection completion.

The collector also has an aggregation gap: `observe()` catches at lines 33-36
retain an error inside `check.evidence.text` (and a reason for `not-run`) without
appending `observations.collectionErrors`. A prior concrete failure keeps status
`fail`, which is correct; however, then neither `not-run` nor collectionErrors
alone identifies the later interruption.

## Executed commands and results

All commands ran from `/Users/rex/Desktop/personal/lutriva`. Every prepare command
and every Node driver command below exited 0. The directory was obtained with
`mktemp -d /tmp/lutriva-scope-exit-audit.XXXXXX`.

```sh
python3 scripts/check_scope.py prepare audit-read-only /tmp/lutriva-scope-exit-audit.4hQzs7/unavailable
AI_SLOP_CHROME=/tmp/lutriva-scope-exit-audit.4hQzs7/absent-chrome node scripts/run_scope_checks.mjs audit-read-only /tmp/lutriva-scope-exit-audit.4hQzs7/unavailable/product /tmp/lutriva-scope-exit-audit.4hQzs7/unavailable

python3 scripts/check_scope.py prepare audit-read-only /tmp/lutriva-scope-exit-audit.4hQzs7/good
node scripts/run_scope_checks.mjs audit-read-only /tmp/lutriva-scope-exit-audit.4hQzs7/good/product /tmp/lutriva-scope-exit-audit.4hQzs7/good

python3 scripts/check_scope.py prepare narrow-spacing /tmp/lutriva-scope-exit-audit.4hQzs7/observed-fail
node scripts/run_scope_checks.mjs narrow-spacing /tmp/lutriva-scope-exit-audit.4hQzs7/observed-fail/product /tmp/lutriva-scope-exit-audit.4hQzs7/observed-fail

python3 scripts/check_scope.py prepare audit-read-only /tmp/lutriva-scope-exit-audit.4hQzs7/navigation-503
node --import /tmp/lutriva-scope-exit-audit.4hQzs7/inject-navigation-503.mjs scripts/run_scope_checks.mjs audit-read-only /tmp/lutriva-scope-exit-audit.4hQzs7/navigation-503/product /tmp/lutriva-scope-exit-audit.4hQzs7/navigation-503

python3 scripts/check_scope.py prepare narrow-spacing /tmp/lutriva-scope-exit-audit.4hQzs7/fail-then-reload-503
node --import /tmp/lutriva-scope-exit-audit.4hQzs7/inject-reload-503.mjs scripts/run_scope_checks.mjs narrow-spacing /tmp/lutriva-scope-exit-audit.4hQzs7/fail-then-reload-503/product /tmp/lutriva-scope-exit-audit.4hQzs7/fail-then-reload-503
```

The preloads replace only the evaluator's HTTP document response with an actual
HTTP 503 error page: respectively the first or second `GET /`. They leave all
product bytes unchanged and retain actual Chrome navigation/readiness handling.
They log `Synthetic evaluator injection: GET / -> HTTP 503` or
`Synthetic evaluator injection: second GET / -> HTTP 503` to stderr.

| Trial | Browser check | collectionErrors | Other collected evidence |
| --- | --- | --- | --- |
| good | audit-observation=pass | [] | 3 completed facts; wide/narrow/keyboard images; 2 focus entries |
| unavailable | audit-observation=not-run | One Chrome-unavailable error | environment={}; images=[]; focus=[] |
| observed-fail | spacing-and-state=fail | [] | 3 completed facts [false,true,true]; 24px margin vs expected 16px; save/reload complete; all 3 images |
| navigation-503 | audit-observation=not-run | [] | evidence.text contains {facts:[],error}; only wide/narrow images; 8 BODY focus entries |
| fail-then-reload-503 | spacing-and-state=fail | [] | partial facts [false,true] plus error; only wide/narrow images; 8 BODY focus entries |

Every row's raw `browser.json` is retained in its corresponding trial directory.
Successful Chrome launches recorded `Chrome/152.0.7977.76` and Node `v26.8.1`.
No screenshot was visually reviewed; image presence is reported only as evidence
coverage, not a visual or accessibility pass.

Exact unavailable reason:

```text
Installed Chrome collection unavailable: Error: Chrome unavailable; set AI_SLOP_CHROME to its executable. Browser checks not run.
```

Its `observations.collectionErrors` contains:

```text
Error: Chrome unavailable; set AI_SLOP_CHROME to its executable. Browser checks not run.
```

Initial 503 check reason:

```text
Browser observation did not complete: Error: Fixture did not finish loading
```

Initial 503 decoded `evidence.text`:

```json
{"facts":[],"error":"Error: Fixture did not finish loading"}
```

Late 503 has no check-level reason because a concrete failure is retained. Its
decoded `evidence.text` contains the failed 24px spacing fact, a successful save
fact and `error: "Error: Fixture did not finish loading"`; it omits the unobserved
reload-restoration fact. It contains no `not-run` check and no collectionErrors.

The three audit trial source checks were inspected with `check_scope.inspect_source`
and returned `product-files-unchanged=pass`. The untouched narrow fixture is an
intentional baseline negative control: its source check and expected-16px browser
check fail without requiring a product mutation. Product inventories were checked
with `check_scope.inventory` against each repository fixture and matched in all
five trials. These were direct executions, not a complete unittest suite run.

## Narrow recommendation and compatibility

If the desired next-cycle outcome is usable collector completion status, make an
explicit coordinated contract change: preserve JSON and continue independent
checks, record every caught observation/collection exception in collectionErrors,
and exit 1 when collection was interrupted. Keep exit 0 for completed evidence
containing ordinary observed `fail` checks, and preserve exit 2 for usage/reserved
output. Do not map every behavior fail to a collector failure and do not erase a
concrete fail when collection later breaks. A final guard using only current
collectionErrors or only not-run statuses is insufficient, as late 503 proves.

Tests should distinguish success, completed behavior failure, unavailable Chrome,
initial navigation failure, late failure after a concrete mismatch and screenshot
collection failure. The existing unavailable/root-rejection/navigation tests'
exit-zero expectations need intentional updates, not silent reinterpretation.
Review whether runtime exception telemetry should also force exit 1; that is
separate from the directly reproduced collector exceptions here.

This tightens the current public CLI contract. A caller using check=True/set -e
that presently continues after an incomplete recorded artifact will begin stopping
on exit 1 and must deliberately retain/read that artifact. JSON check statuses,
comparator behavior and independent quality review remain authoritative. Static
inspection of `check_scope.collect` shows it carries required browser not-run
checks and withholds quality passes when required images/review are absent; no
comparator or final quality verdict was executed in this diagnosis. Historical
pinned replay tools/results should remain untouched; new tools require new hashes.

An equally compatible decision is to retain the existing record-only contract and
make the distinction from the search driver explicit. That avoids a behavioral
change but leaves ordinary process-status completion detection unavailable. The
five observations justify the narrow completion-status improvement; they do not
justify claiming the existing code violates its scope-specific tests/docs.

## Inspected source hashes

```text
ec0eae7c4f727a8ea3427d19c56623f9b7a85ceb24fa419d2f0eb37bf3d21047  scripts/run_scope_checks.mjs
d74e018d3fd512e73fa354c4d254217ae6fcb2662d4487091d679c36efaa33e2  scripts/browser_harness.mjs
3888ec0b9de4f00362b0a49b3c1b93244d3d972c28caccbc2a547833593a9c22  tests/test_scope_browser_checks.py
4f7e2e6d68f2b535cdb6c05fd8ba063d23ad5ed18b3a4c122ef0aa4bb2bc3f13  evals/README.md
9d1c445888b31f0a11c2152fbf015d644cc337291428ad24457a3338d06c38bb  inject-navigation-503.mjs
fb5668753cf6199a14bc559df5f4b8970d0bdb24027d7461d5e551193ea9415a  inject-reload-503.mjs
```
