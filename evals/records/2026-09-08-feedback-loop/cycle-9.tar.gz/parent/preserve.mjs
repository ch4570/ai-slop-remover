import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { copyFileSync, lstatSync, mkdirSync, readFileSync, readdirSync, writeFileSync } from 'node:fs';
import path from 'node:path';

const output = '/Users/rex/Desktop/personal/lutriva/evals/records/2026-09-08-feedback-loop/cycle-9-evidence';
const groups = [
  ['parent', '/tmp/lutriva-cycle9-cli-work-Fj7YWb'],
  ['scout', '/private/tmp/lutriva-npm-scout-Mbr0O8', ['reproduce.mjs', 'result.json', 'run.stdout.txt', 'run.stderr.txt']],
  ['review', '/private/tmp/lutriva-cycle9-code-review.YbR5mj'],
];
const hash = (bytes) => createHash('sha256').update(bytes).digest('hex');
function files(root, prefix = '') {
  return readdirSync(path.join(root, prefix)).sort().flatMap((name) => {
    const relative = path.join(prefix, name);
    const info = lstatSync(path.join(root, relative));
    assert.ok(!info.isSymbolicLink(), relative);
    if (info.isDirectory()) return files(root, relative);
    assert.ok(info.isFile(), relative);
    return [relative];
  });
}
mkdirSync(output);
const inventory = {};
for (const [group, source, selected] of groups) {
  for (const relative of selected ?? files(source)) {
    const original = path.join(source, relative);
    assert.ok(lstatSync(original).isFile() && !lstatSync(original).isSymbolicLink());
    const before = readFileSync(original);
    const targetRelative = path.join(group, relative);
    const target = path.join(output, targetRelative);
    mkdirSync(path.dirname(target), { recursive: true });
    copyFileSync(original, target);
    assert.deepEqual(readFileSync(target), before);
    assert.deepEqual(readFileSync(original), before);
    inventory[targetRelative] = { bytes: before.length, sha256: hash(before), source: original };
  }
}
const report = { schema: 1, files: inventory, regularFiles: Object.keys(inventory).length,
  bytes: Object.values(inventory).reduce((total, entry) => total + entry.bytes, 0),
  scope: 'Exact selected file copies; original absolute metadata retained. Not a replay or whole scout bundle copy.' };
writeFileSync(path.join(output, 'inventory.json'), JSON.stringify(report, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify({ regularFiles: report.regularFiles, bytes: report.bytes }));
