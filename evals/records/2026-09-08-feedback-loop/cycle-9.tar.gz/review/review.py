#!/usr/bin/env python3
"""Bounded read-only CLI review. No installation, source copy, or broad suites."""
import hashlib
import json
import os
from pathlib import Path
import platform
import stat
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
REPO = Path('/Users/rex/Desktop/personal/lutriva')
NODE = '/opt/homebrew/bin/node'
CLI = REPO / 'bin/ai-slop-remover.js'
PROJECT = ROOT / 'project with spaces'
PROJECT.mkdir()
(PROJECT / 'user-note.txt').write_bytes(b'Keep this project unchanged.\n')

def sha(data):
    return hashlib.sha256(data).hexdigest()

def save(name, value):
    (ROOT / name).write_text(json.dumps(value, indent=2) + '\n')

def snapshot():
    result = {}
    for path in [PROJECT] + sorted(PROJECT.rglob('*')):
        info = path.lstat()
        entry = {'mode': stat.S_IMODE(info.st_mode), 'mtime_ns': info.st_mtime_ns,
                 'type': 'directory' if path.is_dir() else 'file'}
        if path.is_file():
            data = path.read_bytes()
            entry.update({'bytes_hex': data.hex(), 'sha256': sha(data), 'bytes': len(data)})
        result['.' if path == PROJECT else str(path.relative_to(PROJECT))] = entry
    return result

source_names = ['bin/ai-slop-remover.js', 'tests/npm-cli.test.mjs', 'install.py']
source_before = {name: sha((REPO / name).read_bytes()) for name in source_names}
before = snapshot()
save('project-before.json', before)
save('source-before.json', source_before)
records = []

def run(label, argv, env):
    result = subprocess.run(argv, cwd=PROJECT, env=env, capture_output=True, timeout=20)
    record = {'label': label, 'argv': argv, 'cwd': str(PROJECT),
              'AI_SLOP_PYTHON': env.get('AI_SLOP_PYTHON'), 'returncode': result.returncode,
              'stdout_sha256': sha(result.stdout), 'stderr_sha256': sha(result.stderr)}
    for channel in ('stdout', 'stderr'):
        (ROOT / (label + '.' + channel)).write_bytes(getattr(result, channel))
    save(label + '.command.json', record)
    assert snapshot() == before, label + ': project changed'
    records.append(record)
    return result

missing_python = dict(os.environ, AI_SLOP_PYTHON=str(ROOT / 'absent-python'), PYTHONDONTWRITEBYTECODE='1')
known_python = dict(os.environ, AI_SLOP_PYTHON=sys.executable, PYTHONDONTWRITEBYTECODE='1')
help_cases = [[], ['--help'], ['-h'], ['install', '--help'], ['--help', '--', 'ignored'], ['install', '-h', '--', 'ignored']]
for index, args in enumerate(help_cases):
    result = run('help-' + str(index), [NODE, str(CLI)] + args, missing_python)
    assert result.returncode == 0 and result.stdout.startswith(b'Lutriva ')
    assert b'Usage:' in result.stdout and not result.stderr

for prefix_index, prefix in enumerate([[], ['install']]):
    for help_index, help_arg in enumerate(['--help', '-h']):
        forwarded = ['--repo', str(PROJECT), '--agent', 'codex', '--status', '--', help_arg]
        label = 'boundary-' + str(prefix_index) + '-' + str(help_index)
        result = run(label, [NODE, str(CLI)] + prefix + forwarded, known_python)
        assert result.returncode == 2 and result.stdout == b''
        assert ('unrecognized arguments: -- ' + help_arg).encode() in result.stderr
        direct = run(label + '-direct-python', [sys.executable, str(REPO / 'install.py')] + forwarded, known_python)
        assert (result.returncode, result.stdout, result.stderr) == (direct.returncode, direct.stdout, direct.stderr)

for agent, prefix, selected, expected_missing in [('codex', [], ['--skill', 'ux-writing'], 2), ('claude', ['install'], [], 7)]:
    args = prefix + ['--repo', str(PROJECT), '--agent', agent, '--status'] + selected
    result = run('valid-status-' + agent, [NODE, str(CLI)] + args, known_python)
    assert result.returncode == 0 and not result.stderr
    assert result.stdout.count(b'Status: not installed') == expected_missing

after = snapshot()
source_after = {name: sha((REPO / name).read_bytes()) for name in source_names}
save('project-after.json', after)
save('source-after.json', source_after)
assert source_after == source_before
result = {'verified': True, 'base': '2ef9fa7e0417ad6c47666a0a6acfabe9c682039b',
          'node': subprocess.check_output([NODE, '--version'], text=True).strip(),
          'python': sys.version, 'platform': platform.platform(),
          'wrapper_cases': 12, 'direct_python_boundary_comparisons': 4,
          'project_paths_types_modes_mtimes_bytes_unchanged': before == after,
          'reviewed_source_hashes_unchanged': source_before == source_after,
          'source_hashes': source_after, 'commands': records,
          'limits': 'No package installation/alias execution, Windows, browser, global configuration, network, or broad test suite. Status controls target missing installations only.'}
save('result.json', result)
print(json.dumps({key: value for key, value in result.items() if key != 'commands'}, indent=2))
