import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { copyFileSync, mkdirSync, readFileSync, readdirSync, statSync, writeFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const source = '/Users/rex/Desktop/personal/lutriva';
const root = path.dirname(fileURLToPath(import.meta.url));
assert.equal(path.dirname(root), '/private/tmp');
assert.ok(path.basename(root).startsWith('lutriva-npm-scout-'));
const bundle = path.join(root, 'bundle');
const project = path.join(root, 'project');
mkdirSync(bundle);
mkdirSync(project);
writeFileSync(path.join(project, 'user-note.txt'), 'Keep this isolated project unchanged.\n');
const hash = (data) => createHash('sha256').update(data).digest('hex');
const manifest = JSON.parse(readFileSync(path.join(source, 'manifest.json'), 'utf8'));
const names = [...new Set([...Object.keys(manifest.files), 'manifest.json', 'package.json', 'bin/ai-slop-remover.js', 'tests/npm-cli.test.mjs'])].sort();
const inventory = {};
for (const relative of names) {
  const original = path.resolve(source, relative);
  assert.ok(original.startsWith(source + path.sep));
  const target = path.join(bundle, relative);
  mkdirSync(path.dirname(target), { recursive: true });
  copyFileSync(original, target);
  inventory[relative] = hash(readFileSync(target));
  if (manifest.files[relative]) assert.equal(inventory[relative], manifest.files[relative], relative);
}
const cli = path.join(bundle, 'bin/ai-slop-remover.js');
const installer = path.join(bundle, 'install.py');
const probe = spawnSync('python3', ['-B', '-c', 'import sys; print(sys.executable); print(sys.version)'], { encoding: 'utf8', timeout: 15000 });
assert.equal(probe.status, 0, probe.stderr);
const python = probe.stdout.split('\n')[0];
const env = { ...process.env, AI_SLOP_PYTHON: python, PYTHONDONTWRITEBYTECODE: '1' };
function snapshot(directory) {
  const entries = {};
  function visit(base) {
    for (const name of readdirSync(base)) {
      const absolute = path.join(base, name);
      const stats = statSync(absolute, { bigint: true });
      const isDirectory = stats.isDirectory();
      entries[path.relative(directory, absolute)] = { kind: isDirectory ? 'directory' : 'file', mtimeNs: String(stats.mtimeNs), sha256: isDirectory ? null : hash(readFileSync(absolute)) };
      if (isDirectory) visit(absolute);
    }
  }
  visit(directory);
  return entries;
}
const before = snapshot(project);
const commands = [];
function run(label, executable, args) {
  const result = spawnSync(executable, args, { cwd: root, env, encoding: 'utf8', timeout: 15000 });
  const record = { label, argv: [executable, ...args], cwd: root, envOverrides: { AI_SLOP_PYTHON: python, PYTHONDONTWRITEBYTECODE: '1' }, exit: result.status, signal: result.signal, error: result.error?.message ?? null, stdout: result.stdout, stderr: result.stderr };
  commands.push(record);
  console.log(JSON.stringify(record));
  return record;
}
const ordinaryHelp = run('ordinary wrapper help control', process.execPath, [cli, '--help']);
const validStatus = run('ordinary wrapper status control', process.execPath, [cli, '--repo', project, '--agent', 'codex', '--status']);
const argumentsUnderTest = ['--repo', project, '--agent', 'codex', '--status', '--', '--help'];
const direct = run('direct installer with help after option terminator', python, ['-B', installer, ...argumentsUnderTest]);
const wrapped = run('wrapper with identical arguments', process.execPath, [cli, ...argumentsUnderTest]);
const after = snapshot(project);
const observations = {
  ordinaryHelpExit: ordinaryHelp.exit,
  ordinaryStatusExit: validStatus.exit,
  ordinaryStatusCompletesReport: validStatus.stdout.includes('Checked 7 skills'),
  directInvalidArgumentsExit: direct.exit,
  wrapperInvalidArgumentsExit: wrapped.exit,
  wrapperPrintsHelpInsteadOfStatus: wrapped.stdout.includes('Usage:') && !wrapped.stdout.includes('Checked 7 skills'),
  projectBytesAndMtimesPreserved: JSON.stringify(before) === JSON.stringify(after),
  scope: 'One option-terminator argument handling discrepancy. No installation attempted; no overwrite or data loss observed.',
};
const head = spawnSync('git', ['rev-parse', 'HEAD'], { cwd: source, encoding: 'utf8', timeout: 15000 });
const report = { source, sourceHead: head.stdout.trim(), platform: process.platform, architecture: process.arch, node: process.version, nodeExecutable: process.execPath, pythonProbe: { argv: ['python3', '-B', '-c', 'import sys; print(sys.executable); print(sys.version)'], exit: probe.status, stdout: probe.stdout, stderr: probe.stderr }, inventory, commands, observations, projectBefore: before, projectAfter: after };
writeFileSync(path.join(root, 'result.json'), JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify(observations, null, 2));
assert.equal(ordinaryHelp.exit, 0);
assert.equal(validStatus.exit, 0);
assert.ok(observations.ordinaryStatusCompletesReport);
assert.equal(direct.exit, 2);
assert.ok(observations.projectBytesAndMtimesPreserved);
assert.equal(wrapped.exit, direct.exit, 'Wrapper must preserve invalid-argument exit 2 when --help follows --');
