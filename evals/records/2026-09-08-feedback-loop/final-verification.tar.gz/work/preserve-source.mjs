import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,mkdirSync,copyFileSync,lstatSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {spawnSync} from 'node:child_process';
import path from 'node:path';
const repo='/Users/rex/Desktop/personal/lutriva';
const work='/tmp/lutriva-overnight-final-j11Dtc';
const git=args=>{const r=spawnSync('/usr/bin/git',args,{cwd:repo,encoding:'utf8'});assert.equal(r.status,0,r.stderr);return r.stdout;};
const sha=b=>createHash('sha256').update(b).digest('hex');
const head=git(['rev-parse','HEAD']).trim();
assert.equal(head,'bc085c81e26c66b06c275dc7337c559e801bdb4c');
const names=git(['ls-files','-z']).split('\0').filter(n=>n&&!n.startsWith('evals/records/'));
const entries=[];
for(const name of names){const source=repo+'/'+name,destination=work+'/source/'+name,stat=lstatSync(source,{bigint:true});assert.ok(stat.isFile()&&!stat.isSymbolicLink());const b=readFileSync(source);mkdirSync(path.dirname(destination),{recursive:true});copyFileSync(source,destination);assert.equal(sha(readFileSync(destination)),sha(b));entries.push({name,source,bytes:b.length,sha256:sha(b),mode:Number(stat.mode&0o777n),mtimeNs:String(stat.mtimeNs)});}
for(const e of entries){const b=readFileSync(e.source),s=lstatSync(e.source,{bigint:true});assert.equal(sha(b),e.sha256);assert.equal(String(s.mtimeNs),e.mtimeNs);assert.equal(Number(s.mode&0o777n),e.mode);}
writeFileSync(work+'/source-copy.json',JSON.stringify({createdAt:new Date().toISOString(),head,selection:'all tracked non-evals/records files; existing historical evidence archives are not duplicated',files:entries,sourceBytesModesMtimesUnchanged:true},null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({head,files:entries.length,bytes:entries.reduce((n,e)=>n+e.bytes,0)}));
