import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {spawnSync} from 'node:child_process';
const repo='/Users/rex/Desktop/personal/lutriva';
const output='/tmp/lutriva-overnight-final-j11Dtc';
const records='evals/records/2026-09-08-feedback-loop';
const sha=b=>createHash('sha256').update(b).digest('hex');
const results=[];
for(let cycle=1;cycle<=12;cycle++){
 const inventory=records+'/'+(cycle===1?'flow-inventory.json':`cycle-${cycle}-inventory.json`);
 const archive=records+'/'+(cycle===1?'flow-trial.tar.gz':`cycle-${cycle}.tar.gz`);
 const before={inventory:sha(readFileSync(repo+'/'+inventory)),archive:sha(readFileSync(repo+'/'+archive))};
 const args=['scripts/check_evidence_archive.py',inventory,archive];
 const started=new Date().toISOString();
 const run=spawnSync('/usr/bin/python3',args,{cwd:repo,encoding:'utf8',maxBuffer:2*1024*1024});
 const after={inventory:sha(readFileSync(repo+'/'+inventory)),archive:sha(readFileSync(repo+'/'+archive))};
 const result={cycle,executable:'/usr/bin/python3',args,cwd:repo,started,finished:new Date().toISOString(),exit:run.status,signal:run.signal,error:run.error?.message??null,stdout:run.stdout,stderr:run.stderr,before,after};
 results.push(result);
 writeFileSync(output+`/record-${cycle}-integrity.json`,JSON.stringify(result,null,2)+'\n',{flag:'wx'});
 assert.deepEqual(before,after);
 assert.equal(run.status,cycle<=2?1:0,'Known old inventory limits remain explicit; newer records must verify');
 assert.equal(run.stderr,'');
 const report=JSON.parse(run.stdout);
 assert.equal(report.verdict,cycle<=2?'invalid':'verified');
 console.log(JSON.stringify({cycle,exit:run.status,verdict:report.verdict,files:report.files??null,unchanged:true}));
}
writeFileSync(output+'/record-integrity-summary.json',JSON.stringify({createdAt:new Date().toISOString(),sourceHead:'bc085c81e26c66b06c275dc7337c559e801bdb4c',records:results.map(r=>({cycle:r.cycle,exit:r.exit,verdict:JSON.parse(r.stdout).verdict,hashes:r.before})),limits:'Byte/inventory consistency, not evidence truth or new behavioral coverage. First two exact-set failures are known documented historical limits, not repaired or relabeled.'},null,2)+'\n',{flag:'wx'});
