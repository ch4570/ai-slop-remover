import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
const source='/tmp/lutriva-overnight-archive-lqiVht';
const names=['tar-command.json','tar.stdout','tar.stderr','archive-result.json','repository-check-after-archive.json','repository-check-after-archive.stdout','repository-check-after-archive.stderr','archive-check-final.json','archive-check-final.stdout','archive-check-final.stderr','final-whitespace.json','final-whitespace.stdout','final-whitespace.stderr','all-archive-shas.json','all-archive-shas.stdout','all-archive-shas.stderr'];
const files=Object.fromEntries(names.map(name=>{const b=readFileSync(source+'/'+name);return [name,{source:source+'/'+name,bytes:b.length,sha256:createHash('sha256').update(b).digest('hex'),utf8:b.toString('utf8')}];}));
writeFileSync('/Users/rex/Desktop/personal/lutriva/evals/records/2026-09-08-feedback-loop/final-verification-build.json',JSON.stringify({schema:1,note:'Verbatim UTF-8 build/check outputs retained outside the archive they validate. Repeated integrity/static checks are not additional behavioral coverage.',files},null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({preservedFiles:names.length}));
