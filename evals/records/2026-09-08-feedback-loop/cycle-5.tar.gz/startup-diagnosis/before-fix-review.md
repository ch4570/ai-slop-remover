# Before-fix diagnosis: incomplete DevToolsActivePort

Confirmed preexisting defect at baseline `6514ff3` and the then-current keyboard diff. No repository edits were made during this diagnosis.

The startup loop breaks after any successful DevToolsActivePort read, including empty or port-only contents. It then concatenates both presumed lines into a WebSocket URL. The temporary fake Chrome controls reproduced the exact reported error before the observer callback:

| File contents | Attempted URL | Baseline and current result |
| --- | --- | --- |
| Empty | `ws://127.0.0.1:undefined` | `SyntaxError: TypeError: Invalid URL` |
| `1\n` | `ws://127.0.0.1:1undefined` | `SyntaxError: TypeError: Invalid URL` |
| Complete port and browser path | `ws://127.0.0.1:1/devtools/browser/diagnostic-control` | URL accepted; expected `Error: Cannot connect to Chrome` |

Command: `node /tmp/lutriva-cycle5-endpoint-diagnosis-bPN6qO/diagnose.mjs` exited 0; all six baseline/current controls passed their assertions. `diagnosis.json` and individual control JSON retain attempted URLs, exception stacks, fake-process publication times, and observer status. `baseline-browser-harness.mjs` preserves the baseline launch code used. The fake launcher was terminated by the harness before its scheduled complete publication in all incomplete controls. No real Chrome, native key adapter, or package installation was used.

Original failures remain unchanged at `/tmp/lutriva-cycle5-regression-AbPthY/scope.stderr.log` and the following `scope-evidence/scope-uziod2sr` cases:

- `good-master-page-consistency/browser.json`: both checks not-run, empty environment/images/focus, exact Invalid URL error.
- `shared-density-token/browser.json`: same pre-observer failure shape.

The original runs did not preserve the DevToolsActivePort bytes. An incomplete read in those specific runs is therefore inferred from the identical exception route and startup state, not directly observed. The defect and its presence in both source revisions are directly reproduced.

Minimal fix recommendation: accept the read only after a valid numeric TCP port and a nonempty `/devtools/browser/…` path are present; retry incomplete/invalid reads with the existing 100 attempts and 100 ms delay, then emit the existing readiness timeout. Keep transport and keyboard behavior unchanged. Add dependency-free startup-path controls for partial→complete publication, never-complete publication, and an immediately complete endpoint, including cleanup assertions. Record implementation and after-fix results separately from this before-fix diagnosis.
