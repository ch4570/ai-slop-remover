# Endpoint readiness fix and verification

Implemented the narrowly scoped fix authorized after the before-fix diagnosis. The production change is confined to the existing DevToolsActivePort polling loop in `scripts/browser_harness.mjs`: wait until there are two lines containing a decimal TCP port in 1–65535 and a nonempty `/devtools/browser/…` path, accepting LF or CRLF. Missing, incomplete, or invalid endpoint contents retry within the existing 100 attempts with 100 ms pauses. Exhaustion retains the existing readiness error. The keyboard helper, browser launch flags, transport, and trial frozen harness were not changed by this fix.

Added `tests/browser-startup.test.mjs` and included it in `npm test`/`check:js`. The tests exercise the full withBrowser startup and cleanup path with injected built-in spawn/readFile behavior and a fake WebSocket. They launch no executable and make no browser/WebSocket connection. The harness's temporary HTTP listener/profile setup and teardown remain real. Timers are accelerated while asserting the retry count and requested 100 ms delays.

The four startup controls cover:

- Empty and port-only contents, invalid/out-of-range ports, and incomplete/wrong browser paths followed by a complete endpoint: only the complete endpoint opens a socket and enters the observer.
- An immediately complete LF endpoint: one read and no readiness retry.
- An immediately complete CRLF endpoint: accepted without requiring a claim about Chrome's actual newline format on Windows.
- A never-complete port-only file: exactly 100 reads and retries, no socket/observer, the existing readiness error, and cleanup of the owned fake process and real temporary profile.

Before/after evidence:

- Before the production edit, `node --test tests/browser-startup.test.mjs` ran the initial three controls: 1 passed, 2 failed because empty/port-only data reached WebSocket construction immediately. Raw output: `startup-test-before.log`.
- After the first edit, keyboard/startup controls: 11 passed; `check:js` and `git diff --check` passed. Raw output: `startup-test-after.log`.
- Final source, including the CRLF control: `node --test tests/browser-startup.test.mjs tests/browser-input.test.mjs`: 12 passed, 0 failed/skipped; `npm run check:js` and `git diff --check` passed.
- `node --import 'data:text/javascript,delete globalThis.WebSocket' --test tests/browser-startup.test.mjs`: 4 passed, confirming the default tests do not require native WebSocket availability. These executions used Node v26.8.1, not an actual Node 20 binary or Windows host. Final raw output: `startup-test-final.log`.

The earlier six fake-process diagnostic controls and their raw endpoint contents remain in `diagnosis.json` and the individual JSON/log files. `before-fix-review.md` is intentionally unchanged and describes the pre-fix state. The reconstructed `before-fix-current-browser-harness.mjs` was verified to have SHA-256 `769f64d50519859c43f3dc298db44592537f8bf71b0fd533b6024c180c728452`, exactly matching the source hash recorded in the earlier independent keyboard review. The diagnostic runner's original `current` import points to the repository and must be redirected to this saved snapshot to repeat the before-fix controls after implementation; the original recorded output has not been overwritten.

The original three-test source was not separately captured or hashed before execution; its raw output was captured. `reconstructed-before-crlf-browser-startup.test.mjs` reverses the exact one-line CRLF-case addition, which was the sole subsequent edit to that file. It is labeled as a reconstruction, not an original historical snapshot. Its original relative harness import is retained, so replay requires placing it in an equivalent tests/scripts layout or redirecting that import to the preserved harness.

Reproducible temporary layouts are now preserved under `replay-before/` and `replay-after/`, each containing the same reconstructed three-test source and the corresponding frozen harness. Running `node --test tests/browser-startup.test.mjs` in `replay-before/` reproduced 1 pass/2 failures (exit 1), and the same command in `replay-after/` passed 3/3 (exit 0). These later replay outputs are retained as `replay-before.log` and `replay-after.log`, separate from the original before-run log. The before harness again hashes to the independently recorded `769f64d50519859c43f3dc298db44592537f8bf71b0fd533b6024c180c728452`; the after harness hashes to `5538f93787bf84a401eba4ce747264ddd6bfc6e5e31049e4004a8986ad85a1e1`.

Final implementation hashes at handoff:

```text
5538f93787bf84a401eba4ce747264ddd6bfc6e5e31049e4004a8986ad85a1e1  scripts/browser_harness.mjs
20a81b411721b5a7079b9d6d8d9b05c5343c58ad4a68c45d4d5c89e2dfc030bc  tests/browser-startup.test.mjs
3b987b4c3f93ce1dca3fd9db1d18f6a32f7508400819b2818ec7e3300722735c  package.json
```

Limits: this subtask did not rerun Chrome, the full final npm/Python suites, or CI. The parent is performing independent review and final Chrome regression runs. No install, commit, push, or unrelated repository edit was performed by this subtask.
