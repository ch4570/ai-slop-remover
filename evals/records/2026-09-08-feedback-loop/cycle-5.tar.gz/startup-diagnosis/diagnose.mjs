import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const diagnosisRoot = path.dirname(fileURLToPath(import.meta.url));
const repositoryRoot = '/Users/rex/Desktop/personal/lutriva';
const initialValues = [
  ['empty', ''],
  ['port-only', '1\n'],
  ['complete', '1\n/devtools/browser/diagnostic-control'],
];
const reports = [];
const NativeWebSocket = globalThis.WebSocket;
let attemptedUrls = [];
globalThis.WebSocket = class extends NativeWebSocket {
  constructor(url, ...rest) {
    attemptedUrls.push(url);
    super(url, ...rest);
  }
};
for (const [revision, modulePath] of [
  ['6514ff3', path.join(diagnosisRoot, 'baseline-browser-harness.mjs')],
  ['current', path.join(repositoryRoot, 'scripts/browser_harness.mjs')],
]) {
  const { withBrowser } = await import(pathToFileURL(modulePath));
  for (const [control, initialContent] of initialValues) {
    attemptedUrls = [];
    const fakeLog = path.join(diagnosisRoot, `${revision}-${control}-fake.log`);
    process.env.AI_SLOP_CHROME = path.join(diagnosisRoot, 'fake-chrome.mjs');
    // A base64-encoded empty string needs a nonempty equivalent accepted by Buffer.from.
    process.env.DIAG_INITIAL_CONTENT = Buffer.from(initialContent).toString('base64') || '\n';
    process.env.DIAG_FAKE_LOG = fakeLog;
    let observerCalled = false;
    const started = Date.now();
    let caught;
    try {
      await withBrowser(path.join(repositoryRoot, 'evals/fixtures/search-editor'), path.join(diagnosisRoot, `${revision}-${control}-output`), async () => {
        observerCalled = true;
      });
    } catch (error) {
      caught = { name: error.name, message: error.message, string: String(error), stack: error.stack };
    }
    const elapsedMs = Date.now() - started;
    const published = (await readFile(fakeLog, 'utf8')).trim().split('\n').map(line => JSON.parse(line));
    assert.equal(observerCalled, false);
    assert.equal(attemptedUrls.length, 1);
    if (control === 'complete') {
      assert.equal(caught.string, 'Error: Cannot connect to Chrome');
    } else {
      assert.equal(caught.string, 'SyntaxError: TypeError: Invalid URL');
      assert.equal(published.some(event => event.stage === 'complete'), false);
    }
    const report = { revision, control, initialContent, attemptedUrls, observerCalled, elapsedMs, caught, published };
    reports.push(report);
    await writeFile(path.join(diagnosisRoot, `${revision}-${control}.json`), JSON.stringify(report, null, 2) + '\n');
    console.log(JSON.stringify({ revision, control, initialContent, attemptedUrls, observerCalled, elapsedMs, error: caught.string }));
  }
}
await writeFile(path.join(diagnosisRoot, 'diagnosis.json'), JSON.stringify(reports, null, 2) + '\n');
