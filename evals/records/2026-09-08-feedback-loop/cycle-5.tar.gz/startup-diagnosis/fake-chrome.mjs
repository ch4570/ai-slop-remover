#!/usr/bin/env node
import { writeFile, appendFile } from 'node:fs/promises';
import path from 'node:path';

const profile = process.argv.find(arg => arg.startsWith('--user-data-dir='))?.slice('--user-data-dir='.length);
if (!profile || !process.env.DIAG_INITIAL_CONTENT || !process.env.DIAG_FAKE_LOG) process.exit(2);
const initial = Buffer.from(process.env.DIAG_INITIAL_CONTENT, 'base64').toString();
await writeFile(path.join(profile, 'DevToolsActivePort'), initial);
await writeFile(process.env.DIAG_FAKE_LOG, JSON.stringify({ stage: 'initial', content: initial, time: Date.now() }) + '\n');
setTimeout(async () => {
  const complete = '1\n/devtools/browser/diagnostic-control';
  await writeFile(path.join(profile, 'DevToolsActivePort'), complete);
  await appendFile(process.env.DIAG_FAKE_LOG, JSON.stringify({ stage: 'complete', content: complete, time: Date.now() }) + '\n');
}, 800);
setTimeout(() => process.exit(3), 5000);
