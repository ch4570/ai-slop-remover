# Cycle 5 final independent regression report

최종 endpoint-readiness 수정과 CRLF 처리가 반영된 작업 상태에서 요청된 세 회귀 검사가 모두 통과했다. 각 suite를 한 번씩 전체 실행했으며 재시도는 없었다. 검사자는 저장소 파일을 수정하거나 커밋/푸시/설치하지 않았다.

대상: `/Users/rex/Desktop/personal/lutriva`, 브랜치 `work/overnight-feedback-2026-09-08`, HEAD `6514ff3c81be7e6d5047ce53ef70b145e8404a6f` 위의 작업 중인 변경. 환경은 macOS, Node `v26.8.1`, Python `3.9.6`이다. Chrome 실행 파일 `/Applications/Google Chrome.app/Contents/MacOS/Google Chrome`의 시작/종료 버전은 모두 `152.0.7977.83`이고, 모든 버전이 기록된 브라우저 증거도 `Chrome/152.0.7977.83`이었다.

| 실행 | 총 테스트 | 통과 | 실패/오류 | 건너뜀 | 종료 코드 | 시간 |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| 일반 Python 전체 | 291 | 244 | 0 | 47 | 0 | 74.586초 |
| Chrome browser 전체 | 33 | 33 | 0 | 0 | 0 | 216.637초 |
| Chrome scope 전체 | 14 | 14 | 0 | 0 | 0 | 81.077초 |

일반 검사에서 건너뛴 47개는 opt-in 브라우저 33개와 scope 브라우저 14개다. 두 Chrome 전체 suite에서 이 항목들을 별도로 모두 실행했다. Scope 전체 실행에는 앞선 초기 실행에서 실패했던 `test_known_good_controls_preserve_source_and_browser_contracts`와 `test_shared_density_token_breaks_master`도 포함되었고 둘 다 통과했다.

실행 전후 `scripts/browser_harness.mjs`, 두 브라우저 어댑터, 두 Python 브라우저 테스트, `tests/browser-input.test.mjs`, `tests/browser-startup.test.mjs`, `package.json`, `CHANGELOG.md`, `docs/verification.md`, `manifest.json` 등 11개 파일의 SHA-256이 일치했다. 최종 하네스 SHA-256은 `5538f93787bf84a401eba4ce747264ddd6bfc6e5e31049e4004a8986ad85a1e1`이다. 전체 값과 실행 환경은 `context-before.txt`, `context-after.txt`에 기록되어 있다. 이 보고서는 Node 테스트 자체의 실행 결과를 주장하지 않으며 해당 실행은 주 작업자 담당이었다.

명령은 저장소 루트에서 실행했다. 일반 검사는 다음 명령이었다.

```sh
env -u AI_SLOP_BROWSER_TESTS PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s tests -v
```

두 Chrome 검사는 각각 다음 명령이었으며, 세 suite는 동시에 실행했다. 하네스는 각 Chrome 실행에 별도 임시 사용자 프로필과 동적 HTTP/CDP 포트를 사용한다.

```sh
env PYTHONDONTWRITEBYTECODE=1 AI_SLOP_BROWSER_TESTS=1 AI_SLOP_BROWSER_EVIDENCE=/tmp/lutriva-cycle5-final-regression-eTs81n/browser-evidence AI_SLOP_CHROME='/Applications/Google Chrome.app/Contents/MacOS/Google Chrome' python3 -m unittest discover -s tests -p test_browser_checks.py -v
env PYTHONDONTWRITEBYTECODE=1 AI_SLOP_BROWSER_TESTS=1 AI_SLOP_BROWSER_EVIDENCE=/tmp/lutriva-cycle5-final-regression-eTs81n/scope-evidence AI_SLOP_CHROME='/Applications/Google Chrome.app/Contents/MacOS/Google Chrome' python3 -m unittest discover -s tests -p test_scope_browser_checks.py -v
```

원시 stdout/stderr는 `ordinary.stdout.log`, `ordinary.stderr.log`, `browser.stdout.log`, `browser.stderr.log`, `scope.stdout.log`, `scope.stderr.log`에 있다. 각 실행의 `*.exit-code.txt`, `*.started.txt`, `*.finished.txt`도 보존했다. unittest의 주 결과 출력은 stderr 로그에 있으며, browser stdout에는 키보드 제어 증거 경로가 있다.

주요 증거 경로:

- Chrome browser: `browser-evidence/run-bdrxnp6c/`
- Chrome scope: `scope-evidence/scope-mqlyygg2/`
- 키보드 제어: `browser-evidence/run-bdrxnp6c/bounded-keyboard/keyboard-control.json`
- 생성된 증거 요약: `evidence-summary.json`

키보드 제어에서 Tab/Shift+Tab 포커스 순서 `submit → check → submit → query`, Enter 제출, Space 체크박스 변경, Escape가 검증됐으며 keydown/keyup 18개 모두 trusted였다. 전후 페이지 target 목록이 일치하고, 관찰 구간의 target 이벤트와 예상 밖 navigation 목록은 비어 있다. 최종 실행의 브라우저 문서에서 `Invalid URL` 수집 오류는 발견되지 않았다. 증거 보존 테스트가 의도적으로 만든 기존 `browser.json` 두 개는 JSON이 아닌 자리 보존 바이트이며 `evidence-summary.json`에서 별도로 표시했다.

앞선 하네스 상태의 최초 scope 실패 및 개별 재실행 기록은 `/tmp/lutriva-cycle5-regression-AbPthY/REPORT.md`와 그 증거 디렉터리에 그대로 남아 있고 수정하지 않았다. 이번 최종 전체 통과 결과로 이전 실패 기록을 대체하지 않는다. 기존 실패의 원시 `DevToolsActivePort` 내용은 보존되지 않았으므로 이번 통과만으로 당시 오류 원인을 확정하지 않는다.

일부 회귀 테스트는 의도적으로 손상된 fixture의 `fail`/`not-run` 관찰을 기대하므로, Python 테스트 통과는 모든 생성 fixture가 정상이라는 뜻이 아니다. 이 결과는 해당 로컬 Chrome/Node/Python 조합의 자동 관찰에 한정된다. 실제 OS IME, 다른 OS/Chrome 버전, 실제 기기, 독립 스크린샷 시각 검토, 모델 품질 평가, CI 현재 head 결과는 이 실행 범위에 포함되지 않는다. 업데이트 UI, 브라우저 설치/되돌리기, native keycode 재생은 수행하지 않았다.
