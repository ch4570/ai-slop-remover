Cycle 5 evidence staging — awaiting parent final files

This directory contains exact copies prepared for a later record. No repository commit or archive was created by this staging task. The parent agent will add its final scope/visual review and regression/review logs before packaging.

Source mapping:

- `trial/` ← `/tmp/lutriva-filter-motion-trial-xOupNS`, including TASK, the unchanged 65-file skill snapshot, four-file original and candidate products, and the supplied harness.
- `parent-observations/` ← `/tmp/lutriva-filter-motion-parent-aUMyBe`, including frozen input inventory, helpers, original/unversioned preliminary evidence and the matched versioned pair.
- `observer/` ← `/tmp/lutriva-filter-observer-wlMxTW`, in full.
- `negative-control/` ← `/tmp/lutriva-filter-negative-5TZ2zw`, in full.
- `author/` ← `/tmp/lutriva-filter-author-vecfhX`, in full.
- `keyboard-evidence/` ← `/tmp/lutriva-keyboard-helper-lhBxF5`, in full.
- `final-tools/` contains the current repository's Python/MJS scripts and tests, complete `evals/checks/` and `evals/fixtures/`, and `package.json` for command context.

Every copied file retains its source bytes. Original report wording and historical absolute paths are deliberately unchanged. This label is separate from the reports. `STAGING-COPY-MANIFEST.json` records per-file SHA-256, source mappings and equality checks. No `.git`, prior record archive, Chrome profile or cache was included. The six evidence trees were sized and their files/directories listed before copying; no actual profile/cache was present, so no evidence files were omitted.

Evidence interpretation labels:

- `observer/REPORT-corrected.md`, `observer/original-corrected/`, `observer/candidate-corrected/` and `observer/comparison-corrected.json` are the observer's final comparison after the independently demonstrated one-condition evaluator correction.
- `observer/evaluate.mjs`, `observer/REPORT.md`, `observer/original-frozen/` and `observer/candidate-frozen/` remain the earlier frozen comparison, preserved unchanged for the audit trail.
- `observer/original-run-1/` is the aborted native-keycode preparation run; `original-run-2/`, `original-run-3/` and native-select probes have the original exclusion/limitation explanations. They are preserved and are not relabeled as valid comparison evidence.
- `negative-control/old-checker-result/` preserves the demonstrated false pass; `negative-control/corrected-checker-result/` preserves the expected failure after the narrow evaluator correction.
- Author preparation/baseline/candidate outputs and the parent's earlier unversioned `original/` observation remain unchanged. Use the versioned and final outputs according to their original reports and the parent's forthcoming final review.

The copied unittest search/scope helpers have their relative harness/check/fixture dependencies. Other copied test files are retained as source context; this stage does not claim that unrelated installation/package tests are standalone without the rest of the repository. No new browser or test run was performed for this staging task.

Post-copy coordination: the parent's `REVIEW.md`, `verify-scope.mjs`, `scope-final.json` and `npm-python312.log` were already present by the actual copy operation, and a separate post-copy byte comparison confirmed all four current files exactly match `parent-observations/`. Further regression/review work remains with the parent. `final-tools/` is the repository snapshot at the recorded copy time and must be refreshed if the parent changes tools after ongoing diagnosis. This staging directory remains unarchived and is not yet declared the final record.
