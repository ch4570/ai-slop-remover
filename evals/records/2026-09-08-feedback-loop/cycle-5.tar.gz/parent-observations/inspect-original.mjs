import { mkdir, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { withBrowser } from '/tmp/lutriva-filter-motion-trial-xOupNS/harness/browser_harness.mjs';

const root = path.dirname(new URL(import.meta.url).pathname);
const source = '/tmp/lutriva-filter-motion-trial-xOupNS/original-product';
const output = path.join(root, 'original');
await mkdir(output);
const observations = [];
await withBrowser(source, output, async ({ origin, page, evaluate, screenshot, pause, exceptions }) => {
  await page('Page.navigate', { url: origin });
  for (let i = 0; i < 100; i += 1) {
    try { if (await evaluate("document.readyState === 'complete' && document.querySelectorAll('#orders > li').length === 4")) break; } catch {}
    await pause(50);
  }
  const state = label => evaluate(`(() => {
    const panel = document.getElementById('filters'), style = getComputedStyle(panel);
    return { label: ${JSON.stringify(label)}, expanded: document.getElementById('filter-toggle').getAttribute('aria-expanded'), hidden: panel.hidden, opacity: style.opacity,
      active: document.activeElement?.id || document.activeElement?.getAttribute('aria-label'),
      reduce: matchMedia('(prefers-reduced-motion: reduce)').matches,
      panel: panel.getBoundingClientRect().toJSON(), width: innerWidth, documentWidth: document.documentElement.scrollWidth };
  })()`);
  const click = async selector => {
    const box = await evaluate(`(() => { const r = document.querySelector(${JSON.stringify(selector)}).getBoundingClientRect(); return { x: r.x + r.width / 2, y: r.y + r.height / 2 }; })()`);
    await page('Input.dispatchMouseEvent', { type: 'mousePressed', button: 'left', clickCount: 1, ...box });
    await page('Input.dispatchMouseEvent', { type: 'mouseReleased', button: 'left', clickCount: 1, ...box });
  };
  await screenshot('initial-wide.png');
  await click('#filter-toggle'); await pause(60);
  observations.push(await state('open-60ms'));
  await click('#filter-toggle'); await pause(40);
  await click('#filter-toggle'); await pause(500);
  observations.push(await state('open-close-open-settled'));
  await screenshot('rapid-repeat-wide.png', { captureBeyondViewport: false });
  // Reset the fixture document, not the product implementation.
  await page('Page.reload', { ignoreCache: true }); await pause(150);
  await page('Emulation.setDeviceMetricsOverride', { width: 320, height: 900, deviceScaleFactor: 1, mobile: false });
  await page('Emulation.setEmulatedMedia', { features: [{ name: 'prefers-reduced-motion', value: 'reduce' }] });
  await click('#filter-toggle'); await pause(60);
  observations.push(await state('reduced-open-60ms'));
  await pause(400);
  await evaluate("document.getElementById('owner').value = '가족 모임 전에 주문을 확인해야 하는 아주 길고 구체적인 한국어 고객 이름'; document.getElementById('owner').dispatchEvent(new Event('input', {bubbles:true}));");
  observations.push(await state('reduced-open-settled'));
  await screenshot('reduced-open-320.png', { captureBeyondViewport: false });
  await page('Input.dispatchKeyEvent', { type: 'keyDown', key: 'Escape', code: 'Escape', windowsVirtualKeyCode: 27 });
  await page('Input.dispatchKeyEvent', { type: 'keyUp', key: 'Escape', code: 'Escape', windowsVirtualKeyCode: 27 });
  await pause(60);
  observations.push(await state('reduced-escape-60ms'));
  await screenshot('reduced-closing-320.png', { captureBeyondViewport: false });
  await pause(400);
  observations.push(await state('reduced-escape-settled'));
  await writeFile(path.join(output, 'observations.json'), JSON.stringify({ observations, exceptions, limits: ['60ms samples show these observed stages, not a universal duration requirement.', 'Pointer/keyboard input used browser protocol; long query was synthetic setup.', 'Viewport emulation is not a physical device or OS-level reduced-motion test.'] }, null, 2) + '\n');
});
console.log(JSON.stringify(observations));
