import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';

const [trial, inventoryPath, repo] = process.argv.slice(2);
if (!trial || !inventoryPath) throw new Error('Usage: node verify-scope.mjs TRIAL FROZEN_INVENTORY [REPO]');
const inventory = JSON.parse(fs.readFileSync(inventoryPath, 'utf8'));
const digest = bytes => createHash('sha256').update(bytes).digest('hex');
const list = (root, prefix = '') => fs.readdirSync(root).sort().flatMap(name => {
  const absolute = path.join(root, name), relative = prefix + name, stat = fs.lstatSync(absolute);
  assert(!stat.isSymbolicLink(), 'Unexpected link: ' + absolute);
  if (stat.isDirectory()) return list(absolute, relative + '/');
  assert(stat.isFile(), 'Unexpected file type: ' + absolute);
  return [relative];
});
const frozenPaths = ['TASK.md', ...['skills', 'original-product', 'harness'].flatMap(name => list(path.join(trial, name), name + '/'))].sort();
assert.deepEqual(frozenPaths, Object.keys(inventory.files).sort());
for (const name of frozenPaths) {
  const bytes = fs.readFileSync(path.join(trial, name));
  assert.deepEqual({ bytes: bytes.length, sha256: digest(bytes) }, inventory.files[name], name);
}
const skillPaths = frozenPaths.filter(name => name.startsWith('skills/'));
if (repo) {
  for (const name of [...skillPaths, 'harness/browser_harness.mjs']) {
    const gitPath = name.startsWith('harness/') ? 'scripts/browser_harness.mjs' : name;
    const bytes = execFileSync('git', ['show', inventory.baseline_commit + ':' + gitPath], { cwd: repo });
    assert.equal(digest(bytes), inventory.files[name].sha256, gitPath + ' snapshot');
  }
}
const allowed = ['DESIGN.md', 'app.js', 'index.html', 'style.css'];
assert.deepEqual(list(path.join(trial, 'product')), allowed);
assert.deepEqual(list(path.join(trial, 'original-product')), allowed);
const source = (side, name) => fs.readFileSync(path.join(trial, side, name), 'utf8');
const before = source('original-product', 'app.js'), after = source('product', 'app.js');
assert.deepEqual(after.split('function setOpen(next) {')[0], before.split('function setOpen(next) {')[0]);
assert.deepEqual(after.slice(after.indexOf("el('filter-form').addEventListener")), before.slice(before.indexOf("el('filter-form').addEventListener")));
const ids = html => [...html.matchAll(/\bid="([^"]+)"/g)].map(match => match[1]).sort();
assert.deepEqual(ids(source('product', 'index.html')), ids(source('original-product', 'index.html')));
const products = Object.fromEntries(allowed.map(name => {
  const bytes = fs.readFileSync(path.join(trial, 'product', name));
  return [name, { bytes: bytes.length, sha256: digest(bytes) }];
}));
console.log(JSON.stringify({ frozenFiles: frozenPaths.length, skills: skillPaths.length, matchedGit: repo ? inventory.baseline_commit : null, allowedFiles: allowed, preserved: ['order data, state declarations and render function', 'submit/clear handlers', 'HTML ID list'], products }, null, 2));
