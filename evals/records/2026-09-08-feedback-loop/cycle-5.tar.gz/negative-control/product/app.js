const orders = [
  { id: 'M-101', owner: '김민지', item: '머그', status: 'ready' },
  { id: 'M-102', owner: '박도윤', item: '접시', status: 'sent' },
  { id: 'M-103', owner: '김민지', item: '잔', status: 'sent' },
  { id: 'M-104', owner: '이서연', item: '앞치마', status: 'ready' },
];
const el = id => document.getElementById(id);
let open = false;
let applied = { owner: '', status: 'all' };
const statusName = value => ({ ready: '준비 중', sent: '발송 완료', all: '전체 상태' })[value];

function render() {
  const visible = orders.filter(order => order.owner.includes(applied.owner.trim()) && (applied.status === 'all' || order.status === applied.status));
  el('orders').replaceChildren(...visible.map(order => {
    const row = document.createElement('li'); row.className = 'order'; row.dataset.order = order.id;
    const summary = document.createElement('div');
    const heading = document.createElement('strong'); heading.textContent = order.id + ' · ' + order.owner;
    const body = document.createElement('p'); body.textContent = order.item + ' · ' + statusName(order.status);
    summary.append(heading, body);
    const button = document.createElement('button'); button.type = 'button'; button.dataset.order = order.id; button.textContent = '상세'; button.setAttribute('aria-label', order.id + ' 주문 상세');
    button.addEventListener('click', () => { el('detail').textContent = order.id + ' · ' + order.owner + ' · ' + order.item + ' 주문을 확인 중입니다.'; });
    row.append(summary, button); return row;
  }));
  el('count').textContent = visible.length + '개 주문';
  el('empty').hidden = visible.length !== 0;
  el('applied').textContent = applied.owner || applied.status !== 'all' ? '적용한 조건: ' + (applied.owner || '모든 고객') + ' · ' + statusName(applied.status) : '모든 주문을 보고 있습니다.';
}

function setOpen(next) {
  if (open === next) return;
  const panel = el('filters');
  const focusWasInside = panel.contains(document.activeElement);
  open = next;
  el('filter-toggle').setAttribute('aria-expanded', String(open));
  // Semantic state and focus follow the action, never an animation callback.
  panel.hidden = !open;
  if (open) {
    el('owner').focus();
  } else if (focusWasInside) {
    el('filter-toggle').focus();
  }
}

el('filter-toggle').addEventListener('click', () => setOpen(!open));
el('filter-close').addEventListener('click', () => setOpen(false));
document.addEventListener('keydown', event => {
  if (open && event.key === 'Escape' && !event.isComposing && !event.defaultPrevented) {
    event.preventDefault();
    setOpen(false);
  }
});
el('filter-form').addEventListener('submit', event => {
  event.preventDefault();
  applied = { owner: el('owner').value, status: el('status').value };
  render(); setOpen(false);
});
el('clear').addEventListener('click', () => {
  el('owner').value = ''; el('status').value = 'all';
  applied = { owner: '', status: 'all' }; render();
});
render();
