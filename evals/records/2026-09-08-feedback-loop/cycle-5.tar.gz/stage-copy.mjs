import { cp, mkdir, readFile, readdir, readlink, lstat, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import path from 'node:path';

// Mechanical, exact-copy staging only. Never creates a repository commit/archive.
const staging='/tmp/lutriva-cycle5-record-mhKBGX';
const repo='/Users/rex/Desktop/personal/lutriva';
const mappings=[
  ['/tmp/lutriva-filter-motion-trial-xOupNS','trial'],
  ['/tmp/lutriva-filter-motion-parent-aUMyBe','parent-observations'],
  ['/tmp/lutriva-filter-observer-wlMxTW','observer'],
  ['/tmp/lutriva-filter-negative-5TZ2zw','negative-control'],
  ['/tmp/lutriva-filter-author-vecfhX','author'],
  ['/tmp/lutriva-keyboard-helper-lhBxF5','keyboard-evidence'],
];
const hash=value=>createHash('sha256').update(value).digest('hex');
async function inventory(root){
  const entries=[];
  async function walk(dir,relative=''){
    for(const item of (await readdir(dir,{withFileTypes:true})).sort((a,b)=>a.name.localeCompare(b.name))){
      const rel=relative?relative+'/'+item.name:item.name;
      const absolute=path.join(dir,item.name),stat=await lstat(absolute);
      if(item.isDirectory()) { entries.push({path:rel,type:'directory'});await walk(absolute,rel); }
      else if(item.isSymbolicLink()) entries.push({path:rel,type:'symlink',target:await readlink(absolute)});
      else if(item.isFile()) entries.push({path:rel,type:'file',bytes:stat.size,sha256:hash(await readFile(absolute))});
      else throw new Error('Unexpected special file: '+absolute);
    }
  }
  await walk(root);return entries;
}
const equal=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
const summarize=entries=>({files:entries.filter(e=>e.type==='file').length,directories:entries.filter(e=>e.type==='directory').length,symlinks:entries.filter(e=>e.type==='symlink').length,bytes:entries.reduce((n,e)=>n+(e.bytes||0),0)});
const report={staging,started:new Date().toISOString(),scope:'Exact copies only; source reports retain their original text and absolute historical paths. No archive or repository commit.',cacheProfileInspection:'All six evidence roots were listed and sized before copying. No Chrome profile/cache or .git directory was found; no evidence omissions were required.',omissions:[],evidence:[],tools:[]};
for(const [source,destination] of mappings){
  const before=await inventory(source);
  const forbidden=before.filter(e=>/(^|\/)(\.git|Cache|Code Cache|GPUCache|ShaderCache|GrShaderCache|DawnCache|Crashpad|__pycache__)(\/|$)/.test(e.path));
  if(forbidden.length)throw new Error('Inspection required before copying potential cache/profile paths: '+JSON.stringify(forbidden));
  await cp(source,path.join(staging,destination),{recursive:true,errorOnExist:true,force:false,preserveTimestamps:true});
  const after=await inventory(source),copied=await inventory(path.join(staging,destination));
  if(!equal(before,after)||!equal(before,copied))throw new Error('Source changed or copy mismatch: '+source);
  report.evidence.push({source,destination,sourceUnchanged:true,copyExact:true,...summarize(copied),entries:copied});
}
const toolsRoot=path.join(staging,'final-tools');
await mkdir(toolsRoot,{recursive:false});
const toolSources=[];
for(const directory of ['scripts','tests']){
  for(const entry of await inventory(path.join(repo,directory))){
    if(entry.type==='file'&&/\.(py|mjs)$/.test(entry.path))toolSources.push(directory+'/'+entry.path);
  }
}
toolSources.push('package.json');
for(const relative of toolSources){
  const source=path.join(repo,relative),destination=path.join(toolsRoot,relative),before=await readFile(source);
  await mkdir(path.dirname(destination),{recursive:true});
  await cp(source,destination,{errorOnExist:true,force:false,preserveTimestamps:true});
  const copied=await readFile(destination),after=await readFile(source);
  if(!before.equals(after)||!before.equals(copied))throw new Error('Tool copy mismatch: '+relative);
  report.tools.push({source,destination:'final-tools/'+relative,bytes:copied.length,sha256:hash(copied),copyExact:true});
}
for(const relative of ['evals/checks','evals/fixtures']){
  const source=path.join(repo,relative),destination=path.join(toolsRoot,relative),before=await inventory(source);
  await mkdir(path.dirname(destination),{recursive:true});
  await cp(source,destination,{recursive:true,errorOnExist:true,force:false,preserveTimestamps:true});
  const copied=await inventory(destination),after=await inventory(source);
  if(!equal(before,after)||!equal(before,copied))throw new Error('Dependency copy mismatch: '+relative);
  report.tools.push({source,destination:'final-tools/'+relative,copyExact:true,sourceUnchanged:true,...summarize(copied),entries:copied});
}
report.finalTools=await inventory(toolsRoot);
report.summary={evidenceFiles:report.evidence.reduce((n,e)=>n+e.files,0),evidenceBytes:report.evidence.reduce((n,e)=>n+e.bytes,0),finalTools:summarize(report.finalTools),allCopiesExact:true};
report.finished=new Date().toISOString();
await writeFile(path.join(staging,'STAGING-COPY-MANIFEST.json'),JSON.stringify(report,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({staging,summary:report.summary,mappings:report.evidence.map(({source,destination,files,bytes})=>({source,destination,files,bytes}))},null,2));
