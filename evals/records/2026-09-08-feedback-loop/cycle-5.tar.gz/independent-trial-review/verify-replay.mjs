import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';

const [record, review] = process.argv.slice(2);
const read = (root, name) => JSON.parse(fs.readFileSync(path.join(root, name)));
const cases = [
  ['original', 'observer/original-corrected/browser.json', 'original-replay-1/browser.json'],
  ['candidate', 'observer/candidate-corrected/browser.json', 'candidate-replay-1/browser.json'],
  ['negative', 'negative-control/corrected-checker-result/browser.json', 'negative-replay-1/browser.json'],
];
const results = {};
for (const [name, saved, replay] of cases) {
  const before = read(record, saved), after = read(review, replay);
  assert.deepEqual(after.summary, before.summary);
  assert.deepEqual(after.checks.map(c => [c.name, c.pass]), before.checks.map(c => [c.name, c.pass]));
  assert.deepEqual(after.before, before.before);
  assert.deepEqual(after.before, after.after);
  assert.equal(after.errors.length, 0);
  assert.equal(after.exceptions.length, 0);
  assert.equal(after.evaluatorSha256, before.evaluatorSha256);
  assert.equal(after.browserVersionBefore.product, 'Chrome/152.0.7977.83');
  assert.deepEqual(after.browserVersionBefore, after.browserVersionAfter);
  assert.equal(after.unexpectedTargets, undefined);
  const motion = after.checks.find(c => c.name === 'dynamic reduced preference is honored');
  const max = m => Math.max(0, ...m.css.flatMap(e => [...(e.transitionProperty === 'none' ? [] : e.transition), ...(e.animationName === 'none' ? [] : e.animation)]), ...m.running.map(e => Number(e.timing.duration) || 0));
  results[name] = { file: path.join(review, replay), summary: after.summary, sameOrderedNamesAndPassesAsStored: true, evaluatorSha256: after.evaluatorSha256, harness: after.harness, versions: [after.browserVersionBefore.product, after.browserVersionAfter.product], productHashesBefore: after.before, productHashesAfter: after.after, failureNames: after.checks.filter(c => !c.pass).map(c => c.name), motion: { pass: motion.pass, normalMaxMs: max(motion.actual.normal), reducedMaxMs: max(motion.actual.dynamicReduced), reducedFrames: motion.actual.dynamicReduced.running.map(a => a.frames) } };
}
const before = read(review, 'audit-before.json'), after = read(review, 'audit-after.json');
for (const key of ['executableVersion', 'executableSha256', 'evaluatorV1Sha256', 'evaluatorV2Sha256', 'frozenHarnessSha256', 'productHashes']) assert.deepEqual(after[key], before[key]);
console.log(JSON.stringify({ environmentAndSourceHashesUnchanged: true, results }, null, 2));
