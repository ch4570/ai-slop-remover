# Cycle 5 copied-evidence review

Reviewer: `/root/cycle5_archive_review`, 2026-09-09 KST.
Input: `/tmp/lutriva-cycle5-record-mhKBGX`, a staging directory supplied by the parent.
Review output: `/tmp/lutriva-cycle5-archive-review-fhzkNQ`.
No repository, product, evaluator, frozen harness, or staging files were edited by this reviewer.

## Findings

No discrepancy found in the reviewed frozen-input, comparison, negative-control, or parent-observation claims. The corrected observer independently replayed the stored results on the copied products: original 28/42, candidate 42/42, and negative control 41/42 with exactly the reduced-motion check failing. All three fresh runs had zero collection errors and zero runtime exceptions. This review has not yet verified a final archive or external inventory.

`scope-verification.log` records the actual exit-0 scope command with the repository argument. It checked exactly 71 frozen files (TASK + 65 skill files + 4 original product files + 1 harness), matched all skill/harness bytes to Git `6514ff3`, restricted the final product to the allowed four files, and confirmed the declared source sections and HTML ID list remain equal. Source equality is narrower than full behavioral equivalence.

`audit.mjs` directly reads the six stored browser reports, without trusting the comparison summary. `audit-before.json` and `audit-after.json` show the same ordered list of 42 distinct names for original/candidate v1, original/candidate v2, and both negative-control versions. Recomputed counts and failure names agree with the reports: both original versions have the same 14 failures; both candidates pass all 42. Every stored report has identical before/after product hashes matching the copied product bytes, no errors/exceptions, and equal before/after Chrome `.83` version records. The two parent versioned observation reports also record `.83` and zero exceptions.

The entire v2 evaluator is exactly v1 with one occurrence of the reduced-effect predicate replaced. V1 SHA-256 is `9e8301f2f78c10ba4229ecb3e9994c6cf90fd5d0511bdae890418db6366bc02e`; v2 is `92d8cdc2b2e1990746d53018dc8437eac77e5edc0d885b826c51ede5de773ef6`. The changed branch requires reduced motion to remain zero when normal motion is zero. The old negative-control report actually records normal 0ms / reduced 800ms with translateY(-80px) to translateY(0px), yet passes; the corrected report fails exactly `dynamic reduced preference is honored`. Only the negative-control CSS differs from the candidate; its other three files match. The preserved v1 false pass was audited from its raw report and was not rerun in this review.

## Actual replay

All commands used the explicit third `trial/harness/browser_harness.mjs` argument and fresh output directories. Exact commands, stdout, and exits are preserved in the corresponding `.log` files. All three completed on their first attempt; this review did not encounter the known preexisting partial DevToolsActivePort read race or change its frozen implementation.

| Output | Exit | Passed | Failed | Errors | Result |
| --- | --- | --- | --- | --- | --- |
| `original-replay-1/` | 1 | 28 | 14 | 0 | Same 14 failed names as stored original |
| `candidate-replay-1/` | 0 | 42 | 0 | 0 | Same ordered names and outcomes as stored candidate |
| `negative-replay-1/` | 1 | 41 | 1 | 0 | Only dynamic reduced preference fails |

`verify-replay.mjs` and `replay-comparison.json` compare actual replay names/outcomes, hashes, versions and motion records to the stored evidence. Replayed motion metrics are original 350ms/0.01ms, candidate 160ms/0ms, and negative 0ms/800ms; the negative keyframes again show the spatial travel. Each run records `Chrome/152.0.7977.83` before/after and unchanged product bytes, with no unexpected page target recorded.

The current Node is `v26.8.1`. The Chrome executable reported `Google Chrome 152.0.7977.83` before and after this sequence; executable SHA-256 remained `5f3d43277ede0c2804c099e71f712d033a3351216f49ac34d9482cab00ec9d0c`. Frozen harness SHA-256 remained `d74e018d3fd512e73fa354c4d254217ae6fcb2662d4487091d679c36efaa33e2`; both evaluator and all three product hash sets were also unchanged. These hashes cover the named bytes, not the entire installed Chrome bundle or its background activity.

## Observation and image review

I read the parent versioned observation JSON directly. The stored original rapid open-close-open settles at expanded=true/hidden=true; the candidate settles expanded=true/hidden=false with owner focus. At the stored reduced-Escape 60ms sample, original is opacity=0/hidden=false with owner focus; candidate is hidden=true with toggle focus, retained in the settled sample. This supports the parent narrative at those sampled stages; I did not independently rerun the parent's transition adapter.

I directly opened these three existing copied images: `observer/candidate-corrected/wide-open.png`, `narrow-open-long.png`, and `narrow-empty.png`. The wide image is 1280x900, the narrow images 320x800. Visible controls and text do not overlap in these frames. The narrow long input displays a scrolled portion of its text, and the applied query wraps through many lines; the empty state and toggle focus outline remain visible. This is a limited AI visual inspection of static screenshots, not animation-frame analysis, a user study, or accessibility certification. The fresh replay also generated new PNGs, but I did not visually open those separately.

## Limits and remaining validation

This is a review of one snapshot-direct task and its copied evidence, not a model comparison, skill-version comparison, installed-host discovery test, or evidence of broad autonomous learning. The author self-review and observer reports overlap and are not summed as independent checks. Candidate-blind chronology is explicitly reported by the original observer; copied artifacts alone cannot authenticate that history or prove independent human review.

The actual replay uses headless Chrome protocol input, committed Korean text, emulated reduced-motion preferences and viewports, and explicitly seeded select.value after real Tab access. It does not establish native select-menu success, OS IME composition, physical devices, screen-reader speech, cross-browser behavior, zoom behavior, network isolation, or updater isolation. The `.76`→`.83` historical incident remains an excluded preparation run with unknown cause/timing, as documented. No unsafe/native-keycode preparation adapter, installation, full Python/npm suite, or new-helper test was run by this reviewer during this stage.

Final tar/inventory consistency, archive whole-file SHA, fresh extraction, and the requested bounded new-helper test are pending a concrete final archive from the parent. Staging bytes can refresh, especially `final-tools/`; this report makes no claim to have validated those future bytes.
