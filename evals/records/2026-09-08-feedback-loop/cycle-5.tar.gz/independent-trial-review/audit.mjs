import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';

const root = process.argv[2];
const read = name => fs.readFileSync(path.join(root, name));
const json = name => JSON.parse(read(name));
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const productHashes = name => Object.fromEntries(fs.readdirSync(path.join(root, name)).sort().map(file => [file, hash(read(name + '/' + file))]));
const v1 = read('observer/evaluate.mjs').toString();
const v2 = read('observer/evaluate-corrected.mjs').toString();
const oldPredicate = 'maximumMotion(normal)===0||maximumMotion(reduced)<maximumMotion(normal)||(spatialMotion(normal)&&!spatialMotion(reduced))';
const newPredicate = 'maximumMotion(normal)===0 ? maximumMotion(reduced)===0 : maximumMotion(reduced)<maximumMotion(normal)||(spatialMotion(normal)&&!spatialMotion(reduced))';
assert.equal(v1.split(oldPredicate).length, 2);
assert.equal(v1.replace(oldPredicate, newPredicate), v2);
assert.equal(hash(Buffer.from(v1)), '9e8301f2f78c10ba4229ecb3e9994c6cf90fd5d0511bdae890418db6366bc02e');
assert.equal(hash(Buffer.from(v2)), '92d8cdc2b2e1990746d53018dc8437eac77e5edc0d885b826c51ede5de773ef6');
const cases = [
  ['originalV1', 'observer/original-frozen/browser.json', 'trial/original-product', 28, 14, hash(Buffer.from(v1))],
  ['candidateV1', 'observer/candidate-frozen/browser.json', 'trial/product', 42, 0, hash(Buffer.from(v1))],
  ['originalV2', 'observer/original-corrected/browser.json', 'trial/original-product', 28, 14, hash(Buffer.from(v2))],
  ['candidateV2', 'observer/candidate-corrected/browser.json', 'trial/product', 42, 0, hash(Buffer.from(v2))],
  ['negativeV1', 'negative-control/old-checker-result/browser.json', 'negative-control/product', 42, 0, hash(Buffer.from(v1))],
  ['negativeV2', 'negative-control/corrected-checker-result/browser.json', 'negative-control/product', 41, 1, hash(Buffer.from(v2))],
];
const reports = {};
const names = json(cases[0][1]).checks.map(c => c.name);
assert.equal(new Set(names).size, 42);
for (const [name, file, product, passed, failed, evaluator] of cases) {
  const j = json(file);
  assert.deepEqual(j.checks.map(c => c.name), names);
  assert.deepEqual(j.summary, { passed, failed, errors: 0, total: 42 });
  assert.equal(j.checks.filter(c => c.pass).length, passed);
  assert.equal(j.checks.filter(c => !c.pass).length, failed);
  assert.equal(j.errors.length, 0);
  assert.equal(j.exceptions.length, 0);
  assert.equal(j.evaluatorSha256, evaluator);
  assert.deepEqual(j.before, j.after);
  assert.deepEqual(j.before, productHashes(product));
  assert.equal(j.browserVersionBefore.product, 'Chrome/152.0.7977.83');
  assert.deepEqual(j.browserVersionBefore, j.browserVersionAfter);
  assert.equal(j.unexpectedTargets, undefined);
  const motion = j.checks.find(c => c.name === 'dynamic reduced preference is honored');
  const max = m => Math.max(0, ...m.css.flatMap(e => [...(e.transitionProperty === 'none' ? [] : e.transition), ...(e.animationName === 'none' ? [] : e.animation)]), ...m.running.map(e => Number(e.timing.duration) || 0));
  reports[name] = { file, summary: j.summary, evaluatorSha256: j.evaluatorSha256, versions: [j.browserVersionBefore.product, j.browserVersionAfter.product], productUnchangedAndMatchesCopy: true, failureNames: j.checks.filter(c => !c.pass).map(c => c.name), motion: { pass: motion.pass, normalMaxMs: max(motion.actual.normal), reducedMaxMs: max(motion.actual.dynamicReduced), reducedFrames: motion.actual.dynamicReduced.running.map(a => a.frames) } };
}
assert.deepEqual(reports.originalV1.failureNames, reports.originalV2.failureNames);
assert.deepEqual(reports.negativeV2.failureNames, ['dynamic reduced preference is honored']);
assert.equal(reports.negativeV1.motion.normalMaxMs, 0);
assert.equal(reports.negativeV1.motion.reducedMaxMs, 800);
assert.equal(reports.negativeV1.motion.pass, true);
assert.equal(reports.negativeV2.motion.normalMaxMs, 0);
assert.equal(reports.negativeV2.motion.reducedMaxMs, 800);
assert.equal(reports.negativeV2.motion.pass, false);
for (const f of ['parent-observations/original-versioned/observations.json', 'parent-observations/result-versioned/observations.json']) {
  const j = json(f);
  assert.equal(j.browserBefore.product, 'Chrome/152.0.7977.83');
  assert.deepEqual(j.browserBefore, j.browserAfter);
  assert.equal(j.exceptions.length, 0);
}
const chromium = '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';
console.log(JSON.stringify({ root, timestamp: new Date().toISOString(), node: process.version, executableVersion: execFileSync(chromium, ['--version'], {encoding:'utf8'}).trim(), executableSha256: hash(fs.readFileSync(chromium)), exactOnePredicateChange: true, evaluatorV1Sha256: hash(Buffer.from(v1)), evaluatorV2Sha256: hash(Buffer.from(v2)), frozenHarnessSha256: hash(read('trial/harness/browser_harness.mjs')), allSixReportsHaveSame42Names: true, reports, productHashes: { original: productHashes('trial/original-product'), candidate: productHashes('trial/product'), negative: productHashes('negative-control/product') } }, null, 2));
