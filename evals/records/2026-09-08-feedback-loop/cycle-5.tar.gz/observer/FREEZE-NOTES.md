Candidate-blind preparation

- Only TASK.md, original-product and the read-only browser harness were inspected when defining the evaluator.
- Original run 1 was aborted due to an invalid macOS native-keycode adapter and an unexpected settings/help browser target. Its artifacts and explanation are preserved. It is excluded from comparisons.
- Original run 2 exposed incomplete Enter activation in the keyboard adapter. Its artifacts are preserved and excluded.
- Original run 3 and two native-select probes established a transport limitation in native dropdown choice. They are excluded from final comparison; the evaluator explicitly seeds status value separately and does not claim native choice or IME composition.
- Original run 4 is a valid 42-check execution with 28 passes, 14 product failures, no harness errors and unchanged product bytes. Before candidate inspection, the reduced-motion metric was broadened to also allow removing spatial motion while retaining opacity at the same duration. This is a task-interpretation refinement, not a candidate-driven change. The duration-only version is preserved in evaluate-v3-valid-duration-metric.mjs.
- The next original run supplies the frozen evaluator SHA and baseline. No candidate has been inspected or executed at the time this note is written.

Known evidence limits: Chromium headless only; synthetic status seeding is disclosed; Korean insertion is committed text rather than IME composition; no screen-reader speech, touch hardware or visual-quality score. Stale callbacks are observed over 800ms, exceeding the original 350ms timers but not proving behavior for every future duration. Geometry, focus, DOM and AX evidence are separate from screenshot judgment.
