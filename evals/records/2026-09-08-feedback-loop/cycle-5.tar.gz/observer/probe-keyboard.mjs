import { withBrowser,claimBrowserEvidence } from '/tmp/lutriva-filter-motion-trial-xOupNS/harness/browser_harness.mjs';
import { writeFile } from 'node:fs/promises';
const out='/tmp/lutriva-filter-observer-wlMxTW/keyboard-probe-2';
await claimBrowserEvidence(out,[]);
const data=[];
await withBrowser('/tmp/lutriva-filter-motion-trial-xOupNS/original-product',out,async({origin,page,call,evaluate,pause})=>{
 data.push({before:await call('Browser.getVersion')});
 const guard=async()=>{const {targetInfos}=await call('Target.getTargets');const u=targetInfos.filter(t=>t.type==='page'&&t.url!=='about:blank'&&!t.url.startsWith(origin+'/'));if(u.length)throw new Error(JSON.stringify(u));};
 const state=async label=>{const value=await evaluate(`({active:document.activeElement.id,value:document.getElementById('status').value,open:document.getElementById('filter-toggle').getAttribute('aria-expanded'),count:document.getElementById('count').textContent})`);data.push({label,value});console.log(label,value)};
 const click=async id=>{const p=await evaluate(`(()=>{const r=document.getElementById(${JSON.stringify(id)}).getBoundingClientRect();return{x:r.left+r.width/2,y:r.top+r.height/2}})()`);await page('Input.dispatchMouseEvent',{type:'mousePressed',...p,button:'left',clickCount:1});await page('Input.dispatchMouseEvent',{type:'mouseReleased',...p,button:'left',clickCount:1});await guard();};
 const key=async(name,vk,code)=>{await page('Input.dispatchKeyEvent',{type:name==='Enter'?'keyDown':'rawKeyDown',key:name,code,windowsVirtualKeyCode:vk,...(name==='Enter'?{text:'\r',unmodifiedText:'\r'}:{})});await page('Input.dispatchKeyEvent',{type:'keyUp',key:name,code,windowsVirtualKeyCode:vk});await guard();};
 await page('Page.navigate',{url:origin+'/'});await pause(300);await click('filter-toggle');await pause(800);await click('status');await state('pointer open select');await key('ArrowDown',40,'ArrowDown');await state('arrow down');await key('Enter',13,'Enter');await state('enter commit');await key('Tab',9,'Tab');await state('Tab after select');data.push({after:await call('Browser.getVersion')});
});
await writeFile(out+'/browser.json',JSON.stringify(data,null,2)+'\n',{flag:'wx'});
