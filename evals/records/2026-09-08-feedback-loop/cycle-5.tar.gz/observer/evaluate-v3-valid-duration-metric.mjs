import { readFile, writeFile, readdir, mkdir } from 'node:fs/promises';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { pathToFileURL } from 'node:url';

// Frozen from TASK.md and original-product before candidate inspection.
// Usage: node evaluate.mjs PRODUCT_DIR NEW_OUTPUT_DIR [HARNESS_PATH]
const [productArg, outputArg, harnessArg = '/tmp/lutriva-filter-motion-trial-xOupNS/harness/browser_harness.mjs'] = process.argv.slice(2);
if (!productArg || !outputArg) throw new Error('Usage: node evaluate.mjs PRODUCT_DIR NEW_OUTPUT_DIR [HARNESS_PATH]');
const product = path.resolve(productArg), output = path.resolve(outputArg);
const { withBrowser, claimBrowserEvidence } = await import(pathToFileURL(path.resolve(harnessArg)));
const sha = value => createHash('sha256').update(value).digest('hex');
async function digestTree(root) {
  const result = {};
  async function walk(dir, prefix = '') {
    for (const item of (await readdir(dir, { withFileTypes: true })).sort((a,b) => a.name.localeCompare(b.name))) {
      const name = prefix + item.name;
      if (item.isDirectory()) await walk(path.join(dir, item.name), name + '/');
      else if (item.isFile()) result[name] = sha(await readFile(path.join(dir, item.name)));
      else result[name] = 'nonregular';
    }
  }
  await walk(root); return result;
}
const before = await digestTree(product);
const imageNames = ['wide-open.png', 'narrow-open-long.png', 'narrow-empty.png'];
await claimBrowserEvidence(output, imageNames);
const report = {
  evaluatorSha256: sha(await readFile(new URL(import.meta.url))),
  product, output, harness: path.resolve(harnessArg), before, started: new Date().toISOString(),
  methodology: {
    input: 'All claimed activation and Tab/Escape/Enter behavior uses Chrome Input.dispatchMouseEvent/Input.dispatchKeyEvent. Korean strings use Chrome Input.insertText. No HTMLElement.click(), focus(), or synthetic DOM input/change events are used.',
    setup: 'Page reload and Emulation media/viewport are test setup. Pointer helper may scroll the target into view through DOM scrollIntoView before sending real browser pointer events. Status value ready is explicitly seeded by assigning select.value after actual Tab reaches status; no native dropdown-selection success is claimed. Subsequent draft preservation, application and clear are actual browser actions.',
    keyboardLimitation: 'Original-only native-select probes did not change status through this macOS headless CDP path, including rawKeyDown and pointer-open variants; Enter submitted the form. Those exploratory runs are excluded from comparison. Native dropdown selection and IME composition remain unverified; Tab/Escape/Enter and Korean committed-text insertion are directly exercised.',
    horizon: '800 ms stale-callback observation exceeds the original known 350 ms timer; this is a finite observation limit, not a preferred animation duration or a deadline for visual completion.',
    evidence: 'Assertions use DOM, rendered rectangles, focus, hit testing and accessibility-tree presence. Screenshots are artifacts for separate visual review, not a visual-quality score. No assistive-technology speech or physical-device test is claimed.',
    motion: 'Zero animation is permitted. For normal motion with measurable panel effects, reduced motion must remove or reduce the measurable transition/animation duration; focus and interaction checks remain immediate. No library/class/timer architecture is prescribed.',
    focus: 'Opening may retain visible focus on the disclosure toggle or move it to an available panel control. Actual Tab must reach the panel input. Escape is tested from within the panel, not as an unrequested global shortcut or modal trap.'
  }, checks: [], scenarios: [], errors: [], exceptions: []
};
function check(name, pass, actual, expected) { report.checks.push({ name, pass: !!pass, actual, expected }); }
try {
  await withBrowser(product, output, async ({ origin, page, call, evaluate, screenshot, pause, exceptions }) => {
    report.browserVersionBefore=await call('Browser.getVersion');
    const guard = async () => {
      const {targetInfos}=await call('Target.getTargets');
      const unexpected=targetInfos.filter(t=>t.type==='page'&&t.url!=='about:blank'&&!t.url.startsWith(origin+'/'));
      if(unexpected.length){report.unexpectedTargets=unexpected;const error=new Error('Unexpected browser page target/navigation; aborting: '+JSON.stringify(unexpected));error.fatal=true;throw error;}
    };
    await guard();
    const q = JSON.stringify;
    const key = async (name, modifiers = 0) => {
      const map = { Tab: [9,'Tab'], Enter: [13,'Enter'], Escape: [27,'Escape'], ArrowDown: [40,'ArrowDown'], Backspace: [8,'Backspace'], a: [65,'KeyA'] };
      const [vk,code] = map[name] || [0,name];
      await page('Input.dispatchKeyEvent', { type: name==='Enter'?'keyDown':'rawKeyDown', key:name, code, windowsVirtualKeyCode:vk, modifiers, ...(name==='Enter'?{text:'\r',unmodifiedText:'\r'}:{}) });
      await page('Input.dispatchKeyEvent', { type: 'keyUp', key:name, code, windowsVirtualKeyCode:vk, modifiers });
      await guard();
    };
    const insert = text => page('Input.insertText', { text });
    const point = async selector => evaluate(`(() => { const e=document.querySelector(${q(selector)}); if(!e) throw new Error('Missing pointer target '+${q(selector)}); const r=e.getBoundingClientRect(); if(r.top<0||r.bottom>innerHeight||r.left<0||r.right>innerWidth) e.scrollIntoView({block:'center',inline:'nearest',behavior:'instant'}); const b=e.getBoundingClientRect(); const x=b.left+b.width/2,y=b.top+b.height/2; const hit=document.elementFromPoint(x,y); return {x,y,width:b.width,height:b.height,hit:hit&&(hit.id||hit.tagName),targetReceives:!!hit&&(hit===e||e.contains(hit))}; })()`);
    const click = async selector => {
      const p = await point(selector);
      if (!p.width || !p.height || !p.targetReceives) throw new Error(`Pointer target unavailable ${selector}: ${JSON.stringify(p)}`);
      await page('Input.dispatchMouseEvent', { type: 'mouseMoved', x:p.x, y:p.y });
      await page('Input.dispatchMouseEvent', { type: 'mousePressed', x:p.x, y:p.y, button:'left', clickCount:1 });
      await page('Input.dispatchMouseEvent', { type: 'mouseReleased', x:p.x, y:p.y, button:'left', clickCount:1 });
      await guard();
      return p;
    };
    const snap = async () => evaluate(`(() => {
      const panel=document.getElementById('filters'), active=document.activeElement;
      const rect=e=>{const r=e.getBoundingClientRect();return {left:r.left,top:r.top,right:r.right,bottom:r.bottom,width:r.width,height:r.height}};
      const available=e=>!!e&&!!e.getClientRects().length&&!e.closest('[hidden],[inert]')&&!e.disabled&&getComputedStyle(e).visibility!=='hidden'&&getComputedStyle(e).display!=='none';
      const controls=['filter-toggle','filter-close','owner','status','apply','clear'].map(id=>{const e=document.getElementById(id);const r=rect(e),s=getComputedStyle(e); const hit=document.elementFromPoint(r.left+r.width/2,r.top+r.height/2);return {id,available:available(e),rect:r,opacity:s.opacity,tabIndex:e.tabIndex,pointerAtCenter:hit===e||e.contains(hit),disabled:e.disabled}});
      return {expanded:document.getElementById('filter-toggle').getAttribute('aria-expanded'),panelHidden:panel.hidden,panelInert:panel.inert,panelAriaHidden:panel.getAttribute('aria-hidden'),panelRect:rect(panel),panelOpacity:getComputedStyle(panel).opacity,active:active.id||active.getAttribute('aria-label')||active.tagName,activeInside:panel.contains(active),activeAvailable:available(active),owner:document.getElementById('owner').value,status:document.getElementById('status').value,count:document.getElementById('count').textContent,ids:[...document.querySelectorAll('#orders li')].map(e=>e.dataset.order),rows:[...document.querySelectorAll('#orders li')].map(e=>e.textContent),detail:document.getElementById('detail').textContent,applied:document.getElementById('applied').textContent,emptyVisible:available(document.getElementById('empty')),controls,viewport:{width:innerWidth,height:innerHeight,scrollWidth:document.documentElement.scrollWidth,bodyScrollWidth:document.body.scrollWidth,scrollX,scrollY}};
    })()`);
    const axPanelControls = async () => {
      const {root} = await page('DOM.getDocument');
      const backend = {};
      for (const id of ['owner','status','apply','clear','filter-close']) {
        const {nodeId} = await page('DOM.querySelector', {nodeId:root.nodeId,selector:'#'+id});
        const {node} = await page('DOM.describeNode',{nodeId}); backend[node.backendNodeId]=id;
      }
      const {nodes} = await page('Accessibility.getFullAXTree');
      return nodes.filter(n=>backend[n.backendDOMNodeId]).map(n=>({id:backend[n.backendDOMNodeId],ignored:n.ignored,role:n.role?.value,name:n.name?.value}));
    };
    const motion = async () => evaluate(`(() => {const p=document.getElementById('filters'); const els=[p,...p.querySelectorAll('*')]; const times=s=>s.split(',').map(x=>parseFloat(x)*(x.trim().endsWith('ms')?1:1000)).filter(Number.isFinite); return {reduced:matchMedia('(prefers-reduced-motion: reduce)').matches,css:els.map(e=>{const s=getComputedStyle(e);return {id:e.id||e.tagName,transitionProperty:s.transitionProperty,transition:times(s.transitionDuration),animationName:s.animationName,animation:times(s.animationDuration)}}),running:document.getAnimations().filter(a=>a.effect?.target&&(a.effect.target===p||p.contains(a.effect.target))).map(a=>({state:a.playState,timing:a.effect.getComputedTiming(),frames:a.effect.getKeyframes().map(f=>({opacity:f.opacity,transform:f.transform,height:f.height,offset:f.offset}))}))};})()`);
    const maximumMotion = m => Math.max(0,...m.css.flatMap(e=>[...(e.transitionProperty==='none'?[]:e.transition),...(e.animationName==='none'?[]:e.animation)]),...m.running.map(e=>Number(e.timing.duration)||0));
    const media = reduce => page('Emulation.setEmulatedMedia',{features:[{name:'prefers-reduced-motion',value:reduce?'reduce':'no-preference'}]});
    const reset = async ({reduce=false,width=1280,height=900}={}) => {
      await media(reduce);
      await page('Emulation.setDeviceMetricsOverride',{width,height,deviceScaleFactor:1,mobile:false});
      await page('Page.navigate',{url:origin+'/'});
      for(let i=0;i<100;i++){if(await evaluate("document.readyState==='complete' && !!document.getElementById('orders') && document.querySelectorAll('#orders li').length===4"))return;await pause(20);}
      throw new Error('Page did not reach original four-order initial state');
    };
    const record = (name,data) => report.scenarios.push({name,...data});
    const run = async (name, fn) => {process.stdout.write('Scenario: '+name+'\n');try {await guard();await fn();await guard();} catch(error){report.errors.push({scenario:name,error:String(error),stack:error.stack});check(name+' executed',false,String(error),'Scenario completes');if(error.fatal)throw error;}};
    const closedChecks = async (prefix,s) => {
      check(prefix+' focus is outside closed panel',s.expanded==='false'&&!s.activeInside&&s.activeAvailable,s,'Collapsed intent and available outside focus');
      const ax=await axPanelControls();check(prefix+' controls excluded from AX',ax.every(n=>n.ignored),ax,'No exposed panel input/button AX nodes');
      await key('Tab');const tab=await snap();check(prefix+' next Tab skips panel',!tab.activeInside&&tab.activeAvailable,tab,'Available focus outside panel');
      record(prefix+' closed exclusion',{ax,tab});
    };
    await page('Accessibility.enable');

    await run('identity and initial keyboard/Escape',async()=>{
      await reset(); const initial=await snap();
      const identity=await evaluate(`({title:document.title,brand:document.querySelector('.site-header strong')?.textContent,ids:[...document.querySelectorAll('[id]')].map(e=>e.id),options:[...document.querySelector('#status').options].map(o=>({value:o.value,text:o.textContent})),dialog:!!document.querySelector('[aria-modal="true"],dialog[open]')})`);
      const expectedIds=['filter-toggle','filters','filter-heading','filter-close','filter-form','owner','status','apply','clear','count','applied','orders','empty','detail-heading','detail'];
      check('original IDs/data/options/brand preserved',expectedIds.every(id=>identity.ids.includes(id))&&identity.brand==='다온 운영'&&JSON.stringify(identity.options)==JSON.stringify([{value:'all',text:'전체 상태'},{value:'ready',text:'준비 중'},{value:'sent',text:'발송 완료'}])&&JSON.stringify(initial.ids)===JSON.stringify(['M-101','M-102','M-103','M-104'])&&initial.rows.every((r,i)=>r.includes(['김민지머그 · 준비 중','박도윤접시 · 발송 완료','김민지잔 · 발송 완료','이서연앞치마 · 준비 중'][i]))&&initial.count==='4개 주문',{identity,initial},'Existing IDs, four original records, brand and filter meanings');
      check('initial panel closed and nonmodal',initial.expanded==='false'&&!identity.dialog,{initial,identity},'Closed disclosure, no active modal');
      await key('Tab');let tab=await snap();check('keyboard reaches filter toggle first',tab.active==='filter-toggle',tab.active,'filter-toggle');
      await key('Enter');const opened=await snap();
      check('keyboard opening immediately makes panel usable with suitable focus',opened.expanded==='true'&&(opened.activeInside||opened.active==='filter-toggle')&&opened.activeAvailable&&opened.controls.find(c=>c.id==='owner').available,opened,'Open panel, available focus on toggle or panel after browser activation');
      const entry=[];for(let i=0;i<8;i++){const s=await snap();entry.push(s.active);if(s.active==='owner')break;await key('Tab');}
      const entered=await snap();check('actual Tab immediately reaches open input',entered.active==='owner'&&entered.activeAvailable,{entry,entered},'Browser keyboard reaches available owner input');
      await pause(800);const settled=await snap();await screenshot('wide-open.png',{captureBeyondViewport:false});
      await key('Escape');const escaped=await snap();check('Escape immediately restores toggle focus',escaped.expanded==='false'&&escaped.active==='filter-toggle',escaped,'Collapsed intent and filter-toggle focus');
      await closedChecks('Escape',escaped);await pause(800);const late=await snap();
      check('Escape preserves later outside focus',late.active===report.scenarios.at(-1).tab.active&&!late.activeInside,late,'No delayed focus reassignment after Tab');
      record('identity/keyboard/Escape',{initial,identity,opened,entry,entered,settled,escaped,late});
    });

    await run('real filter application, draft and reset',async()=>{
      await reset();await click('#filter-toggle');await pause(800);await click('#owner');await insert('김');
      await key('Tab');const reachedStatus=await snap();check('actual Tab reaches status input',reachedStatus.active==='status'&&reachedStatus.activeAvailable,reachedStatus,'Available status input reached from owner with actual Tab');
      const syntheticStatusSeed=await evaluate("(() => {const s=document.getElementById('status');s.value='ready';return {method:'explicit synthetic select.value setup; no native selection claim',value:s.value};})()");
      const draft=await snap();check('seeded status prepares ready draft',draft.status==='ready',{syntheticStatusSeed,draft},'Explicit synthetic ready value for application and preservation checks');
      check('unapplied draft leaves all results',draft.count==='4개 주문'&&draft.ids.length===4,draft,'4 unchanged results');
      await click('#filter-close');await pause(800);await click('#filter-toggle');await pause(800);const restored=await snap();
      check('unapplied owner/status survive close and reopen',restored.owner==='김'&&restored.status==='ready'&&restored.ids.length===4,restored,'Draft preserved, still unapplied');
      await click('#apply');const applied=await snap();check('apply changes actual rows and count',JSON.stringify(applied.ids)==='["M-101"]'&&applied.count==='1개 주문'&&applied.applied.includes('김')&&applied.applied.includes('준비 중'),applied,'Only M-101, 1개 주문, applied condition displayed');
      await pause(800);await click('button[data-order="M-101"]');const detail=await snap();check('filtered detail action retains original record',detail.detail==='M-101 · 김민지 · 머그 주문을 확인 중입니다.',detail.detail,'M-101 detail');
      await click('#filter-toggle');await pause(800);await click('#clear');const cleared=await snap();check('clear restores draft and all actual rows/count',cleared.owner===''&&cleared.status==='all'&&cleared.count==='4개 주문'&&JSON.stringify(cleared.ids)==='["M-101","M-102","M-103","M-104"]',cleared,'Empty/all draft with all four orders');
      await click('#owner');await insert('박');await click('#apply');await pause(800);await reset();const reload=await snap();check('reload resets local filter',reload.owner===''&&reload.status==='all'&&reload.ids.length===4&&reload.count==='4개 주문',reload,'Default local state');
      record('filter semantics',{reachedStatus,syntheticStatusSeed,draft,restored,applied,detail,cleared,reload});
    });

    for(const [name,startsOpen,actions,expected] of [['open-close-open',false,3,'true'],['close-open-close',true,3,'false']]) {
      await run(name,async()=>{
        await reset();if(startsOpen){await click('#filter-toggle');await pause(800);}const states=[];
        for(let i=0;i<actions;i++){await click('#filter-toggle');states.push(await snap());}
        await pause(800);const final=await snap();
        check(name+' follows latest intent',final.expanded===expected&&(expected==='true'?final.controls.find(c=>c.id==='owner').available:!final.activeInside)&&final.activeAvailable,{states,final},'Final '+(expected==='true'?'open usable panel':'closed panel with available outside focus'));
        if(expected==='false')await closedChecks(name,final);
        record(name,{states,final});
      });
    }

    await run('nonmodal detail during open without delayed focus theft',async()=>{
      await reset();await click('#filter-toggle');const open=await snap();await click('button[data-order="M-102"]');const immediate=await snap();await pause(800);const late=await snap();
      check('detail works during opening and panel remains nonmodal',immediate.detail==='M-102 · 박도윤 · 접시 주문을 확인 중입니다.'&&immediate.expanded==='true',immediate,'M-102 detail updates while filter open');
      check('opening never steals later detail focus',immediate.active==='M-102 주문 상세'&&late.active===immediate.active, {immediate,late},'Detail button retains deliberate pointer focus after observation');
      await key('Tab');const next=await snap();check('nonmodal keyboard continues through list',next.active==='M-103 주문 상세',next,'Next actual Tab reaches next order detail');
      record('nonmodal opening detail',{open,immediate,late,next});
    });
    await run('detail during closing without delayed focus theft',async()=>{
      await reset();await click('#filter-toggle');await pause(800);await click('#filter-close');const closed=await snap();
      const ax=await axPanelControls();check('close immediately excludes panel controls from AX',ax.every(n=>n.ignored),ax,'No exposed closed panel inputs/buttons');
      check('close immediately removes panel controls from pointer hit testing',closed.controls.filter(c=>c.id!=='filter-toggle').every(c=>!c.pointerAtCenter),closed.controls,'Closed panel controls do not receive pointer at their centers');
      await click('button[data-order="M-104"]');const immediate=await snap();await pause(800);const late=await snap();
      check('detail action is available during closing',immediate.detail==='M-104 · 이서연 · 앞치마 주문을 확인 중입니다.',immediate,'M-104 detail update immediately after close intent');
      check('closing never steals later detail focus',immediate.active==='M-104 주문 상세'&&late.active===immediate.active&&!late.activeInside,{immediate,late},'Detail retains deliberate pointer focus');
      record('closing detail',{closed,ax,immediate,late});
    });

    await run('reduced preference and dynamic changes',async()=>{
      await reset();await click('#filter-toggle');const normal=await motion();
      await media(true);const dynamicReduced=await motion();const dynamicState=await snap();
      check('dynamic reduced preference is honored',dynamicReduced.reduced&&(maximumMotion(normal)===0||maximumMotion(dynamicReduced)<maximumMotion(normal)),{normal,dynamicReduced},'Reduced preference removes/reduces existing motion; absent motion is permitted');
      await click('button[data-order="M-101"]');const selected=await snap();await pause(800);const late=await snap();check('dynamic reduce keeps detail focus and latest open intent',late.active===selected.active&&late.active==='M-101 주문 상세'&&late.expanded==='true'&&late.controls.find(c=>c.id==='owner').available,{dynamicState,selected,late},'Intent and deliberate detail focus survive media change');
      await media(false);await click('#filter-close');await media(true);await click('button[data-order="M-103"]');const closing=await snap();await pause(800);const closingLate=await snap();
      check('reduce during closing preserves outside action/focus',closingLate.expanded==='false'&&closingLate.active===closing.active&&closingLate.active==='M-103 주문 상세',{closing,closingLate},'Closed state and M-103 focus survive media change');
      await reset({reduce:true});await key('Tab');await key('Enter');const reducedOpen=await snap();const reducedMotion=await motion();
      check('reduced initial opening is immediately keyboard usable',reducedOpen.expanded==='true'&&(reducedOpen.activeInside||reducedOpen.active==='filter-toggle')&&reducedOpen.activeAvailable&&reducedOpen.controls.find(c=>c.id==='owner').available,reducedOpen,'Immediate available toggle or panel focus with reduced preference');
      await media(false);const restoredMotion=await motion();await click('#filter-toggle');await click('#filter-toggle');const latest=await snap();await pause(800);const latestLate=await snap();
      check('reduce-to-normal and repetition preserve latest intent',latestLate.expanded==='true'&&latestLate.controls.find(c=>c.id==='owner').available&&latestLate.activeAvailable,{restoredMotion,latest,latestLate},'Panel remains usable after preference returns to normal');
      record('motion preferences',{normal,dynamicReduced,dynamicState,selected,late,closing,closingLate,reducedOpen,reducedMotion,restoredMotion,latest,latestLate});
    });

    await run('320px long Korean query and empty state',async()=>{
      await reset({reduce:true,width:320,height:800});await click('#filter-toggle');await pause(800);await click('#owner');
      const long='아주긴한국어고객이름검색어'.repeat(16);await insert(long);const draft=await snap();await screenshot('narrow-open-long.png',{captureBeyondViewport:false});
      check('320px long draft preserves usable controls without horizontal document overflow',draft.owner===long&&draft.viewport.scrollWidth<=320&&draft.viewport.bodyScrollWidth<=320&&draft.controls.every(c=>c.rect.width===0||(c.rect.left>=-1&&c.rect.right<=321)),draft,'Full draft retained and controls within 320px document');
      await key('Enter');const empty=await snap();await pause(800);const emptyLate=await snap();await screenshot('narrow-empty.png',{captureBeyondViewport:false});
      check('320px keyboard submit produces true zero-result state',empty.count==='0개 주문'&&empty.ids.length===0&&empty.emptyVisible&&empty.applied.includes(long),empty,'0 rows/count and empty guidance, long applied query');
      check('320px long applied/empty state has no horizontal document overflow',emptyLate.viewport.scrollWidth<=320&&emptyLate.viewport.bodyScrollWidth<=320,emptyLate,'Document remains 320px wide');
      await click('#filter-toggle');await pause(800);await click('#clear');const restored=await snap();
      check('320px clear recovers usable full results',restored.ids.length===4&&restored.count==='4개 주문'&&restored.owner==='',restored,'All four orders restored');
      await click('button[data-order="M-104"]');const detail=await snap();check('320px open-panel detail remains usable',detail.detail==='M-104 · 이서연 · 앞치마 주문을 확인 중입니다.'&&detail.expanded==='true',detail,'M-104 detail accessible while panel remains open');
      record('narrow long query',{draft,empty,emptyLate,restored,detail});
    });
    report.exceptions = exceptions;
    report.browserVersionAfter=await call('Browser.getVersion');
    check('no browser runtime exceptions',exceptions.length===0,exceptions,'No Runtime.exceptionThrown events');
  });
} catch(error) { report.errors.push({scenario:'browser harness',error:String(error),stack:error.stack}); }
finally {
  report.after=await digestTree(product);
  check('product bytes unchanged by evaluator',JSON.stringify(before)===JSON.stringify(report.after),{before,after:report.after},'Identical recursive file hashes before and after');
  report.finished=new Date().toISOString();
  report.summary={passed:report.checks.filter(c=>c.pass).length,failed:report.checks.filter(c=>!c.pass).length,errors:report.errors.length,total:report.checks.length};
  await writeFile(path.join(output,'browser.json'),JSON.stringify(report,null,2)+'\n',{flag:'wx'});
  await writeFile(path.join(output,'summary.txt'),report.checks.map(c=>`${c.pass?'PASS':'FAIL'} ${c.name}`).join('\n')+'\n'+JSON.stringify(report.summary)+'\n',{flag:'wx'});
  process.stdout.write(JSON.stringify({output,evaluatorSha256:report.evaluatorSha256,summary:report.summary,failures:report.checks.filter(c=>!c.pass).map(c=>c.name),errors:report.errors},null,2)+'\n');
}
if(report.errors.length) process.exitCode=2;
else if(report.checks.some(c=>!c.pass)) process.exitCode=1;
