독립 필터 전환 평가 결과

동결 평가기 기준으로 원본은 42개 중 28개 통과·14개 실패, 후보는 42개 전부 통과했습니다. 양쪽 실행 오류는 0개이고 동일 이름·순서의 42개 검사를 비교했습니다. 관찰된 회귀는 없으며, 원본의 14개 실패가 모두 후보에서 통과했습니다.

평가기와 비교 경계

- 평가기: `/tmp/lutriva-filter-observer-wlMxTW/evaluate.mjs`
- SHA-256: `9e8301f2f78c10ba4229ecb3e9994c6cf90fd5d0511bdae890418db6366bc02e`
- 원본 기준: `/tmp/lutriva-filter-motion-trial-xOupNS/original-product`
- 후보: `/tmp/lutriva-filter-motion-trial-xOupNS/product`
- TASK와 원본, 읽기 전용 harness로 기대값을 작성하고 원본 결과와 동결 SHA를 부모 에이전트에게 전달한 뒤 후보를 실행했습니다. 후보 관찰 후 평가기나 기대값은 변경하지 않았습니다.
- 원본·후보 각 실행 전후 네 번의 `Browser.getVersion`이 모두 `Chrome/152.0.7977.83`, revision `@79460ebecaa5625e57a5fb679a735659e73dc687`였습니다. 유효 비교 실행에서는 예기치 않은 페이지 target을 관찰하지 않았습니다.
- 각 제품의 네 파일 재귀 SHA-256은 실행 전후 동일했습니다. 평가기는 제품 파일을 수정하지 않았습니다.

관찰 결과

- 원래 컨트롤 ID, 브랜드, 4개 주문 ID·고객·품목·상태와 필터 옵션이 유지됐습니다.
- 실제 브라우저 Tab/Enter로 열기와 입력 접근, 패널 내부 Escape, 닫힌 패널의 AX 제외·Tab 제외·포인터 hit 제외를 검사했습니다. 열 때 토글 포커스 유지와 패널로 이동 모두 허용했습니다.
- 적용 전 입력 유지, 실제 적용 후 M-101 한 행·1개 주문, 원래 상세 내용, 초기화 후 네 행·4개 주문, 새로고침 초기화를 확인했습니다.
- 실제 포인터로 open-close-open과 close-open-close를 연속 실행하고 최종 의도를 관찰했습니다. 열기·닫기 직후 상세 행동과 후속 Tab이 가능하고 800ms 관찰 동안 포커스를 다시 빼앗지 않는지 확인했습니다.
- 모션 감소 초기 설정, 조작 중 설정 변경과 원래 설정 복귀 후 반복 동작을 검사했습니다. 시간 단축뿐 아니라 공간 이동을 opacity로 단순화하는 방식과 모션 생략도 허용합니다.
- 320px 화면에서 긴 한국어 초안, Enter 적용에 따른 0개 결과·빈 상태, 긴 적용 조건의 문서 가로 넘침, 초기화와 열린 패널 상태의 상세 행동을 확인했습니다.

원본에서 실패하고 후보에서 통과한 14개 검사

1. Escape immediately restores toggle focus
2. Escape focus is outside closed panel
3. Escape controls excluded from AX
4. Escape next Tab skips panel
5. Escape preserves later outside focus
6. open-close-open follows latest intent
7. opening never steals later detail focus
8. nonmodal keyboard continues through list
9. close immediately excludes panel controls from AX
10. close immediately removes panel controls from pointer hit testing
11. closing never steals later detail focus
12. dynamic reduce keeps detail focus and latest open intent
13. reduce during closing preserves outside action/focus
14. reduce-to-normal and repetition preserve latest intent

정확한 증거 파일

- 원본 전체 상태·AX·포커스·치수·모션·버전·해시: `/tmp/lutriva-filter-observer-wlMxTW/original-frozen/browser.json`
- 원본 검사 목록: `/tmp/lutriva-filter-observer-wlMxTW/original-frozen/summary.txt`
- 후보 전체 증거: `/tmp/lutriva-filter-observer-wlMxTW/candidate-frozen/browser.json`
- 후보 검사 목록: `/tmp/lutriva-filter-observer-wlMxTW/candidate-frozen/summary.txt`
- 각 `original-frozen` 및 `candidate-frozen` 폴더의 이미지: `wide-open.png`, `narrow-open-long.png`, `narrow-empty.png`
- 준비 과정과 동결 경계: `/tmp/lutriva-filter-observer-wlMxTW/FREEZE-NOTES.md`
- 최초 중단 실행 설명: `/tmp/lutriva-filter-observer-wlMxTW/original-run-1/ABORTED.md`
- 보존한 이전 평가기: `evaluate-v0-native-keycode.mjs`, `evaluate-v1-no-native.mjs`, `evaluate-v2-enter-text.mjs`, `evaluate-v3-valid-duration-metric.mjs`

한계와 제외한 준비 실행

macOS의 headless Chrome·CDP 경로로 검사했습니다. 모든 포인터 활성화와 Tab/Escape/Enter 주장은 실제 Chrome Input 명령에 근거하지만 물리 키보드·터치 기기·스크린 리더 음성은 검사하지 않았습니다. 한국어는 committed text를 삽입했으며 IME 조합을 시험하지 않았습니다. 네이티브 select 팝업은 원본만 대상으로 한 두 차례 probe에서도 선택이 바뀌지 않았으므로, 최종 평가에서는 실제 Tab으로 status 접근을 확인한 뒤 `select.value='ready'`를 별도 명시적 상태 준비로 사용했습니다. 이후 보존·적용·초기화는 실제 브라우저 행동입니다. 네이티브 선택 메뉴 조작 성공은 주장하지 않습니다.

800ms의 지연 관찰은 원본의 알려진 350ms 예약 작업을 넘기기 위한 유한한 관찰 구간이며 임의의 애니메이션 권장 길이나 모든 미래 지연에 대한 증명은 아닙니다. DOM·AX·포커스·치수 증거를 시각적 완성도 판정과 구분합니다. 이미지는 부모 에이전트의 별도 시각 검토를 위한 자료이며 이 평가기는 미적 품질을 점수화하지 않았습니다.

첫 원본 준비 실행은 잘못된 macOS nativeVirtualKeyCode 어댑터와 예상하지 않은 `chrome://settings/help` 페이지가 발견되어 해당 실행의 Node·격리 Chrome 프로세스를 종료했습니다. 해당 PID와 프로필 프로세스가 남지 않았음을 확인했습니다. 당시 실행 중 Helper 경로는 152.0.7977.76이었고 종료 뒤 실행 파일 `--version`은 152.0.7977.83이었습니다. 실행 전 버전값을 수집하지 않았으므로 변화의 원인이나 시점을 단정하지 않습니다. 업데이트 UI를 추가 조작하지 않았으며 프로필 분리가 백그라운드 업데이트·네트워크 격리를 보장한다고 주장하지 않습니다. 이 중단 실행과 키 어댑터 준비 실행 2·3 및 native-select probe는 최종 비교에서 제외했습니다. 유효 비교는 동일 .83 버전의 `original-frozen`과 `candidate-frozen`만 사용합니다.

보관 후 다시 실행할 때는 기존 출력 폴더를 재사용하지 않고 다음 위치 인수를 명시합니다.

`node <evaluate.mjs> <product-directory> <new-output-directory> <browser_harness.mjs>`
