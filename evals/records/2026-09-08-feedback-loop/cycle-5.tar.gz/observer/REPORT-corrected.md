독립 평가 최종 결과 — 반례로 입증한 평가기 오류 수정 후 재검증

수정한 같은 평가기로 원본은 42개 중 28개 통과·14개 실패, 후보는 42개 전부 통과했습니다. 양쪽 실행 오류는 0개입니다. 반례 제품은 의도한 모션 감소 검사 한 항목만 실패했습니다. 원본과 후보의 제품 파일은 수정하지 않았고 모든 재실행에서 제품 SHA가 전후 동일했습니다.

현재 증거와 재현 위치

- 최종 평가기: `/tmp/lutriva-filter-observer-wlMxTW/evaluate-corrected.mjs`
- SHA-256: `92d8cdc2b2e1990746d53018dc8437eac77e5edc0d885b826c51ede5de773ef6`
- 원본: `/tmp/lutriva-filter-observer-wlMxTW/original-corrected/browser.json`
- 후보: `/tmp/lutriva-filter-observer-wlMxTW/candidate-corrected/browser.json`
- 기계 판독용 비교·버전·해시·반례 수치: `/tmp/lutriva-filter-observer-wlMxTW/comparison-corrected.json`
- 각 실제 제품 결과 폴더의 `summary.txt`는 42개 항목별 결과이며, `wide-open.png`, `narrow-open-long.png`, `narrow-empty.png`는 별도 시각 검토용 이미지입니다.
- 휴대 가능한 실행: `node <evaluate-corrected.mjs> <product-directory> <new-output-directory> <browser_harness.mjs>`

평가기 수정의 이유와 범위

최초 후보 비교가 끝난 후 부모 검토자가 제품 동작과 독립적으로 평가기 조건의 허점을 지적했습니다. 기본 모션 최대값이 0이면 모션 감소 설정에 새로운 움직임이 생겨도 통과시키는 분기였습니다. 이를 입증하기 위해 새로운 `/tmp/lutriva-filter-negative-5TZ2zw/product`에만 후보를 복사하고 CSS를 추가했습니다. 평상시 모션은 없애고 감소 설정에서만 `translateY(-80px)`에서 `translateY(0px)`까지 800ms 애니메이션을 도입했습니다. 실제 제품·원본·기존 평가기는 그대로 보존했습니다.

기존 평가기의 반례 실행 `/tmp/lutriva-filter-negative-5TZ2zw/old-checker-result/browser.json`에는 기본 최대값 0ms, 감소 설정 최대값 800ms와 공간 이동 keyframe이 실제로 기록됐지만 `dynamic reduced preference is honored`가 통과했습니다. 이것으로 제품 결과에 맞춘 기대값 조정이 아닌 평가기 결함을 확인했습니다.

별도 `evaluate-corrected.mjs`는 이 한 조건만 변경했습니다. 기본 모션이 0일 때는 감소 설정의 모션도 0이어야 통과합니다. 나머지 시나리오·기대값·입력·관찰 시간은 이전 파일과 같습니다. 수정한 반례 실행 `/tmp/lutriva-filter-negative-5TZ2zw/corrected-checker-result/browser.json`은 41개 통과·모션 감소 1개 실패·오류 0이며 같은 0ms/800ms 이동을 올바르게 실패로 처리했습니다.

수정 평가기로 실제 원본과 후보를 모두 새 출력 경로에 다시 실행했습니다. 동일 이름·순서의 42개 중 원본 실패 14개가 모두 후보에서 통과했고 회귀는 없었습니다. 실제 원본의 모션 수치는 기본 350ms/감소 0.01ms, 후보는 기본 160ms/감소 0ms로 이 분기 수정이 실제 제품에 대한 기준을 바꾸지 않았습니다. 원본·후보·반례 수정 실행의 전후 `Browser.getVersion`은 모두 `Chrome/152.0.7977.83`이었고 예상하지 않은 페이지 target은 없었습니다.

보존한 이전 기록

`/tmp/lutriva-filter-observer-wlMxTW/evaluate.mjs`와 SHA `9e8301f2f78c10ba4229ecb3e9994c6cf90fd5d0511bdae890418db6366bc02e`, `original-frozen`, `candidate-frozen`, `REPORT.md`는 수정하지 않고 보존했습니다. 최초 기대값은 후보를 읽기 전에 작성하고 원본 실행·SHA를 부모에게 전달한 뒤 후보를 검사했습니다. 후보 관찰 후의 유일한 검사 변경은 위의 독립 반례로 입증한 한 분기 오류 수정입니다. 최초 준비 실행의 키 어댑터 문제와 버전 관찰 전환은 기존 `REPORT.md`, `original-run-1/ABORTED.md`, `FREEZE-NOTES.md`에 그대로 남아 있으며 비교 기준으로 사용하지 않습니다.

실제 검증 범위와 한계

실제 Chrome 포인터와 Tab/Escape/Enter 입력으로 열기·닫기·미적용 초안 유지·적용 결과/개수·초기화·상세 행동·빠른 반복·포커스 유지·닫힌 패널 AX/Tab/포인터 제외, 모션 감소 초기 설정과 조작 중 변경, 320px 긴 한국어 초안·빈 결과를 검사했습니다. 토글 포커스 유지 방식도 허용하며 특정 클래스·타이머 구조·애니메이션 권장 시간을 강제하지 않습니다.

상태 select는 실제 Tab으로 접근을 확인한 뒤 `select.value='ready'`를 별도 명시적 준비로 사용했습니다. macOS headless CDP의 네이티브 선택 메뉴 조작은 원본 전용 probe에서 검증되지 않았으며 그 성공을 주장하지 않습니다. 한국어는 committed text 입력으로 IME 조합은 시험하지 않았습니다. 물리 키보드·터치 기기·스크린 리더 음성·다른 브라우저는 미검증입니다. 800ms는 원본의 350ms 예약 작업을 넘기는 유한한 관찰 구간입니다. DOM·AX·포커스·치수 근거를 시각적 완성도와 구분하며 이미지 품질 판단은 부모의 별도 검토 범위입니다. 브라우저 프로필 분리가 업데이트나 네트워크까지 격리한다고 주장하지 않습니다.
