# Final staging scope

The initial STAGING-COPY-MANIFEST.json and STAGING-STATUS.md are preserved copy-time
records, not the final inventory. After that initial copy, the parent refreshed
`final-tools/scripts/browser_harness.mjs` and `final-tools/package.json` and added
`final-tools/tests/browser-startup.test.mjs` for the demonstrated startup defect.
All final scripts/tests, fixtures/checks and package.json were compared to the
repository and matched. The frozen product-trial harness was not refreshed.

The parent added EVIDENCE.md, package-final reports/logs, the independent trial
replay review, the initial/final full regression records, the initial keyboard
review and startup diagnosis/replay layouts. These copies preserve each original
report's wording and historical paths. Reconstructed sources are labeled in the
startup implementation report; no original three-test snapshot is invented.

The external cycle-5-inventory.json and exact archive checker cover the final
complete file set. No Chrome profile/cache, prior record archive or .git is part
of the intended record. Archive verification happens after this note and cannot
be embedded here as a self-hashing claim; its actual result is reported separately
in the repository's cycle-5 record.
