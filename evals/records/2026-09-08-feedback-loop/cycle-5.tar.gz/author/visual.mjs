import { withBrowser, claimBrowserEvidence } from '/tmp/lutriva-filter-motion-trial-xOupNS/harness/browser_harness.mjs';
import { writeFile } from 'node:fs/promises';
const output='/tmp/lutriva-filter-author-vecfhX/visual-final';
await claimBrowserEvidence(output,['narrow-draft-viewport.png','narrow-empty-viewport.png']);
await withBrowser('/tmp/lutriva-filter-motion-trial-xOupNS/product',output,async ({origin,page,call,evaluate,pause,screenshot})=>{
  const browser=await call('Browser.getVersion');
  await page('Emulation.setDeviceMetricsOverride',{width:320,height:640,deviceScaleFactor:1,mobile:false});
  await page('Emulation.setEmulatedMedia',{features:[{name:'prefers-reduced-motion',value:'reduce'}]});
  await page('Page.navigate',{url:origin});
  for(let i=0;i<100;i++){if(await evaluate(`document.readyState==='complete' && document.querySelectorAll('#orders li').length===4`))break;await pause(20);}
  await evaluate(`document.getElementById('filter-toggle').click()`);
  await page('Input.insertText',{text:'서울특별시에서주문하신아주긴한국어고객검색이름'.repeat(8)});
  await screenshot('narrow-draft-viewport.png',{captureBeyondViewport:false});
  await page('Input.dispatchKeyEvent',{type:'keyDown',key:'Enter',code:'Enter',windowsVirtualKeyCode:13,text:'\r',unmodifiedText:'\r'});
  await page('Input.dispatchKeyEvent',{type:'keyUp',key:'Enter',code:'Enter',windowsVirtualKeyCode:13});
  await screenshot('narrow-empty-viewport.png',{captureBeyondViewport:false});
  const observation=await evaluate(`(() => {const e=document.activeElement,r=e.getBoundingClientRect();return {width:innerWidth,clientWidth:document.documentElement.clientWidth,scrollWidth:document.documentElement.scrollWidth,active:e.id,outlineWidth:getComputedStyle(e).outlineWidth,outlineOffset:getComputedStyle(e).outlineOffset,rect:{left:r.left,right:r.right,top:r.top,bottom:r.bottom},count:document.getElementById('count').textContent};})()`);
  await writeFile(output+'/browser.json',JSON.stringify({browser,observation,screenshotMode:'viewport to avoid full-page capture reframing scrollbars'},null,2));
  console.log(JSON.stringify({output,browser:browser.product,observation},null,2));
});
