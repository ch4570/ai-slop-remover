# 주문 필터 전환 수정 — 작성자 실행 기록

제품: `/tmp/lutriva-filter-motion-trial-xOupNS/product`

필터의 `hidden`, `aria-expanded`, 포커스를 같은 이벤트에서 변경하도록 수정했다.
이전 350ms 타이머는 제거했다. 열 때는 고객 이름 입력에 즉시 포커스하고,
닫을 때는 입력을 즉시 숨긴다. 닫기 직전 패널 안에 있던 포커스만 필터 버튼으로
돌려주므로 패널 밖 주문 상세의 포커스를 뒤늦게 빼앗지 않는다.

열기는 160ms 불투명도 변화로 새 영역을 알려 준다. 처음부터 컨트롤을 볼 수 있고
입력할 수 있다. 닫기는 즉시 끝나 다음 목록 조작 중 뒤늦은 재배치가 생기지 않는다.
모션 감소 설정은 CSS 애니메이션을 제거하며 조작 도중 설정 변경도 반영한다.
애니메이션 완료가 상태나 포커스를 변경하는 코드가 없다.

미적용 입력, 적용 필터, 초기화, 실제 주문 상세, 새로고침 초기화는 기존 로컬
계약을 유지한다. 문서 수준 Escape는 열린 패널을 닫으며 패널 밖 포커스는 유지한다.
조합 중이거나 이미 처리된 Escape는 가로채지 않는다. 비모달 구조와 모든 ID를 유지했다.

사용한 스킬은 `/tmp/lutriva-filter-motion-trial-xOupNS/skills/ux-flow-refine/SKILL.md`이다.
스킬의 원칙, 상태 소유/복구 KB, 공유 interaction-design·motion·web 참조와
관련 interaction recipes를 읽었다. 입력/포커스와 시각 전환의 분리, 편집 초안 보존,
최신 의도, 로컬 저장 경계, 결과를 검증하는 방식에 반영했다.
정리 전 계획은 `/tmp/lutriva-filter-author-vecfhX/plan.md`에 기록했다.
이 보고서는 작성자의 구현·검증 기록이며 독립 평가 결과가 아니다.

## 최종 실행과 결과

기존 Node `v26.8.1`, 제공된 읽기 전용 `harness/browser_harness.mjs`, loopback 서버,
임시 Chrome 프로필을 사용했다. 새 패키지나 브라우저를 설치하지 않았다.

아래 원본/수정본 실행에서 각각 직접 수집한 `Browser.getVersion`은 모두
`Chrome/152.0.7977.83`이었다. 상세 메타데이터는 각 `browser.json`의 `browser`에 있다.

```sh
node /tmp/lutriva-filter-author-vecfhX/verify.mjs /tmp/lutriva-filter-motion-trial-xOupNS/original-product /tmp/lutriva-filter-author-vecfhX/baseline-versioned
```

결과: 42개 중 26개 통과, 16개 실패, 종료 코드 1. 즉시 입력·닫기, 재열기 경쟁,
주문 상세에서 지연 포커스 탈취, 패널 밖 Escape, 모션 설정 변경 등이 실패했다.
원본은 읽기 전용으로 검사했다.

```sh
node /tmp/lutriva-filter-author-vecfhX/verify.mjs /tmp/lutriva-filter-motion-trial-xOupNS/product /tmp/lutriva-filter-author-vecfhX/candidate-versioned
```

결과: 42개 모두 통과, 종료 코드 0. 페이지 런타임 예외 0건.
42개는 이 작성자 어댑터의 한정된 결과 assertion 수이며 전반적 접근성 인증이 아니다.
검사 결과/개별 관찰 값:

- 원본: `/tmp/lutriva-filter-author-vecfhX/baseline-versioned/browser.json`
- 수정본: `/tmp/lutriva-filter-author-vecfhX/candidate-versioned/browser.json`
- 어댑터: `/tmp/lutriva-filter-author-vecfhX/verify.mjs`

실행한 행동은 즉시 열기·닫기·Escape, 빠른 반복/재열기 후 450ms 관찰,
모션 정상/감소 및 진행 중 감소 설정 전환, 패널을 연 채 주문 상세 사용,
Tab·Shift+Tab·Enter·Space·Escape를 통한 브라우저 기본 키 동작,
패널에서 목록으로 Tab 이동, 닫힌 입력의 Tab 제외, 실제 필터 결과와 개수,
미적용 초안 보존, 긴 한국어의 빈 결과와 초기화, 새로고침 초기화,
320px에서 모사 터치로 상세 열기·닫기다. 주문 M-101~M-104의 상세 결과를 확인했다.
키 입력은 DOM `dispatchEvent`가 아닌 Chrome CDP 입력 경로를 사용했다.
한국어 텍스트는 `Input.insertText`로 삽입했다.

```sh
node --check /tmp/lutriva-filter-motion-trial-xOupNS/product/app.js
node /tmp/lutriva-filter-author-vecfhX/check-scope.mjs
diff -qr /tmp/lutriva-filter-motion-trial-xOupNS/original-product /tmp/lutriva-filter-motion-trial-xOupNS/product
```

결과: JS 문법 검사 종료 코드 0. 범위 검사 종료 코드 0: 모든 기존 ID와 ID 집합이
동일하고 원본 주문 상수 배열은 문자 단위로 동일하다. 제품 디렉터리에는 허용된
네 파일만 있다. `diff -qr`은 네 파일의 변경만 출력했고, 차이를 나타내는 종료 코드 1이었다.

## 직접 본 화면

1280×900 설정에서 데스크톱 열린 화면과 320×640 설정에서 긴 한국어 입력,
빈 결과/필터 버튼 포커스, 키보드 초기화 버튼 포커스를 캡처하여 이미지 뷰어로 직접 확인했다.

- `/tmp/lutriva-filter-author-vecfhX/candidate-versioned/desktop-open.png`
- `/tmp/lutriva-filter-author-vecfhX/candidate-versioned/narrow-keyboard-focus.png`
- `/tmp/lutriva-filter-author-vecfhX/visual-final/narrow-draft-viewport.png`
- `/tmp/lutriva-filter-author-vecfhX/visual-final/narrow-empty-viewport.png`

기존 녹색 브랜드, 제목·폼·카드 배치가 유지된다. 320px에서 필드·적용/초기화 버튼은
겹치지 않으며, 긴 검색어는 입력 내부에서 스크롤되고 결과 조건 문구는 줄바꿈된다.
보라색 키보드 포커스 외곽선이 화면 안에 보이고 빈 결과에서도 필터 버튼으로 복구할 수 있다.

전체 페이지 캡처가 스크롤바에 맞춰 폭을 재조정하는 현상이 있어 좁은 화면의
포커스 판단은 다음 별도 실행의 뷰포트 캡처를 기준으로 했다.

```sh
node /tmp/lutriva-filter-author-vecfhX/visual.mjs
```

결과: 종료 코드 0, `Chrome/152.0.7977.83`. 관찰 파일은
`/tmp/lutriva-filter-author-vecfhX/visual-final/browser.json`이다.
빈 결과에서 `innerWidth=320`, `clientWidth=scrollWidth=305`로 가로 넘침이 없었다.
필터 버튼은 x=225.3125~287, y=102.25~146.25에 있었고 3px 외곽선/3px 간격도
305px 콘텐츠 폭 안에 들어왔다. 스크린샷은 동작 검증의 대체 근거로 사용하지 않았다.

## 남은 한계와 이전 실행 기록

- 물리 키보드/터치 기기, 실제 한국어 IME의 조합 확정·Escape, 모바일 가상 키보드,
  스크린 리더, 다른 브라우저, 글자만 확대/확대율별 reflow는 확인하지 못했다.
- 이 macOS headless Chrome 실행에서는 기본 select에 보낸 ArrowDown이 값을 바꾸지 않았다.
  선택 상자까지의 Tab 접근은 확인했으나 화살표 선택 완료는 미검증이다.
  상태 필터의 실제 결과는 로컬 select 값을 설정하고 적용하는 별도 검사로 확인했다.
  탐색용 스크립트는 `/tmp/lutriva-filter-author-vecfhX/select-probe.mjs`에 남겼다.
- 초기에 CDP Enter의 문자 데이터 누락과 Shift 수정자 오류가 있어
  `baseline`(16/37 통과), `candidate-1`(27/37 통과) 키보드 결과는 최종 근거에서 제외했다.
  수정 후 `baseline-2`는 20/37, `candidate-2`는 34/37이었다. 남은 세 실패는
  화살표 select 선택을 가정한 연속 검사의 실패였으며 미검증 한계로 분리했다.
- 다음 `baseline-final`은 26/42, `candidate-final`은 42/42였지만 브라우저 버전을
  수집하지 않았다. 환경 담당자로부터 별도 실행 도중 설치된 Chrome 버전 변화가
  관찰됐다는 알림을 받아 이 쌍의 버전 동일성은 미검증으로 남기고 위 `*-versioned`
  쌍을 다시 실행했다. 알림에 나온 버전 변화의 원인/시점은 작성자가 확인하지 않았으며,
  백그라운드 네트워크/업데이트 격리가 입증됐다고 주장하지 않는다.
- 모든 이전 결과는 `/tmp/lutriva-filter-author-vecfhX/` 아래 해당 이름의 디렉터리에
  보존했다. 제공된 수집기는 경로 재사용을 거부하므로 재실행에는 새 출력 경로가 필요하다.
- 서버·URL·영구 저장을 새로 만들지 않았으며 원격 서비스 동작, 성능 수치나
  모든 플랫폼의 접근성을 검증했다고 주장하지 않는다.

## 변경 파일

- `/tmp/lutriva-filter-motion-trial-xOupNS/product/app.js`: 동기 전환/포커스, Escape.
- `/tmp/lutriva-filter-motion-trial-xOupNS/product/style.css`: 짧은 등장, 즉시 종료, 모션 감소.
- `/tmp/lutriva-filter-motion-trial-xOupNS/product/index.html`: 버튼 type, 초안 보존 안내.
- `/tmp/lutriva-filter-motion-trial-xOupNS/product/DESIGN.md`: 동작·모션 선택과 검증 경계.

제품 밖의 작성자 산출물은 `/tmp/lutriva-filter-author-vecfhX/`에만 생성했다.
source skill snapshot, TASK, original-product, 제공 harness는 수정하지 않았다.
