import { withBrowser, claimBrowserEvidence } from '/tmp/lutriva-filter-motion-trial-xOupNS/harness/browser_harness.mjs';
import { writeFile } from 'node:fs/promises';

const [fixture, output] = process.argv.slice(2);
const checks = [];
let browser;
const shots = ['desktop-open.png', 'narrow-draft.png', 'narrow-empty.png', 'narrow-keyboard-focus.png'];
await claimBrowserEvidence(output, shots);
await withBrowser(fixture, output, async ({ origin, page, call, evaluate, screenshot, pause, exceptions }) => {
  browser = await call('Browser.getVersion');
  const read = () => evaluate(`(() => {
    const p = document.getElementById('filters');
    const active = document.activeElement;
    const r = active.getBoundingClientRect();
    return { hidden:p.hidden, expanded:document.getElementById('filter-toggle').getAttribute('aria-expanded'), active:active.id || active.dataset.order || active.tagName, owner:document.getElementById('owner').value, status:document.getElementById('status').value, count:document.getElementById('count').textContent, orders:[...document.querySelectorAll('#orders li')].map(e=>e.dataset.order), empty:!document.getElementById('empty').hidden, applied:document.getElementById('applied').textContent, detail:document.getElementById('detail').textContent, focusVisible:r.width>0 && r.height>0 && r.top>=0 && r.bottom<=innerHeight, overflow:document.documentElement.scrollWidth>innerWidth, animations:p.getAnimations().filter(a=>a.playState==='running').length, reduced:matchMedia('(prefers-reduced-motion: reduce)').matches };
  })()`);
  const assert = (name, pass, actual) => checks.push({ name, pass:!!pass, actual });
  const jsClick = id => evaluate(`document.getElementById(${JSON.stringify(id)}).click()`);
  const trustedClick = async selector => {
    const pos = await evaluate(`(() => { const e=document.querySelector(${JSON.stringify(selector)}); e.scrollIntoView({block:'center'}); const r=e.getBoundingClientRect(); return {x:r.x+r.width/2,y:r.y+r.height/2}; })()`);
    await page('Input.dispatchMouseEvent', {type:'mousePressed', ...pos, button:'left', clickCount:1});
    await page('Input.dispatchMouseEvent', {type:'mouseReleased', ...pos, button:'left', clickCount:1});
  };
  const key = async (key, code, modifiers=0) => {
    const windowsVirtualKeyCode = {Tab:9,Enter:13,Escape:27,ArrowDown:40,' ':32}[key];
    const text = key==='Enter' ? '\r' : key===' ' ? ' ' : '';
    await page('Input.dispatchKeyEvent', {type:'keyDown',key,code,windowsVirtualKeyCode,modifiers,text,unmodifiedText:text});
    await page('Input.dispatchKeyEvent', {type:'keyUp',key,code,windowsVirtualKeyCode,modifiers});
  };
  const navigate = async () => {
    await page('Page.navigate', {url:origin});
    for(let i=0;i<100;i++) {
      if(await evaluate(`document.readyState==='complete' && document.querySelectorAll('#orders li').length===4`)) return;
      await pause(20);
    }
    throw new Error('Product readiness timed out');
  };
  const reduce = value => page('Emulation.setEmulatedMedia', {features:[{name:'prefers-reduced-motion',value}]});
  const draft = async (owner,status='all') => evaluate(`document.getElementById('owner').value=${JSON.stringify(owner)}; document.getElementById('status').value=${JSON.stringify(status)}`);
  await navigate();
  let s = await read(); assert('initial original orders and closed panel', s.hidden && s.orders.join(',')==='M-101,M-102,M-103,M-104',s);
  s = await evaluate(`document.getElementById('filter-toggle').click(); ({hidden:document.getElementById('filters').hidden, active:document.activeElement.id, opacity:getComputedStyle(document.getElementById('filters')).opacity})`);
  assert('open is immediately visible and focuses editable owner', !s.hidden && s.active==='owner' && Number(s.opacity)>0,s);
  await pause(400);
  await screenshot('desktop-open.png');
  await draft('김민지','sent');
  s=await evaluate(`document.getElementById('owner').focus(); document.getElementById('filter-close').click(); ({hidden:document.getElementById('filters').hidden,active:document.activeElement.id})`);
  assert('close immediately removes inputs and returns focus',s.hidden && s.active==='filter-toggle',s);
  await pause(400);
  await jsClick('filter-toggle'); await pause(400);
  s=await read(); assert('closing preserves unapplied owner and status without changing results',s.owner==='김민지' && s.status==='sent' && s.orders.length===4,s);
  await jsClick('filter-close'); await pause(400);
  s=await evaluate(`document.getElementById('filter-toggle').click(); document.getElementById('filter-close').click(); document.getElementById('filter-toggle').click(); document.getElementById('status').focus(); ({expanded:document.getElementById('filter-toggle').getAttribute('aria-expanded')})`);
  await pause(450); s=await read(); assert('rapid open close reopen follows final open and preserves later focus',!s.hidden && s.expanded==='true' && s.active==='status',s);
  await navigate();
  await jsClick('filter-toggle');
  await trustedClick('#orders button[data-order="M-102"]');
  await pause(450); s=await read(); assert('nonmodal detail action works during entry without delayed focus theft',s.detail.includes('M-102') && s.active==='M-102' && !s.hidden,s);
  await key('Escape','Escape'); s=await read(); assert('Escape from outside closes and preserves detail focus',s.hidden && s.expanded==='false' && s.active==='M-102',s);

  await navigate();
  await key('Tab','Tab'); s=await read(); assert('native Tab reaches opener',s.active==='filter-toggle',s);
  await key('Enter','Enter'); s=await read(); assert('native Enter opens with immediate visible input focus',!s.hidden && s.active==='owner' && s.focusVisible,s);
  await pause(400);
  await page('Input.insertText',{text:'김민지'});
  await key('Tab','Tab');
  s=await read(); assert('native Tab reaches status',s.active==='status',s);
  await key('Tab','Tab'); s=await read(); assert('native Tab reaches apply',s.active==='apply',s);
  await key('Enter','Enter'); s=await read(); assert('native apply changes actual IDs and count immediately',s.orders.join(',')==='M-101,M-103' && s.count==='2개 주문' && s.hidden && s.active==='filter-toggle',s);
  await pause(400);
  await key(' ','Space'); await pause(400);
  s=await read(); assert('native Space reopens and preserves applied draft',!s.hidden && s.owner==='김민지' && s.status==='all',s);
  await key('Tab','Tab',8); s=await read(); assert('native Shift Tab reaches close',s.active==='filter-close',s);
  await key('Escape','Escape'); s=await read(); assert('native Escape closes and returns visible focus immediately',s.hidden && s.active==='filter-toggle' && s.focusVisible,s);
  await pause(400);
  await key('Tab','Tab'); s=await read(); assert('closed fields are excluded from native Tab order',s.active==='M-101',s);
  await trustedClick('#filter-toggle'); await pause(400);
  await trustedClick('#clear'); s=await read(); assert('reset restores all original results and draft',s.orders.length===4 && s.owner==='' && s.status==='all' && s.count==='4개 주문',s);
  await evaluate(`document.getElementById('owner').focus()`);
  await key('Tab','Tab'); await key('Tab','Tab'); await key('Tab','Tab'); await key('Tab','Tab');
  s=await read(); assert('open nonmodal panel permits native Tab into list',s.active==='M-101' && !s.hidden,s);
  await key('Enter','Enter'); s=await read(); assert('native Enter detail shows correct record while panel open',s.detail.includes('M-101') && !s.hidden,s);

  for(const mode of ['no-preference','reduce']) {
    await reduce(mode); await navigate();
    for(let i=0;i<15;i++) await jsClick('filter-toggle');
    await pause(450); s=await read(); assert(`${mode}: repeated toggles settle to last open`,!s.hidden && s.expanded==='true',s);
    await jsClick('filter-toggle'); s=await read(); assert(`${mode}: repeated toggles last close is immediate`,s.hidden && s.expanded==='false' && s.active==='filter-toggle',s);
    await pause(450); s=await read(); assert(`${mode}: no stale later focus or panel changes`,s.hidden && s.active==='filter-toggle',s);
    await jsClick('filter-toggle'); s=await read(); assert(`${mode}: immediate input independent of motion`,s.active==='owner' && !s.hidden && (mode!=='reduce' || s.animations===0),s);
  }
  await navigate(); await reduce('no-preference');
  await jsClick('filter-toggle');
  s=await read(); assert('normal entry has a running optional animation while input is focused',s.animations>0 && s.active==='owner',s);
  await reduce('reduce');
  s=await read(); assert('changing preference removes active entry animation immediately',s.reduced && s.animations===0 && !s.hidden,s);
  await evaluate(`document.getElementById('status').focus()`); await pause(450);
  s=await read(); assert('changing to reduced motion mid-entry cancels motion without focus theft',!s.hidden && s.reduced && s.animations===0 && s.active==='status',s);
  await jsClick('filter-close'); await reduce('no-preference'); await pause(450);
  s=await read(); assert('changing preference after close cannot resurrect panel',s.hidden && s.expanded==='false' && s.active==='filter-toggle',s);

  await page('Emulation.setDeviceMetricsOverride',{width:320,height:640,deviceScaleFactor:1,mobile:false});
  await reduce('reduce'); await navigate(); await trustedClick('#filter-toggle'); await pause(400);
  const long='서울특별시에서주문하신아주긴한국어고객검색이름'.repeat(8);
  await page('Input.insertText',{text:long});
  s=await read(); assert('320px long Korean draft remains editable without page overflow',s.owner===long && !s.overflow && s.focusVisible,s);
  await screenshot('narrow-draft.png');
  await key('Enter','Enter'); s=await read(); assert('320px no matches updates actual rows and preserves visible return focus',s.empty && s.orders.length===0 && s.count==='0개 주문' && s.hidden && s.active==='filter-toggle' && s.focusVisible && !s.overflow,s);
  await screenshot('narrow-empty.png');
  await pause(400); await key('Enter','Enter'); await pause(400);
  s=await read(); assert('320px reopen preserves complete long Korean draft',s.owner===long && !s.hidden,s);
  await key('Tab','Tab'); await key('Tab','Tab'); await key('Tab','Tab');
  s=await read(); assert('320px keyboard reset target is visible and reachable',s.active==='clear' && s.focusVisible && !s.overflow,s);
  await screenshot('narrow-keyboard-focus.png',{captureBeyondViewport:false});
  await key('Enter','Enter'); s=await read(); assert('320px keyboard reset recovers from empty results',s.orders.length===4 && !s.empty && s.owner==='',s);
  await draft('김민지','sent'); await jsClick('apply'); s=await read();
  assert('combined customer and sent status filters actual M-103',s.orders.join(',')==='M-103' && s.count==='1개 주문',s);
  await trustedClick('#orders button[data-order="M-103"]');s=await read();
  assert('filtered M-103 detail retains original record identity',s.detail.includes('M-103 · 김민지 · 잔'),s);
  await pause(400);
  await page('Page.reload');
  for(let i=0;i<100;i++){if(await evaluate(`document.readyState==='complete' && document.querySelectorAll('#orders li').length===4`))break;await pause(20);}
  s=await read(); assert('reload clears local drafts and applied filters',s.hidden && s.owner==='' && s.status==='all' && s.orders.length===4,s);
  await page('Emulation.setTouchEmulationEnabled',{enabled:true,maxTouchPoints:1});
  const touch = async selector => {
    const pos=await evaluate(`(() => {const e=document.querySelector(${JSON.stringify(selector)});e.scrollIntoView({block:'center'});const r=e.getBoundingClientRect();return {x:r.x+r.width/2,y:r.y+r.height/2};})()`);
    await page('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[pos]});
    await page('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});
  };
  await touch('#filter-toggle'); await pause(400);
  await touch('#orders button[data-order="M-104"]'); s=await read(); assert('320px emulated touch reaches nonmodal order detail',!s.hidden && s.detail.includes('M-104'),s);
  await touch('#filter-close'); s=await read(); assert('320px emulated touch close is immediate',s.hidden && s.expanded==='false',s);
  assert('no page runtime exceptions',exceptions.length===0,exceptions);
});
const result={fixture,browser,checks,total:checks.length,passed:checks.filter(c=>c.pass).length,failed:checks.filter(c=>!c.pass).length,limitations:['Chrome headless on loopback; CDP trusted key, pointer and emulated touch events, not physical devices.','Korean text inserted via CDP Input.insertText, not a real Korean IME.','Native select ArrowDown did not change selection in this headless environment; Tab reachability is exercised, status filtering is tested by setting the local select value.','No screen reader, other browsers, hardware mobile keyboard, text-only resize, or performance measurement.']};
await writeFile(`${output}/browser.json`,JSON.stringify(result,null,2));
console.log(JSON.stringify({output,browser:browser.product,total:result.total,passed:result.passed,failed:result.failed,failures:checks.filter(c=>!c.pass).map(c=>c.name)},null,2));
process.exitCode=result.failed?1:0;
