import {withBrowser} from '/tmp/lutriva-filter-motion-trial-xOupNS/harness/browser_harness.mjs';
await withBrowser('/tmp/lutriva-filter-motion-trial-xOupNS/product','/tmp/lutriva-filter-author-vecfhX/select-probe',async ({origin,page,evaluate,pause})=>{
await page('Page.navigate',{url:origin});await pause(300);
await evaluate(`document.getElementById('filter-toggle').click();document.getElementById('status').focus()`);
for(const [key,code,value,text] of [[' ','Space',32,' '],['ArrowDown','ArrowDown',40,''],['Enter','Enter',13,'\r']]){
await page('Input.dispatchKeyEvent',{type:'keyDown',key,code,windowsVirtualKeyCode:value,nativeVirtualKeyCode:{' ':49,ArrowDown:125,Enter:36}[key],text,unmodifiedText:text});
await page('Input.dispatchKeyEvent',{type:'keyUp',key,code,windowsVirtualKeyCode:value});
console.log(key,await evaluate(`({value:document.getElementById('status').value,active:document.activeElement.id,hidden:document.getElementById('filters').hidden})`));
}
});
