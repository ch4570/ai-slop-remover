# Scoped filter-flow plan

Skill used: `/tmp/lutriva-filter-motion-trial-xOupNS/skills/ux-flow-refine/SKILL.md`, with its principles, state-recovery KB, interaction-design, motion, web and relevant interaction recipes (visible focus; rapid interrupted input). No dependency installation.

| Trigger | State/data change | Feedback | Recovery | Persistence |
| --- | --- | --- | --- | --- |
| Open / repeated toggle | Synchronous latest `open`, native `hidden` | `aria-expanded`, visible panel, immediate owner focus | Toggle / Escape; no queued callbacks | UI only |
| Close / Escape | Hide immediately; keep draft | Collapse and return focus if it was inside; preserve outside focus | Reopen same draft | DOM draft until refresh |
| Apply | Copy draft to `applied`, render actual matching orders/count | Results/empty message, close and visible toggle focus | Reopen/edit or clear | In-memory until refresh |
| Clear | Empty owner + all statuses, clear applied conditions | Four original orders and accurate count | Edit again | In-memory until refresh |
| Motion preference changes | CSS media query cancels optional entry animation | Same resulting state without movement or delay | Repeated intent always synchronous | OS/browser setting only |

Motion choice: short opacity-only entry; immediate closing deliberately avoids a closing surface or delayed list reposition while people act on the nonmodal list. No timers, animation callbacks, inert page, focus trap, storage, history or service work.

Before editing, exercise focused baseline assertions. Then run the same assertions on changed product, plus trusted Chrome keyboard/pointer and touch input, 320px long Korean input/result, empty recovery, refresh, normal/reduced/dynamically changed motion, repeated operations and delayed-focus checks. Screenshots are inspected separately from interaction assertions. Real hardware keyboard/IME, assistive technology and additional browsers are outside the automated environment; report this limitation rather than imply coverage.
