# Cycle 5 evidence navigation and replay

This record is a single snapshot-direct nonmodal-filter skill trial plus bounded
browser-tool regressions. It is not a model/skill-version comparison, host discovery
test, user study, or evidence of general autonomous learning. Original reports keep
their historical absolute paths; the relative replay commands below use the copied
bytes. No full conversation transcript is claimed.

## Product evidence

- `trial/TASK.md`, `trial/original-product/`, `trial/product/`, `trial/skills/` and
  `trial/harness/` preserve the task, original/final product, 65-file skill snapshot
  and read-only harness from `6514ff3`.
- `parent-observations/REVIEW.md` distinguishes source equality, actual parent
  transitions, visually opened images, observer results and limitations.
  `frozen-inputs.json` and `scope-final.json` cover 71 frozen files and four final
  product files. Parent screenshots are 1280px wide or 320×900; the observer's narrow
  viewport is 320×800, and the author's separate viewport review is 320×640.
- `observer/REPORT-corrected.md`, `comparison-corrected.json`, `original-corrected/`
  and `candidate-corrected/` hold the final independent 28/42→42/42 comparison.
  `evaluate.mjs`, `*-frozen/` and `REPORT.md` are the preserved v1 comparison.
- `negative-control/product/` deliberately adds reduced-only 800ms spatial motion.
  `old-checker-result/` is its false pass, while `corrected-checker-result/` is the
  expected one-check failure. The corrected evaluator differs by one predicate.
- `author/REPORT.md` is the author's separate, overlapping 26/42→42/42 result and
  self-review, not another independent 42 checks. Earlier invalid adapters,
  unversioned results and native-select probes remain preparation evidence.
- `observer/original-run-1/ABORTED.md` records the unexpected settings/help target
  and observed .76→.83 executable-version difference. The cause/time is unknown;
  that run has no valid pass/fail result. No update/network isolation is claimed.
- `independent-trial-review/REVIEW.md` audits the raw copied reports and contains
  three new corrected replays reproducing original/candidate/negative results.
  It explicitly predates final archive verification.

From a freshly extracted record directory, with existing Node 22+ and Chrome:

```sh
node parent-observations/verify-scope.mjs trial parent-observations/frozen-inputs.json
node observer/evaluate-corrected.mjs trial/original-product /new/unique/original trial/harness/browser_harness.mjs
node observer/evaluate-corrected.mjs trial/product /new/unique/candidate trial/harness/browser_harness.mjs
node observer/evaluate-corrected.mjs negative-control/product /new/unique/negative trial/harness/browser_harness.mjs
node parent-observations/inspect-transitions.mjs trial/product /new/unique/parent
```

Replace each output argument with a new absolute directory path. The first scope
command checks frozen bytes; an optional final repository argument also compares
skill/harness bytes to Git `6514ff3`. The original evaluator is expected to exit 1
with 14 failed checks, the candidate 0, and the negative control 1 with exactly the
motion-reduction failure. These are product outcomes, not collection exceptions.
Read browser version/error/hash fields rather than assuming a future identical
environment. Products are served on loopback; output paths cannot be reused.

The author's original helpers have historical absolute imports/paths. They are
preserved as executed and are not advertised as directly portable. Use the
observer and parent commands above for the primary portable comparison. Do not
execute the archived unsafe/native-keycode preparation adapter.

## Repository tool evidence

`keyboard-evidence/` is the helper author's early actual Chrome control and four
targeted regression methods. It uses the new helper, unlike the product trial's
frozen harness. Final tool snapshots live in `final-tools/`; regression and
independent-review reports retain the exact commands, hashes, initial failures and
later runs. New source-only startup controls use fake processes, not live browser
keyboard shortcuts. Do not confuse a fake startup probe with an actual Chrome run.
`regression-initial/` retains the first two scope startup failures and their
successful isolated retries; `regression-final/` holds the full runs after the
startup fix. `startup-diagnosis/` records deterministic incomplete-file controls,
before/after tests and explicitly labeled reconstruction provenance.
`keyboard-review-initial/` reviews the earlier keyboard-only diff;
`package-final/` contains the final 20-test npm commands on Python 3.9 and 3.12.

From `final-tools/`, selected standalone checks are:

```sh
node --test tests/browser-input.test.mjs
node --test tests/browser-startup.test.mjs
AI_SLOP_BROWSER_TESTS=1 AI_SLOP_BROWSER_EVIDENCE=/new/unique/browser python3 -B -m unittest discover -s tests -p test_browser_checks.py -v
AI_SLOP_BROWSER_TESTS=1 AI_SLOP_BROWSER_EVIDENCE=/new/unique/scope python3 -B -m unittest discover -s tests -p test_scope_browser_checks.py -v
python3 -B -m unittest discover -s tests -p test_evidence_archive.py -v
```

Other copied Python/npm tests are source context, not a complete standalone npm
package: package/installer tests need the full repository release payload. The
scope/search fixtures, checks and Python helper imports are included. No libraries
or browser installation is needed for the dependency-free checks; actual Chrome
tests require an already available executable (`AI_SLOP_CHROME` can select it).

Archive validation uses the repository's `check_evidence_archive.py` against the
external cycle-5 inventory, plus a separate SHA-256 of the entire archive. Exact
file bytes and a clean replay do not authenticate the truth of observations or
prove independent human review. No Chrome profiles, .git, caches or previous
record archives are included. Initial staging manifests describe their own copy
time; the external final inventory is authoritative for the final file set.
