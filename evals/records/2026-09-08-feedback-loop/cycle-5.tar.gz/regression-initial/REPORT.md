# Cycle 5 independent regression report

검사 대상은 `/Users/rex/Desktop/personal/lutriva`, 브랜치 `work/overnight-feedback-2026-09-08`, HEAD `6514ff3c81be7e6d5047ce53ef70b145e8404a6f` 위의 작업 중인 변경이다. 실행 전후 브라우저 하네스, 두 어댑터, 두 Python 브라우저 테스트 파일의 SHA-256이 같았다. 패키지 문서/manifest 변경이 안정됐다는 주 작업자의 통보 후 일반 검사를 시작했다. 검사자가 저장소 파일을 수정하거나 커밋/푸시/설치를 실행하지 않았다.

환경: macOS, Node `v26.8.1`, Python `3.9.6`. 설치된 Chrome 실행 파일은 `/Applications/Google Chrome.app/Contents/MacOS/Google Chrome`이며 시작과 종료 모두 `152.0.7977.83`이었다. 버전이 기록된 브라우저 증거 역시 모두 `Chrome/152.0.7977.83`이다. 실행 전후 기록과 소스 해시는 `context-before.txt`, `context-after.txt`에 있다.

| 실행 | 총 테스트 | 통과 | 실패 | 건너뜀 | 종료 코드 | 시간 |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| 일반 Python 전체 | 291 | 244 | 0 | 47 | 0 | 54.401초 |
| Chrome browser 전체 | 33 | 33 | 0 | 0 | 0 | 194.885초 |
| Chrome scope 전체, 최초 | 14 | 12 | 2 | 0 | 1 | 60.563초 |
| scope known-good 개별 재실행 | 1 | 1 | 0 | 0 | 0 | 12.254초 |
| scope shared-density 개별 재실행 | 1 | 1 | 0 | 0 | 0 | 3.054초 |

일반 전체 명령은 `env -u AI_SLOP_BROWSER_TESTS PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s tests -v`였다. 47개 건너뜀은 opt-in 브라우저 33개와 scope 브라우저 14개다.

Chrome 전체 명령은 각각 `python3 -m unittest discover -s tests -p test_browser_checks.py -v`, `python3 -m unittest discover -s tests -p test_scope_browser_checks.py -v`였다. 두 실행 모두 `PYTHONDONTWRITEBYTECODE=1`, `AI_SLOP_BROWSER_TESTS=1`, 위의 절대 경로를 지정한 `AI_SLOP_CHROME`, 별도 `AI_SLOP_BROWSER_EVIDENCE`를 사용했다. 하네스가 매번 새 임시 Chrome 프로필과 동적 HTTP/CDP 포트를 생성함을 확인하고 두 전체 Chrome suite를 동시에 시작했다. 일반 Python suite는 일부 시간 동안 이들과 겹쳤다.

최초 scope 실패는 다음 두 항목이다.

- `test_known_good_controls_preserve_source_and_browser_contracts`: `master-page-consistency` subtest의 두 행동 관찰이 예상 `pass` 대신 `not-run`.
- `test_shared_density_token_breaks_master`: `shared-master-preserved`가 예상 `fail` 대신 `not-run`.

두 실패 증거의 `environment`는 `{}`, 이미지와 포커스 목록은 비어 있고, `collectionErrors`는 `["SyntaxError: TypeError: Invalid URL"]`이었다. 이는 브라우저 버전 수집 전 연결 초기화가 완료되지 않았음을 보여 준다. 하네스는 `DevToolsActivePort`를 처음 읽는 데 성공하면 내용을 검증하지 않고 WebSocket 주소를 만들므로 불완전한 파일 읽기 가능성이 있으나, 이번 증거에는 원시 파일 내용이나 오류 스택이 없어 원인으로 확정하지 않는다. 동시 실행 부하가 원인이라는 결론도 내리지 않는다.

main Chrome suite 종료 후 위 두 실패 메서드만 각각 새 프로세스와 새 증거 디렉터리에서 순서대로 재실행했다. 명령은 `PYTHONPATH=tests`를 추가한 환경에서 각각 `python3 -m unittest test_scope_browser_checks.ScopeBrowserTests.test_known_good_controls_preserve_source_and_browser_contracts -v`, `python3 -m unittest test_scope_browser_checks.ScopeBrowserTests.test_shared_density_token_breaks_master -v`였다. 두 재실행은 통과했으며, known-good은 네 fixture subtest를 모두 실행했다. 최초 scope suite 실패는 그대로 보존되며, 개별 재실행 통과를 전체 scope suite의 깨끗한 통과로 취급하지 않는다. baseline 하네스 비교나 전체 scope 추가 재실행은 수행하지 않았다.

`test_bounded_keyboard_helper_uses_trusted_browser_defaults`도 최초 main suite에서 통과했다. 별도 `keyboard-control.json`에 Tab/Shift+Tab 포커스 순서 `submit → check → submit → query`, Enter 제출, Space 체크박스 변경, Escape, 총 18개의 trusted keydown/keyup 이벤트가 있다. 전후 페이지 target 목록이 같고, 관찰 구간의 target 이벤트와 예상 밖 navigation 목록은 비어 있다. 이 결과는 해당 제어 테스트 관찰 범위에 한정되며 OS IME, 실제 기기, 다른 OS나 Chrome 버전을 검증하지 않는다. 이전 `.76 → .83` 버전 변화의 원인은 이번 실행으로 규명되지 않았다. 업데이트 화면을 열거나 설치/되돌리기, native keycode 재생을 수행하지 않았다.

모든 원시 stdout/stderr는 이 디렉터리의 `ordinary.*.log`, `browser.*.log`, `scope.*.log`, `scope-retry-good.*.log`, `scope-retry-density.*.log`에 보존했다. 각 실행의 `*.exit-code.txt`, `*.started.txt`, `*.finished.txt`도 보존했다. 생성된 종합 요약은 `evidence-summary.json`이다.

주요 증거 경로:

- 최초 main: `browser-evidence/run-61l7_9y_/`
- 키보드 제어: `browser-evidence/run-61l7_9y_/bounded-keyboard/keyboard-control.json`
- 최초 scope: `scope-evidence/scope-uziod2sr/`
- 실패 known-good: `scope-evidence/scope-uziod2sr/good-master-page-consistency/browser.json`
- 실패 shared-density: `scope-evidence/scope-uziod2sr/shared-density-token/browser.json`
- 개별 재실행: `scope-retry-good-evidence/`, `scope-retry-density-evidence/`

일부 회귀 테스트는 의도적으로 망가진 fixture가 `fail`/`not-run`으로 관찰되는지 확인한다. Python 테스트 통과 수는 이 기대까지 포함하며, 모든 생성 fixture가 정상이라는 뜻은 아니다. 이 검사는 로컬 실행 결과이며 CI 현재 head 결과, 모델 품질 평가, 스크린샷 독립 시각 검토를 대신하지 않는다.
