# Frozen independent criteria: cycle 11

The fixed TASK.md, PRIOR-TASK.md and immutable service contract are the acceptance source. This observer runs the original before any author exists. It never repairs/refocuses/scrolls the product after an observed action. Setup uses the public resetDemo adapter, then a fresh-document UUID readiness check. The observer uses only the supplied dependency-free harness and installed isolated Chrome/local HTTP origin. No network dependencies, OS shortcuts/native keycodes, user Chrome profiles, or whole-page captures.

## Focus acceptance

At 1280×900, 375×650 and 1280×500, actual trusted Tab/Shift+Tab navigation and alternating Enter/Space activations exercise both full-order boundaries and repeated same-job movement. Each key is followed by exactly two animation-frame observations bounded by a 200ms deadline; unavailable frames retain partial evidence and mark the scenario incomplete. The second frame must show the acted job's still-operable direction or its same-job opposite at a boundary. Natural Tab focus on a move button must meet the same visibility requirement. The focus-visible outline remains solid rgb(23, 108, 101), 3px thick with 3px offset. The entire button rectangle expanded by 6px must fit inside the live visual viewport and every live clipping ancestor padding box (0.5px rounding tolerance). A passing button rectangle alone is insufficient. Missing/non-focus-visible rings and disabled current controls cannot pass. The same footprint is inspected when saved/error/retry feedback settles without additional refocusing or scrolling. Only actual observer samples and a few viewport PNGs are retained.

Intentional trusted vertical wheel input is delivered at the focused row, then the changed scroll position must remain after 800ms. User scrolling may hide focus. This is checked separately from keyboard-action visibility and must not trigger continuous auto-restoration.

## Invariants and regression acceptance

The original initial per-button width/height, padding, font, border/background/text colors, border radius, disabled opacity, minimum sizes and labels form the frozen comparison input for a later trial at each matching viewport. Original brand/static HTML remains byte-identical. Every row's title, metadata, full-order rank and boundary disabled rules must match all six expected jobs. Expected jobs include every nested payload. Service, HTML, fixed tasks and contract must be byte-identical. No direct app localStorage writes are allowed.

Rapid moves must preserve the newest full order while pending controls remain operable; waiting for actual public adapter reads and saved UI is required before a fresh-document reload confirms persistence. An armed failure is set only after fresh reload, retains the complete latest draft through an additional edit, retains an explicit retry, and must not announce saved or silently auto-save while failed. The explicit retry commits the current draft; a further edit during retry must also survive actual completion and fresh-document reload. No requirement to auto-save in failed state is imposed.

A case-insensitive ID filter hides five rows; moving the one visible job swaps its immediate hidden full-order neighbor, preserves full-order rank, and clearing the filter returns all six jobs. Public read verifies the full job objects and nested payloads after rapid saves, failure/retry and filter movement.

All setup/runtime errors are retained and make that scenario incomplete; no criteria are relaxed in response. Code, criteria, helper and expected data hashes are recorded before original browser launch. Original measured invariant profiles and raw outcomes are frozen before any author launch. Trial use passes the original browser.json as a relative baseline argument. The harness creates and removes only its own temporary Chrome profile; output paths are exclusively claimed and never reused.

## Invocation

`node observer.mjs ../cycle-work/original original` produces the original observations. `node observer.mjs ../cycle-work/trial trial original/browser.json` compares a later trial to the frozen original profiles. Paths are resolved relative to the calling directory; helper and expected-jobs.json are relative to observer.mjs. Browser output is compact JSON and at most four viewport PNGs. A nonzero exit means failed checks or setup/runtime errors.
