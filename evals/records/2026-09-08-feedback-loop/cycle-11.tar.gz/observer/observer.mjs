import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { withBrowser, claimBrowserEvidence } from './browser_harness.mjs';

const here = path.dirname(fileURLToPath(import.meta.url));
const [fixtureArg, outputArg, baselineArg] = process.argv.slice(2);
if (!fixtureArg || !outputArg) throw new Error('Usage: node observer.mjs FIXTURE NEW_OUTPUT [ORIGINAL_BROWSER_JSON]');
const fixture = path.resolve(fixtureArg), output = path.resolve(outputArg);
const jobs = JSON.parse(await readFile(path.join(here, 'expected-jobs.json'), 'utf8'));
const ids = jobs.map(j => j.id), jobJSON = JSON.stringify(jobs);
const hash = value => createHash('sha256').update(value).digest('hex');
const equal = (a, b) => JSON.stringify(a) === JSON.stringify(b);
const baseline = baselineArg ? JSON.parse(await readFile(path.resolve(baselineArg), 'utf8')) : null;
const immutable = {
  'index.html': '7c1114df530dad332f5beb0f625fa7fb5247b15104102c8d1cb7bcb24a620b73',
  'product/service.js': '591b0da648d5bec049fa26dd0c952ab9830edf6c14e37bd6b7805c8dbc0ee20c',
  'SERVICE_CONTRACT.md': '44041793e12b8330e2cea1ebad966a0f063cbcfae6bc46c4afa5552e349d9eef',
  'TASK.md': 'cf68db8914d9a4b42e3ae2ba271e2fc3fb50b0135912ab9d9092833f7a7d27f6',
  'PRIOR-TASK.md': '3cd47a0911d9e12761ae85c139ab08effb1b94a5cd29e2adad0695e696a3ade9',
};
const result = { schema: 1, started: new Date().toISOString(), fixture, baseline: baselineArg || null, hashes: {}, checks: [], samples: [], profiles: {}, initialProfiles: {}, documents: [], persistence: [], screenshots: [], errors: [] };
const sourceNames = ['index.html', 'product/app.js', 'product/service.js', 'styles.css', 'DESIGN.md', 'SERVICE_CONTRACT.md', 'TASK.md', 'PRIOR-TASK.md'];
const sourceHashes = async () => Object.fromEntries(await Promise.all(sourceNames.map(async name => [name, hash(await readFile(path.join(fixture, name)))])));
const check = (name, pass, detail) => result.checks.push({ name, pass: Boolean(pass), ...(detail === undefined ? {} : { detail }) });
const store = () => writeFile(path.join(output, 'browser.json'), JSON.stringify(result, null, 2) + '\n');
await claimBrowserEvidence(output, ['wide-focus.png', 'narrow-focus.png', 'low-focus.png', 'wheel-retained.png']);
result.fixtureSourceBefore = await sourceHashes();
for (const name of ['observer.mjs', 'CRITERIA.md', 'browser_harness.mjs', 'expected-jobs.json']) result.hashes[name] = hash(await readFile(path.join(here, name)));
for (const [name, expected] of Object.entries(immutable)) {
  const actual = hash(await readFile(path.join(fixture, name)));
  result.hashes['fixture/' + name] = actual;
  check('immutable:' + name, actual === expected);
}
check('writes-use-adapter', !/\blocalStorage\b|\bindexedDB\b/.test(await readFile(path.join(fixture, 'product/app.js'), 'utf8')));
await store();

function installObserver(expectedJobs) {
  const doc = { token: crypto.randomUUID(), keys: [], wheels: [] };
  const trim = a => { if (a.length > 4) a.shift(); };
  addEventListener('keydown', e => { doc.keys.push({ key: e.key, shift: e.shiftKey, trusted: e.isTrusted, t: performance.now() }); trim(doc.keys); }, { capture: true, passive: true });
  addEventListener('wheel', e => { doc.wheels.push({ dy: e.deltaY, trusted: e.isTrusted, target: e.target.id || e.target.className, t: performance.now() }); trim(doc.wheels); }, { capture: true, passive: true });
  const rect = r => Object.fromEntries(['x', 'y', 'width', 'height', 'top', 'right', 'bottom', 'left'].map(k => [k, Math.round(r[k] * 100) / 100]));
  const profile = b => {
    const s = getComputedStyle(b), r = b.getBoundingClientRect();
    const props = ['minWidth', 'minHeight', 'paddingTop', 'paddingRight', 'paddingBottom', 'paddingLeft', 'fontFamily', 'fontSize', 'fontWeight', 'lineHeight', 'borderTopWidth', 'borderTopStyle', 'borderTopColor', 'borderRadius', 'backgroundColor', 'color', 'opacity'];
    return { width: r.width, height: r.height, text: b.textContent, disabled: b.disabled, css: Object.fromEntries(props.map(k => [k, s[k]])) };
  };
  const sample = () => {
    const a = document.activeElement, isMove = a?.matches('.move-button'), r = a?.getBoundingClientRect(), s = a && getComputedStyle(a);
    const viewport = visualViewport ? { left: visualViewport.offsetLeft, top: visualViewport.offsetTop, right: visualViewport.offsetLeft + visualViewport.width, bottom: visualViewport.offsetTop + visualViewport.height } : { left: 0, top: 0, right: innerWidth, bottom: innerHeight };
    const outer = isMove ? { left: r.left - 6, top: r.top - 6, right: r.right + 6, bottom: r.bottom + 6 } : null;
    const bounds = [{ name: 'viewport', ...viewport, clipX: true, clipY: true }];
    const scrolls = [{ name: 'document', x: scrollX, y: scrollY }];
    for (let e = a?.parentElement; e; e = e.parentElement) {
      const c = getComputedStyle(e), er = e.getBoundingClientRect();
      const clipX = /hidden|clip|scroll|auto/.test(c.overflowX), clipY = /hidden|clip|scroll|auto/.test(c.overflowY);
      if (clipX || clipY) bounds.push({ name: e.id || e.className || e.tagName, left: er.left + e.clientLeft, top: er.top + e.clientTop, right: er.left + e.clientLeft + e.clientWidth, bottom: er.top + e.clientTop + e.clientHeight, clipX, clipY });
      if ((e.scrollHeight > e.clientHeight || e.scrollWidth > e.clientWidth) && (clipX || clipY)) scrolls.push({ name: e.id || e.className || e.tagName, x: e.scrollLeft, y: e.scrollTop });
    }
    const clippedBy = isMove ? bounds.filter(b => (b.clipX && (outer.left < b.left - .5 || outer.right > b.right + .5)) || (b.clipY && (outer.top < b.top - .5 || outer.bottom > b.bottom + .5))) : [];
    const rows = [...document.querySelectorAll('#queue-list > li')];
    const order = rows.map(row => row.dataset.jobId);
    const rowsValid = rows.every(row => {
      const j = expectedJobs.find(j => j.id === row.dataset.jobId);
      return j && row.querySelector('.job-title')?.textContent === j.title && row.querySelector('.job-meta')?.textContent === `${j.id} · ${j.route} · ${j.timeWindow} · ${j.packageLabel}`;
    });
    const rank = rows.map(row => Number(row.querySelector('.job-rank')?.textContent));
    const disabled = rows.map(row => [...row.querySelectorAll('.move-button')].map(b => b.disabled));
    return { token: doc.token, t: performance.now(), order, rank, rowsValid, disabled, state: document.querySelector('.save-line')?.dataset.state, status: document.querySelector('#save-status')?.textContent,
      retry: { hidden: document.querySelector('[data-action="retry-save"]')?.hidden, disabled: document.querySelector('[data-action="retry-save"]')?.disabled },
      active: { id: a?.id || null, job: a?.dataset.jobId || null, action: a?.dataset.action || null, disabled: Boolean(a?.disabled), visible: Boolean(isMove && a.matches(':focus-visible')), rect: isMove ? rect(r) : null, outer,
        outline: isMove ? { width: s.outlineWidth, offset: s.outlineOffset, style: s.outlineStyle, color: s.outlineColor } : null,
        profile: isMove ? profile(a) : null }, bounds: isMove ? bounds : [], clippedBy, scrolls, lastKey: doc.keys.at(-1) || null, lastWheel: doc.wheels.at(-1) || null };
  };
  window.__cycleObserver = { ...doc, sample, profile };
}

try {
  if (baseline) {
    const matchingCode = ['observer.mjs', 'CRITERIA.md', 'browser_harness.mjs', 'expected-jobs.json'].every(name => baseline.hashes?.[name] === result.hashes[name]);
    const completeProfiles = ['wide', 'narrow', 'low'].every(name => Array.isArray(baseline.initialProfiles?.[name]) && baseline.initialProfiles[name].length === 12);
    check('baseline:matching-frozen-evaluator', matchingCode);
    check('baseline:all-three-invariant-profiles', completeProfiles);
    if (!matchingCode || !completeProfiles) throw new Error('Baseline unavailable/incompatible: frozen evaluator hashes and all three initial profiles required');
  }
  await withBrowser(fixture, output, async b => {
    const { page, evaluate, pressKey, pause, screenshot, origin } = b;
    await page('Page.addScriptToEvaluateOnNewDocument', { source: `(${installObserver.toString()})(${jobJSON})` });
    const current = () => evaluate('__cycleObserver.sample()');
    const compact = s => {
      if (s.active.profile) {
        const id = hash(JSON.stringify(s.active.profile)).slice(0, 12);
        result.profiles[id] = s.active.profile; s.active.profile = id;
      }
      const known = result.statusTexts ||= {};
      const statusId = hash(s.status || '').slice(0, 10); known[statusId] = s.status; s.status = statusId;
      return s;
    };
    let documentToken = null, currentCase = '', step = 0, screenshotCount = 0;
    const waitFor = async (expression, description, timeout = 2500) => {
      const started = Date.now(); let value, error;
      while (Date.now() - started < timeout) {
        try { value = await evaluate(expression); if (value) return value; } catch (e) { error = String(e); }
        await pause(30);
      }
      throw new Error(`${description}; timeout ${timeout}ms; last=${JSON.stringify(value)}; error=${error || ''}`);
    };
    const fresh = async reset => {
      if (!documentToken) await page('Page.navigate', { url: origin });
      else {
        if (reset) await evaluate(`(async () => (await import('/product/service.js')).resetDemo())()`);
        await page('Page.reload', { ignoreCache: true });
      }
      const old = documentToken;
      await waitFor(`Boolean(window.__cycleObserver && __cycleObserver.token !== ${JSON.stringify(old)} && document.querySelectorAll('#queue-list > li').length === 6 && document.querySelector('.save-line')?.dataset.state === 'saved')`, 'fresh document ready');
      documentToken = await evaluate('__cycleObserver.token');
      check(currentCase + ':fresh-document', documentToken !== old);
      result.documents.push({ case: currentCase, old, token: documentToken });
    };
    const twoFrames = async () => {
      const observed = await evaluate('new Promise(resolve => { let first = null; const timer = setTimeout(() => resolve({ unavailable: true, first }), 200); requestAnimationFrame(() => { first = __cycleObserver.sample(); requestAnimationFrame(() => { clearTimeout(timer); resolve({ frames: [first, __cycleObserver.sample()] }); }); }); })');
      if (observed.unavailable) { result.samples.push({ name: currentCase + ':two-frame-unavailable', partial: observed.first ? compact(observed.first) : null }); throw new Error('Two-frame observation unavailable within 200ms'); }
      return observed.frames;
    };
    const recordFrames = async (label, expectedFocus = null, expectedOrder = null, visibility = true) => {
      const [first, s] = await twoFrames();
      const name = `${currentCase}:${++step}:${label}`;
      check(name + ':rowdata', s.rowsValid);
      if (expectedOrder) {
        check(name + ':order', equal(s.order, expectedOrder), { expected: expectedOrder, actual: s.order });
        check(name + ':ranks', equal(s.rank, expectedOrder.map((_, i) => i + 1)));
        check(name + ':operable', equal(s.disabled, expectedOrder.map((_, i) => [i === 0, i === expectedOrder.length - 1])));
      }
      if (expectedFocus) check(name + ':focus-target', s.active.job === expectedFocus.job && s.active.action === expectedFocus.action && !s.active.disabled, s.active.job + '/' + s.active.action);
      if (s.active.job && visibility) {
        check(name + ':outline-preserved', s.active.visible && equal(s.active.outline, { width: '3px', offset: '3px', style: 'solid', color: 'rgb(23, 108, 101)' }));
        check(name + ':whole-indicator-visible', s.clippedBy.length === 0, s.clippedBy.map(c => c.name));
        const actualProfile = s.active.profile;
        const expectedProfile = (baseline || result).initialProfiles[currentCase]?.find(p => p.job === s.active.job && p.action === s.active.action)?.profile;
        if (expectedProfile) {
          const strip = p => ({ ...p, disabled: false, css: { ...p.css, opacity: '1' } });
          check(name + ':button-style-and-size', equal(strip(actualProfile), strip(expectedProfile)));
        }
      }
      result.samples.push({ name, frame1: { t: first.t, active: { job: first.active.job, action: first.active.action, rect: first.active.rect }, clippedBy: first.clippedBy.map(c => c.name), scrolls: first.scrolls }, frame2: compact(s) });
      return s;
    };
    const key = async (name, options, focus, order) => { await pressKey(name, options); const s = await recordFrames(`${options?.shift ? 'Shift+' : ''}${name}`, focus, order); check(`${currentCase}:${step}:trusted-key`, s.lastKey?.trusted && s.lastKey.key === (name === 'Space' ? ' ' : name) && s.lastKey.shift === Boolean(options?.shift)); return s; };
    const goByTab = async (job, action, order, shift = false) => {
      for (let n = 0; n < 18; n++) {
        const s = await key('Tab', { shift }, null, order);
        if (s.active.job === job && s.active.action === action) return s;
      }
      throw new Error(`natural Tab could not reach ${job}/${action}`);
    };
    const serviceRead = async label => {
      const snap = await evaluate(`(async () => (await import('/product/service.js')).read())()`);
      const entry = { case: currentCase, label, order: snap.order, jobsHash: hash(JSON.stringify(snap.jobs)), allSixPayloadsIntact: equal(snap.jobs, jobs) };
      result.persistence.push(entry); check(currentCase + ':' + label + ':all-six-payloads', entry.allSixPayloadsIntact); return snap;
    };
    const saved = async (expected, label) => {
      await waitFor(`document.querySelector('.save-line')?.dataset.state === 'saved'`, label + ' saved state');
      const snap = await serviceRead(label); check(currentCase + ':' + label + ':actual-commit', equal(snap.order, expected), { expected, actual: snap.order });
    };
    const move = async (job, action, keyName, order) => {
      const i = order.indexOf(job), target = i + (action === 'up' ? -1 : 1);
      if (target < 0 || target >= order.length) throw new Error('Invalid observer boundary movement');
      [order[i], order[target]] = [order[target], order[i]];
      const after = target === 0 ? 'down' : target === order.length - 1 ? 'up' : action;
      return key(keyName, {}, { job, action: after }, order);
    };
    const runCase = async (name, fn) => {
      currentCase = name; step = 0;
      try { await fn(); } catch (e) { result.errors.push({ case: name, error: String(e), stack: e.stack }); }
      await store();
    };
    await fresh(false);
    for (const [name, width, height] of [['wide', 1280, 900], ['narrow', 375, 650], ['low', 1280, 500]]) await runCase(name, async () => {
      await page('Emulation.setDeviceMetricsOverride', { width, height, deviceScaleFactor: 1, mobile: false });
      await fresh(true);
      await page('Input.dispatchMouseEvent', { type: 'mouseMoved', x: 1, y: 1 });
      result.initialProfiles[name] = await evaluate(`[...document.querySelectorAll('.move-button')].map(b=>({job:b.dataset.jobId,action:b.dataset.action,profile:__cycleObserver.profile(b)}))`);
      if (baseline) check(name + ':initial-invariants', equal(result.initialProfiles[name], baseline.initialProfiles[name]));
      const order = [...ids];
      await goByTab('JOB-1042', 'up', order);
      await move('JOB-1042', 'up', 'Enter', order);
      for (let n = 0; n < 5; n++) await move('JOB-1042', 'down', n % 2 ? 'Enter' : 'Space', order);
      const imageName = name + '-focus.png';
      await screenshot(imageName, { captureBeyondViewport: false }); result.screenshots.push({ name: imageName, after: result.samples.at(-1)?.name }); screenshotCount++;
      for (let n = 0; n < 5; n++) await move('JOB-1042', 'up', n % 2 ? 'Space' : 'Enter', order);
      await saved(order, 'feedback-settled');
      await recordFrames('saved-feedback-focus', { job: 'JOB-1042', action: 'down' }, order);
      await goByTab('JOB-1046', 'up', order);
      await goByTab('JOB-1042', 'down', order, true);
      const before = await current();
      const x = Math.min(width - 20, Math.max(20, before.active.rect.x + 10));
      const y = Math.min(height - 20, Math.max(20, before.active.rect.y + 20));
      await page('Input.dispatchMouseEvent', { type: 'mouseWheel', x, y, deltaX: 0, deltaY: 280 });
      await pause(100); const delivered = await current();
      await pause(800); const retained = await current();
      check(name + ':wheel-delivered', delivered.lastWheel?.trusted && delivered.lastWheel.dy === 280, delivered.lastWheel);
      const moved = delivered.scrolls.some((p, i) => Math.abs(p.y - (before.scrolls[i]?.y || 0)) > 10);
      check(name + ':wheel-changed-scroll', moved, { before: before.scrolls, after: delivered.scrolls });
      check(name + ':wheel-retained', equal(delivered.scrolls, retained.scrolls), { delivered: delivered.scrolls, retained: retained.scrolls });
      result.samples.push({ name: name + ':intentional-wheel', before: compact(before), delivered: compact(delivered), retained: compact(retained) });
      if (name === 'narrow') { await screenshot('wheel-retained.png', { captureBeyondViewport: false }); result.screenshots.push({ name: 'wheel-retained.png', after: name + ':intentional-wheel' }); screenshotCount++; }
      await saved(order, 'keyboard-sweep-saved');
    });
    await runCase('rapid', async () => {
      await page('Emulation.setDeviceMetricsOverride', { width: 1280, height: 900, deviceScaleFactor: 1, mobile: false });
      await fresh(true); const order = [...ids]; await goByTab('JOB-1042', 'down', order);
      const started = Date.now();
      for (let n = 0; n < 3; n++) { const s = await move('JOB-1042', 'down', n % 2 ? 'Space' : 'Enter', order); check('rapid:' + n + ':pending-honest', s.state === 'saving'); }
      check('rapid:actions-within-first-commit', Date.now() - started < 350, Date.now() - started);
      await saved(order, 'rapid-latest'); await fresh(false); check('rapid:reload-latest', equal((await current()).order, order)); await serviceRead('rapid-reloaded');
    });
    await runCase('failure', async () => {
      await fresh(true); const order = [...ids];
      await pressKey('Tab'); await pressKey('Tab');
      check('failure:visible-arm-focus', (await current()).active.id === 'fail-next-save');
      await pressKey('Enter');
      await goByTab('JOB-1042', 'down', order);
      await move('JOB-1042', 'down', 'Enter', order);
      await waitFor(`document.querySelector('.save-line')?.dataset.state === 'error'`, 'explicit failure');
      await recordFrames('error-feedback-focus', { job: 'JOB-1042', action: 'down' }, order);
      const failure = await current(); check('failure:retry-available', !failure.retry.hidden && !failure.retry.disabled);
      check('failure:honest-draft-message', /새로고침/.test(failure.status) && /다시 저장/.test(failure.status));
      await move('JOB-1042', 'down', 'Space', order);
      await pause(500); const edited = await current(); const committed = await serviceRead('failed-additional-edit');
      await recordFrames('failed-edit-settled-focus', { job: 'JOB-1042', action: 'down' }, order);
      check('failure:additional-edit-retained', equal(edited.order, order));
      check('failure:explicit-retry-policy', edited.state === 'error' && !edited.retry.hidden && equal(committed.order, ids));
      for (let n = 0; n < 18; n++) { const s = await key('Tab', { shift: true }, null, order); if (s.active.action === 'retry-save') break; }
      check('failure:retry-natural-focus', (await current()).active.action === 'retry-save');
      await pressKey('Enter');
      const retryState = await current(); check('failure:retry-pending', retryState.state === 'saving');
      // The second valid adapter call takes 80ms. These immediate trusted Tabs
      // reach first-row down, then Enter edits while the explicit retry runs.
      await pressKey('Tab');
      check('failure:retry-tab-move-focus', (await current()).active.job === 'JOB-1041' && (await current()).active.action === 'down');
      const retryEdit = await move('JOB-1041', 'down', 'Enter', order);
      check('failure:retry-additional-edit-pending', retryEdit.state === 'saving');
      await saved(order, 'retry-latest'); await recordFrames('retry-settled-focus', { job: 'JOB-1041', action: 'down' }, order); await fresh(false); check('failure:reload-latest', equal((await current()).order, order)); await serviceRead('retry-reloaded');
    });
    await runCase('filter', async () => {
      await fresh(true); const order = [...ids]; await pressKey('Tab');
      await page('Input.insertText', { text: 'job-1044' });
      await recordFrames('typed-filter');
      const filtered = await current(); check('filter:single-case-insensitive-row', equal(filtered.order, ['JOB-1044']) && equal(filtered.rank, [4]));
      await pressKey('Tab'); await pressKey('Tab');
      check('filter:natural-up-focus', (await current()).active.job === 'JOB-1044' && (await current()).active.action === 'up');
      await pressKey('Space'); const after = await recordFrames('Space-hidden-neighbor', { job: 'JOB-1044', action: 'up' });
      [order[2], order[3]] = [order[3], order[2]];
      check('filter:global-rank', equal(after.order, ['JOB-1044']) && equal(after.rank, [3]));
      await saved(order, 'hidden-neighbor-saved');
      await pressKey('Tab', { shift: true }); await pressKey('Tab', { shift: true });
      check('filter:return-to-input', (await current()).active.id === 'queue-filter');
      await pressKey('Escape');
      await waitFor(`document.querySelector('#queue-filter').value === '' && document.querySelectorAll('#queue-list > li').length === 6`, 'native search Escape clears filter');
      const cleared = await current(); check('filter:clear-restores-full-order', equal(cleared.order, order) && cleared.rowsValid);
      await fresh(false); check('filter:reload-full-order', equal((await current()).order, order)); await serviceRead('filter-reloaded');
    });
    result.runtimeExceptions = b.exceptions.map(e => ({ text: e.text, description: e.exception?.description }));
    check('runtime:no-exceptions', b.exceptions.length === 0);
  });
} catch (e) { result.errors.push({ case: 'browser', error: String(e), stack: e.stack }); }
result.fixtureSourceAfter = await sourceHashes();
check('fixture:all-eight-sources-unchanged-during-run', equal(result.fixtureSourceBefore, result.fixtureSourceAfter));
result.finished = new Date().toISOString();
result.summary = { checks: result.checks.length, passed: result.checks.filter(c => c.pass).length, failed: result.checks.filter(c => !c.pass).length, errors: result.errors.length, screenshots: result.screenshots.length };
await store();
console.log(JSON.stringify({ output, summary: result.summary, failed: result.checks.filter(c => !c.pass).map(c => ({ name: c.name, detail: c.detail })), errors: result.errors }, null, 2));
process.exitCode = result.summary.failed || result.errors.length ? 1 : 0;
