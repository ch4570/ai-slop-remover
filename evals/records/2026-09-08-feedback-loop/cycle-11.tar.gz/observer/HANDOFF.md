# Observer execution handoff

This is metadata written after the parent accepted final v2 and began the author. No browser was launched and no evaluator, criteria, expected data, helper, fixture, or collected browser evidence was changed for this handoff. Parent owns the later control-run command records; they are not reproduced here.

## Actual executions

Both commands were issued through `exec_command` with working directory `/tmp/lutriva-cycle11-observer-CSCtCF`. The invoked executable name was `node`, resolved by the shell; its absolute executable path was not captured. An earlier actual `node --version` call returned `v26.8.1`. The transport uses the installed Chrome and an isolated temporary profile/local origin. The evidence resolves the output root to `/private/tmp/lutriva-cycle11-observer-CSCtCF` on this system.

### First original attempt

Exact shell command supplied to the tool:

```sh
node observer.mjs ../lutriva-cycle11-work-NoUEQi/original original
```

Observer arguments: `observer.mjs`, `../lutriva-cycle11-work-NoUEQi/original`, `original`. Initial tool call returned running session `47756` (chunk `a215eb`) with no stdout; the following `write_stdin` poll returned terminal exit code `1` (chunk `e5e1f5`). The actual terminal stdout was the observer JSON report: 8 checks passed, 0 check failures, 6 setup errors, 0 screenshots. Each scenario failed at the observer's top-level `await import(...)` Runtime.evaluate expression with `SyntaxError: Unexpected token 'import'`. This was a collector setup failure and provides no product behavioral verdict.

`original/browser.json` records start `2026-09-08T20:23:27.721Z` and finish `2026-09-08T20:23:28.934Z`. These are observer-recorded timestamps, not independently captured shell start/exit timestamps. Its SHA256 is `fdbf436b072c1117fffc6d458796758dc08d97d96541a5abbf036d8aa64f7756`.

The exact executed evaluator and criteria are preserved as `observer-v1.mjs` and `CRITERIA-v1.md`. The exact v1 helper is preserved as `browser_harness-v1.mjs`; it differs from the supplied helper only by one extra terminal newline. This first attempt did not record all-eight before/after source manifests; do not attribute v2's integrity check to it.

### Original v2

Exact shell command supplied to the tool:

```sh
shasum -a 256 CRITERIA-v1.md && node observer.mjs ../lutriva-cycle11-work-NoUEQi/original original-v2
```

Observer executable/arguments: `node`, `observer.mjs`, `../lutriva-cycle11-work-NoUEQi/original`, `original-v2`. Initial tool call returned running session `7396` (chunk `21f8a6`) and printed the preserved v1 criteria hash. The following `write_stdin` poll returned terminal exit code `1` (chunk `d9f39f`). Its actual stdout reported 1,074 checks: 1,059 passed, 15 failed, 0 errors, 4 screenshots, followed by the 15 failed check names and an empty errors array.

All 15 failed checks were `whole-indicator-visible` viewport clipping: wide 2, narrow 9, low 4. This includes Enter/Space movement, boundary direction fallback, natural Tab/Shift+Tab, and narrow settled saved feedback. Focus target, preserved outline/style/button sizes, order/ranks, pending operability, latest rapid-save reload, explicit failure/additional edit/retry/retry-time edit/reload, hidden-neighbor filtering, all six complete job payloads, and the sampled wheel-retention checks passed. All eight fixture source hashes were identical before and after this run; those exact manifests are in `original-v2/browser.json` under `fixtureSourceBefore` and `fixtureSourceAfter`.

`original-v2/browser.json` records start `2026-09-08T20:25:41.922Z` and finish `2026-09-08T20:25:53.818Z`; its SHA256 is `3903e2dcc47f5083027c9ff4d3ba39a5f6409f31bb14e703617ff14e029fe85d`. This is the accepted comparison baseline, despite its intentional original-product clipping failures.

## Frozen hash records

| Input | First attempt | Final v2 |
| --- | --- | --- |
| Evaluator | `858ee9c5b4c87b71b176c46db3a6466522e3b739b2b13b7d9933371a2a07de6c` | `6dc3fc538d0819df6f789ce84b1d8a07379515bab13382c9cd6a4221cd668eef` |
| Criteria | `1788c2951412e5e0a0dd643f720d50bfbfbe40182ece6d4b9e84bbee04ff0a72` | `488a1c2c40b824985fa01530ca7393233b027fe62118923ce8c53b0e39144b94` |
| Helper | `add3cd1cb9df4d7db604a242bac94b16b5eb9bcdb91281dc1f96e09360f24079` | `5538f93787bf84a401eba4ce747264ddd6bfc6e5e31049e4004a8986ad85a1e1` |
| Expected jobs | `8b655f9e75c7fbaa34b831d1a3b41bb6866146b4a2c62862c892e07618cb6472` | same |

Final helper is byte-identical to the supplied repository helper. `CALIBRATION.md` describes the pre-author correction and unexecuted intermediate candidate. No acceptance criterion was relaxed after a product outcome.

## Applicability and record limits

- Keyboard sweeps and saved-feedback focus cover 1280×900, 375×650 and 1280×500; error/additional-edit/retry-settled focus covers only 1280×900.
- Wheel delivery/scroll position is sampled after a 100ms pause, then again after 800ms. Passing these samples establishes retained sampled positions and does not prove there was no earlier transient movement or restoration before the first sample.
- Key observation uses two subsequent animation frames with a 200ms availability deadline. It is not a continuous frame-by-frame recording from key dispatch.
- Viewport PNGs and compact DOM-derived geometry are evidence for these bounded scenarios, not exhaustive visibility under every layout or input sequence.
- The console report was visible in actual tool results, but no separate stdout file or machine-exported full tool transcript was saved. This handoff summarizes the exposed terminal results and is not presented as a raw transcript. Exact shell launch/exit timestamps and absolute Node binary path were not exposed/captured; the timestamp claims above come only from preserved observer JSON.
