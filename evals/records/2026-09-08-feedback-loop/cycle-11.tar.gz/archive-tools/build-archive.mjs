import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync, readdirSync, lstatSync, existsSync } from 'node:fs';
import { spawnSync } from 'node:child_process';
import path from 'node:path';
const metadata='/tmp/lutriva-cycle11-archive-FmdxSW';
const repository='/Users/rex/Desktop/personal/lutriva';
const destination=repository+'/evals/records/2026-09-08-feedback-loop/cycle-11.tar.gz';
const inventory=repository+'/evals/records/2026-09-08-feedback-loop/cycle-11-inventory.json';
assert.ok(!existsSync(destination)&&!existsSync(inventory),'New archive and inventory only');
const sets=[
  {name:'lutriva-cycle11-work-NoUEQi',prefix:'work'},
  {name:'lutriva-cycle11-observer-CSCtCF',prefix:'observer'},
  {name:'lutriva-cycle11-independent-review-XP5ZUZ',prefix:'review'},
  {name:'lutriva-cycle11-scope-controls-Nce97v',prefix:'scope-controls',only:['controls.json','run-controls.mjs']},
  {name:'lutriva-cycle11-archive-FmdxSW',prefix:'archive-tools',only:['ARCHIVE-README.md','build-archive.mjs','run-command.mjs','preserve-build-record.mjs']},
];
const sha=b=>createHash('sha256').update(b).digest('hex');
function collect(set) {
  const entries=[];
  const walk=relative=>{
    const source=path.join('/tmp',set.name,relative),stat=lstatSync(source,{bigint:true});
    assert.ok(!stat.isSymbolicLink(),source+': symlinks are not archived');
    if(stat.isDirectory()) for(const name of readdirSync(source).sort())walk(path.join(relative,name));
    else {assert.ok(stat.isFile(),source+': regular files only');const b=readFileSync(source);entries.push({source,input:path.join(set.name,relative),archive:path.join(set.prefix,relative),bytes:b.length,sha256:sha(b),mode:Number(stat.mode&0o777n),mtimeNs:String(stat.mtimeNs)});}
  };
  for(const relative of set.only??[''])walk(relative);
  return entries;
}
const records=sets.flatMap(collect).sort((a,b)=>a.archive.localeCompare(b.archive));
assert.equal(new Set(records.map(r=>r.archive)).size,records.length);
const provenance={schema:1,createdAt:new Date().toISOString(),baseCommit:'1eb503c35f6807b9e01eead49b44353d9f65176d',method:'direct tar stream with prefix mapping; no second uncompressed staging copy',sets,files:records};
writeFileSync(metadata+'/source-map.json',JSON.stringify(provenance,null,2)+'\n',{flag:'wx'});
const mapStat=lstatSync(metadata+'/source-map.json',{bigint:true}),mapBytes=readFileSync(metadata+'/source-map.json');
records.push({source:metadata+'/source-map.json',input:'lutriva-cycle11-archive-FmdxSW/source-map.json',archive:'archive-tools/source-map.json',bytes:mapBytes.length,sha256:sha(mapBytes),mode:Number(mapStat.mode&0o777n),mtimeNs:String(mapStat.mtimeNs)});
records.sort((a,b)=>a.archive.localeCompare(b.archive));
writeFileSync(inventory,JSON.stringify({schema:1,files:Object.fromEntries(records.map(r=>[r.archive,{bytes:r.bytes,sha256:r.sha256}]))},null,2)+'\n',{flag:'wx'});
writeFileSync(metadata+'/tar-inputs.list',records.map(r=>r.input).join('\0')+'\0',{flag:'wx'});
const args=['-czf',destination,'-C','/tmp',...sets.flatMap(s=>['-s',`|^${s.name}/|${s.prefix}/|`]),'--null','-T',metadata+'/tar-inputs.list'];
const started=new Date().toISOString();
const result=spawnSync('/usr/bin/tar',args,{cwd:repository,encoding:'utf8',env:{...process.env,COPYFILE_DISABLE:'1'},maxBuffer:1024*1024});
writeFileSync(metadata+'/tar.stdout',result.stdout??'',{flag:'wx'});writeFileSync(metadata+'/tar.stderr',result.stderr??'',{flag:'wx'});
writeFileSync(metadata+'/tar-command.json',JSON.stringify({executable:'/usr/bin/tar',args,cwd:repository,environmentOverride:{COPYFILE_DISABLE:'1'},started,finished:new Date().toISOString(),exit:result.status,signal:result.signal,error:result.error?.message??null},null,2)+'\n',{flag:'wx'});
assert.equal(result.status,0,'tar must complete');
for(const r of records){const b=readFileSync(r.source),s=lstatSync(r.source,{bigint:true});assert.equal(sha(b),r.sha256,r.source);assert.equal(b.length,r.bytes);assert.equal(Number(s.mode&0o777n),r.mode);assert.equal(String(s.mtimeNs),r.mtimeNs);}
assert.deepEqual(sets.flatMap(collect).map(r=>r.input).sort(),records.filter(r=>r.archive!=='archive-tools/source-map.json').map(r=>r.input).sort(),'Selected regular-file set unchanged');
const output={files:records.length,uncompressedBytes:records.reduce((n,r)=>n+r.bytes,0),archive:{path:destination,bytes:lstatSync(destination).size,sha256:sha(readFileSync(destination))},inventory:{path:inventory,sha256:sha(readFileSync(inventory))},allSourceBytesModesMtimesAndSelectedPathsUnchanged:true};
writeFileSync(metadata+'/archive-result.json',JSON.stringify(output,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(output));
