# Cycle11 evidence archive

This is a new explicit product follow-up to cycle10's candidate, not replacement of its result or a skill-version comparison. Base repository commit: 1eb503c35f6807b9e01eead49b44353d9f65176d. Product copy provenance ties the input to the committed cycle10 inventory; the previous archive is not duplicated here.

`work/` preserves original/trial product, exact current release skill snapshots, immutable helper, task and prior task, source freezes, author launch request/response/final answer, available author checks, frozen evaluator controls, candidate browser output, parent observations and readable product.patch. `observer/` contains the fixed observer, exact initial failed evaluator/helper/criteria, calibration, baseline outputs and metadata handoff. `review/` contains the independent review. `scope-controls/` contains only the synthetic controls script and combined raw command/result JSON; synthetic trees (including an intentional symlink) are not archived.

The source map records original path, bytes, SHA, mode and mtime. Tar reads those regular files directly with prefix mapping, without a second uncompressed staging tree. The external inventory includes source-map.json itself. Build/check stdout/stderr and terminal metadata are preserved separately outside the tar they validate. Historical absolute paths and timestamps remain historical; no transcripts were reconstructed.

After extracting into a NEW owned directory, from that extracted archive root, the portable frozen observer can be invoked with existing Node and Chrome:

```sh
node observer/observer.mjs work/original /tmp/NEW-original-output
node observer/observer.mjs work/trial /tmp/NEW-candidate-output /tmp/NEW-original-output/browser.json
```

The names above are illustrative unused output paths, not automatically allocated directories. Use genuinely fresh paths. The original was observed to exit1 due 15 full-outline clips; candidate exit0 in the historical run. This archive was checked without extraction; no relocated browser replay is claimed. Parent/author one-off scripts bind historical absolute paths and need explicit path adaptation for a new run; do not rewrite archived historical hashes or treat adapted scripts as the originals.

Keyboard focus covers three frozen viewports with two-frame bounded sampling. Failure/retry focus covers wide only in the independent observer. Wheel observations are at roughly100ms and800ms later, not continuous recording. Author checks extend dimensions/workflows but remain author-run evidence. No physical-device, broad screen-reader, cross-browser, universal clipping or automatic host-discovery claim. Installed skills, release payload and manifest are unchanged.
