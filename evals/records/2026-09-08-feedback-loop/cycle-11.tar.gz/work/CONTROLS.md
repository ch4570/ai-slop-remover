# Frozen-before-author evaluator sensitivity copies

control-no-outline/ is the same eight original task/product files with only a final CSS rule removing the move-button focus-visible outline. It must not be accepted as fixing visibility by deleting the indicator. Other original clipping failures are not unique control failures.

control-sticky-focus/ is the same original files with only an appended requestAnimationFrame loop that centers the active move button on every frame. It never changes order/storage/focus or the original style; it should make the focus footprint visible but interfere with deliberate wheel exploration. The wheel preservation criterion must detect this behavior. No claim about intermediate motion before sampled states.

These are synthetic evaluator controls, not agent runs, guidance versions or legitimate product proposals. Their exact source diffs are evaluator data and must not be given to the author. Use the same independently frozen observer on each after its original run. Do not change criteria based on their results after author launch. All raw failed observations remain preserved.
