# Parent observations

## Before author handoff

The parent read the final observer/criteria, calibration history, original-v2 report, both control reports, actual command records and scope-control outcomes before evaluating any candidate. Original-v2 has 15 whole-indicator viewport clips (wide 2, narrow 9, low 4), with no collection/runtime errors. These observations concern the 6px footprint of the existing 3px outline and 3px offset, not merely the button rectangle. Other sampled focus targets, original profiles, ordering/data, persistence, retry, filter and intentional scroll checks pass.

Direct image inspection: all four original-v2 viewport PNGs (wide-focus, narrow-focus, low-focus, wheel-retained), control-no-outline-output/wide-focus.png and control-sticky-focus-output/wheel-retained.png. The boundary images show clipped lower focus outlines; removing the outline visibly removes it; sticky centering leaves the first focused row onscreen in its wheel image. The latter image alone does not establish wheel behavior: raw trusted wheel delivery and the unchanged 100ms position establish the control failure. The parent has not claimed inspection of the other six control PNGs.

No-outline control: 118 outline-preservation failures plus the original 15 clips, no errors. Sticky control: only three wheel-changed-scroll failures, no clipping failures or errors. The unchanged 100ms/900ms positions do not reveal any transient motion before 100ms. Controls are synthetic evaluator sensitivity cases, not author runs, alternative skill versions or additional independently discovered product defects.

The original has 1,074 assertions; baseline-compared controls/candidate have five additional baseline integrity/profile assertions. Assertion totals are not comparable task counts or uplift percentages. Six scenario families remain fixed. Error/retry settled focus is covered only at 1280x900; narrow/low cover ordinary saved feedback. Source and actual PNG review must supplement rectangle/profile checks; the observer is not a universal accessibility, appearance, clipping or adapter-write proof.

The metadata-only observer HANDOFF.md and first-stage independent REVIEW.md were read after author launch. Both preserve the initial collector SyntaxErrors as setup failure, not product failure, and do not amend the frozen evaluator. The reviewer had not read trial/author evidence at that stage.

## After author handoff

The parent read all three source diffs and author RESULTS.md. The only executable changes are a cancelled/superseded one-frame focusin reveal, its active-element guard, removal of the old immediate reveal, and 7px scroll margin. Original outline, button dimensions, layout, data and save implementation remain unchanged. Source inspection, not the observer's simple localStorage/indexedDB lexical guard alone, supports the unchanged adapter write path.

The same frozen observer ran once on candidate and exited0: 1,079 assertions passed, no setup/runtime errors, 131 compact samples and four viewport PNGs. Parent opened all four candidate PNGs. Lower outline is fully visible at the wide, narrow and low boundaries, retaining the teal style; wheel-retained narrow shows later rows, with intentional offscreen focus allowed. No claim about uninspected author PNGs is made by the parent.

Parent post-collection consistency script matched all15 earlier clips to their now-unclipped candidate samples with the same job/action/outline. It checked frozen input hashes, current/before/after source hashes, ten distinct document UUIDs, and thirteen adapter reads preserving all six payloads. Latest rapid order134526, retry order314256 and filtered order124356 each match their fresh-document reload. These are abbreviated JOB-1041..1046 IDs. Wheel positions change and remain: wide75→157→157, narrow531→811→811, low475→557→557.

The first parent consistency script incorrectly treated clippedBy as strings, but raw entries are boundary objects. It stopped before writing results with AssertionError. Exact v1 source and command/stdout/stderr are preserved. v2 checks boundary.name and retains all three wheel sample objects; it exited0. No evaluator, product or browser result was changed or rerun for this correction.

Author self-checks report142 final assertions across additional low/narrow viewports, reduced-motion and workflows. These are separate self-checks, not parent reruns or frozen independent coverage. Author baseline JSON/screenshots preserve15 actual clips plus a later diagnostic SyntaxError. The available author check.mjs is its final script; no exact pre-correction script or intermediate product snapshot is present. Do not claim those missing bytes were preserved. The supplied skill snapshots are explicit inputs, not evidence of automatic host discovery or skill causality.
