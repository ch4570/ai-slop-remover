Implemented the scoped focus fix in `trial/product/app.js`, `trial/styles.css`, and `trial/DESIGN.md`.

Move-button focus now reveals once after native focus/layout completes, with a 7px scroll margin preserving the existing 3px outline and 3px offset. Same-job focus and boundary fallback remain intact; manual scrolling does not trigger focus following.

Final checks: `node --check product/app.js` passed; 142 browser checks passed across 375×320, 320×240 with reduced motion, 1280×240, 620×360, and failure/retry/search/reload/manual-scroll/emulated-touch workflows. No runtime exceptions.

Inspected baseline and final upper/lower-edge screenshots, narrow reduced-motion captures, desktop bottom focus, failure focus, and touch layout. Baseline reproduced 15 clipping failures; its later diagnostic SyntaxError remains preserved as partial evidence.

Actual commands, screenshot inventory, and limitations: [RESULTS.md](/tmp/lutriva-cycle11-work-NoUEQi/author-evidence/RESULTS.md).

Physical devices, other browsers, and screen readers were not tested. No remaining failure was observed in final checks.
