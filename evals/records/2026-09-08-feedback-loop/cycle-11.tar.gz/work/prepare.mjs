import assert from 'node:assert/strict';
import { readFileSync, writeFileSync, mkdirSync, copyFileSync, constants, lstatSync } from 'node:fs';
import { createHash } from 'node:crypto';
import path from 'node:path';
const root='/tmp/lutriva-cycle11-work-NoUEQi', repository='/Users/rex/Desktop/personal/lutriva', previous='/tmp/lutriva-cycle10-work-NpakUR/trial';
const oldInventory=JSON.parse(readFileSync(repository+'/evals/records/2026-09-08-feedback-loop/cycle-10-inventory.json'));
const release=JSON.parse(readFileSync(repository+'/manifest.json'));
const sha=b=>createHash('sha256').update(b).digest('hex');
const record=[];
function copy(source,destination,expected){
  assert.ok(lstatSync(source).isFile()&&!lstatSync(source).isSymbolicLink());
  const before=readFileSync(source); if(expected)assert.equal(sha(before),expected,source);
  mkdirSync(path.dirname(destination),{recursive:true});copyFileSync(source,destination,constants.COPYFILE_EXCL);
  assert.deepEqual(readFileSync(destination),before);assert.deepEqual(readFileSync(source),before);
  record.push({source,destination,bytes:before.length,sha256:sha(before)});
}
for(const lane of ['original','trial']) {
  for(const name of ['DESIGN.md','index.html','styles.css','product/app.js','product/service.js','SERVICE_CONTRACT.md'])copy(previous+'/'+name,root+'/'+lane+'/'+name,oldInventory.files['work/trial/'+name].sha256);
  copy(previous+'/TASK.md',root+'/'+lane+'/PRIOR-TASK.md',oldInventory.files['work/trial/TASK.md'].sha256);
  copy(root+'/TASK.md',root+'/'+lane+'/TASK.md');
}
const payload=release.files;
console.log(JSON.stringify({manifestFilesType:Array.isArray(payload)?'array':typeof payload,keys:Object.keys(release)}));
writeFileSync(root+'/product-copy-provenance.json',JSON.stringify(record,null,2)+'\n',{flag:'wx'});
