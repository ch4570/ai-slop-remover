// Immutable local persistence adapter. See SERVICE_CONTRACT.md for the public API.
const STORAGE_KEY = 'charye.dispatch.order.v1';
const JOBS = [
  {
    id: 'JOB-1041',
    title: '서교 작은도서관 정기 자료 교체 · 반납 도서와 전시 안내물 회수',
    route: '서교 자료실 → 연남 공동보관소',
    timeWindow: '09:00–09:30',
    packageLabel: '도서 상자 3개',
    payload: { reference: 'SYN-LIB-041', units: 3, handling: '상자 번호 1·2·3 유지', tags: ['가상', '정기'] },
  },
  {
    id: 'JOB-1042',
    title: '성산 마을공방 주말 수업 준비물 · 도자기 도구와 보호 포장 세트 전달',
    route: '성산 공방 창고 → 망원 배움터',
    timeWindow: '09:20–10:00',
    packageLabel: '공구함 2개',
    payload: { reference: 'SYN-CRAFT-042', units: 2, handling: '수평 유지', tags: ['가상', '취급 주의'] },
  },
  {
    id: 'JOB-1043',
    title: '합정 전시 준비팀 이동 집기 · 접이식 안내대와 재사용 표지판 운반',
    route: '합정 준비실 → 상수 전시공간',
    timeWindow: '09:40–10:20',
    packageLabel: '안내대 4개',
    payload: { reference: 'SYN-EXHIBIT-043', units: 4, handling: '묶음 끈 보관', tags: ['가상', '왕복 예정'] },
  },
  {
    id: 'JOB-1044',
    title: '연남 생활수리 교실 공용 장비 · 점검 완료 공구와 설명서 묶음 인계',
    route: '연남 장비실 → 성미산 교실',
    timeWindow: '10:00–10:40',
    packageLabel: '장비 가방 2개',
    payload: { reference: 'SYN-REPAIR-044', units: 2, handling: '설명서 동봉 확인', tags: ['가상', '인계 확인'] },
  },
  {
    id: 'JOB-1045',
    title: '망원 동네기록 모임 촬영 소품 · 빈 액자와 배경 천 세트 옮기기',
    route: '망원 기록실 → 서교 모임방',
    timeWindow: '10:20–11:00',
    packageLabel: '소품 꾸러미 5개',
    payload: { reference: 'SYN-ARCHIVE-045', units: 5, handling: '천은 접힌 상태로 전달', tags: ['가상', '소품'] },
  },
  {
    id: 'JOB-1046',
    title: '상수 공유정원 계절 정리 물품 · 빈 화분과 손도구 보관함 회수',
    route: '상수 공유정원 → 성산 자재실',
    timeWindow: '10:40–11:20',
    packageLabel: '보관함 3개',
    payload: { reference: 'SYN-GARDEN-046', units: 3, handling: '빈 화분 완충재 유지', tags: ['가상', '회수'] },
  },
];
const DEFAULT_ORDER = JOBS.map((job) => job.id);
let startedCommits = 0;
let failNextCommit = false;
let generation = 0;

function serviceError(code, message) {
  return Object.assign(new Error(message), { code });
}

function validateOrder(ids) {
  if (!Array.isArray(ids) || ids.length !== DEFAULT_ORDER.length ||
      new Set(ids).size !== DEFAULT_ORDER.length ||
      ids.some((id) => !DEFAULT_ORDER.includes(id))) {
    throw serviceError('INVALID_ORDER', '모든 작업 번호를 중복 없이 한 번씩 전달해야 합니다.');
  }
  return [...ids];
}

function loadOrder() {
  const saved = localStorage.getItem(STORAGE_KEY);
  if (saved === null) return [...DEFAULT_ORDER];
  try {
    return validateOrder(JSON.parse(saved));
  } catch {
    return [...DEFAULT_ORDER];
  }
}

let committedOrder = loadOrder();

function snapshot() {
  return { jobs: JSON.parse(JSON.stringify(JOBS)), order: [...committedOrder] };
}

export function read() {
  return new Promise((resolve) => setTimeout(() => resolve(snapshot()), 20));
}

export function commit(ids) {
  let requestedOrder;
  try {
    requestedOrder = validateOrder(ids);
  } catch (error) {
    return Promise.reject(error);
  }

  const callNumber = ++startedCommits;
  const delay = callNumber % 2 === 1 ? 350 : 80;
  const shouldFail = failNextCommit;
  const callGeneration = generation;
  failNextCommit = false;

  return new Promise((resolve, reject) => {
    setTimeout(() => {
      if (callGeneration !== generation) {
        reject(serviceError('DEMO_RESET', '데모 초기화로 이전 저장 요청이 취소되었습니다.'));
        return;
      }
      if (shouldFail) {
        reject(serviceError('DEMO_SAVE_FAILED', '데모에서 이번 저장을 한 번 실패시켰습니다.'));
        return;
      }
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(requestedOrder));
        committedOrder = requestedOrder;
        resolve(snapshot());
      } catch {
        reject(serviceError('LOCAL_STORAGE_FAILED', '이 브라우저의 저장 공간에 기록하지 못했습니다.'));
      }
    }, delay);
  });
}

export function armNextCommitFailure() {
  failNextCommit = true;
}

export function resetDemo({ order = DEFAULT_ORDER, failNext = false } = {}) {
  const resetOrder = validateOrder(order);
  localStorage.setItem(STORAGE_KEY, JSON.stringify(resetOrder));
  generation += 1;
  startedCommits = 0;
  failNextCommit = Boolean(failNext);
  committedOrder = resetOrder;
  return snapshot();
}
