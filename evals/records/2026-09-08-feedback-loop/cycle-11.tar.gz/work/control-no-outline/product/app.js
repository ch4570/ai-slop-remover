import * as service from './service.js';

const list = document.querySelector('#queue-list');
const filter = document.querySelector('#queue-filter');
const count = document.querySelector('#queue-count');
const saveStatus = document.querySelector('#save-status');
const emptyState = document.querySelector('#empty-state');
const failButton = document.querySelector('#fail-next-save');
const demoStatus = document.querySelector('#demo-status');
const saveLine = document.querySelector('.save-line');
const retryButton = document.querySelector('[data-action="retry-save"]');

let jobs = [];
let order = [];
let revision = 0;
let savedRevision = 0;
let savingRevision = 0;
let saving = false;
let saveError = null;
let retrying = false;
let failureArmed = false;

function render(focusTarget = null) {
  const query = filter.value.trim().toLocaleLowerCase('ko');
  const visibleJobs = order
    .map((id) => jobs.find((job) => job.id === id))
    .filter((job) => `${job.id} ${job.title} ${job.route}`.toLocaleLowerCase('ko').includes(query));

  list.replaceChildren();
  for (const job of visibleJobs) {
    const position = order.indexOf(job.id);
    const row = document.createElement('li');
    row.className = 'job-row';
    row.dataset.jobId = job.id;

    const rank = document.createElement('span');
    rank.className = 'job-rank';
    rank.textContent = String(position + 1).padStart(2, '0');
    rank.setAttribute('aria-label', `전체 순서 ${position + 1}`);

    const description = document.createElement('div');
    const title = document.createElement('h3');
    title.className = 'job-title';
    title.textContent = job.title;
    const meta = document.createElement('p');
    meta.className = 'job-meta';
    meta.textContent = `${job.id} · ${job.route} · ${job.timeWindow} · ${job.packageLabel}`;
    description.append(title, meta);

    const controls = document.createElement('div');
    controls.className = 'job-controls';
    for (const [action, label, disabled] of [
      ['up', '↑ 위로', position === 0],
      ['down', '↓ 아래로', position === order.length - 1],
    ]) {
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'move-button';
      button.dataset.action = action;
      button.dataset.jobId = job.id;
      button.textContent = label;
      button.setAttribute('aria-label', `${job.title} ${action === 'up' ? '위로' : '아래로'} 이동`);
      button.disabled = disabled;
      controls.append(button);
    }
    row.append(rank, description, controls);
    list.append(row);
  }
  count.textContent = `전체 ${jobs.length}건 · 표시 ${visibleJobs.length}건`;
  emptyState.hidden = visibleJobs.length !== 0;

  if (focusTarget) {
    const row = [...list.children].find((item) => item.dataset.jobId === focusTarget.id);
    const sameDirection = row?.querySelector(`[data-action="${focusTarget.action}"]`);
    const nextFocus = sameDirection?.disabled ? row.querySelector('button:not(:disabled)') : sameDirection;
    nextFocus?.focus({ preventScroll: true });
    nextFocus?.scrollIntoView({ block: 'nearest', inline: 'nearest' });
  }
}

function renderSaveState() {
  saveLine.dataset.state = saveError ? 'error' : saving ? 'saving' : 'saved';
  if (saveError) {
    const reason = saveError.code === 'DEMO_SAVE_FAILED'
      ? '시험 설정으로 저장하지 못했어요.'
      : saveError.code === 'LOCAL_STORAGE_FAILED'
        ? '이 브라우저의 저장 공간에 기록하지 못했어요.'
        : '순서를 저장하지 못했어요.';
    saveStatus.textContent = `${reason} 현재 정한 순서는 화면에 남아 있어요. 다시 저장해 주세요. 새로고침하면 미저장 변경은 사라집니다.`;
  } else if (saving) {
    saveStatus.textContent = revision > savingRevision
      ? '순서를 저장하는 중… 추가로 정한 최신 순서도 이어서 저장해요. 계속 이동할 수 있어요.'
      : `${retrying ? '현재 순서를 다시 저장하는 중' : '순서를 저장하는 중'}… 계속 이동할 수 있어요.`;
  } else {
    saveStatus.textContent = '현재 순서를 이 브라우저에 저장했어요.';
  }

  const showRetry = Boolean(saveError) || retrying;
  if (!showRetry && document.activeElement === retryButton) {
    saveStatus.focus({ preventScroll: true });
  }
  retryButton.hidden = !showRetry;
  retryButton.disabled = saving;
  retryButton.textContent = saving ? '다시 저장 중…' : '다시 저장';
}

async function saveLatestOrder(isRetry = false) {
  if (saving || savedRevision === revision) return;
  saving = true;
  saveError = null;
  retrying = isRetry;

  // The adapter writes in completion order. Never overlap commits: a request
  // finishes before the latest complete draft is copied for the next write.
  while (savedRevision !== revision) {
    savingRevision = revision;
    const requestedOrder = [...order];
    renderSaveState();
    if (failureArmed) {
      failureArmed = false;
      demoStatus.textContent = '이번 저장에 실패 시험을 적용했어요. 다음 저장부터는 정상 시도합니다.';
    }
    try {
      await service.commit(requestedOrder);
      savedRevision = savingRevision;
    } catch (error) {
      // Preserve every edit, including edits made after this request began.
      // Further moves remain local until the user retries the current draft.
      saveError = error;
      break;
    }
  }

  saving = false;
  retrying = false;
  renderSaveState();
}

function moveJob(id, direction) {
  const index = order.indexOf(id);
  const target = index + direction;
  if (index < 0 || target < 0 || target >= order.length) return;

  const activeControl = document.activeElement;
  const focusTarget = activeControl?.dataset.jobId === id
    ? { id, action: direction === -1 ? 'up' : 'down' }
    : null;
  [order[index], order[target]] = [order[target], order[index]];
  revision += 1;
  render(focusTarget);
  if (saving || saveError) renderSaveState();
  else void saveLatestOrder();
}

list.addEventListener('click', (event) => {
  const button = event.target.closest('button[data-action]');
  if (!button || button.disabled) return;
  void moveJob(button.dataset.jobId, button.dataset.action === 'up' ? -1 : 1);
});

filter.addEventListener('input', () => render());
retryButton.addEventListener('click', () => {
  if (saveError && !saving) void saveLatestOrder(true);
});
failButton.addEventListener('click', () => {
  service.armNextCommitFailure();
  failureArmed = true;
  demoStatus.textContent = '다음에 시작하는 저장 한 번은 실패합니다. 이동하거나 다시 저장해 보세요.';
});

try {
  const snapshot = await service.read();
  jobs = snapshot.jobs;
  order = snapshot.order;
  render();
  saveLine.dataset.state = 'saved';
  saveStatus.textContent = '저장된 순서를 불러왔어요.';
} catch (error) {
  saveLine.dataset.state = 'error';
  saveStatus.textContent = `순서를 불러오지 못했어요. ${error.message}`;
}
