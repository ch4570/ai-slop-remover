# Local dispatch persistence contract

`product/service.js` is supplied infrastructure and must not be edited. It is an ES module with exactly four public functions. The product must use this adapter for all writes of queue order. The adapter has no dependencies and makes no network requests.

## Data

The six fixed job IDs in default order are `JOB-1041`, `JOB-1042`, `JOB-1043`, `JOB-1044`, `JOB-1045`, `JOB-1046`. A snapshot is `{ jobs, order }`. `jobs` is an array of all six complete objects, each with `id`, `title`, `route`, `timeWindow`, `packageLabel`, and nested `payload`. `order` is an array containing every ID exactly once. Returned arrays and objects are independent copies; changing them never changes the adapter. Job objects and payloads cannot be written through this API.

## Public functions

- `read(): Promise<Snapshot>` resolves after 20 ms with the currently committed order and all jobs. It does not wait for pending commits.
- `commit(ids: string[]): Promise<Snapshot>` accepts the complete ordered ID list. It validates and copies the input when called. Wrong length, duplicate IDs, or unknown IDs reject with `error.code === 'INVALID_ORDER'` without using a delay slot or consuming the failure flag. Every accepted call receives a delay based on its start number: odd calls take 350 ms, even calls take 80 ms. Browser timer scheduling may make actual elapsed time longer. Successful calls write in completion order, then resolve a snapshot. The adapter does not serialize calls or protect a newer request from a later completion of an older request. A rejected call never writes its requested order.
- `armNextCommitFailure(): void` arms exactly the next valid `commit` call to reject with `error.code === 'DEMO_SAVE_FAILED'` after that call's ordinary delay. The flag is consumed when that commit starts, not when it finishes. Repeated arming before a commit does not stack failures. The existing UI button invokes this function.
- `resetDemo({ order?, failNext? } = {}): Snapshot` is synchronous evaluator/demo setup. It defaults to the original six-job order, validates and persists the supplied order if present, resets the delay sequence so the next valid commit takes 350 ms, and resets the failure flag (default `false`). Already pending commits are invalidated and reject with `error.code === 'DEMO_RESET'` at their scheduled completion without writing. It returns an independent snapshot. It does not directly update already rendered UI. For a clean evaluator setup, await/import the adapter, call `resetDemo()`, then reload the page; failure flags and timing counters are intentionally per-page, so arm a failure after reload or through the visible button.

Orders persist in `localStorage` at `charye.dispatch.order.v1` for this browser and origin. A missing or malformed stored order loads the original order without discarding jobs. A write denied by the browser rejects with `error.code === 'LOCAL_STORAGE_FAILED'`. Clearing browser storage removes persistence. There is no backend, remote account, transmission, or cross-device synchronization. The app should not write localStorage directly.

## Running

Serve this folder over local HTTP because it uses ES modules. For example, from the fixture root run `python3 -m http.server 8765 --bind 127.0.0.1`, then open `http://127.0.0.1:8765/`. No installation or build is required. Keep this origin stable when checking persistence across reloads. Evaluators can access the same module instance from the page with `await import('/product/service.js')`.

## Existing UI hooks and rules

The queue is `#queue-list`, with one `li[data-job-id]` per visible job. Move buttons carry `data-job-id` and `data-action="up"` or `"down"`. `#queue-filter` searches job ID, title, and route, case-insensitively. `#save-status` is the existing polite live status, and `#fail-next-save` arms the one-shot demo failure. These IDs and data attributes are useful existing integration hooks; preserve them when improving the UI. If adding retry, expose a button with `data-action="retry-save"`.

Displayed ranks refer to the full order. Filtering only hides rows: it does not discard or reorder jobs. Moving a visible job always swaps it with the immediate neighbor in the full queue, including a hidden neighbor. Controls are disabled only when that direction is impossible at the full-queue boundary. Keyboard activation must keep focus on the acted job's corresponding control after a reorder whenever that control remains operable; if the action reaches a boundary, keep focus in that job's controls with the remaining operable direction. A pending save does not by itself make a move control inoperable.
