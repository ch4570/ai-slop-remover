import assert from 'node:assert/strict';
import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
const work='/tmp/lutriva-cycle11-work-NoUEQi', observer='/tmp/lutriva-cycle11-observer-CSCtCF';
const expected={
  'observer.mjs':'6dc3fc538d0819df6f789ce84b1d8a07379515bab13382c9cd6a4221cd668eef',
  'CRITERIA.md':'488a1c2c40b824985fa01530ca7393233b027fe62118923ce8c53b0e39144b94',
  'browser_harness.mjs':'5538f93787bf84a401eba4ce747264ddd6bfc6e5e31049e4004a8986ad85a1e1',
  'expected-jobs.json':'8b655f9e75c7fbaa34b831d1a3b41bb6866146b4a2c62862c892e07618cb6472',
  'original-v2/browser.json':'3903e2dcc47f5083027c9ff4d3ba39a5f6409f31bb14e703617ff14e029fe85d',
};
const sha=b=>createHash('sha256').update(b).digest('hex');
for(const [name,hash] of Object.entries(expected))assert.equal(sha(readFileSync(observer+'/'+name)),hash,name);
const controlReports={};
for(const name of ['control-no-outline','control-sticky-focus']){
  const p=work+'/'+name+'-output/browser.json',b=readFileSync(p),r=JSON.parse(b);
  assert.deepEqual(r.errors,[]);assert.deepEqual(r.fixtureSourceBefore,r.fixtureSourceAfter);
  for(const key of Object.keys(expected).filter(k=>!k.includes('/')))assert.equal(r.hashes[key],expected[key]);
  controlReports[name]={path:p,sha256:sha(b),summary:r.summary,failed:r.checks.filter(c=>!c.pass)};
}
const record={schema:1,frozenAt:new Date().toISOString(),beforeAuthor:true,observerRoot:observer,files:expected,controls:controlReports,
  scopeCheckerSha256:sha(readFileSync(work+'/check-scope.mjs')),inputInventorySha256:sha(readFileSync(work+'/input-paths-before.json')),
  authorRequestSha256:sha(readFileSync(work+'/author-launch-request.json')),
  note:'Final independent evaluator, original measured profiles and both controls accepted before one author launch. All earlier calibration source/results retained. Not a skill-version comparison.'};
writeFileSync(work+'/observer-freeze.json',JSON.stringify(record,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({frozenAt:record.frozenAt,files:expected,controls:Object.keys(controlReports)}));
