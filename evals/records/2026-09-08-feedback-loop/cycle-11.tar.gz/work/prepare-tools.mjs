import assert from 'node:assert/strict';
import { readFileSync, writeFileSync, mkdirSync, copyFileSync, constants } from 'node:fs';
import { createHash } from 'node:crypto';
import path from 'node:path';
const root='/tmp/lutriva-cycle11-work-NoUEQi', repository='/Users/rex/Desktop/personal/lutriva';
const release=JSON.parse(readFileSync(repository+'/manifest.json'));
const sha=b=>createHash('sha256').update(b).digest('hex');
const record=[];
function copy(source,destination,expected){
  const before=readFileSync(source);if(expected)assert.equal(sha(before),expected,source);
  mkdirSync(path.dirname(destination),{recursive:true});copyFileSync(source,destination,constants.COPYFILE_EXCL);
  assert.deepEqual(readFileSync(destination),before);assert.deepEqual(readFileSync(source),before);
  record.push({source,destination,bytes:before.length,sha256:sha(before)});
}
for(const [name,hash] of Object.entries(release.files).filter(([name])=>name.startsWith('skills/')))copy(repository+'/'+name,root+'/trial/'+name,hash);
copy(repository+'/scripts/browser_harness.mjs',root+'/author-tools/browser_harness.mjs','5538f93787bf84a401eba4ce747264ddd6bfc6e5e31049e4004a8986ad85a1e1');
mkdirSync(root+'/author-evidence');
writeFileSync(root+'/tools-copy-provenance.json',JSON.stringify(record,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({copied:record.length,skillFiles:record.length-1}));
