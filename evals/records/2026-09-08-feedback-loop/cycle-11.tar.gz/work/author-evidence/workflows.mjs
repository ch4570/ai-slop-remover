import { writeFile } from 'node:fs/promises';
import { withBrowser, claimBrowserEvidence } from '../author-tools/browser_harness.mjs';

const output = '/tmp/lutriva-cycle11-work-NoUEQi/author-evidence/workflows';
const results = { checks: [] };
const record = (label, passed, details) => results.checks.push({ label, passed, details });
await claimBrowserEvidence(output, ['failure.png', 'touch.png']);
try {
  await withBrowser('/tmp/lutriva-cycle11-work-NoUEQi/trial', output, async ({ origin, page, pressKey, evaluate, screenshot, pause, exceptions }) => {
    const settle = () => evaluate('new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve)))');
    const read = () => evaluate("(async () => (await (await import('/product/service.js')).read()))()");
    const state = () => evaluate(`(() => {
      const a = document.activeElement, r = a.getBoundingClientRect(), s = getComputedStyle(a);
      const ring = (parseFloat(s.outlineWidth) || 0) + Math.max(0, parseFloat(s.outlineOffset) || 0);
      return { order: [...document.querySelectorAll('#queue-list > li')].map(row => row.dataset.jobId),
        id: a.dataset.jobId, action: a.dataset.action, focusVisible: a.matches(':focus-visible'),
        rect: { top: r.top, bottom: r.bottom, left: r.left, right: r.right },
        visible: r.top >= ring - .1 && r.bottom <= innerHeight - ring + .1 && r.left >= ring - .1 && r.right <= innerWidth - ring + .1,
        state: document.querySelector('.save-line').dataset.state, status: document.querySelector('#save-status').textContent,
        retry: !document.querySelector('[data-action="retry-save"]').hidden,
        disabled: [...document.querySelectorAll('.move-button:disabled')].map(b => [b.dataset.jobId,b.dataset.action]),
        scrollY, horizontalOverflow: document.documentElement.scrollWidth > innerWidth,
        styles: { outline: s.outline, outlineOffset: s.outlineOffset, width: r.width, height: r.height } };
    })()`);
    const reload = async () => { await page('Page.reload'); await pause(100); };
    const reset = async () => { await evaluate("import('/product/service.js').then(service => service.resetDemo())"); await reload(); };
    const same = (a,b) => JSON.stringify(a) === JSON.stringify(b);
    const setFilter = async value => {
      await evaluate(`(() => { const f = document.querySelector('#queue-filter'); f.value = ${JSON.stringify(value)}; f.dispatchEvent(new Event('input', {bubbles:true})); })()`);
    };
    await page('Emulation.setDeviceMetricsOverride', { width: 375, height: 320, deviceScaleFactor: 1, mobile: false });
    await page('Page.navigate', {url:origin}); await pause(100);
    const original = await read();
    await pressKey('Tab'); await pressKey('Tab'); await pressKey('Enter'); await pressKey('Tab');
    for (const key of ['Enter','Space','Enter']) { await pressKey(key); await settle(); }
    let observed = await state();
    record('pending moves remain available except full-order boundaries', observed.state === 'saving' && observed.disabled.length === 2 && observed.order[3] === 'JOB-1041', observed);
    await pause(450);
    observed = await state();
    record('failed save retains latest draft and reveals retry', observed.state === 'error' && observed.retry && observed.order[3] === 'JOB-1041', observed);
    record('failed save focus remains visible', observed.id === 'JOB-1041' && observed.visible && observed.focusVisible, observed);
    record('failure does not write draft', same((await read()).order, original.order));
    await screenshot('failure.png',{captureBeyondViewport:false});
    await pressKey('Space'); await settle(); await pause(420);
    observed = await state();
    record('editing after failure stays unsaved until explicit retry', observed.state === 'error' && observed.order[4] === 'JOB-1041' && same((await read()).order, original.order), observed);
    await evaluate("document.querySelector('[data-action=\"retry-save\"]').click()");
    await pressKey('Enter'); await settle();
    observed = await state();
    record('movement during retry keeps same job at bottom with up control', observed.id === 'JOB-1041' && observed.action === 'up' && observed.order[5] === 'JOB-1041' && observed.visible, observed);
    await pause(550);
    observed = await state();
    const committed = await read();
    record('retry persists newest complete order and all job data', observed.state === 'saved' && same(committed.order, observed.order) && same(committed.jobs, original.jobs), observed);
    await reload();
    record('reload reads actual retry result', same((await state()).order, committed.order));

    await reset();
    await setFilter('job-1043');
    // Reach the filtered row through native Tab rather than assigning focus.
    for (let i=0;i<3;i++) await pressKey('Tab');
    await pressKey('Enter'); await settle();
    observed = await state();
    record('search moves visible job through hidden full-order neighbor', observed.order.length === 1 && observed.id === 'JOB-1043' && observed.action === 'up' && observed.visible, observed);
    await pause(450);
    const filteredSaved = await read();
    record('filtered save keeps all six IDs and complete data', same(filteredSaved.order, ['JOB-1041','JOB-1043','JOB-1042','JOB-1044','JOB-1045','JOB-1046']) && same(filteredSaved.jobs, original.jobs), filteredSaved.order);
    await setFilter('');
    record('clearing search restores full order and ranks', await evaluate("[...document.querySelectorAll('#queue-list > li')].every((row,index) => row.querySelector('.job-rank').textContent === String(index+1).padStart(2,'0'))") && (await state()).order.length === 6);

    await reset();
    for(let i=0;i<3;i++) await pressKey('Tab');
    await pressKey('Enter'); await settle();
    await page('Input.dispatchMouseEvent',{type:'mouseWheel',x:260,y:140,deltaY:550,deltaX:0});
    await pause(90);
    const scrolled = await state();
    await pause(550);
    const afterSave = await state();
    record('manual wheel reading position survives pending save completion', scrolled.id === 'JOB-1041' && !scrolled.visible && Math.abs(scrolled.scrollY-afterSave.scrollY) <= 1 && afterSave.state === 'saved', { before:scrolled, after:afterSave });
    await pressKey('Tab'); await settle();
    observed = await state();
    record('new Tab reveals current target after manual scrolling', observed.visible && observed.focusVisible, observed);

    await reset();
    await page('Emulation.setDeviceMetricsOverride',{width:390,height:844,deviceScaleFactor:1,mobile:true});
    await page('Emulation.setTouchEmulationEnabled',{enabled:true,maxTouchPoints:1});
    const target = await evaluate(`(() => { const b = document.querySelector('[data-job-id="JOB-1042"][data-action="down"]'); b.scrollIntoView({block:'center'}); const r = b.getBoundingClientRect(); return {x:r.x+r.width/2,y:r.y+r.height/2}; })()`);
    await page('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{x:target.x,y:target.y}]});
    await page('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});
    await settle(); await pause(450);
    observed = await state();
    record('synthetic touch activates a real move and persists it', observed.order[2] === 'JOB-1042' && same((await read()).order, observed.order) && !observed.horizontalOverflow, observed);
    await screenshot('touch.png',{captureBeyondViewport:false});
    results.exceptions = exceptions;
  });
} catch(error) { results.error=String(error.stack||error); }
await writeFile(`${output}/browser.json`,JSON.stringify(results,null,2));
console.log(JSON.stringify({ checks:results.checks.length, failed:results.checks.filter(c=>!c.passed), error:results.error, exceptions:results.exceptions?.length, output },null,2));
if(results.error || results.checks.some(c=>!c.passed))process.exitCode=1;
