# Scoped flow plan

- Tab / Shift+Tab → native focus changes, no queue changes → current move button and its existing 3px outline plus 3px offset are fully visible → no extra scroll/refocus required → no persistence.
- Enter / Space on a move button → swap the full-order neighbor and retain the acted job/direction; use the operable opposite at a boundary → show that control and its entire outline after layout settles → later actions supersede earlier focus work → existing serialized service commit only.
- Save feedback changes → preserve the existing draft/status/retry logic → avoid clipping the currently used control when status content changes the layout → do not return to a control the user has scrolled away from → existing adapter success is the persistence boundary.
- Manual scroll → user's reading position changes → no continual focus-following → a new deliberate focus or move can reveal its target again → no persistence.

Checks: reproduce pre-change clipping; exercise Tab and Shift+Tab, repeated Enter and Space, both boundaries, narrow/short viewports and reduced motion; verify rapid saved order/reload, failure draft/edit/retry, filtered hidden-neighbor movement and manual scrolling. Use isolated synthetic Chrome and compact evidence only.
