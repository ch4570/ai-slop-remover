import { writeFile } from 'node:fs/promises';
import { withBrowser, claimBrowserEvidence } from '../author-tools/browser_harness.mjs';

const mode = process.argv[2] || 'baseline';
const width = Number(process.argv[3] || 375);
const height = Number(process.argv[4] || 320);
const reduced = process.argv[5] === 'reduce';
const output = `/tmp/lutriva-cycle11-work-NoUEQi/author-evidence/${mode}`;
const results = { mode, width, height, reduced, checks: [], screenshots: [] };
await claimBrowserEvidence(output, ['focus-bottom.png', 'focus-top.png']);
try {
  await withBrowser('/tmp/lutriva-cycle11-work-NoUEQi/trial', output, async ({ origin, page, pressKey, evaluate, screenshot, pause, exceptions }) => {
    const settle = () => evaluate('new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve)))');
    const snapshot = () => evaluate(`(() => {
      const a = document.activeElement, s = getComputedStyle(a), r = a.getBoundingClientRect();
      const pad = (parseFloat(s.outlineWidth) || 0) + Math.max(0, parseFloat(s.outlineOffset) || 0);
      return { id: a.dataset.jobId, action: a.dataset.action, tag: a.tagName,
        focused: a.matches(':focus-visible'), disabled: a.disabled,
        rect: { top: r.top, bottom: r.bottom, left: r.left, right: r.right }, pad,
        viewport: { width: innerWidth, height: innerHeight }, scrollY,
        visible: r.top >= pad - .1 && r.bottom <= innerHeight - pad + .1 && r.left >= pad - .1 && r.right <= innerWidth - pad + .1,
        state: document.querySelector('.save-line').dataset.state,
        order: [...document.querySelectorAll('#queue-list > li')].map(row => row.dataset.jobId) };
    })()`);
    const observeFocus = async label => {
      await settle();
      const state = await snapshot();
      if (state.id) results.checks.push({ label, passed: state.visible && state.focused && !state.disabled, ...state });
      return state;
    };
    await page('Emulation.setDeviceMetricsOverride', { width, height, deviceScaleFactor: 1, mobile: false });
    if (reduced) await page('Emulation.setEmulatedMedia', { features: [{ name: 'prefers-reduced-motion', value: 'reduce' }] });
    await page('Page.navigate', { url: origin });
    await pause(100);
    for (let i = 0; i < 3; i++) await pressKey('Tab');
    await observeFocus('first down via Tab');
    for (let i = 0; i < 5; i++) {
      await pressKey(i % 2 ? 'Space' : 'Enter');
      const state = await observeFocus(`move first job down ${i + 1}`);
      if (i === 0) { await screenshot('focus-bottom.png', { captureBeyondViewport: false }); results.screenshots.push('focus-bottom.png'); }
      if (i === 4) results.checks.push({ label: 'bottom boundary switches to same job up', passed: state.id === 'JOB-1041' && state.action === 'up' && state.order[5] === 'JOB-1041' });
    }
    for (let i = 0; i < 5; i++) {
      await pressKey(i % 2 ? 'Enter' : 'Space');
      const state = await observeFocus(`move same job up ${i + 1}`);
      if (i === 2) { await screenshot('focus-top.png', { captureBeyondViewport: false }); results.screenshots.push('focus-top.png'); }
      if (i === 4) results.checks.push({ label: 'top boundary switches to same job down', passed: state.id === 'JOB-1041' && state.action === 'down' && state.order[0] === 'JOB-1041' });
    }
    for (let i = 0; i < 9; i++) { await pressKey('Tab'); await observeFocus(`Tab forward ${i + 1}`); }
    for (let i = 0; i < 9; i++) { await pressKey('Tab', { shift: true }); await observeFocus(`Shift Tab backward ${i + 1}`); }
    await pause(550);
    const current = await snapshot();
    const saved = await evaluate("(async () => (await (await import('/product/service.js')).read()).order)()");
    results.checks.push({ label: 'rapid changes saved through adapter', passed: JSON.stringify(saved) === JSON.stringify(current.order), saved, displayed: current.order });
    results.exceptions = exceptions;
  });
} catch (error) { results.error = String(error.stack || error); }
await writeFile(`${output}/browser.json`, JSON.stringify(results, null, 2));
console.log(JSON.stringify({ mode, checks: results.checks.length, failed: results.checks.filter(check => !check.passed).map(({label, rect, pad}) => ({label, rect, pad})), error: results.error, exceptions: results.exceptions?.length, output }, null, 2));
if (results.error || (mode !== 'baseline' && results.checks.some(check => !check.passed))) process.exitCode = 1;
