import assert from 'node:assert/strict';
import { readFileSync, writeFileSync, copyFileSync, mkdirSync, constants } from 'node:fs';
import { createHash } from 'node:crypto';
import path from 'node:path';
const root='/tmp/lutriva-cycle11-work-NoUEQi';
const copied=[];
for(const lane of ['control-no-outline','control-sticky-focus'])for(const file of ['TASK.md','PRIOR-TASK.md','SERVICE_CONTRACT.md','DESIGN.md','index.html','styles.css','product/app.js','product/service.js']){
  const source=root+'/original/'+file,target=root+'/'+lane+'/'+file,bytes=readFileSync(source);
  mkdirSync(path.dirname(target),{recursive:true});copyFileSync(source,target,constants.COPYFILE_EXCL);
  assert.deepEqual(readFileSync(target),bytes);assert.deepEqual(readFileSync(source),bytes);
  copied.push({source,target,bytes:bytes.length,sha256:createHash('sha256').update(bytes).digest('hex')});
}
writeFileSync(root+'/control-copy-provenance.json',JSON.stringify(copied,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({copied:copied.length,mutations:'None yet; explicit separate apply_patch follows.'}));
