import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { copyFileSync, mkdirSync, readFileSync } from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const work = path.dirname(fileURLToPath(import.meta.url));
const sourceChecker = '/tmp/lutriva-cycle11-work-NoUEQi/check-scope.mjs';
const expectedCheckerHash = 'ef0ae696e2a472112f0d557a09d9b76586693763a2ffe4e9647b016c98ccd55d';
const sha = (data) => createHash('sha256').update(data).digest('hex');
const fileSha = (name) => sha(readFileSync(name));
assert.equal(fileSha(sourceChecker), expectedCheckerHash);
const commands = [];
function command(cwd, argv, input) {
  const result = spawnSync(argv[0], argv.slice(1), { cwd, input, encoding: 'utf8' });
  assert.ifError(result.error);
  const entry = { cwd, argv, ...(input === undefined ? {} : { stdin: input }), exit: result.status,
    stdout: result.stdout.trim(), stderr: result.stderr.trim() };
  commands.push(entry);
  return entry;
}
function patch(cwd, text) {
  const entry = command(cwd, ['apply_patch'], text);
  assert.equal(entry.exit, 0, JSON.stringify(entry));
}
const seed = path.join(work, 'seed');
mkdirSync(seed);
patch(seed, '*** Begin Patch\n*** Add File: original/product/app.js\n+export const value = 1;\n*** Add File: trial/product/app.js\n+export const value = 1;\n*** Add File: trial/styles.css\n+body { color: black; }\n*** Add File: trial/DESIGN.md\n+Synthetic design.\n*** Add File: trial/index.html\n+<!doctype html><title>Synthetic</title>\n*** Add File: author-tools/sentinel.txt\n+Immutable synthetic tool.\n*** End Patch\n');
copyFileSync(sourceChecker, path.join(seed, 'check-scope.mjs'));
const initialFreeze = command(seed, ['node', 'check-scope.mjs', 'freeze', 'input-paths-before.json']);
assert.equal(initialFreeze.exit, 0);
const freezeHash = fileSha(path.join(seed, 'input-paths-before.json'));
const cases = [
  { id: 'untouched', negativeControl: false, expectedExit: 0 },
  { id: 'allowed-app', negativeControl: false, expectedExit: 0, changed: 'trial/product/app.js',
    patch: '*** Begin Patch\n*** Update File: trial/product/app.js\n@@\n-export const value = 1;\n+export const value = 2;\n*** End Patch\n' },
  { id: 'allowed-styles', negativeControl: false, expectedExit: 0, changed: 'trial/styles.css',
    patch: '*** Begin Patch\n*** Update File: trial/styles.css\n@@\n-body { color: black; }\n+body { color: blue; }\n*** End Patch\n' },
  { id: 'allowed-design', negativeControl: false, expectedExit: 0, changed: 'trial/DESIGN.md',
    patch: '*** Begin Patch\n*** Update File: trial/DESIGN.md\n@@\n-Synthetic design.\n+Synthetic design changed.\n*** End Patch\n' },
  { id: 'negative-index-boundary', negativeControl: true, expectedExit: 1, failure: ['trial/index.html', 'immutable content or modification time changed'],
    patch: '*** Begin Patch\n*** Update File: trial/index.html\n@@\n-<!doctype html><title>Synthetic</title>\n+<!doctype html><title>Synthetic changed</title>\n*** End Patch\n' },
  { id: 'negative-new-file', negativeControl: true, expectedExit: 1, failure: ['trial/product/extra.js', 'added path'],
    patch: '*** Begin Patch\n*** Add File: trial/product/extra.js\n+export const unexpected = true;\n*** End Patch\n' },
  { id: 'negative-source-symlink', negativeControl: true, expectedExit: 1, failure: ['trial/product/app.js', 'type or mode changed'], symlink: true },
  { id: 'negative-original-edit', negativeControl: true, expectedExit: 1, failure: ['original/product/app.js', 'immutable content or modification time changed'],
    patch: '*** Begin Patch\n*** Update File: original/product/app.js\n@@\n-export const value = 1;\n+export const value = 2;\n*** End Patch\n' },
];
const results = [];
for (const test of cases) {
  const directory = path.join(work, test.id);
  const copy = command(work, ['cp', '-pR', seed, directory]);
  assert.equal(copy.exit, 0);
  assert.equal(fileSha(path.join(directory, 'input-paths-before.json')), freezeHash);
  const checkerBefore = fileSha(path.join(directory, 'check-scope.mjs'));
  assert.equal(checkerBefore, expectedCheckerHash);
  if (test.patch) patch(directory, test.patch);
  if (test.symlink) {
    const saved = command(directory, ['mv', 'trial/product/app.js', 'preserved-app.js']);
    assert.equal(saved.exit, 0);
    const linked = command(directory, ['ln', '-s', '../../preserved-app.js', 'trial/product/app.js']);
    assert.equal(linked.exit, 0);
  }
  const verification = command(directory, ['node', 'check-scope.mjs', 'verify', 'after.json']);
  assert.equal(verification.exit, test.expectedExit, JSON.stringify(verification));
  const before = JSON.parse(readFileSync(path.join(directory, 'input-paths-before.json'), 'utf8'));
  const after = JSON.parse(readFileSync(path.join(directory, 'after.json'), 'utf8'));
  assert.equal(after.verified, test.expectedExit === 0);
  if (test.changed) assert.deepEqual(after.changes, [test.changed]);
  if (test.id === 'untouched') assert.deepEqual(after.changes, []);
  if (test.failure) {
    assert.ok(after.failures.some((item) => item.path === test.failure[0] && item.reason === test.failure[1]));
    assert.equal(after.failures.length, 1);
  }
  const checkerAfter = fileSha(path.join(directory, 'check-scope.mjs'));
  const freezeAfter = fileSha(path.join(directory, 'input-paths-before.json'));
  assert.equal(checkerAfter, checkerBefore);
  assert.equal(freezeAfter, freezeHash);
  results.push({ id: test.id, negative_control: test.negativeControl, expected_exit: test.expectedExit,
    actual_exit: verification.exit, expectation_met: true, path_count_before: Object.keys(before.paths).length,
    path_count_after: Object.keys(after.paths).length, verified: after.verified, changes: after.changes,
    failures: after.failures.map(({ path, reason }) => ({ path, reason })),
    before_state_sha256: sha(JSON.stringify(before.paths)), after_state_sha256: sha(JSON.stringify(after.paths)),
    before_json_sha256: freezeHash, before_json_after_sha256: freezeAfter, after_json_sha256: fileSha(path.join(directory, 'after.json')),
    checker_before_sha256: checkerBefore, checker_after_sha256: checkerAfter });
}
const sourceCheckerAfter = fileSha(sourceChecker);
assert.equal(sourceCheckerAfter, expectedCheckerHash);
const report = { schema: 1, scope: 'Independent synthetic checker controls only; expected rejections are negative controls, not actual candidate failures.',
  artifacts: work, invocation: { cwd: work, argv: ['node', 'run-controls.mjs'] },
  checker_source: sourceChecker, checker_source_before_sha256: expectedCheckerHash, checker_source_after_sha256: sourceCheckerAfter,
  synthetic_paths: 11, immutable_input_freeze_sha256: freezeHash, all_expectations_met: true, results, commands };
patch(work, '*** Begin Patch\n*** Add File: controls.json\n+' + JSON.stringify(report) + '\n*** End Patch\n');
console.log(JSON.stringify({ artifact: path.join(work, 'controls.json'), all_expectations_met: true,
  cases: results.map(({ id, negative_control, actual_exit }) => ({ id, negative_control, actual_exit })),
  checker_sha256: expectedCheckerHash }));
