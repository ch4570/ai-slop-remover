# Frozen observer negative-control audit

Both deliberately defective controls were rejected by the intended frozen predicates. These controls are diagnostic baseline copies, not proposed product candidates or skill versions. No actual product candidate or author output was inspected. The observer, specification, harness, baseline, and control sources were read-only throughout.

| Run | Completed cases | Required failures | Collector errors | Exit |
| --- | --- | --- | --- | --- |
| Frozen reference baseline | 28/28 | 82 visibility failures | 0 | Reference only |
| no-outline | 28/28 | 272 outline-preservation + 82 visibility failures | 0 | 1 |
| pinned-scroll | 28/28 | 26 earlier-column movement + 26 no-snap-back failures | 0 | 1 |

Each control ran all 24 static conditions (both routes; 1280×900, 390×844, 320×800, 320×864; synthetic 100/150/200% CSS text size) and four focused resize/font cases: 256 checkpoints and 20 viewport captures. In each run, 26 overflow scenarios exercised trusted right and left wheel input inside the table. The two 1280×900/100% cases had no horizontal overflow and were skipped by the frozen wheel policy; no left-wheel test was incomplete. Runtime exceptions and review flags were empty; all page-target guards passed; Chrome/152.0.7977.83 was unchanged before/after each run.

## Source differences and frozen hashes

All seven filenames and all untouched file bytes match the dense reference baseline. `no-outline` changes only `components.css`, preserving its full original prefix and appending `:focus-visible { outline: 0 solid transparent; outline-offset: 0; }`. `pinned-scroll` changes only `app.js`, preserving the original order-click handler and appending the documented requestAnimationFrame loop that forces the table containing a focus-visible row button to maximum horizontal scroll. Exact appended source and all per-file byte counts/hashes are recorded in `control-differences.json` and `manifest-before.json`.

| Artifact | SHA256 |
| --- | --- |
| Frozen observer | `545788c49b4e4380520163bb46e50a0dce1b82574ea4bc045786cda5ec99d253` |
| Frozen specification | `9252a96e6e78c2b80a35df01aed77aa7d03778cf76e5e74aab822d219ae80d00` |
| Copied and original harness | `5538f93787bf84a401eba4ce747264ddd6bfc6e5e31049e4004a8986ad85a1e1` |
| Baseline browser.json reference | `56845a16f29056e331bbac74af4bb85e6b8be3fd0870ef4cecabc7ce4b35244b` |
| no-outline/components.css | `6cd32d067d5c02376b9cb052030f5f1f34e1d6e5b7f153cb8d301074b6429fb0` |
| pinned-scroll/app.js | `737d28b31ec3b1b835a96b3a8e52661b8790f8e94e2f0f3a769e65c5dfedac17` |
| no-outline/browser.json | `11060e89cbee15cb243a341262bba78ca1be1a2e4b6dda8abefb3007256fad36` |
| pinned-scroll/browser.json | `773a73b03492c31745d083d650ba1340f49509d5155bfa08fcd0612001d81230` |

Both runs used the same unchanged observer command with their respective source/output directories, after the parent's baseline-ready signal, sequentially with prior Chrome cleanup completed. Exact executable/arguments, times, exit codes, baseline reference, and post-run hashes are in `no-outline.run.json` and `pinned-scroll.run.json`. Full stdout/stderr are retained separately; both stderr files are empty. `manifest-after.json` confirms every recorded observer/specification/harness/baseline/control source hash is unchanged.

## Target-predicate evidence

For `no-outline`, `existing-focus-outline-preserved` fails 272 times, covering 256 focus checkpoints and 16 focused post-capture checks. At `master-390x844-100:tab-first`, active row is `M-101` and `focusVisible` is true, but the computed outline is solid with width `0px`, transparent `rgba(0, 0, 0, 0)`, and offset `0px`; the frozen invariant requires 3px, `rgb(163, 72, 27)`, and 2px. All 82 remaining `full-focused-button-and-outline-visible` failure contexts exactly match the baseline. Those baseline failures are retained and are not the control-specific rejection evidence. The control has zero wheel-invariant failures.

For `pinned-scroll`, both `user-wheel-moves-earlier-columns` and `user-wheel-does-not-snap-back` fail in all 26 exercised overflow scenarios. At `master-320x864-200`, maximum and pre-wheel `scrollLeft` are 942. A trusted table-targeted left-wheel event has `deltaX: -240`, `deltaY: 0`, and `inTable: true`; the pointer hit is a table header at (47, 302.8125). The three samples after waits of 220ms, a further 650ms, and a further 650ms remain `[942, 942, 942]`. All samples retain `M-101`, `focusVisible: true`, and document Y=0. Trusted right-wheel preparation was also recorded. Thus positive available left travel and delivered input are established, but the required movement is absent. The baseline's same wheel scenario moves from 942 to `[702, 702, 702]`. The pinned control has no other required failures, including no outline or automatic visibility failures. This demonstrates why fitting the focused button alone would admit this defective behavior.

## Actual image inspection and limits

I opened these two actual generated PNGs:

- `no-outline/master-390x844-100-tab-first.png` (390×844, 100% synthetic text): first-row button has no visible focus outline and its right side remains clipped at the table's right boundary. This is one first-focus screenshot on the master route, not inspection of every capture.
- `pinned-scroll/master-320x864-200-user-horizontal-wheel.png` (320×864, 200% synthetic text, long Korean customer names, after wheel): work-column end of the table is visible, its horizontal thumb is at the right endpoint, and the first-row button has its orange focus outline. This is a post-input still image; the trusted event and measured scroll samples establish failed browsing. The still image does not establish motion, or distinguish no movement from a return before the first 220ms sample.

Raw per-check fields, wheel entries, and before/after capture measurements remain in each `browser.json`; selected evidence fields and all PNG hashes are in `audit-results.json`. Collector errors/incomplete checks were not substituted for intended failures. Text enlargement is CSS text preparation, not OS/page zoom. The installed Chrome ran through the unchanged temporary-profile harness with local loopback fixtures; no installation, update UI, existing user-profile connection, external write, commit, or assertion adjustment occurred. Auxiliary target provenance is explicitly unverified by this observer. These results validate only the frozen conditions and targeted negative controls, not general accessibility, visual quality, profile/network isolation, or any actual product candidate.
