import { readFile, writeFile, readdir, stat } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { spawn } from 'node:child_process';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const output = path.dirname(fileURLToPath(import.meta.url));
const observerRoot = '/tmp/lutriva-focus-observer-v2-y5Qemd';
const controlRoot = '/tmp/lutriva-cycle7-controls-674Fnm';
const baselineRoot = '/tmp/lutriva-focus-followup-mvK1r3/baseline';
const observerFiles = ['observer.mjs', 'frozen-spec.json', 'browser_harness.mjs'];
const expectedObserverHashes = [
  '545788c49b4e4380520163bb46e50a0dce1b82574ea4bc045786cda5ec99d253',
  '9252a96e6e78c2b80a35df01aed77aa7d03778cf76e5e74aab822d219ae80d00',
  '5538f93787bf84a401eba4ce747264ddd6bfc6e5e31049e4004a8986ad85a1e1',
];
const hash = value => createHash('sha256').update(value).digest('hex');
async function manifest(root) {
  const result = {};
  for (const name of (await readdir(root)).sort()) {
    const full = path.join(root, name);
    if (!(await stat(full)).isFile()) throw new Error('Unexpected non-file in source: ' + full);
    const bytes = await readFile(full);
    result[name] = { bytes: bytes.length, sha256: hash(bytes) };
  }
  return result;
}
async function snapshot() {
  const observer = {};
  for (const [i, name] of observerFiles.entries()) {
    const bytes = await readFile(path.join(observerRoot, name));
    observer[name] = { bytes: bytes.length, sha256: hash(bytes) };
    if (observer[name].sha256 !== expectedObserverHashes[i]) throw new Error('Frozen hash mismatch: ' + name);
  }
  return {
    observer,
    baseline: await manifest(baselineRoot),
    controls: {
      'no-outline': await manifest(path.join(controlRoot, 'no-outline')),
      'pinned-scroll': await manifest(path.join(controlRoot, 'pinned-scroll')),
    },
    controlNotesSha256: hash(await readFile(path.join(controlRoot, 'CONTROL-NOTES.md'))),
    originalHarnessSha256: hash(await readFile('/tmp/lutriva-focus-followup-mvK1r3/harness/browser_harness.mjs')),
  };
}
const phase = process.argv[2];
if (phase === 'prepare') {
  const sources = await snapshot();
  const differences = {};
  for (const name of ['no-outline', 'pinned-scroll']) {
    if (JSON.stringify(Object.keys(sources.baseline)) !== JSON.stringify(Object.keys(sources.controls[name]))) throw new Error('Unexpected control file set');
    differences[name] = Object.keys(sources.baseline).filter(file => sources.baseline[file].sha256 !== sources.controls[name][file].sha256);
    const expected = name === 'no-outline' ? 'components.css' : 'app.js';
    if (JSON.stringify(differences[name]) !== JSON.stringify([expected])) throw new Error('Unexpected control differences');
    const baseline = await readFile(path.join(baselineRoot, expected), 'utf8');
    const changed = await readFile(path.join(controlRoot, name, expected), 'utf8');
    if (!changed.startsWith(baseline)) throw new Error('Control does not retain entire baseline source');
    differences[name] = { file: expected, preservedBaselinePrefix: true, appendedSource: changed.slice(baseline.length) };
  }
  await writeFile(path.join(output, 'manifest-before.json'), JSON.stringify(sources, null, 2) + '\n', { flag: 'wx' });
  await writeFile(path.join(output, 'control-differences.json'), JSON.stringify(differences, null, 2) + '\n', { flag: 'wx' });
  console.log(JSON.stringify({ output, sources, differences }, null, 2));
} else if (phase === 'run') {
  const name = process.argv[3];
  if (!['no-outline', 'pinned-scroll'].includes(name)) throw new Error('Unknown control');
  const baselineFile = path.join(observerRoot, 'baseline/browser.json');
  const baselineBytes = await readFile(baselineFile);
  const baseline = JSON.parse(baselineBytes);
  if (!baseline.finishedAt || baseline.summary.completedCases !== baseline.summary.totalCases || baseline.summary.collectorErrors !== 0) throw new Error('Baseline not completed without collector errors');
  const before = JSON.parse(await readFile(path.join(output, 'manifest-before.json'), 'utf8'));
  const current = await snapshot();
  if (JSON.stringify(before) !== JSON.stringify(current)) throw new Error('Frozen source changed before control');
  const args = [path.join(observerRoot, 'observer.mjs'), path.join(controlRoot, name), path.join(output, name)];
  const startedAt = new Date().toISOString();
  const child = spawn(process.execPath, args, { stdio: ['ignore', 'pipe', 'pipe'] });
  let stdout = '', stderr = '';
  child.stdout.on('data', chunk => { stdout += chunk; process.stdout.write(chunk); });
  child.stderr.on('data', chunk => { stderr += chunk; process.stderr.write(chunk); });
  const exit = await new Promise((resolve, reject) => { child.on('error', reject); child.on('close', (code, signal) => resolve({ code, signal })); });
  await writeFile(path.join(output, name + '.stdout.log'), stdout, { flag: 'wx' });
  await writeFile(path.join(output, name + '.stderr.log'), stderr, { flag: 'wx' });
  const after = await snapshot();
  const result = { startedAt, finishedAt: new Date().toISOString(), command: { executable: process.execPath, args }, exit, baselineReference: { file: baselineFile, sha256: hash(baselineBytes), summary: baseline.summary }, sourcesUnchanged: JSON.stringify(before) === JSON.stringify(after), after };
  await writeFile(path.join(output, name + '.run.json'), JSON.stringify(result, null, 2) + '\n', { flag: 'wx' });
  console.log(JSON.stringify({ control: name, exit, sourcesUnchanged: result.sourcesUnchanged }));
  process.exitCode = exit.code ?? 2;
} else if (phase === 'finalize') {
  const before = JSON.parse(await readFile(path.join(output, 'manifest-before.json'), 'utf8'));
  const after = await snapshot();
  const verification = { verifiedAt: new Date().toISOString(), sourcesUnchanged: JSON.stringify(before) === JSON.stringify(after), after };
  await writeFile(path.join(output, 'manifest-after.json'), JSON.stringify(verification, null, 2) + '\n', { flag: 'wx' });
  console.log(JSON.stringify(verification, null, 2));
} else throw new Error('Usage: audit-controls.mjs prepare|run CONTROL|finalize');
