import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const output = path.dirname(fileURLToPath(import.meta.url));
const baselinePath = '/tmp/lutriva-focus-observer-v2-y5Qemd/baseline/browser.json';
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const baselineBytes = await readFile(baselinePath);
const baseline = JSON.parse(baselineBytes);
const visibilityContexts = r => r.requiredFailures.filter(f => f.name === 'full-focused-button-and-outline-visible').map(f => f.context).sort();
const targetNames = ['existing-focus-outline-preserved', 'user-wheel-moves-earlier-columns', 'user-wheel-does-not-snap-back'];
const result = { baseline: { path: baselinePath, sha256: sha(baselineBytes), summary: baseline.summary }, controls: {} };
for (const name of ['no-outline', 'pinned-scroll']) {
  const dir = path.join(output, name);
  const rawBytes = await readFile(path.join(dir, 'browser.json'));
  const r = JSON.parse(rawBytes);
  const run = JSON.parse(await readFile(path.join(output, name + '.run.json'), 'utf8'));
  const targetFailures = r.requiredFailures.filter(f => targetNames.includes(f.name));
  const noOutline = targetFailures.find(f => f.context === 'master-390x844-100:tab-first');
  const wheel = r.wheel.find(w => w.context === 'master-320x864-200');
  const files = ['browser.json', 'summary.json', ...r.captures.map(c => c.file)];
  const artifacts = {};
  for (const file of files) {
    const bytes = await readFile(path.join(dir, file));
    artifacts[file] = { bytes: bytes.length, sha256: sha(bytes) };
  }
  const sourceVisibility = visibilityContexts(r);
  const baselineVisibility = visibilityContexts(baseline);
  const outlineDetail = noOutline && { context: noOutline.context, order: noOutline.detail.order, focusVisible: noOutline.detail.focusVisible, outlineStyle: noOutline.detail.style.outlineStyle, outlineWidth: noOutline.detail.style.outlineWidth, outlineColor: noOutline.detail.style.outlineColor, outlineOffset: noOutline.detail.style.outlineOffset };
  const wheelDetail = wheel && {
    context: wheel.context,
    automaticScrollLeft: wheel.automaticFocusState.scroller.scrollLeft,
    maxScrollLeft: wheel.before.scroller.scrollWidth - wheel.before.scroller.clientWidth,
    preparation: { deltaX: wheel.preparation.deltaX, events: wheel.preparation.events, samplesScrollLeft: wheel.preparation.samples.map(s => s.scroller.scrollLeft) },
    before: { scrollLeft: wheel.before.scroller.scrollLeft, focusOrder: wheel.before.focus.order, focusVisible: wheel.before.focus.focusVisible, documentY: wheel.before.document.scrollY },
    pointer: wheel.pointer, deltaX: wheel.deltaX, events: wheel.events,
    samples: wheel.samples.map(s => ({ scrollLeft: s.scroller.scrollLeft, focusOrder: s.focus.order, focusVisible: s.focus.focusVisible, documentY: s.document.scrollY })),
    targetFailures: targetFailures.filter(f => f.context === wheel.context).map(f => f.name),
  };
  result.controls[name] = {
    output: dir, exit: run.exit, summary: r.summary,
    frozenObserver: r.observer,
    sourcesUnchanged: run.sourcesUnchanged,
    baselineReferenceSha256: run.baselineReference.sha256,
    collectorErrors: r.collectorErrors,
    reviewFlags: r.reviewFlags,
    runtimeExceptionCount: r.runtimeExceptions.length,
    browserVersion: r.browserBefore.product,
    browserVersionUnchanged: JSON.stringify(r.browserBefore) === JSON.stringify(r.browserAfter),
    guardsAllAllowed: r.guards.every(g => g.allowed),
    auxiliaryTargetProvenance: 'Unverified, as explicitly recorded by unchanged observer.',
    targetFailureCounts: Object.fromEntries(targetNames.map(n => [n, targetFailures.filter(f => f.name === n).length])),
    otherFailureCounts: Object.fromEntries(Object.entries(r.summary.failureCounts).filter(([n]) => !targetNames.includes(n))),
    visibilityContextsMatchBaseline: JSON.stringify(sourceVisibility) === JSON.stringify(baselineVisibility),
    remainingBaselineVisibilityContexts: sourceVisibility.filter(c => baselineVisibility.includes(c)),
    newVisibilityFailureContexts: sourceVisibility.filter(c => !baselineVisibility.includes(c)),
    wheelCoverage: {
      entries: r.wheel.length,
      leftExercised: r.wheel.filter(w => w.events).length,
      rightTrustedInTable: r.wheel.filter(w => w.preparation?.events?.some(e => e.kind === 'wheel' && e.trusted && e.inTable && e.deltaX > 0 && e.deltaY === 0)).length,
      leftTrustedInTable: r.wheel.filter(w => w.events?.some(e => e.kind === 'wheel' && e.trusted && e.inTable && e.deltaX < 0 && e.deltaY === 0)).length,
      skipped: r.wheel.filter(w => w.skipped).map(w => ({ context: w.context, reason: w.skipped })),
      incompleteLeftWheel: r.wheel.filter(w => w.leftWheelNotExercised).map(w => ({ context: w.context, reason: w.leftWheelNotExercised })),
    },
    outlineDetail, wheelDetail, artifacts,
  };
}
await writeFile(path.join(output, 'audit-results.json'), JSON.stringify(result, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify(result, null, 2));
