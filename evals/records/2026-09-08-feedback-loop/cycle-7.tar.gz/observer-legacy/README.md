# Frozen focus observer

Run `node observer.mjs PRODUCT_ROOT NEW_OUTPUT [HARNESS_PATH]` using existing Node 22+ and installed Chrome. `NEW_OUTPUT` must be a fresh path outside the product. Keep `frozen-spec.json`, `browser_harness.mjs`, and the completed `baseline/browser.json` beside this script when relocating it. All browser captures use viewport mode and record geometry before and after capture. Synthetic text preparation is documented in the frozen specification and is not OS or page zoom.

The source was first frozen before any candidate access at SHA256 `425b755e82d80138b0f1fd8ba9c1b66bb04446882e9938da716ffac2107b8e96`. The first baseline attempt hit only an evidence collector error: installed Chrome 152 creates built-in extension and omnibox internal targets even in the harness's new temporary profile. The overly restrictive target guard rejected them before any product checkpoint. The original source is preserved as `observer-v1.mjs`; its complete unsuccessful run is in `baseline-v1-collector-target-error/`.

The corrected source permits only the exact observed internal type/URL pairs while retaining strict guards on page targets and recording every target. Cases, stabilization timings, keyboard delivery, geometry, static constraints and wheel criteria were unchanged. Corrected SHA256: `fdba674d6c9830e92d6fad1ec0e9bb335898e645552d0a74918cf3781cd636da`. Baseline and candidate must both run this corrected source.

The frozen static DESIGN check conservatively flags any change inside the existing marked comparison-density rationale. TASK requires retaining its meaning, not its exact wording. A semantically equivalent rewrite must therefore be reviewed as a documentation flag rather than treated as an automatic task failure. This interpretation was disclosed before candidate access.

`browser.json` separates `requiredFailures` from `collectorErrors`; neither array is silently converted into the other. The final summary includes failure counts and completed case count. Actual PNGs must also be opened and their inspected scope reported. No beauty score or full accessibility certification is produced.
