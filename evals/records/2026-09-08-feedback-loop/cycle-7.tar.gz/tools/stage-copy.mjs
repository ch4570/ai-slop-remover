import assert from 'node:assert/strict';
import { cp, mkdir, readFile, readdir, lstat, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import path from 'node:path';

// Exact-copy evidence staging only. Original texts and absolute paths stay intact.
const [staging, repositoryChecks] = process.argv.slice(2);
assert(staging && repositoryChecks, 'Usage: node stage.mjs EMPTY_STAGING FINAL_CHECKS');
assert.equal((await readdir(staging)).length, 0, 'Staging must be empty');
const repo = '/Users/rex/Desktop/personal/lutriva';
const mappings = [
  ['/tmp/lutriva-focus-followup-mvK1r3', 'input'],
  ['/tmp/lutriva-focus-work-yJaqbx', 'author'],
  ['/tmp/lutriva-focus-observer-S07pGL', 'observer-legacy'],
  ['/tmp/lutriva-focus-observer-v2-y5Qemd', 'observer'],
  ['/tmp/lutriva-focus-candidate-8e7XUz', 'candidate-observation'],
  ['/tmp/lutriva-cycle7-controls-674Fnm', 'controls'],
  ['/tmp/lutriva-cycle7-observer-controls-iV9Zce', 'control-observations'],
  ['/tmp/lutriva-cycle7-parent-ytksPP', 'parent'],
  [repositoryChecks, 'repository-checks'],
];
const singles = [
  ['/tmp/lutriva-focus-followup-mvK1r3-frozen.json', 'input-start-frozen.json'],
  ['/tmp/lutriva-cycle7-controls-674Fnm-frozen.json', 'controls-frozen.json'],
  ['/tmp/lutriva-cycle6-freeze.mjs', 'tools/freeze-inputs.mjs'],
  ['/tmp/lutriva-cycle7-stage.mjs', 'tools/stage-copy.mjs'],
  ['/tmp/lutriva-cycle6-inventory.mjs', 'tools/inventory-record.mjs'],
  [repo + '/scripts/check_evidence_archive.py', 'tools/check_evidence_archive.py'],
];
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
async function inventory(root, prefix = '') {
  const result = {};
  for (const name of (await readdir(root)).sort()) {
    const absolute = path.join(root, name), relative = prefix + name;
    const stat = await lstat(absolute);
    assert(!stat.isSymbolicLink(), 'Unexpected link: ' + absolute);
    assert(!/(^|\/)(\.git|Cache|Code Cache|GPUCache|Crashpad|__pycache__)(\/|$)/.test(relative), 'Unexpected cache: ' + absolute);
    if (stat.isDirectory()) Object.assign(result, await inventory(absolute, relative + '/'));
    else {
      assert(stat.isFile(), 'Unexpected file type: ' + absolute);
      assert(!/(^|\/)profiles\//.test(relative), 'Profile content remains: ' + absolute);
      const bytes = await readFile(absolute);
      result[relative] = { bytes: bytes.length, sha256: hash(bytes) };
    }
  }
  return result;
}
const report = { started: new Date().toISOString(), staging,
  scope: 'Final raw trial inputs, controls, observer revisions, reports, observations and repository checks copied without rewriting.',
  omissions: 'No regular files omitted within mapped roots. Empty directories are not inventoried. Prior cycle archives are not duplicated. Initial pre-correction author script provenance is described in author evidence, not invented by staging.',
  mappings: [], singles: [] };
for (const [source, relative] of mappings) {
  const before = await inventory(source), destination = path.join(staging, relative);
  await cp(source, destination, { recursive: true, errorOnExist: true, force: false, preserveTimestamps: true });
  assert.deepEqual(await inventory(source), before, 'Source changed: ' + source);
  assert.deepEqual(await inventory(destination), before, 'Copy differs: ' + source);
  report.mappings.push({ source, destination: relative, files: Object.keys(before).length,
    bytes: Object.values(before).reduce((sum, file) => sum + file.bytes, 0),
    sourceUnchanged: true, copyExact: true, entries: before });
}
for (const [source, relative] of singles) {
  const before = await readFile(source), destination = path.join(staging, relative);
  await mkdir(path.dirname(destination), { recursive: true });
  await cp(source, destination, { errorOnExist: true, force: false, preserveTimestamps: true });
  assert.deepEqual(await readFile(source), before);
  assert.deepEqual(await readFile(destination), before);
  report.singles.push({ source, destination: relative, bytes: before.length, sha256: hash(before), copyExact: true });
}
report.finished = new Date().toISOString();
await writeFile(path.join(staging, 'STAGING-COPY-MANIFEST.json'), JSON.stringify(report, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify({ staging, mappings: report.mappings.map(({source, destination, files, bytes}) => ({source, destination, files, bytes})), singles: report.singles.length, allCopiesExact: true }, null, 2));
