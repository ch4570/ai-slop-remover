# Baseline image inspection

The following actual viewport PNGs from the frozen v2 baseline run were opened with the image-view tool. The source images were not edited or converted to full-page captures.

- `baseline/master-1280x900-100-initial.png`: Wide initial master page shows all five columns and all three rows, with the original brand header and spacing.
- `baseline/master-390x844-100-tab-first.png`: The first row's focused button and orange outer outline visibly extend beyond the table's right inner edge; the right edge is clipped. The horizontal scrollbar remains local to the table.
- `baseline/compare-390x844-100-tab-first.png`: Comparison's first focused row has the same right-edge clipping, with its denser row spacing retained.
- `baseline/master-320x864-200-enter-third.png`: At synthetic 200% text, selection status reads `M-103 주문을 선택했습니다.` over wrapped lines, while the focused third button and outline remain clipped on the right. A document vertical scrollbar and separate table horizontal scrollbar are visible.
- `baseline/master-320x864-200-user-horizontal-wheel.png`: After user wheel input, earlier product/amount columns remain visible and the focused action column has moved offscreen. This image illustrates permitted deliberate user scrolling; the trusted input and delayed stability measurements, not this still image alone, establish the scroll outcome.
- `baseline/master-focused-resize-transition-2.png`: After the fixed 320×864 → 320×800 → 390×844 → 320×864 sequence at 150% text, the third row remains selected and focused, but most of its button is beyond the right clipping edge.
- `baseline/master-focused-font-transition-1.png`: After text changes from 100% through 150% to 200% while the third row stays selected/focused, the action column is entirely offscreen; the screenshot shows long customer names while the `M-103` status remains intact.
- `baseline/compare-1280x900-100-initial.png`: Wide comparison retains all rows and columns with the existing denser spacing; the 8px vertical density exception remains visibly local to comparison.
- `baseline/compare-focused-font-transition-1.png`: Comparison likewise leaves the focused action column entirely offscreen after the focused text-size increase, while the third-row selection status remains visible and wraps.

Only explicitly listed images are claimed as visually inspected. Programmatic geometry covers the broader frozen matrix; this is not an overall accessibility certification.
