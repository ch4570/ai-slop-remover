# Independent frozen focus observer, v2

Final frozen observer SHA256: `545788c49b4e4380520163bb46e50a0dce1b82574ea4bc045786cda5ec99d253`.
Frozen specification SHA256: `9252a96e6e78c2b80a35df01aed77aa7d03778cf76e5e74aab822d219ae80d00`.
Unmodified copied harness SHA256: `5538f93787bf84a401eba4ce747264ddd6bfc6e5e31049e4004a8986ad85a1e1`.

Usage: `node observer.mjs PRODUCT_ROOT NEW_OUTPUT [HARNESS_PATH] [PROTECTED_INPUT_ROOT]`.

Use existing Node 22+ and installed Chrome. `NEW_OUTPUT` must be a fresh path outside the product. Keep the script, frozen specification, copied harness, and completed `baseline/browser.json` together when relocating this observer. `PROTECTED_INPUT_ROOT` can point to an extracted trial root containing the original TASK, baseline, and harness; it changes only the source of the fixed protected-file hash checks and is recorded in the result. A custom harness must match the frozen input's bytes.

The 24 static cases cover both routes, all four requested viewport sizes, and synthetic 100/150/200% CSS text size. Enlarged static cases contain fixed long Korean customer names. Four further route/mode cases cover focused viewport transitions and focused font changes while retaining the selected third row. Exact scenarios, timing, text preparation and criteria are in `frozen-spec.json`. This is synthetic text preparation, not OS or page zoom.

All focus assertions are made before user-scroll preparation. Wheel scenarios use moved-pointer trusted horizontal wheel events in both directions only after automatic-focus checkpoints. Actual scroll measurements, trusted events and stable-document-Y outcomes distinguish input delivery errors from product behavior. Evidence uses viewport PNGs and captures measurements before and after each image.

`browser.json` separates required outcome failures, evidence collector errors, and documentation review flags. A change to the existing DESIGN density-rationale wording is only a manual review flag: TASK requires preserving its meaning, not exact wording. Baseline and candidate must run the same source and fixed criteria.

## Preserved earlier attempts

The original observer source SHA256 `425b755e82d80138b0f1fd8ba9c1b66bb04446882e9938da716ffac2107b8e96` is preserved at `/tmp/lutriva-focus-observer-S07pGL/observer-v1.mjs`; its output is in `baseline-v1-collector-target-error/` beside that file. It stopped before product observations because it rejected every auxiliary Chrome target. The raw target type/URL metadata is preserved; no provenance claim about those auxiliary targets is made here.

The target-only corrected source SHA256 `fdba674d6c9830e92d6fad1ec0e9bb335898e645552d0a74918cf3781cd636da` is preserved at `/tmp/lutriva-focus-observer-S07pGL/observer.mjs`, with its run in `baseline/`. That run completed all cases but treated four wheel-position preconditions as collector errors. It is a legacy run, not the final baseline comparison.

Before the author started and before candidate access, the parent approved this new-directory v2: page target guards verify the original two page identities/count and local page URLs while recording unverified auxiliaries; DESIGN exact wording becomes review-only; actual right-wheel preparation makes left-wheel tests meaningful even when baseline automatic focus leaves the table at zero horizontal offset. No automatic-focus failure is erased by later preparation. Prior sources/specification/results remain preserved. No full accessibility certification, beauty score, or profile/network isolation claim is made.
