# Frozen v2 baseline result

Command: `node /tmp/lutriva-focus-observer-v2-y5Qemd/observer.mjs /tmp/lutriva-focus-followup-mvK1r3/baseline /tmp/lutriva-focus-observer-v2-y5Qemd/baseline`

Exit 1 represents observed required-outcome failures. All 28 bounded cases completed. There are 256 automatic-focus checkpoints and 20 actual viewport PNGs. The 82 raw failures are all `full-focused-button-and-outline-visible`: 73 checkpoint failures plus 9 repeated checks after captures, across 11 cases. No evidence collector errors or runtime exceptions occurred. Label/order/status, real Enter/Space selection, preserved styling constraints and local/document overflow checks produced no failures.

Both-direction trusted horizontal wheel checks completed in all 26 cases with horizontal overflow. The two initial wide 100% cases have no horizontal overflow and were explicitly recorded as inapplicable. User scrolling, retained active row and stable document Y produced no failures. Automatic-focus failures were measured before any wheel preparation and remain recorded.

Representative geometry, in CSS px:

- Master 390×844 at 100%, first Tab: expanded focus right `395.703125`, allowed right `373`, table scrollLeft `0`.
- Master 320×864 at synthetic 200%, third-row Enter: expanded right `295.625`, allowed right `288`, scrollLeft `927`.
- Master focused resize, final return to 320×864 at 150%: expanded right `365.53125`, allowed right `303`, scrollLeft `590`.
- Master focused text change to 200%: expanded right `825.625`, allowed right `288`, scrollLeft `397`; the action is entirely beyond the visible table region.

Chrome before and after was `Chrome/152.0.7977.83`, revision `@79460ebecaa5625e57a5fb679a735659e73dc687`; complete Browser.getVersion values match. Every scoped page target guard passed. Auxiliary targets are recorded with unverified provenance. Product bytes and all nine protected TASK/harness/baseline file manifest entries match before/after and the frozen manifest. Source/hash: `observer.mjs`, SHA256 `545788c49b4e4380520163bb46e50a0dce1b82574ea4bc045786cda5ec99d253`. Specification SHA256 `9252a96e6e78c2b80a35df01aed77aa7d03778cf76e5e74aab822d219ae80d00`.

Nine representative actual images were opened; the exact inspected files and observations are in `baseline-image-inspection.md`. Full measurements, trusted-event logs, capture measurements, input bytes/hashes, target metadata and errors are in `baseline/browser.json`; summary is `baseline/summary.json`. Prior collector-error versions remain preserved as documented in README.

Candidate product was not read or executed. Awaiting explicit candidate-ready message before candidate inspection with this same frozen observer.
