import { readFile, writeFile, mkdir, readdir, realpath } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const sha = data => createHash('sha256').update(data).digest('hex');
const files = ['DESIGN.md', 'app.js', 'compare.css', 'compare.html', 'components.css', 'master.html', 'tokens.css'];
const routes = ['master.html', 'compare.html'];
const widths = [[1280, 900], [390, 844], [320, 800], [320, 864]];
const longNames = ['김민지 서울특별시 성북구 생활문화공동체 주문 담당자', '박도윤 제주특별자치도 서귀포시 공동구매 고객 담당자', '이서연 부산광역시 해운대구 지역문화협동조합 담당자'];
const shortNames = ['김민지', '박도윤', '이서연'];
const expectedOrders = ['M-101', 'M-102', 'M-103'];
const timing = { readinessPollMs: 50, readinessAttempts: 100, initialMs: 400, inputMs: 450, resizeMs: 650, fontMs: 650, pointerBeforeWheelMs: 120, wheelSamplesMs: [220, 650, 650], screenshotAfterMs: 50, geometryToleranceCssPx: 0.75 };
const cases = routes.flatMap(route => widths.flatMap(([width, height]) => [1, 1.5, 2].map(scale => ({ id: `${route.replace('.html', '')}-${width}x${height}-${scale * 100}`, route, width, height, scale, long: scale > 1 }))));
const sequence = [
  { key: 'Tab', target: 'M-101', label: 'tab-first' },
  { key: 'Enter', target: 'M-101', label: 'enter-first', select: true },
  { key: 'Tab', target: 'M-102', label: 'tab-second' },
  { key: 'Space', target: 'M-102', label: 'space-second', select: true },
  { key: 'Tab', target: 'M-103', label: 'tab-third' },
  { key: 'Enter', target: 'M-103', label: 'enter-third', select: true },
  { key: 'Tab', shift: true, target: 'M-102', label: 'shift-tab-second' },
  { key: 'Space', target: 'M-102', label: 'space-second-backward', select: true },
  { key: 'Tab', shift: true, target: 'M-101', label: 'shift-tab-first' },
  { key: 'Enter', target: 'M-101', label: 'enter-first-backward', select: true },
];
async function manifest(root, names) {
  const result = {};
  for (const name of names) {
    try { const bytes = await readFile(path.join(root, name)); result[name] = { bytes: bytes.length, sha256: sha(bytes) }; }
    catch (error) { result[name] = { error: error.code || error.message }; }
  }
  return result;
}
async function exists(file) { try { return await readFile(file, 'utf8'); } catch (e) { if (e.code === 'ENOENT') return null; throw e; } }
if (process.argv[2] === '--freeze') {
  const input = await realpath(process.argv[3]);
  const baseline = await manifest(path.join(input, 'baseline'), files);
  const harness = await readFile(path.join(input, 'harness/browser_harness.mjs'));
  const design = await readFile(path.join(input, 'baseline/DESIGN.md'), 'utf8');
  const spec = {
    frozenAt: new Date().toISOString(), input, baseline, protectedInput: await manifest(input, ['TASK.md', 'harness/browser_harness.mjs', ...files.map(f => `baseline/${f}`)]),
    unchanged: ['tokens.css', 'compare.css', 'master.html', 'compare.html'], allowedChanges: ['components.css', 'app.js', 'DESIGN.md'],
    designException: design.match(/<!-- comparison-exception:start -->[\s\S]*?<!-- comparison-exception:end -->/)[0],
    cases, sequence, timing, longNames,
    focusedResize: { start: [320, 864], scale: 1.5, long: true, target: 'M-103', transitions: [[320, 800], [390, 844], [320, 864]] },
    focusedFont: { start: [320, 864], scale: 1, long: true, target: 'M-103', transitions: [1.5, 2, 1] },
    zoomPreparation: 'Synthetic DOM-only CSS text scaling: body 16px × scale and h1 28px × scale. Buttons inherit body. Not OS zoom, page zoom, or device scaling. Long names replace only tbody customer-cell text in memory.',
    wheelPolicy: 'Only after all automatic-focus checkpoints, move pointer into table client area away from the focused button; wait 120ms; send trusted CDP right wheel to establish or retain positive offset, with 220/650/650ms observations and trusted-input checks. This user-input preparation cannot repair or overwrite earlier automatic-focus failures. Then move pointer again, wait 120ms, send trusted left wheel, and sample after 220ms, 650ms and another 650ms. Require trusted wheel targeted within table, actual horizontal movement when travel is available, no late return toward work column, same active row, stable document Y. No programmatic scrolling, recovery keys, or refocusing is used. Both directions run on each overflow case for baseline and candidate.',
    focusPolicy: 'Each required keyboard/selection/resize/font checkpoint requires same expected active row, focus-visible, full button border box plus computed outline width and positive offset inside intersection of table inner client box and viewport. 0.75 CSS px rounding tolerance. All checks occur after bounded stabilization without recovery keys or programmatic scrolling.',
    staticPolicy: 'Unchanged file bytes and no product files added/removed. HTML-derived labels, order values, links, role/status and selection results. Preserve design density rationale in meaning (any marked-block wording change is a manual-review flag, never an automatic failure), brand/font/button padding and minimum button dimensions, 16px master/8px comparison vertical cells, document versus local table overflow. Wide initial geometry compared to baseline measurements.',
    evidencePolicy: 'Viewport PNG only with captureBeyondViewport false; measure before/after and fail collector if capture changes geometry. Browser.getVersion before/after; guard exactly the two initial page target identities/count and only about:blank or scoped route URLs. Record all auxiliary targets without verifying their provenance. Runtime exceptions, trusted input logs, per-file bytes/hashes; required outcome failures separately from collector errors and documentation review flags. No beauty score, patch-syntax assertions, profile/network isolation claim, or accessibility certification.',
  };
  await writeFile(path.join(here, 'frozen-spec.json'), JSON.stringify(spec, null, 2) + '\n', { flag: 'wx' });
  await writeFile(path.join(here, 'browser_harness.mjs'), harness, { flag: 'wx' });
  console.log(JSON.stringify({ frozenSpec: path.join(here, 'frozen-spec.json'), observerSha256: sha(await readFile(fileURLToPath(import.meta.url))), specSha256: sha(await readFile(path.join(here, 'frozen-spec.json'))), harnessSha256: sha(harness), cases: cases.length }));
  process.exit(0);
}

if (!process.argv[2] || !process.argv[3]) throw new Error('Usage: node observer.mjs PRODUCT_ROOT NEW_OUTPUT [HARNESS_PATH] [PROTECTED_INPUT_ROOT]');
const root = await realpath(process.argv[2]);
const output = path.resolve(process.argv[3]);
if (output === root || output.startsWith(root + path.sep)) throw new Error('Evidence must be outside product root');
const specBytes = await readFile(path.join(here, 'frozen-spec.json'));
const spec = JSON.parse(specBytes);
const protectedInputRoot=await realpath(process.argv[5] || spec.input);
const harnessPath = process.argv[4] ? path.resolve(process.argv[4]) : path.join(here, 'browser_harness.mjs');
const harnessBytes = await readFile(harnessPath);
if (sha(harnessBytes) !== spec.protectedInput['harness/browser_harness.mjs'].sha256) throw new Error('Provided harness differs from frozen input');
const { claimBrowserEvidence, withBrowser } = await import(pathToFileURL(harnessPath));
await claimBrowserEvidence(output, []);
const referenceText = await exists(path.join(here, 'baseline/browser.json'));
const reference = referenceText ? JSON.parse(referenceText) : null;
const report = { schema: 2, startedAt: new Date().toISOString(), productRoot: root, output, protectedInputRoot, protectedInputRootOverride:!!process.argv[5], observer: { sha256: sha(await readFile(fileURLToPath(import.meta.url))), specSha256: sha(specBytes), harnessSha256: sha(harnessBytes) }, spec, inputBefore: await manifest(root, files), inputFileNames: await readdir(root), protectedBefore: await manifest(protectedInputRoot, Object.keys(spec.protectedInput)), requiredFailures: [], collectorErrors: [], reviewFlags: [], checkpoints: [], initials: [], wheel: [], captures: [], cases: [], guards: [], notes: [] };
const requireOutcome = (condition, name, context, detail) => { if (!condition) report.requiredFailures.push({ name, context, detail }); };
const collectorError = (name, context, detail) => report.collectorErrors.push({ name, context, detail });
const isBaseline = JSON.stringify(report.inputBefore) === JSON.stringify(spec.baseline);
if (!isBaseline && !reference) throw new Error('Run frozen baseline first into observer directory / baseline before examining candidate');
requireOutcome(JSON.stringify(report.inputFileNames.slice().sort()) === JSON.stringify(files.slice().sort()), 'product-file-set', 'static', report.inputFileNames);
for (const name of spec.unchanged) requireOutcome(JSON.stringify(report.inputBefore[name]) === JSON.stringify(spec.baseline[name]), 'protected-product-bytes', name, { expected: spec.baseline[name], actual: report.inputBefore[name] });
const design = await readFile(path.join(root, 'DESIGN.md'), 'utf8');
if(!design.includes(spec.designException)) report.reviewFlags.push({name:'comparison-density-rationale-wording-changed',context:'DESIGN.md',detail:'TASK permits DESIGN edits. Manually confirm the existing comparison-only density exception and its rationale remain in meaning; exact wording is not required.'});

const sampleExpression = `(() => {
 const rect = element => { const r = element.getBoundingClientRect(); return { x:r.x, y:r.y, left:r.left, top:r.top, right:r.right, bottom:r.bottom, width:r.width, height:r.height }; };
 const sc = document.querySelector('.table-scroll'), table = document.querySelector('table'), a = document.activeElement;
 const style = el => { const s=getComputedStyle(el); return Object.fromEntries(['fontFamily','fontSize','lineHeight','color','backgroundColor','paddingTop','paddingRight','paddingBottom','paddingLeft','borderTopWidth','borderRightWidth','borderBottomWidth','borderLeftWidth','borderTopColor','borderRadius','outlineStyle','outlineWidth','outlineColor','outlineOffset','overflowX','overflowY'].map(k=>[k,s[k]])); };
 const sr=rect(sc), client={left:sr.left+sc.clientLeft,top:sr.top+sc.clientTop,right:sr.left+sc.clientLeft+sc.clientWidth,bottom:sr.top+sc.clientTop+sc.clientHeight};
 const focus=a?.matches('[data-order]') ? { order:a.dataset.order, text:a.textContent, rect:rect(a), style:style(a), focusVisible:a.matches(':focus-visible') } : { tag:a?.tagName, text:a?.textContent?.slice(0,100), href:a?.getAttribute('href') };
 if (focus.rect) { const extra=parseFloat(focus.style.outlineWidth)+Math.max(0,parseFloat(focus.style.outlineOffset)); focus.expanded={left:focus.rect.left-extra,right:focus.rect.right+extra,top:focus.rect.top-extra,bottom:focus.rect.bottom+extra}; }
 return { viewport:{width:innerWidth,height:innerHeight,visualWidth:visualViewport.width,visualHeight:visualViewport.height}, document:{scrollX,scrollY,clientWidth:document.documentElement.clientWidth,scrollWidth:document.documentElement.scrollWidth,scrollHeight:document.documentElement.scrollHeight,bodyScrollWidth:document.body.scrollWidth}, scroller:{rect:sr,client,clientWidth:sc.clientWidth,clientHeight:sc.clientHeight,scrollWidth:sc.scrollWidth,scrollHeight:sc.scrollHeight,scrollLeft:sc.scrollLeft,scrollTop:sc.scrollTop,style:style(sc)}, focus, detail:{text:document.getElementById('detail').textContent,role:document.getElementById('detail').getAttribute('role'),rect:rect(document.getElementById('detail'))}, rows:[...table.tBodies[0].rows].map(r=>({cells:[...r.cells].map(c=>c.textContent),order:r.querySelector('button').dataset.order,button:rect(r.querySelector('button')),buttonStyle:style(r.querySelector('button')),cellStyles:[...r.cells].map(style)})), links:[...document.querySelectorAll('header a')].map(a=>({text:a.textContent,href:a.getAttribute('href')})), headers:[...table.tHead.rows[0].cells].map(c=>c.textContent), heading:document.querySelector('h1').textContent, bodyStyle:style(document.body), headerStyle:style(document.querySelector('header')), headingStyle:style(document.querySelector('h1')), geometry:Object.fromEntries(['header','main','h1','.table-scroll','table','#detail'].map(sel=>[sel,rect(document.querySelector(sel))])), events:window.__observerEvents?.slice() || [] };
})()`;
function close(a, b) { return Math.abs(a - b) <= timing.geometryToleranceCssPx; }
function validate(sample, context, options) {
 const { route, scale, long, expectedFocus, expectedStatus } = options;
 const names = long ? longNames : shortNames;
 requireOutcome(sample.detail.role === 'status', 'status-role', context, sample.detail);
 if (expectedStatus !== undefined) requireOutcome(sample.detail.text === expectedStatus, 'selection-status', context, { expected:expectedStatus, actual:sample.detail.text });
 requireOutcome(JSON.stringify(sample.headers) === JSON.stringify(['주문','고객','상품','금액','작업']), 'column-label-order', context, sample.headers);
 requireOutcome(JSON.stringify(sample.links) === JSON.stringify([{text:'모아 주문',href:'master.html'},{text:'비교',href:'compare.html'}]), 'navigation-labels-links', context, sample.links);
 const expectedCells = expectedOrders.map((order,i)=>[order,names[i],['머그','접시','잔'][i],['12,000원','18,000원','9,000원'][i],'상세 보기']);
 requireOutcome(JSON.stringify(sample.rows.map(r=>r.cells)) === JSON.stringify(expectedCells) && JSON.stringify(sample.rows.map(r=>r.order)) === JSON.stringify(expectedOrders), 'row-content-order-labels', context, sample.rows.map(r=>({cells:r.cells,order:r.order})));
 requireOutcome(sample.document.scrollWidth <= sample.document.clientWidth + 1 && sample.document.bodyScrollWidth <= sample.document.clientWidth + 1, 'no-document-horizontal-overflow', context, sample.document);
 requireOutcome(['auto','scroll'].includes(sample.scroller.style.overflowX), 'table-local-horizontal-scroll', context, sample.scroller);
 requireOutcome(!['hidden','clip'].includes(sample.bodyStyle.overflowY), 'document-vertical-scroll-preserved', context, sample.bodyStyle.overflowY);
 requireOutcome(sample.headerStyle.backgroundColor === 'rgb(35, 89, 66)' && sample.bodyStyle.color === 'rgb(25, 43, 35)' && sample.bodyStyle.backgroundColor === 'rgb(241, 244, 242)', 'brand-colors', context, {header:sample.headerStyle,body:sample.bodyStyle});
 requireOutcome(sample.bodyStyle.fontFamily === 'system-ui, sans-serif' && close(parseFloat(sample.bodyStyle.fontSize),16*scale) && close(parseFloat(sample.headingStyle.fontSize),28*scale), 'font-preserved', context, {body:sample.bodyStyle,heading:sample.headingStyle});
 for (const [i,row] of sample.rows.entries()) {
   const bs=row.buttonStyle;
   requireOutcome(bs.fontFamily === sample.bodyStyle.fontFamily && close(parseFloat(bs.fontSize),16*scale) && bs.paddingTop === '8px' && bs.paddingBottom === '8px' && bs.paddingLeft === '12px' && bs.paddingRight === '12px' && bs.borderTopWidth === '1px' && bs.color === 'rgb(35, 89, 66)' && bs.backgroundColor === 'rgb(255, 255, 255)', 'button-brand-font-hitarea-style', context+':'+i, bs);
   for (const cs of row.cellStyles) requireOutcome(cs.paddingTop === (route==='compare.html'?'8px':'16px') && cs.paddingBottom === (route==='compare.html'?'8px':'16px') && cs.paddingLeft==='12px' && cs.paddingRight==='12px', 'cell-density-preserved', context+':'+i, cs);
 }
 if (expectedFocus) {
   requireOutcome(sample.focus.order === expectedFocus, 'active-row', context, {expected:expectedFocus,actual:sample.focus});
   if (sample.focus.order) {
     const f=sample.focus, s=f.style, e=f.expanded, c=sample.scroller.client, t=timing.geometryToleranceCssPx;
     requireOutcome(f.focusVisible && s.outlineStyle==='solid' && s.outlineWidth==='3px' && s.outlineColor==='rgb(163, 72, 27)' && s.outlineOffset==='2px', 'existing-focus-outline-preserved', context, f);
     const bounds={left:Math.max(0,c.left),right:Math.min(sample.viewport.width,c.right),top:Math.max(0,c.top),bottom:Math.min(sample.viewport.height,c.bottom)};
     requireOutcome(e.left>=bounds.left-t && e.right<=bounds.right+t && e.top>=bounds.top-t && e.bottom<=bounds.bottom+t, 'full-focused-button-and-outline-visible', context, {order:f.order,button:f.rect,expanded:e,bounds,scroller:sample.scroller,document:sample.document});
   }
 }
}
const captureStable = sample => ({ viewport:sample.viewport,document:sample.document,scroller:{rect:sample.scroller.rect,client:sample.scroller.client,scrollLeft:sample.scroller.scrollLeft,scrollTop:sample.scroller.scrollTop},focus:sample.focus,detail:sample.detail });
try {
 await withBrowser(root, output, async ({ origin, page, evaluate, call, screenshot, pause, exceptions, pressKey }) => {
   report.browserBefore = await call('Browser.getVersion');
   const initialTargets=(await call('Target.getTargets')).targetInfos;
   const pageTargetIds=initialTargets.filter(t=>t.type==='page').map(t=>t.targetId).sort();
   report.initialTargets=initialTargets;
   if(pageTargetIds.length!==2)throw new Error('Harness expected two fresh page targets');
   async function guard(context) {
     const {targetInfos}=await call('Target.getTargets');
     const targets=targetInfos.map(t=>({type:t.type,url:t.url,targetId:t.targetId}));
     const pages=targets.filter(t=>t.type==='page');
     const allowed=JSON.stringify(pages.map(t=>t.targetId).sort())===JSON.stringify(pageTargetIds) && pages.every(t=>t.url==='about:blank'||routes.some(r=>t.url===origin+'/'+r));
     report.guards.push({context,allowed,targets,auxiliaryProvenance:'Unverified; recorded only. Only page target identity/count/URLs are guarded.'});
     if(!allowed) throw new Error('Unexpected browser target: '+JSON.stringify(targets));
   }
   async function getSample() { return await evaluate(sampleExpression); }
   async function capture(name, options) {
     const before=await getSample();
     await screenshot(name+'.png',{captureBeyondViewport:false});
     await pause(timing.screenshotAfterMs);
     const after=await getSample();
     report.captures.push({file:name+'.png',before,after});
     if(JSON.stringify(captureStable(before))!==JSON.stringify(captureStable(after))) collectorError('screenshot-changed-measured-state',name,{before:captureStable(before),after:captureStable(after)});
     if(options) validate(after,name+':after-capture',options);
   }
   async function scaleText(scale) {
     await evaluate(`(() => { let s=document.getElementById('observer-text-preparation'); if(!s){s=document.createElement('style');s.id='observer-text-preparation';document.head.append(s);} s.textContent='body { font-size: ${16*scale}px; } h1 { font-size: ${28*scale}px; }'; })()`);
     await evaluate('document.fonts.ready.then(()=>true)');
   }
   async function load(c) {
     await page('Emulation.setDeviceMetricsOverride',{width:c.width,height:c.height,deviceScaleFactor:1,mobile:false});
     await page('Page.navigate',{url:origin+'/'+c.route});
     let ready=false;
     for(let i=0;i<timing.readinessAttempts;i++) {
       try { ready=await evaluate(`location.href===${JSON.stringify(origin+'/'+c.route)} && document.readyState==='complete' && document.querySelectorAll('[data-order]').length===3`); } catch {}
       if(ready)break; await pause(timing.readinessPollMs);
     }
     if(!ready)throw new Error('Page readiness did not complete');
     await evaluate(`(() => {window.__observerEvents=[]; for(const kind of ['keydown','keyup','focusin','click','wheel']) document.addEventListener(kind,e=>window.__observerEvents.push({kind,key:e.key,shift:e.shiftKey,order:e.target?.dataset?.order,tag:e.target?.tagName,href:e.target?.getAttribute?.('href'),trusted:e.isTrusted,deltaX:e.deltaX,deltaY:e.deltaY,inTable:!!e.target?.closest?.('.table-scroll'),at:performance.now()}),true); ${c.long?`[...document.querySelectorAll('tbody tr')].forEach((r,i)=>r.cells[1].textContent=${JSON.stringify(longNames)}[i]);`:''} })()`);
     await scaleText(c.scale);
     await pause(timing.initialMs);
     await guard(c.id+':loaded');
   }
   async function key(key,options={}) {
     const count=await evaluate('window.__observerEvents.length');
     await pressKey(key,options);
     await pause(timing.inputMs);
     const events=await evaluate(`window.__observerEvents.slice(${count})`);
     const text=key==='Space'?' ':key;
     if(!events.some(e=>e.kind==='keydown'&&e.key===text&&e.trusted&&!!e.shift===!!options.shift) || !events.some(e=>e.kind==='keyup'&&e.key===text&&e.trusted)) collectorError('missing-trusted-key-events',key,{options,events});
   }
   async function checkpoint(context,options) { const sample=await getSample(); report.checkpoints.push({context,options,sample}); validate(sample,context,options); return sample; }
   async function focusFirst(c) {
     await key('Tab');
     let active=await evaluate('({tag:document.activeElement.tagName,href:document.activeElement.getAttribute("href")})');
     requireOutcome(active.tag==='A'&&active.href==='master.html','tab-navigation-first',c.id,active);
     await key('Tab');
     active=await evaluate('({tag:document.activeElement.tagName,href:document.activeElement.getAttribute("href")})');
     requireOutcome(active.tag==='A'&&active.href==='compare.html','tab-navigation-second',c.id,active);
   }
   async function wheel(c) {
     let before=await getSample(); const automaticFocusState=before, max=before.scroller.scrollWidth-before.scroller.clientWidth;
     if(max<2) { report.wheel.push({context:c.id,skipped:'Table has no horizontal overflow',before}); return; }
     const cl=before.scroller.client;
     const left=Math.max(cl.left,0),right=Math.min(cl.right,before.viewport.width),top=Math.max(cl.top,0),bottom=Math.min(cl.bottom,before.viewport.height);
     const x=Math.min(right-10,left+30),y=top+Math.min(30,(bottom-top)/2);
     const hit=await evaluate(`(() => {const e=document.elementFromPoint(${x},${y});return {tag:e?.tagName,inTable:!!e?.closest('.table-scroll'),order:e?.dataset?.order};})()`);
     if(!hit.inTable||hit.order) { collectorError('wheel-pointer-target-precondition',c.id,{x,y,hit,before}); return; }
     await page('Input.dispatchMouseEvent',{type:'mouseMoved',x,y,buttons:0});
     await pause(timing.pointerBeforeWheelMs);
     const preparationEventCount=await evaluate('window.__observerEvents.length');
     const preparationDeltaX=Math.min(240,Math.max(60,max/2));
     await page('Input.dispatchMouseEvent',{type:'mouseWheel',x,y,deltaX:preparationDeltaX,deltaY:0});
     const preparationSamples=[];
     for(const ms of timing.wheelSamplesMs){await pause(ms);preparationSamples.push(await getSample());}
     const preparationEvents=await evaluate(`window.__observerEvents.slice(${preparationEventCount})`);
     const preparation={before:automaticFocusState,pointer:{x,y,hit},deltaX:preparationDeltaX,events:preparationEvents,samples:preparationSamples};
     if(!preparationEvents.some(e=>e.kind==='wheel'&&e.trusted&&e.inTable&&e.deltaX>0&&e.deltaY===0)){collectorError('right-wheel-input-not-delivered-to-table',c.id,preparation);report.wheel.push({context:c.id,preparation});return;}
     if(max-automaticFocusState.scroller.scrollLeft>10)requireOutcome(preparationSamples[0].scroller.scrollLeft>automaticFocusState.scroller.scrollLeft+10,'user-right-wheel-moves-later-columns',c.id,preparation);
     requireOutcome(preparationSamples.every(s=>s.focus.order===automaticFocusState.focus.order),'right-wheel-preserves-focused-row',c.id,preparation);
     requireOutcome(preparationSamples.every(s=>close(s.document.scrollY,automaticFocusState.document.scrollY)),'right-horizontal-wheel-does-not-pull-document-y',c.id,preparation);
     before=preparationSamples.at(-1);
     if(before.scroller.scrollLeft<10){requireOutcome(false,'user-wheel-cannot-retain-positive-horizontal-position',c.id,preparation);report.wheel.push({context:c.id,preparation,leftWheelNotExercised:'Trusted right wheel did not leave earlier-column travel; product outcome, not collector error.'});return;}
     await page('Input.dispatchMouseEvent',{type:'mouseMoved',x,y,buttons:0});
     await pause(timing.pointerBeforeWheelMs);
     const eventCount=await evaluate('window.__observerEvents.length');
     const deltaX=-Math.min(240,Math.max(60,before.scroller.scrollLeft/2));
     await page('Input.dispatchMouseEvent',{type:'mouseWheel',x,y,deltaX,deltaY:0});
     const samples=[];
     for(const ms of timing.wheelSamplesMs){await pause(ms);samples.push(await getSample());}
     const events=await evaluate(`window.__observerEvents.slice(${eventCount})`);
     const entry={context:c.id,automaticFocusState,preparation,before,pointer:{x,y,hit},deltaX,events,samples}; report.wheel.push(entry);
     if(!events.some(e=>e.kind==='wheel'&&e.trusted&&e.inTable&&e.deltaX<0&&e.deltaY===0)) { collectorError('wheel-input-not-delivered-to-table',c.id,entry);return; }
     const first=samples[0],last=samples.at(-1);
     requireOutcome(first.scroller.scrollLeft<before.scroller.scrollLeft-10,'user-wheel-moves-earlier-columns',c.id,entry);
     requireOutcome(last.scroller.scrollLeft<=first.scroller.scrollLeft+2&&last.scroller.scrollLeft<before.scroller.scrollLeft-10,'user-wheel-does-not-snap-back',c.id,entry);
     requireOutcome(samples.every(s=>s.focus.order===before.focus.order),'wheel-preserves-focused-row',c.id,entry);
     requireOutcome(samples.every(s=>close(s.document.scrollY,before.document.scrollY)),'horizontal-wheel-does-not-pull-document-y',c.id,entry);
     if(c.width===320&&c.height===864&&c.scale===2) await capture(c.id+'-user-horizontal-wheel');
   }
   for(const c of cases) {
     const start=Date.now();
     try {
       await load(c);
       const initial=await getSample(); report.initials.push({context:c.id,case:c,sample:initial}); validate(initial,c.id+':initial',{...c,expectedStatus:'주문을 선택해 주세요.'});
       const prior=reference?.initials.find(i=>i.context===c.id)?.sample;
       if(prior) {
         for(let i=0;i<3;i++) requireOutcome(initial.rows[i].button.width>=prior.rows[i].button.width-0.75&&initial.rows[i].button.height>=prior.rows[i].button.height-0.75,'button-hitarea-not-reduced',c.id+':'+i,{baseline:prior.rows[i].button,candidate:initial.rows[i].button});
         if(c.width===1280&&c.scale===1) for(const [selector,box] of Object.entries(prior.geometry)) for(const field of ['x','y','width','height']) requireOutcome(close(initial.geometry[selector][field],box[field]),'wide-initial-layout-preserved',c.id+':'+selector+':'+field,{baseline:box,candidate:initial.geometry[selector]});
       }
       if(c.width===1280&&c.scale===1) await capture(c.id+'-initial',{...c,expectedStatus:'주문을 선택해 주세요.'});
       await focusFirst(c);
       let status='주문을 선택해 주세요.';
       for(const step of sequence) {
         await key(step.key,step.shift?{shift:true}:{});
         if(step.select)status=step.target+' 주문을 선택했습니다.';
         const options={...c,expectedFocus:step.target,expectedStatus:status};
         await checkpoint(c.id+':'+step.label,options);
         if((c.width===390&&c.scale===1&&step.label==='tab-first')||(c.width===320&&c.height===864&&c.scale===2&&step.label==='enter-third')) await capture(c.id+'-'+step.label,options);
       }
       await wheel(c);
       report.cases.push({id:c.id,completed:true,elapsedMs:Date.now()-start});
     } catch(error){collectorError('case-exception',c.id,{message:error.message,stack:error.stack});report.cases.push({id:c.id,completed:false,elapsedMs:Date.now()-start});}
     console.log(JSON.stringify({case:c.id,requiredFailures:report.requiredFailures.length,collectorErrors:report.collectorErrors.length}));
   }
   for(const route of routes) for(const mode of ['resize','font']) {
     const c={id:`${route.replace('.html','')}-focused-${mode}`,route,width:320,height:864,scale:mode==='resize'?1.5:1,long:true};
     try {
       await load(c);await focusFirst(c);
       for(let i=0;i<3;i++)await key('Tab');
       await key('Enter');
       let options={...c,expectedFocus:'M-103',expectedStatus:'M-103 주문을 선택했습니다.'};
       await checkpoint(c.id+':start',options);
       const transitions=mode==='resize'?spec.focusedResize.transitions:spec.focusedFont.transitions;
       for(const [index,transition] of transitions.entries()) {
         if(mode==='resize'){await page('Emulation.setDeviceMetricsOverride',{width:transition[0],height:transition[1],deviceScaleFactor:1,mobile:false});options={...options,width:transition[0],height:transition[1]};await pause(timing.resizeMs);}
         else{await scaleText(transition);options={...options,scale:transition};await pause(timing.fontMs);}
         await checkpoint(c.id+':transition-'+index,options);
         await capture(c.id+'-transition-'+index,options);
       }
       await wheel({...options,id:c.id+':wheel-after-transition'});
       report.cases.push({id:c.id,completed:true});
     } catch(error){collectorError('dynamic-case-exception',c.id,{message:error.message,stack:error.stack});report.cases.push({id:c.id,completed:false});}
     console.log(JSON.stringify({case:c.id,requiredFailures:report.requiredFailures.length,collectorErrors:report.collectorErrors.length}));
   }
   await guard('final');
   report.browserAfter=await call('Browser.getVersion');
   report.runtimeExceptions=exceptions;
   requireOutcome(exceptions.length===0,'no-runtime-exceptions','browser',exceptions);
   if(JSON.stringify(report.browserBefore)!==JSON.stringify(report.browserAfter))collectorError('browser-version-changed','browser',{before:report.browserBefore,after:report.browserAfter});
 });
} catch(error) { collectorError('browser-collection-exception','browser',{message:error.message,stack:error.stack}); }
report.inputAfter=await manifest(root,files);
report.protectedAfter=await manifest(protectedInputRoot,Object.keys(spec.protectedInput));
if(JSON.stringify(report.inputBefore)!==JSON.stringify(report.inputAfter))collectorError('product-mutated-during-observation','manifest',{before:report.inputBefore,after:report.inputAfter});
if(JSON.stringify(report.protectedBefore)!==JSON.stringify(spec.protectedInput)||JSON.stringify(report.protectedAfter)!==JSON.stringify(spec.protectedInput))collectorError('protected-input-mutated','manifest',{expected:spec.protectedInput,before:report.protectedBefore,after:report.protectedAfter});
report.finishedAt=new Date().toISOString();
report.summary={baseline:isBaseline,completedCases:report.cases.filter(c=>c.completed).length,totalCases:cases.length+4,requiredFailures:report.requiredFailures.length,collectorErrors:report.collectorErrors.length,captures:report.captures.length,checkpoints:report.checkpoints.length,failureCounts:Object.fromEntries([...new Set(report.requiredFailures.map(f=>f.name))].map(n=>[n,report.requiredFailures.filter(f=>f.name===n).length]))};
await writeFile(path.join(output,'browser.json'),JSON.stringify(report,null,2)+'\n',{flag:'wx'});
await writeFile(path.join(output,'summary.json'),JSON.stringify(report.summary,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify(report.summary));
process.exitCode=report.collectorErrors.length?2:report.requiredFailures.length?1:0;
