# Candidate image inspection

Actual PNGs listed here were opened with the image-view tool. They are unchanged viewport captures from the frozen v2 run, with before/after geometry in `browser.json`. Baseline images were inspected before candidate access; this record is independent of author reports.

- `master-1280x900-100-initial.png`: All five columns and three rows remain visible in the wide initial view, with original header, spacing and button dimensions.
- `master-390x844-100-tab-first.png`: The first button's full outline is now visible inside the right table edge. The table has moved horizontally enough to expose the action; its local scrollbar remains present.
- `compare-390x844-100-tab-first.png`: Comparison's first focus likewise has a complete outline inside the table edge, with denser rows retained.
- `master-320x864-200-enter-third.png`: The third button, complete orange outline and `M-103` selection status are visible at synthetic 200% text. Document vertical and table horizontal scrollbars both remain present.
- `master-320x864-200-user-horizontal-wheel.png`: Deliberate horizontal wheel scrolling leaves the product/amount columns in view and the action column offscreen. This is permitted user-directed positioning; event logs and delayed measurements establish stability beyond the still image.
- `master-focused-resize-transition-2.png`: After the full prescribed size transition back to 320×864 at 150% text, the third button and its complete outline remain visible; the selected row stays M-103.
- `master-focused-font-transition-1.png`: The third button and full outline remain visible after increasing text to 200% while focused, and the M-103 status is intact. Baseline had left this action entirely offscreen.
- `compare-1280x900-100-initial.png`: Wide initial comparison retains all columns, three rows and the existing denser spacing.
- `compare-focused-font-transition-1.png`: After focused text changes to 200%, comparison keeps the third action's entire outline within the table while preserving the M-103 status. Baseline had left the action column entirely offscreen.

Only listed images are claimed as visually inspected. Synthetic 150/200% preparation scales body and heading CSS text sizes; it is not OS zoom or page zoom. This is a bounded regression observation, not a beauty rating or full accessibility certification.
