# Independent paired focus regression result

The candidate passes the unchanged preregistered v2 observer. Baseline and candidate each completed 28 cases and 256 automatic-focus checkpoints. No candidate retry, product edit, observer edit or criterion change occurred after candidate access.

| Recorded outcome | Baseline | Candidate |
| --- | ---: | ---: |
| Automatic-focus checkpoint failures | 73 | 0 |
| Additional failure records repeated after captures | 9 | 0 |
| Total required failure records | 82 | 0 |
| Other functional/static failure records | 0 | 0 |
| Evidence collector errors | 0 | 0 |
| Runtime exceptions | 0 | 0 |
| Manual-review flags | 0 | 0 |

The 73 baseline checkpoint failures span 11 cases. They all concern the full button plus computed outline/offset inside the table's inner client clipping boundaries and viewport. The candidate clears these failures across real forward/back Tab traversal, Enter/Space selection, focused viewport changes and focused synthetic text-size changes without recovery input. Row IDs/order/values/labels, status role and row-specific selection results remain intact.

Both-direction trusted horizontal wheel checks pass in all 26 cases with horizontal table overflow; the two wide 100% initial cases have no horizontal overflow and are explicitly inapplicable. Pointer movement and bounded settling precede each wheel input. Automatic-focus checks are recorded before user-scroll preparation. Deliberate user scrolling retains the active row and document Y, and does not snap back during the fixed 220ms + 650ms + 650ms observation interval.

Representative expanded focus right edge / permitted right edge, CSS px:

| Checkpoint | Baseline | Candidate |
| --- | --- | --- |
| Master 390×844, 100%, first Tab | 395.703125 / 373 | 372.703125 / 373 |
| Master 320×864, 200%, third-row Enter | 295.625 / 288 | 287.625 / 288 |
| Master focused resize, return to 320×864 | 365.53125 / 303 | 302.53125 / 303 |
| Master focused font increase to 200% | 825.625 / 288 | 287.625 / 288 |
| Compare focused font increase to 200% | 825.625 / 303 | 302.625 / 303 |

The wide initial layout geometry is unchanged on both routes. Their actual 1280×900 viewport PNGs are also byte-identical to baseline: master SHA256 `28dfed4dfb985ffe788d038acf07b944edea8eccadfe33591511f4c435c97feb`, comparison `35756a7c7e3929abe4b5b6ed0b56da1559ee170b0d7f970e03a3a5abb002bf5b`. Existing brand/font/outline/padding/hit-area checks pass; master retains 16px cell vertical padding and comparison retains its 8px exception. There is no document horizontal overflow, and table horizontal/document vertical scrolling remain available.

Only `app.js` and `DESIGN.md` differ from baseline. All seven candidate files remain stable before/after the run, and all nine protected TASK/harness/baseline manifest entries match the frozen values before and after. `tokens.css`, `compare.css`, both HTML files, and `components.css` retain their baseline bytes. Candidate `app.js`: 2260 bytes, SHA256 `cdfc0b50e4f6222503e65e56ef7864fefc5c1ba54df058c21fef75c80dcba007`; `DESIGN.md`: 2395 bytes, SHA256 `1954a8428429d0fbc50d35c8f2d3eef71a4a065ddedd480327872ecfaed9c512`.

DESIGN was read separately for meaning. It retains the comparison-only density exception and rationale, and adds the shared focus policy, code locations, natural-height condition and unverified browser/zoom/assistive-technology limits. Its statement of author verification was not used as test evidence. No author report or implementation source was used to guide acceptance.

The frozen observer SHA256 remains `545788c49b4e4380520163bb46e50a0dce1b82574ea4bc045786cda5ec99d253`; specification remains `9252a96e6e78c2b80a35df01aed77aa7d03778cf76e5e74aab822d219ae80d00`, verified before and after. Paired baseline `browser.json` remains `56845a16f29056e331bbac74af4bb85e6b8be3fd0870ef4cecabc7ce4b35244b`. Candidate `browser.json` SHA256 is `b00bbc64f014b42e43b074317c2ff77adb2e475a00a898c003f7667418e88412`. All scoped page target guards pass. Auxiliary targets are recorded with unverified provenance. Browser.getVersion is identical across baseline and candidate, before and after: `Chrome/152.0.7977.83`, revision `@79460ebecaa5625e57a5fb679a735659e73dc687`.

Both runs have 20 actual viewport PNGs with measurements before/after capture; no capture changed measured state. Nine representative candidate images were opened, matching the nine baseline inspection categories. Exact opened paths and observations are in `image-inspection.md`; full event/geometry/manifests are in `browser.json`, and the short machine summary is in `summary.json`.

Limits: this is the fixed four-viewport, three-text-size matrix and prescribed transitions in installed headless Chrome. Text enlargement is synthetic CSS body/heading scaling with fixed long Korean customer names, not OS zoom or page zoom. Other browsers, actual zoom modes, assistive technologies, arbitrary row counts, future fixed-height containers/overlays and behavior beyond bounded stabilization intervals were not tested. This result does not claim a beauty score or full accessibility certification.
