import { spawnSync } from 'node:child_process';
import { writeFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const output = path.dirname(fileURLToPath(import.meta.url));
const cwd = '/Users/rex/Desktop/personal/lutriva';
const commands = [
  ['npm-test', 'npm', ['test']],
  ['npm-check', 'npm', ['run', 'check']],
  ['npm-check-js', 'npm', ['run', 'check:js']],
  ['diff-check', 'git', ['diff', '--check']],
];
const results = [];
for (const [name, executable, args] of commands) {
  const start = new Date().toISOString();
  const result = spawnSync(executable, args, { cwd, encoding: 'utf8', maxBuffer: 8 * 1024 * 1024 });
  writeFileSync(path.join(output, name + '.stdout'), result.stdout ?? '', { flag: 'wx' });
  writeFileSync(path.join(output, name + '.stderr'), result.stderr ?? '', { flag: 'wx' });
  const row = { name, executable, args, cwd, started: start, finished: new Date().toISOString(), exit: result.status, signal: result.signal, error: result.error?.message ?? null };
  results.push(row);
  console.log(JSON.stringify(row));
}
writeFileSync(path.join(output, 'results.json'), JSON.stringify({ node: process.version, results }, null, 2) + '\n', { flag: 'wx' });
process.exitCode = results.every(result => result.exit === 0 && !result.error) ? 0 : 1;
