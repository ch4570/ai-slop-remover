for (const button of document.querySelectorAll('[data-order]')) button.addEventListener('click', () => {
  document.getElementById('detail').textContent = button.dataset.order + ' 주문을 선택했습니다.';
  scheduleOrderFocus();
});

let focusFrame = 0;

function scheduleOrderFocus() {
  if (focusFrame) return;
  focusFrame = requestAnimationFrame(() => {
    focusFrame = 0;
    revealOrderFocus();
  });
}

function revealOrderFocus() {
  const button = document.activeElement;
  if (!button?.matches('[data-order]')) return;
  const scroller = button.closest('.table-scroll');
  if (!scroller) return;

  // Include the existing outline and its offset without changing the hit area.
  const style = getComputedStyle(button);
  const margin = Math.max(0, parseFloat(style.outlineWidth) + parseFloat(style.outlineOffset));
  const viewport = document.documentElement;
  const bounds = scroller.getBoundingClientRect();
  const left = Math.max(0, bounds.left + scroller.clientLeft);
  const right = Math.min(viewport.clientWidth, bounds.left + scroller.clientLeft + scroller.clientWidth);
  let rect = button.getBoundingClientRect();

  if (rect.left - margin < left) {
    scroller.scrollLeft += rect.left - margin - left;
  } else if (rect.right + margin > right) {
    scroller.scrollLeft += rect.right + margin - right;
  }

  // The table keeps its natural height; move the document only at a clipped edge.
  rect = button.getBoundingClientRect();
  if (rect.top - margin < 0) {
    window.scrollBy(0, rect.top - margin);
  } else if (rect.bottom + margin > viewport.clientHeight) {
    window.scrollBy(0, rect.bottom + margin - viewport.clientHeight);
  }
}

document.addEventListener('focusin', event => {
  if (event.target.matches('[data-order]')) scheduleOrderFocus();
});
window.addEventListener('resize', scheduleOrderFocus);
window.visualViewport?.addEventListener('resize', scheduleOrderFocus);

// Layout changes (including text size and a newly needed document scrollbar)
// can clip an already focused button. Scrolling itself does not schedule work.
const orderLayout = new ResizeObserver(scheduleOrderFocus);
for (const element of document.querySelectorAll('.table-scroll, .table-scroll table')) {
  orderLayout.observe(element);
}
