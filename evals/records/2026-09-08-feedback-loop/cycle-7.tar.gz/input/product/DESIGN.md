# 모아 주문 화면 기준

브랜드 초록은 탐색과 행동에 사용한다. 흰 표면, 8px 모서리, 공통 16px 셀 위아래 간격을 기본으로 한다. master.html은 이 기준 화면이다.
비교 화면도 브랜드 역할, 열 내용, 행의 상세 보기, 키보드 포커스를 유지한다. 작은 화면에서는 표 영역 안에서 가로로 스크롤할 수 있다.

두 화면의 행 버튼은 포커스 이동, 선택 상태 변경, 표 또는 viewport 크기 변경 후 전체 조작 영역과 기존 포커스 외곽선이 보이도록 자동 노출한다. 공통 구현은 app.js의 `scheduleOrderFocus`·`revealOrderFocus`와 표/스크롤 영역의 `ResizeObserver`이다. components.css의 기존 3px 외곽선과 2px offset을 계산에 포함해 표 내부 가로 스크롤을 필요한 거리만 보정하고, 버튼이 viewport의 위·아래 경계를 벗어날 때만 문서를 세로로 이동한다. 포커스와 선택 행은 유지하며, 스크롤 이벤트에는 보정을 연결하지 않아 사용자가 다른 열이나 문서 위치로 직접 이동한 결과를 유지한다. 현재 표는 자연 높이를 사용한다.

Chrome 152에서 두 화면의 1280×900, 390×844, 320×800, 320×864 CSS px, 임시 CSS 글자 크기 100%·150%·200%, 긴 한국어 고객명으로 Tab/Shift+Tab, Enter/Space, 포커스 유지 중 창·글자 크기 변경과 수동 스크롤을 확인했다. OS/페이지 줌, 다른 브라우저와 보조기술은 미검증이다. 표에 고정 높이 또는 새 겹침 요소를 도입하면 노출 경계도 다시 확인한다.

<!-- comparison-exception:start -->
같은 화면 높이에서 더 많은 주문 행을 비교할 수 있도록 compare.html의 비교 표에만 세로 간격 예외를 적용한다. compare.css의 `.comparison-table th, .comparison-table td`는 공통 16px 대신 아래 규칙을 사용한다.

```css
.comparison-table th, .comparison-table td { padding-block: 8px; }
```

master.html은 공통 16px 기준을 유지하며, 비교 화면의 브랜드·글꼴·행 버튼·포커스·표 내부 가로 스크롤은 기존 기준을 따른다. 셀 내용이나 행 작업이 늘어 가독성 또는 조작 공간이 부족해지면 이 예외를 재검토한다.
<!-- comparison-exception:end -->

새 예외를 다른 화면의 공통 토큰 변경으로 확대하지 않는다.
