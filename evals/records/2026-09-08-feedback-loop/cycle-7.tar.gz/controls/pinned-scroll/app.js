for (const button of document.querySelectorAll('[data-order]')) button.addEventListener('click', () => {
  document.getElementById('detail').textContent = button.dataset.order + ' 주문을 선택했습니다.';
});

// Deliberately wrong diagnostic control, not an intended product fix.
// Pinning on every frame can reveal focus but takes away horizontal browsing.
function pinFocusedTable() {
  const active = document.activeElement;
  const table = active?.matches('[data-order]:focus-visible') && active.closest('.table-scroll');
  if (table) table.scrollLeft = table.scrollWidth - table.clientWidth;
  requestAnimationFrame(pinFocusedTable);
}
requestAnimationFrame(pinFocusedTable);
