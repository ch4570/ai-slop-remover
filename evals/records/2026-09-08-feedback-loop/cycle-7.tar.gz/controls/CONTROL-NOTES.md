# Parent-side observer controls

These are deliberately defective copies of the same cycle7 dense baseline.
They are not proposed product implementations, author guidance or skill variants.
Both were prepared before the independent observer was finalized or any candidate
was read. The real author will not receive these directories or their code.

- no-outline changes only components.css by appending a rule that removes the
  visible outline and its offset. A fit predicate must not mistake a removed
  outline for a valid repair. The separate required focus-style invariant should fail.
- pinned-scroll changes only app.js by appending a requestAnimationFrame loop
  which, while a row button has focus-visible, always sets its table to maximum
  horizontal scroll. The manual user browsing invariant should fail. Any other
  remaining baseline failures are separately retained; this is not intended to
  make every other condition pass.

The original allowed product scope contains both files, so these controls test
observable quality/preservation rather than an obviously forbidden filename.
The dense compare.css, tokens, HTML and original order click handler are retained.
No controls have been executed at this note's creation. Browser processes will
use temporary owned profiles and local fixture servers only, with no installations.
