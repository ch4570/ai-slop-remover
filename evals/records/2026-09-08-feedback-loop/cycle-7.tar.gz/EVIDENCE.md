# Cycle 7 evidence map and replay

This record preserves a separately scoped automatic-focus product follow-up, not
a reinterpretation of the old density-only task or a skill-version A/B experiment.
Starting code/skill snapshot is537e33f. No common skill or repository runtime was
changed. Candidate implementation is in input/product/app.js and DESIGN.md;
all other83-path input entries retain starting bytes. The original input-start
inventory has83files/308896bytes; final input has83files/312159bytes. The allowed
2changed files explain this difference, not an input-integrity failure.

## Exact-copy sources

STAGING-COPY-MANIFEST.json records every mapped file and verifies source unchanged
and destination exact before/after copy. All regular files in each mapped root
are included; empty folders are not inventoried. No profile/cache contents or
prior cycle archive is included. Original reports and absolute metadata are not
rewritten to appear newly portable.

| Preserved path | Original path and purpose |
| --- | --- |
| input/ | /tmp/lutriva-focus-followup-mvK1r3; TASK, original PRIOR-REQUEST, baseline, final product,65skills and harness |
| input-start-frozen.json | /tmp/lutriva-focus-followup-mvK1r3-frozen.json; pre-author83paths |
| author/ | /tmp/lutriva-focus-work-yJaqbx; author own regression, original/corrected-input baseline, result, actual PNGs and reports |
| observer-legacy/ | /tmp/lutriva-focus-observer-S07pGL; first target-guard failure, target-only correction, full raw outputs and both scripts |
| observer/ | /tmp/lutriva-focus-observer-v2-y5Qemd; frozen final observer/spec/harness and complete paired baseline |
| candidate-observation/ | /tmp/lutriva-focus-candidate-8e7XUz; first candidate result and independent paired/image reports |
| controls/ | /tmp/lutriva-cycle7-controls-674Fnm; two deliberately defective baseline copies |
| controls-frozen.json | /tmp/lutriva-cycle7-controls-674Fnm-frozen.json;15pre-run control paths |
| control-observations/ | /tmp/lutriva-cycle7-observer-controls-iV9Zce; both complete control runs, commands, hashes and targeted predicate audit |
| parent/ | /tmp/lutriva-cycle7-parent-ytksPP; chronological plan, strict83-path scope checker/results and actual image notes |
| repository-checks/ | /tmp/lutriva-cycle7-repository-checks-WDuabM; npm20/check/check:js/diff-check logs and command metadata |
| tools/ | exact-copy stage/inventory scripts, original input freeze helper and read-only archive checker |

## Outcome scopes

The frozen final observer completed28cases/256automatic-focus checkpoints/20
viewport captures for each baseline/candidate/control. Baseline has73checkpoint
visibility failures and9capture-repeat failures,82raw entries across11cases.
Candidate has0required failures; both have0collector/runtime errors. They preserve
the remaining functional/style/static contracts. Both-direction trusted wheel
runs in26overflow cases;2wide100% cases are inapplicable. Deliberate offscreen
focus after user horizontal browsing is allowed, not an automatic-focus failure.

No-outline has272outline-preservation failures plus the same82baseline visibility
entries. Pinned-scroll has26earlier-column movement and26no-snap-back failures,
no automatic-focus failures. These specific negative controls are not candidate
implementations, additional user tasks or a general proof of evaluator coverage.
At the pinned representative case the first220ms sample is already back/still at
942; this cannot distinguish no motion from an earlier brief move and return.

Author own1251assertions/238states are separate: first baseline49focus failures
and1invalid vertical-input preparation; corrected-input baseline50focus failures;
candidate0failures. The first test-script revision was NOT preserved verbatim.
author/reconstructed-preparation-change.diff is expressly reconstructed, not an
executed original script. Original raw JSON/PNG were preserved. The corrected
script is the actual source used for the paired author runs. Its absolute harness
import and the offline comparison's absolute root are historical, not advertised
as portable entrypoints. Only2wide initial records/PNG claim complete equality;
238states match the listed preservation fields, not corrected scroll geometry.

Observer initial source425b755… failed before product observations with29collector
errors. Target-only sourcefdba674… completed28cases with4wheel-preparation errors.
Their original sources/raws are preserved. v2 target scope/actual right-wheel
preparation/manual DESIGN review/relocation changes were frozen before author
start. Earlier README auxiliary-target provenance is unverified, not adopted as
fact. Later input preparation never overwrites previous automatic-focus failures.

Final observer SHA256:
545788c49b4e4380520163bb46e50a0dce1b82574ea4bc045786cda5ec99d253.
Spec:9252a96e6e78c2b80a35df01aed77aa7d03778cf76e5e74aab822d219ae80d00.
Harness:5538f93787bf84a401eba4ce747264ddd6bfc6e5e31049e4004a8986ad85a1e1.
Baseline browser.json:56845a16f29056e331bbac74af4bb85e6b8be3fd0870ef4cecabc7ce4b35244b.
Candidate browser.json:b00bbc64f014b42e43b074317c2ff77adb2e475a00a898c003f7667418e88412.

Observer opened9baseline/9candidate actual images; controls runner1per control;
author13post-edit images; parent paths/counts are separate in parent/IMAGE-NOTES.md.
Do not add image views or capture repeats as independent behavioral tasks.

## Portable unchanged observer replay

Use installed Node22+ and Chrome, without installing/updating or connecting a user
profile. Run from a newly extracted record directory. Every output below must be
a new unused location outside input/product; replace examples if already used.
Keep observer.mjs, frozen-spec.json, browser_harness.mjs and baseline/browser.json
together. Do NOT re-freeze or edit the specification. The last argument changes
only where the fixed protected input hashes are read, not acceptance criteria.

```sh
node observer/observer.mjs input/baseline /tmp/lutriva-focus-baseline-new input/harness/browser_harness.mjs input
node observer/observer.mjs input/product /tmp/lutriva-focus-product-new input/harness/browser_harness.mjs input
```

Expected on recorded Chrome152.0.7977.83: original exit1 with82required visibility
entries, candidate exit0 with0required/collector errors. Exit alone is insufficient:
inspect summary, all28case completion,256checkpoints,20captures, failure families,
both-direction trusted wheel entries, version before/after, guards and manifests.
Different platform/font/browser outcomes must be recorded, not silently normalized.
The baseline reference remains read-only; new evidence goes only to new outputs.

Optional targeted-control replays use the same invocation with controls/no-outline
or controls/pinned-scroll as the first argument and distinct unused outputs. Both
are expected exit1 for their documented predicate families, with0collector errors.
parent/check-author-scope.mjs accepts INPUT_ROOT FROZEN_JSON NEW_REPORT and can
compare extracted input with input-start-frozen.json (only3permitted mutable files).
It is a byte/path scope checker, not a functional or DESIGN-meaning verdict.

The adjacent repository inventory and tar are verified without extraction using
tools/check_evidence_archive.py INVENTORY ARCHIVE. The inventory itself is outside
the archive to avoid self-reference. Hashes confirm bytes, not the truth of reports
or context independence. Any final post-archive independent replay/report lives
outside this already frozen tar and must be identified separately.

## Limits

Independent matrix uses body/h1 CSS enlargement and three spaced long Korean
names, not author's element-wise enlargement/same long name, OS zoom or page zoom.
Installed headless Chrome152.0.7977.83 is recorded before/after independent runs;
author own browser helper records start only. Temporary profiles and page-target
guards do not establish network/update isolation or auxiliary-target provenance.
No other browser, physical device, real OS/page zoom, IME, screenreader, arbitrary
row count, future fixed-height scroller/overlay, unbounded timing, full accessibility
certification or remote CI is claimed. Repository Python291/opt-in Chrome47 suites
were not rerun this cycle; npm20 and static checks are not those suites.
