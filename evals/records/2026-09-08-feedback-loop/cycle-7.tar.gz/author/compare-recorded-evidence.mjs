import { readFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import path from 'node:path';

// Read-only comparison of already recorded evidence; no browser is launched.
const root = '/tmp/lutriva-focus-work-yJaqbx';
const sha256 = bytes => createHash('sha256').update(bytes).digest('hex');
const baselinePath = path.join(root, 'baseline-corrected-input/browser.json');
const productPath = path.join(root, 'product-run-1/browser.json');
const baselineBytes = await readFile(baselinePath);
const productBytes = await readFile(productPath);
const baseline = JSON.parse(baselineBytes);
const product = JSON.parse(productBytes);
const baselineStates = new Map(baseline.states.map(state => [state.label, state]));
const productStates = new Map(product.states.map(state => [state.label, state]));
const missingFromProduct = [...baselineStates.keys()].filter(label => !productStates.has(label));
const missingFromBaseline = [...productStates.keys()].filter(label => !baselineStates.has(label));
const matchedLabels = [...baselineStates.keys()].filter(label => productStates.has(label));
const comparedFields = ['buttons', 'order', 'detail', 'detailRole', 'customers', 'viewport', 'font', 'outline'];
const fields = Object.fromEntries(comparedFields.map(field => {
  const mismatches = matchedLabels.filter(label => JSON.stringify(baselineStates.get(label)[field]) !== JSON.stringify(productStates.get(label)[field]));
  return [field, { matchedStates: matchedLabels.length - mismatches.length, mismatches }];
}));
const wideInitial = [];
for (const route of ['master', 'compare']) {
  const label = `${route}-1280x900-100-initial`;
  const baselinePNGPath = path.join(root, 'baseline-corrected-input', `${label}.png`);
  const productPNGPath = path.join(root, 'product-run-1', `${label}.png`);
  const baselinePNG = await readFile(baselinePNGPath);
  const productPNG = await readFile(productPNGPath);
  wideInitial.push({ label,
    recordedStateExactlyEqual: JSON.stringify(baselineStates.get(label)) === JSON.stringify(productStates.get(label)),
    pngBytesExactlyEqual: baselinePNG.equals(productPNG),
    baseline: { path: baselinePNGPath, bytes: baselinePNG.length, sha256: sha256(baselinePNG) },
    product: { path: productPNGPath, bytes: productPNG.length, sha256: sha256(productPNG) } });
}
const pass = missingFromProduct.length === 0 && missingFromBaseline.length === 0 &&
  baselineStates.size === baseline.states.length && productStates.size === product.states.length &&
  Object.values(fields).every(field => field.mismatches.length === 0) &&
  wideInitial.every(state => state.recordedStateExactlyEqual && state.pngBytesExactlyEqual);
console.log(JSON.stringify({
  method: 'Read-only Node comparison of existing recorded JSON and PNG bytes; no browser rerun or product mutation.',
  scope: '238 paired observations preserve the listed input, button and selection fields. Full state/geometry equality is asserted only for the two initial wide-screen records; focus and scroll geometry intentionally change elsewhere.',
  command: 'node /tmp/lutriva-focus-work-yJaqbx/compare-recorded-evidence.mjs',
  inputs: {
    baseline: { path: baselinePath, sha256: sha256(baselineBytes), states: baseline.states.length, uniqueLabels: baselineStates.size },
    product: { path: productPath, sha256: sha256(productBytes), states: product.states.length, uniqueLabels: productStates.size }
  },
  stateComparison: { matchedStates: matchedLabels.length, missingFromProduct, missingFromBaseline,
    buttonsFieldMeaning: 'Each recorded row button has order, text, width and height; this checks order, labels and measured hit-area dimensions.', fields },
  wideInitial, pass
}, null, 2));
process.exitCode = pass ? 0 : 1;
