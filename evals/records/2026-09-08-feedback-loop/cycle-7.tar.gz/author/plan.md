# Automatic order focus visibility

Scope: only product/components.css, product/app.js and product/DESIGN.md may change. The supplied baseline and all other input are read-only.

Observed source: the native button focus outline extends 5 CSS px beyond the button, inside a horizontally scrolling table. Selection changes the following status paragraph; there is no shared focus exposure logic.

Plan: first capture baseline keyboard reach, activation and focused resize/text-change failures with a regression script. Then use the smallest shared focus-exposure adjustment that preserves layout, content, button hit area, selection and the comparison-only 8px density exception. Re-run the same input conditions and inspect actual viewport screenshots. Verify that deliberate horizontal and document vertical scrolling remain possible without focus pulling the view back.

Text enlargement and long Korean names are temporary DOM preparation in the test, not OS or page zoom. Keyboard input uses the provided bounded pressKey. Browser viewport resizing uses actual CDP CSS viewport changes. No product data files are changed by test preparation.
