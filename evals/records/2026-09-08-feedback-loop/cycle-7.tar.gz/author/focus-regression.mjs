import { mkdir, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { withBrowser, claimBrowserEvidence } from '/tmp/lutriva-focus-followup-mvK1r3/harness/browser_harness.mjs';

const [fixture, output] = process.argv.slice(2);
if (!fixture || !output) throw new Error('Usage: node focus-regression.mjs fixture output');
await mkdir(output, { recursive: true });
await claimBrowserEvidence(output, []);
const report = { fixture, preparation: 'Emulation.setDeviceMetricsOverride sets CSS viewport, deviceScaleFactor 1, mobile false. Enlarged text uses temporary inline font sizes multiplied from initial computed font sizes for every element, not OS or page zoom. Long Korean customer names are temporary DOM test data. Keys are actual bounded CDP keyDown/keyUp pairs. Wheel scrolling is actual CDP mouseWheel input.', checks: [], states: [], images: [] };

const geometry = `(() => {
  const button = document.activeElement;
  const region = document.querySelector('.table-scroll');
  const rr = region.getBoundingClientRect();
  const b = button?.matches('[data-order]') ? button : null;
  const br = b?.getBoundingClientRect();
  const style = b && getComputedStyle(b);
  const outer = style ? parseFloat(style.outlineWidth) + parseFloat(style.outlineOffset) : 0;
  const rect = br && { left: br.left - outer, top: br.top - outer, right: br.right + outer, bottom: br.bottom + outer, width: br.width, height: br.height };
  const clip = { left: Math.max(0, rr.left + region.clientLeft), right: Math.min(innerWidth, rr.left + region.clientLeft + region.clientWidth), top: Math.max(0, rr.top + region.clientTop), bottom: Math.min(innerHeight, rr.top + region.clientTop + region.clientHeight) };
  return { order: b?.dataset.order || null, focusVisible: b?.matches(':focus-visible') || false,
    rect, clip, visible: !!rect && rect.left >= clip.left - .6 && rect.right <= clip.right + .6 && rect.top >= clip.top - .6 && rect.bottom <= clip.bottom + .6,
    viewport: [innerWidth, innerHeight], scroll: { x: scrollX, y: scrollY, tableX: region.scrollLeft, tableY: region.scrollTop, maximumX: region.scrollWidth - region.clientWidth },
    detail: document.getElementById('detail').textContent, detailRole: document.getElementById('detail').getAttribute('role'),
    font: { body: getComputedStyle(document.body).fontSize, button: style?.fontSize || null, heading: getComputedStyle(document.querySelector('h1')).fontSize },
    outline: style && { color: style.outlineColor, width: style.outlineWidth, offset: style.outlineOffset },
    layout: { table: { x: rr.x, y: rr.y, width: rr.width, height: rr.height }, bodyWidth: document.documentElement.scrollWidth, cellPadding: getComputedStyle(document.querySelector('td')).paddingBlock },
    customers: [...document.querySelectorAll('tbody tr')].map(row => row.cells[1].textContent),
    buttons: [...document.querySelectorAll('[data-order]')].map(button => ({ order: button.dataset.order, text: button.textContent, width: button.getBoundingClientRect().width, height: button.getBoundingClientRect().height })) };
})()`;

function check(name, pass, evidence) {
  report.checks.push({ name, pass: !!pass, ...(evidence === undefined ? {} : { evidence }) });
}

try {
  await withBrowser(fixture, output, async context => {
    const { page, call, evaluate, pressKey, screenshot, pause, origin, exceptions } = context;
    report.browser = await call('Browser.getVersion');
    let sequence = 0;
    const settle = async () => {
      await evaluate('new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve)))');
      await pause(90);
    };
    const resize = async (width, height) => {
      await page('Emulation.setDeviceMetricsOverride', { width, height, deviceScaleFactor: 1, mobile: false });
      await settle();
    };
    const prepareText = async (scale, longNames) => {
      await evaluate(`(() => {
        if (!window.originalFonts) window.originalFonts = [...document.querySelectorAll('*')].map(element => [element, parseFloat(getComputedStyle(element).fontSize)]);
        for (const [element, size] of window.originalFonts) element.style.fontSize = size * ${scale} + 'px';
        if (${longNames}) for (const row of document.querySelectorAll('tbody tr')) row.cells[1].textContent = '대한민국서울특별시마포구공동구매담당김민지';
      })()`);
      await settle();
    };
    const navigate = async (route, width, height, scale = 1, longNames = false) => {
      await resize(width, height);
      await page('Page.navigate', { url: `${origin}/${route}.html?case=${++sequence}` });
      for (let i = 0; i < 60; i++) {
        if (await evaluate(`document.readyState === 'complete' && !!document.querySelector('[data-order]') && location.search === '?case=${sequence}'`)) break;
        await pause(30);
      }
      await evaluate('document.fonts.ready');
      if (scale !== 1 || longNames) await prepareText(scale, longNames);
      await settle();
    };
    const state = async (label, expectedOrder, image = false, expectedDetail) => {
      await settle();
      const actual = await evaluate(geometry);
      report.states.push({ label, ...actual });
      if (expectedOrder) {
        check(label + ': current row', actual.order === expectedOrder, actual.order);
        check(label + ': full focus exposed', actual.visible && actual.focusVisible, { rect: actual.rect, clip: actual.clip, scroll: actual.scroll });
        check(label + ': original focus appearance', actual.outline?.width === '3px' && actual.outline?.offset === '2px' && actual.outline?.color === 'rgb(163, 72, 27)');
      }
      check(label + ': document has no horizontal overflow', actual.layout.bodyWidth <= actual.viewport[0]);
      check(label + ': original labels and status role', actual.detailRole === 'status' && actual.buttons.every((button, i) => button.order === `M-10${i + 1}` && button.text === '상세 보기'));
      if (expectedDetail) check(label + ': selection result', actual.detail === `${expectedDetail} 주문을 선택했습니다.`, actual.detail);
      if (image) {
        const name = label.replace(/[^a-zA-Z0-9.-]/g, '-') + '.png';
        await screenshot(name, { captureBeyondViewport: false });
        report.images.push(name);
      }
      return actual;
    };
    const firstButton = async () => {
      await pressKey('Tab'); await pressKey('Tab'); await pressKey('Tab');
    };
    for (const route of ['master', 'compare']) {
      for (const [width, height] of [[1280, 900], [390, 844], [320, 800], [320, 864]]) {
        for (const scale of [1, 1.5, 2]) {
          const label = `${route}-${width}x${height}-${scale * 100}`;
          await navigate(route, width, height, scale, scale > 1);
          const initial = await state(label + '-initial', null, scale === 1 && width === 1280);
          check(label + ': text preparation', initial.font.body === `${16 * scale}px` && initial.font.heading === `${28 * scale}px`, initial.font);
          check(label + ': cell density', initial.layout.cellPadding === (route === 'compare' ? '8px' : '16px'));
          await firstButton();
          await state(label + '-tab-first', 'M-101', scale === 1 && width !== 1280);
          await pressKey('Enter');
          await state(label + '-enter-first', 'M-101', false, 'M-101');
          await pressKey('Tab');
          await state(label + '-tab-second', 'M-102');
          await pressKey('Space');
          await state(label + '-space-second', 'M-102', width === 320 && height === 864 && scale > 1, 'M-102');
          await pressKey('Tab');
          await state(label + '-tab-third', 'M-103');
          await pressKey('Enter');
          await state(label + '-enter-third', 'M-103', false, 'M-103');
          await pressKey('Tab', { shift: true });
          await state(label + '-shift-second', 'M-102');
          await pressKey('Tab', { shift: true });
          await state(label + '-shift-first', 'M-101');
        }
      }
      await navigate(route, 390, 844, 2, true);
      await firstButton();
      await pressKey('Tab');
      await pressKey('Space');
      await state(`${route}-resize-start`, 'M-102', false, 'M-102');
      for (const [width, height] of [[320, 800], [320, 864], [390, 844]]) {
        await resize(width, height);
        await state(`${route}-resize-${width}x${height}`, 'M-102', width === 320 && height === 800, 'M-102');
      }
      await navigate(route, 320, 864);
      await firstButton();
      await pressKey('Tab');
      await pressKey('Enter');
      for (const scale of [1.5, 2, 1]) {
        await prepareText(scale, true);
        await state(`${route}-live-text-${scale * 100}`, 'M-102', scale === 2, 'M-102');
      }

      // An actual wheel scroll must remain where the user leaves it even with focus retained.
      await navigate(route, 320, 800, 2, true);
      await firstButton();
      await pressKey('Tab');
      await pressKey('Space');
      const beforeWheel = await state(`${route}-manual-before`, 'M-102');
      const point = await evaluate(`(() => { const r = document.querySelector('.table-scroll').getBoundingClientRect(); return { x: Math.min(innerWidth - 30, r.right - 30), y: Math.max(60, Math.min(innerHeight - 60, r.top + 80)) }; })()`);
      await page('Input.dispatchMouseEvent', { type: 'mouseWheel', ...point, deltaX: -180, deltaY: 0 });
      await pause(250);
      const wheelFirst = await evaluate(geometry);
      await pause(450);
      const wheelRest = await state(`${route}-manual-horizontal-settled`, null, true);
      check(`${route}: manual horizontal input moved table`, wheelFirst.scroll.tableX < beforeWheel.scroll.tableX - 20, { before: beforeWheel.scroll, after: wheelFirst.scroll });
      check(`${route}: manual horizontal position retained`, Math.abs(wheelRest.scroll.tableX - wheelFirst.scroll.tableX) < 1 && wheelRest.order === 'M-102');
      check(`${route}: manual horizontal input did not move document`, Math.abs(wheelRest.scroll.y - beforeWheel.scroll.y) < 1);
      await pressKey('Tab');
      const afterTab = await state(`${route}-tab-after-manual`, 'M-103');
      await page('Input.dispatchMouseEvent', { type: 'mouseWheel', x: 5, y: 400, deltaX: 0, deltaY: afterTab.scroll.y > 0 ? -260 : 260 });
      await pause(250);
      const verticalFirst = await evaluate(geometry);
      await pause(450);
      const verticalRest = await state(`${route}-manual-vertical-settled`, null);
      check(`${route}: manual vertical input moved document`, Math.abs(verticalFirst.scroll.y - afterTab.scroll.y) > 1, { before: afterTab.scroll, after: verticalFirst.scroll });
      check(`${route}: manual vertical position retained`, Math.abs(verticalRest.scroll.y - verticalFirst.scroll.y) < 1 && verticalRest.order === 'M-103');
    }
    report.exceptions = exceptions;
    check('no browser runtime exceptions', exceptions.length === 0, exceptions);
  });
} catch (error) {
  report.error = { message: error.message, stack: error.stack };
}
report.summary = { checks: report.checks.length, failed: report.checks.filter(check => !check.pass).length, states: report.states.length, images: report.images.length };
await writeFile(path.join(output, 'browser.json'), JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify({ output, browser: report.browser, summary: report.summary, error: report.error, failures: report.checks.filter(check => !check.pass).map(check => check.name) }, null, 2));
process.exitCode = report.error || report.summary.failed ? 1 : 0;
