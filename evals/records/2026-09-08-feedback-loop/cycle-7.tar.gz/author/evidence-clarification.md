# Evidence clarification

The first pre-correction focus-regression.mjs was not preserved verbatim as a file. I modified the single script in place to correct input preparation, and no original-script snapshot was created. The preserved baseline-run/browser.json and its screenshots remain the actual first-run artifacts; they do not preserve the entire original script source. There is therefore no original-script path or original-script file hash to provide.

The current corrected script is /tmp/lutriva-focus-work-yJaqbx/focus-regression.mjs. Its SHA-256 is 86b2d5a73ca33e8bccc9a02a32a7ead93a04db43eb16a5337642adee534dcf7f. This hash identifies the corrected script only.

reconstructed-preparation-change.diff documents the two preparation edits from the in-session patch: select the second row using Space before manual scrolling, then choose a vertical wheel direction that can move from the current document position. It is explicitly reconstructed documentation, not an original version or an executed original-script artifact. The first compare manual-vertical check had no document overflow; it was a preparation failure, not evidence of broken product scrolling.

recorded-evidence-comparison.json is produced by the read-only compare-recorded-evidence.mjs against baseline-corrected-input/browser.json, product-run-1/browser.json and the existing initial wide PNGs. The 238-state preservation claim applies to recorded button labels/order/hit-area dimensions and the additional explicitly listed invariant fields. Full state and geometry equality is claimed only for the two 1280×900 initial records, whose PNG bytes are also compared. Corrected focus/scroll geometry intentionally differs in other states.

The clarification only adds files in this existing external work directory. Product, the regression script, prior notes, all existing JSON and all existing screenshots remain unchanged. No browser was launched for this clarification.
