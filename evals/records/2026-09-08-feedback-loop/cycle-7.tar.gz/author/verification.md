# Scoped result

The shared focus correction is implemented in product/app.js and recorded in product/DESIGN.md. product/components.css did not need a change. No styles, fonts, button hit areas, markup, data, copy or density were changed. The comparison-only 8px spacing exception is preserved verbatim.

The correction includes the existing computed outline width and offset in horizontal and vertical visibility bounds. It schedules after focus, selection, viewport resize and table/scroll-container layout changes. It adjusts local horizontal scroll and only an actually clipped vertical viewport edge. It never refocuses a button and does not observe scroll events. Manual horizontal and document vertical wheel positions stay where the user leaves them; subsequent Tab reveals the next row normally.

## Commands and behavioral outcomes

All commands ran from /tmp/lutriva-focus-followup-mvK1r3 using installed Node v26.8.1 and Chrome/152.0.7977.83 via the supplied read-only harness.

1. `diff -qr baseline product` before edits: exit 0; product initially identical to baseline.
2. `node /tmp/lutriva-focus-work-yJaqbx/focus-regression.mjs /tmp/lutriva-focus-followup-mvK1r3/baseline /tmp/lutriva-focus-work-yJaqbx/baseline-run`: exit 1, 1,251 assertions across 238 observed states, 50 failures. Of these, 49 were full-focus failures. One manual-vertical-input assertion had invalid preparation: the compare document had no vertical overflow before a row was selected. The original JSON and all 18 original screenshots remain intact. The test was corrected to select the second row with Space before the manual scroll section and choose a direction that can move the document.
3. `node /tmp/lutriva-focus-work-yJaqbx/focus-regression.mjs /tmp/lutriva-focus-followup-mvK1r3/baseline /tmp/lutriva-focus-work-yJaqbx/baseline-corrected-input`: exit 1, 1,251 assertions, 50 valid focus-exposure failures; input movement assertions passed. This run includes one additional clipped selected state in the corrected manual-scroll preparation. Original evidence remains in its separate directory.
4. `node --check product/app.js && node /tmp/lutriva-focus-work-yJaqbx/focus-regression.mjs /tmp/lutriva-focus-followup-mvK1r3/product /tmp/lutriva-focus-work-yJaqbx/product-run-1`: exit 0, syntax check passed and 1,251/1,251 behavioral/geometry assertions passed across the same 238 states. There were no browser runtime exceptions.
5. A Node Buffer comparison against baseline confirmed tokens.css, compare.css, master.html, compare.html and components.css remained byte-identical. Both 1280×900 initial state/geometry records and PNGs were byte-identical to the baseline. Button text, order and hit-area dimensions matched in all 238 paired states.

The keyboard matrix covers both routes, all four requested viewport dimensions, 100%/150%/200% text, forward rows, reverse rows, Enter on first/third rows, Space on the second row, and the original row-specific status text/role. A selected second row is maintained through actual CSS viewport transitions 390×844 → 320×800 → 320×864 → 390×844 and live text changes 100% → 150% → 200% → 100%. Observations after each transition occur without another key or recovery scroll. Actual CDP mouseWheel inputs test independent horizontal comparison and document vertical scrolling; positions are checked after 250ms and again after 450ms. Tab after manual horizontal scrolling reveals the next row.

## Input preparation and limits

Viewport resizing uses CDP Emulation.setDeviceMetricsOverride with deviceScaleFactor 1 and mobile false. Text enlargement temporarily multiplies each element's initial computed font size using inline styles; body/button font sizes and heading sizes are checked. Enlarged cases temporarily replace all three customer names with 대한민국서울특별시마포구공동구매담당김민지. This is synthetic test preparation, not OS zoom, browser page zoom or real user data. Neither preparation changes product files. Normal keys use only the supplied bounded pressKey helper. Browser profile isolation does not guarantee network/update isolation.

OS/page zoom, other browsers, physical mobile devices, screen readers and complete accessibility conformance were not tested or claimed. The regression targets the current naturally sized three-row tables; fixed-height table scrollers or additional overlapping UI would need new boundary checks.

## Visual observations

All screenshots use captureBeyondViewport:false; no full-page capture was substituted for a viewport observation.

Before editing, these original images were actually opened: baseline-run/master-390x844-100-tab-first.png, compare-320x864-200-space-second.png, master-live-text-200.png and master-1280x900-100-initial.png. The first visibly clips the right button edge/ring; the live text image shows the still-focused action column entirely outside the local view. The 200% comparison example already passes in that particular baseline condition, which does not establish the other conditions.

After editing, these product-run-1 images were actually opened: master-390x844-100-tab-first.png, compare-390x844-100-tab-first.png, master-320x864-200-space-second.png, compare-resize-320x800.png, master-320x864-150-space-second.png, compare-320x864-150-space-second.png, master-320x800-100-tab-first.png, compare-320x864-100-tab-first.png, master-live-text-200.png, compare-live-text-200.png, master-1280x900-100-initial.png, compare-1280x900-100-initial.png and compare-manual-horizontal-settled.png. The inspected focus states show the entire original outline and button inside the table and viewport. The manual-horizontal image intentionally leaves the action column out of view, consistent with the user's comparison scroll. The wide-screen initial layout is visually preserved and its PNG bytes match baseline.

Verdict after the single app.js visual-behavior edit: the inspected clipping is corrected, the requested regression conditions pass, and no further product styling is needed. DESIGN.md records the shared policy and actual tested limits; it is the only later edit and does not affect rendering.

## Evidence locations

- Original untouched first run: /tmp/lutriva-focus-work-yJaqbx/baseline-run/browser.json and sibling PNGs.
- Corrected-input baseline: /tmp/lutriva-focus-work-yJaqbx/baseline-corrected-input/browser.json and sibling PNGs.
- Final product run: /tmp/lutriva-focus-work-yJaqbx/product-run-1/browser.json and sibling PNGs.
- Focused regression script: /tmp/lutriva-focus-work-yJaqbx/focus-regression.mjs.
- Pre-edit plan: /tmp/lutriva-focus-work-yJaqbx/plan.md.
