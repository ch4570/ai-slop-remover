import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFile, readdir, lstat, writeFile } from 'node:fs/promises';
import path from 'node:path';

const [inputRoot, frozenPath, newReport] = process.argv.slice(2);
assert(inputRoot && frozenPath && newReport, 'Usage: node check-author-scope.mjs INPUT_ROOT FROZEN_JSON NEW_REPORT');
const allowed = new Set(['product/app.js', 'product/components.css', 'product/DESIGN.md']);
async function walk(directory, prefix = '') {
  const files = {};
  for (const name of (await readdir(directory)).sort()) {
    const absolute = path.join(directory, name), relative = prefix + name;
    const stat = await lstat(absolute);
    assert(!stat.isSymbolicLink(), 'Unexpected symlink: ' + relative);
    if (stat.isDirectory()) Object.assign(files, await walk(absolute, relative + '/'));
    else {
      assert(stat.isFile(), 'Unexpected file type: ' + relative);
      const bytes = await readFile(absolute);
      files[relative] = {bytes: bytes.length, sha256: createHash('sha256').update(bytes).digest('hex')};
    }
  }
  return files;
}
const before = JSON.parse(await readFile(frozenPath, 'utf8')).files;
const after = await walk(inputRoot);
const missing = Object.keys(before).filter(name => !(name in after));
const extra = Object.keys(after).filter(name => !(name in before));
const changed = Object.keys(before).filter(name => name in after &&
  (before[name].bytes !== after[name].bytes || before[name].sha256 !== after[name].sha256));
const forbiddenChanges = changed.filter(name => !allowed.has(name));
const result = { observedAt: new Date().toISOString(), inputRoot, frozenPath,
  allowed: [...allowed], fileCountBefore: Object.keys(before).length,
  fileCountAfter: Object.keys(after).length, missing, extra, changed, forbiddenChanges,
  scopePreserved: !missing.length && !extra.length && !forbiddenChanges.length,
  limits: 'Only file scope and bytes; no implementation, behavior, design-document truth or visual verdict.',
  before, after };
await writeFile(newReport, JSON.stringify(result, null, 2) + '\n', {flag: 'wx'});
console.log(JSON.stringify({scopePreserved:result.scopePreserved, changed, missing, extra, forbiddenChanges}));
if (!result.scopePreserved) process.exitCode = 1;
