# Parent direct image observations

The parent opened these actual v2 baseline viewport PNGs after they were written:

- baseline/master-390x844-100-tab-first.png
- baseline/compare-390x844-100-tab-first.png
- baseline/master-320x864-200-user-horizontal-wheel.png

Root: /tmp/lutriva-focus-observer-v2-y5Qemd/.

The two390px initial row-focus images show the right end of the first button and
its orange/brown outline clipped by the table edge; the same action-column edge
also cuts the other row buttons. Master retains its taller row spacing and compare
retains its dense rows. The green navigation, typography roles, table data and
status layout remain visibly consistent with the provided starting product.

The320px200% image is a deliberately user-scrolled earlier-column view, not an
automatic-focus checkpoint. It shows product/amount and portions of long customer
names, with the action column outside the scrollport. The M-101 selection status
remains visible below the table. The image alone does not prove DOM focus stayed
on the offscreen button; that is a separate recorded behavior assertion. Do not
treat intentional browsing away from the action column as the same failure as
initial focus/selection failing to reveal the button automatically.

These three parent views are separate from the observer author's own inspection
count. No candidate images have been opened at this note's creation.

## Author's completed candidate captures (later parent inspection)

The parent subsequently opened three actual viewport images under
/tmp/lutriva-focus-work-yJaqbx/product-run-1/:

- master-390x844-100-tab-first.png
- master-live-text-200.png
- compare-manual-horizontal-settled.png

The390px first-row image shows the complete original outline inside the right
table edge; earlier columns move partly outside the local scrollport. The200%
live-text image shows the selected second-row button with its full outline and
the wrapped M-102 status below the table. This author's synthetic element-wise
font/name preparation differs from the independent observer's body/h1 scaling
and three spaced long names, so these are not independent-observer image pairs.
The manual horizontal image intentionally shows product/amount and partial name
columns while action buttons remain outside view. It is evidence of the pictured
user-scroll result, not alone proof of DOM focus or input provenance.

## Completed frozen-v2 candidate inspection

Parent opened the baseline's master-focused-font-transition-1.png together with
candidate-observation/master-focused-font-transition-1.png, plus candidate
master-focused-resize-transition-2.png and compare-390x844-100-tab-first.png.
Candidate original root is /tmp/lutriva-focus-candidate-8e7XUz. The original200%
font-transition image shows long customer text with the action column entirely
offscreen; candidate shows all three action buttons and the selected M-103 outline
inside the table, with the same wrapped status. The candidate resize image retains
full M-103 focus and the compare390px image preserves denser rows with the first
button's full outline visible. These4 image views include1 baseline and3 candidate
views; do not add them to observer-author image counts as independent test cases.
