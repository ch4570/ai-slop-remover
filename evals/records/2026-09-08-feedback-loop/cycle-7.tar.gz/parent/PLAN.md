# Cycle 7: automatic focus visibility follow-up

Starting state: clean537e33f, 2026-09-09 KST. The prior turn was concrete progress:
two scoped read-only product gates, new recovery evidence and immutable records
were committed; the overnight goal remains active, with no blocker.

The parent reread skill-creator in full and current ui-visual-refine SKILL,
principles, KB hierarchy, shared art-direction/web/design-memory/UX-foundations/
verification/behavior-evaluation/anti-slop and behavior-trial template. The selected
methods are preserving visible controls, adapting the task to available space and
stress-checking meaningful variation. No blanket style rule or new dependencies.

This new task is deliberately separate from the original density-only scope.
Both baseline/product copies are exactly the prior seven-file dense release,
verified against cycle6's pre-delegation frozen inventory. Current65 skills and
harness match Git537e33f, all83 starting files frozen in an external inventory.
PRIOR-REQUEST.md remains unchanged historical authority; TASK.md explicitly permits
components.css/app.js/DESIGN.md for a new two-screen automatic visibility fix.
tokens.css/compare.css/twoHTML must remain byte-identical; padding8 remains adopted.

The author receives a realistic bug report and desired result, not an implementation
hint, old reports, parent diagnostics or the independent observer. Author output
and personal tests live outside the product. A separate observer reads only TASK,
baseline and current harness; it must freeze criteria before looking at candidate.
It first runs baseline, retains failures, then later runs unchanged observer against
the delivered product. Same current Chrome version and input conditions are needed
for a paired claim. The automatic full-outline requirement is stronger than the
previous limited product gate; past scoped pass is not retrospectively relabeled.

Required behavior includes Tab/ShiftTab entry, correct Enter/Space order selection,
post-status and focused resize/text changes, local table scroll and intentional
user horizontal browsing without snapback. Actual viewport PNGs and geometry are
separate from behavior and data assertions. Standard fonts/brand/focus treatment/
hitareas/initial wide layout are preservation constraints. Physical devices, OS/
page zoom, IME, screenreader and broad accessibility certification remain outside
the executed emulation scope unless separately performed.

Parent-side observer controls will be separate temporary copies, not author inputs:
removing focus outline must not be counted as a visual fix; constantly pinning a
focused table to the right edge must not pass deliberate horizontal browsing.
They test specific predicates after the observer is frozen and are not product
candidates or general skill-uplift evidence. Any observer correction must preserve
old source/raw outcomes and be rerun on both baseline and final product.

Do not change SKILL/reference guidance without a demonstrated guidance failure.
One recovered product task establishes that task's outcome, not skill-version or
model learning. Do not push, install globally, edit user configuration or enter
browser update UI. Profile/target guards are not full updater/network isolation.

## Observer corrections before author start

Original observer froze as425b755e82d80138b0f1fd8ba9c1b66bb04446882e9938da716ffac2107b8e96.
Its first baseline completed0/28 cases with29 collector errors because the guard
treated every CDP target as a product page. Raw metadata included non-page
browser_ui, service_worker and background_page targets. This is not a product
failure; the parent has not verified the provenance of the extension targets.
Do not repeat the old README's 'built-in extension' provenance as an established
fact. No page target showed browser update UI in the inspected first guards.

A target-only correction froze asfdba674d6c9830e92d6fad1ec0e9bb335898e645552d0a74918cf3781cd636da
and ran baseline with the original spec. Both sources/results remain in
/tmp/lutriva-focus-observer-S07pGL; no candidate was read or edited at this stage.

Before starting the author, parent and observer identified two scope/precondition
issues: exact DESIGN-block prose is stronger than TASK's meaning preservation;
and a baseline button left at scrollLeft0 cannot test an earlier-columns wheel
without explicit input preparation. New v2 in /tmp/lutriva-focus-observer-v2-y5Qemd
uses a manual documentation review flag, checks exactly the original two scoped
page target identities while merely recording auxiliaries, and seeds a positive
table offset with recorded real right-wheel input when necessary AFTER all
automatic-focus checkpoints. The later left-wheel stability check is unchanged
and cannot overwrite earlier focus failures. An explicit protected-input-root CLI
override makes archived replay possible without rewriting the frozen spec.

Final pre-author v2 observer SHA256:
545788c49b4e4380520163bb46e50a0dce1b82574ea4bc045786cda5ec99d253.
Spec SHA256:9252a96e6e78c2b80a35df01aed77aa7d03778cf76e5e74aab822d219ae80d00.
Harness remains5538f93787bf84a401eba4ce747264ddd6bfc6e5e31049e4004a8986ad85a1e1.
The author was spawned only after this freeze, while v2 baseline ran independently.
Its sole task/context is the provided83-file input and real TASK, with no observer
or controls, old reports, suspected cause or implementation suggestion.

## Completed v2 baseline

The frozen v2 completed all28 cases and256 focus checkpoints with no collector or
runtime errors. Required visibility failures are73 checkpoint observations plus
9 after-capture repeat observations,82 raw entries across11 cases, not82 independent
user tasks. Other observed labels/order/status/style/local-overflow constraints
passed. Two wide100% cases have no overflow; both-direction real wheel behavior
completed in26 overflow cases. Browser152.0.7977.83 is equal before/after; protected
and observed product bytes match. The observer opened9 actual baseline images.
Raw browser.json SHA256:
56845a16f29056e331bbac74af4bb85e6b8be3fd0870ef4cecabc7ce4b35244b.

The v2 observer is now idle and has not accessed candidate. After this baseline
finished, a separate controls runner was authorized to execute the unchanged frozen
observer sequentially on no-outline then pinned-scroll. It verified intended file
differences/hashes before running. Control/output root:
/tmp/lutriva-cycle7-observer-controls-iV9Zce. Real author remains independent.

## Final author delivery and candidate handoff

At18:19 UTC parent confirmed the full83-file path set against the starting frozen
inventory: only product/app.js and product/DESIGN.md changed; no missing/extra or
forbidden files. The candidate was then handed to the idle observer for a new
unchanged-v2 paired run. The author report and proposed implementation were not
given to the independent observer. Parent read the actual app.js and DESIGN diff:
coalesced animation-frame correction uses computed outline bounds, local X scroll
and clipped viewport Y, scheduled on focus/selection/layout/resize, not scroll.
The original density exception is verbatim; no CSS changed. These are source
observations, not a generic nested-scroll or physical-device guarantee.

The author separately reports its own1251 assertions/238 states: first baseline
49 focus failures and1 invalid vertical-input preparation; corrected-input baseline
50 focus failures; candidate0 failures. That test uses different synthetic text
and timing from the frozen observer; never combine counts as independent user
trials. Its original raw first failure is retained. It records Chrome at session
start, not the same before/after guards used by the independent observer. Parent
requested explicit provenance for any unpreserved first test-script revision and
a read-only paired state/PNG comparison artifact before final evidence staging.

Both negative-control runs have completed according to their runner. No-outline
has272 outline-preservation failures plus the same82 baseline visibility entries;
pinned-scroll has26 left-wheel-movement and26 snapback failures, no others. Both
completed28cases/256checkpoints/20captures with0collector errors. Final control
source/hash/event report is still to be read; these provisional counts are not a
candidate result. Candidate is running independently in a distinct fresh output.

## Completed candidate and evidence limitations

Parent read completed candidate browser.json:28/28cases,256checkpoints,20captures,
0required failures,0collector errors,0runtime exceptions,0review flags, Chrome.83
before/after and29 allowed page guards. Final scope check again permits exactly
the same2files. Representative390px first-focus expanded right395.703125 becomes
372.703125 inside373 as scrollLeft0 becomes23. Parent opened4 independent-run
images (1baseline+3candidate), including the formerly completely offscreen200%
font transition. Observer final report is being finished separately.

Parent read the controls final REPORT in full; confirms the earlier provisional
counts, source stability and trusted wheel examples. First220ms pin sample cannot
distinguish no motion from early snapback; no stronger timeline claim is made.

Author clarified that its pre-correction test source was not saved verbatim. Its
actual original raw JSON/PNG remain; the two-edit diff is explicitly reconstructed
documentation. The final corrected script and both paired runs are preserved.
Parent read the offline comparison script/report:238unique paired labels and8
listed invariant fields match, while full state and PNG equality applies only
to2wide initial views. No claim of all-state geometry equality is made. Author
evidence output is finalized; no browser rerun was performed for clarification.

Observer final paired report was read in full. Its first candidate run passed
without edits/retry;9candidate images opened,2wide initial PNGs exactly equal to
baseline,26overflow wheel cases pass and2wide100% cases inapplicable. Final raw
candidate SHA256 isb00bbc64f014b42e43b074317c2ff77adb2e475a00a898c003f7667418e88412.
The source/output is finalized for exact-copy staging. Parent repository checks
at18:26UTC passed npm test20, npm check, check:js and diff whitespace. No full
Python291/opt-in47 suite rerun is claimed; repository runtime/test implementation
did not change. Record-source markdown is not a shipped product implementation.
