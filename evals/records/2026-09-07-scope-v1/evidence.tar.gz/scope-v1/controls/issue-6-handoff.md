# Frozen trial handoff

Fixture/TASK files and suite check IDs are frozen at this handoff. Parent can prepare and run native trials now. Harness controls are still being verified; no trial products will be inspected to tune checks.

All commands run from the prepared issue-6 worktree. `CASE` is one of narrow-spacing, audit-read-only, empty-state-copy-only, master-page-consistency. `TRIAL` must be a new directory for prepare.

```sh
python3 scripts/check_scope.py prepare CASE TRIAL
node scripts/run_scope_checks.mjs CASE TRIAL/product TRIAL
python3 scripts/check_scope.py collect CASE TRIAL
python3 scripts/compare_evals.py BASELINE/result.json CANDIDATE/result.json --suite CASE-v1
python3 scripts/summarize_scope_trials.py MANIFEST.json
```

prepare writes product/, TASK.md, prepare.json and before-manifest.json. prepare.json fields: schema=1, case, fixture_sha256, task_sha256. Fixture digest includes TASK.md and product/* sorted by fixture-relative path, then NUL, bytes, NUL. Product inventory includes final content digest/type/mode and a `.` entry for the product root. A symlink or non-directory root is recorded without traversal; traversal errors are raised, never silently omitted. It never follows symlinks. File inventory proves final equality; it cannot prove no intermediate writes without actual transcripts.

collect reads evaluator-owned invocation.json written by parent:

```json
{
  "run_id": "unique-lowercase-trial-id",
  "variant": "baseline",
  "model": "actual common identity or documented parent-session inheritance",
  "settings": {
    "invocation_mode": "snapshot-direct",
    "reasoning": "actual inherited setting description",
    "prompt_template_sha256": "actual common digest",
    "tool_contract_sha256": "actual common digest"
  },
  "skill_revision": "actual exact revision"
}
```

Additional invocation sidecar fields are allowed. Result schema 1 remains strict with only the existing top-level fields. Every settings key/value must meet comparator restrictions and the whole settings object must match across both runs (and all trials). Variant-specific native IDs, paths, timestamps and hashes belong in invocation sidecar / manifest, never shared settings.

Browser collection writes browser.json and images/wide.png, images/narrow.png, images/keyboard.png. master-page-consistency also requires images/master-wide.png. Collection exit zero means artifacts were written, not a passing outcome. Unavailable Chrome observations remain not-run; previously observed failures remain fail. check_scope collect does not run the browser automatically.

Raw actual final response must be TRIAL/agent-output.md. Independent reviewer writes nonempty TRIAL/review.md and review.json keyed by the case quality check ID:

- narrow-spacing: narrow-focus-review
- audit-read-only: prioritized-diagnosis
- empty-state-copy-only: truthful-copy-and-name
- master-page-consistency: design-visual-review

```json
{
  "narrow-focus-review": {
    "status": "pass",
    "evidence": {"path": "review.md", "text": "Actual observed review finding, not a placeholder."},
    "reviewed_images": ["images/wide.png", "images/narrow.png", "images/keyboard.png"]
  }
}
```

Use fail for concrete defects and not-run + concrete reason for unobserved review. The reviewer must actually inspect the listed images; their existence is not proof. Missing image/final output/review makes quality not-run even when a pass was supplied. A concrete fail with valid review evidence and actual final output stays fail if another image is missing; the reason records that coverage gap. Source/browser checks and human quality have separate IDs. Source copy guard recognizes the exact known unsupported phrase `필터 초기화 버튼을 눌러` only; absence of that phrase cannot establish semantic truth.

collect writes source-checks.json, after-manifest.json, diff.patch and result.json. Diff can be empty for read-only success; source-checks.json is nonempty evidence of inventory equality. Every result evidence path stays inside its own trial folder.

Trial summary manifest schema 1:

```json
{
  "schema": 1,
  "repetitions": 2,
  "host_coverage": {
    "installed-host-explicit": {"status": "not-run", "reason": "These runs read assigned snapshots directly; host explicit invocation was not exercised."},
    "automatic-discovery": {"status": "not-run", "reason": "Host automatic discovery was not exercised in the native snapshot trials."}
  },
  "trials": [
    {"case": "narrow-spacing", "repeat": 1, "variant": "baseline", "native_agent_id": "actual native ID", "result": "trials/t01/result.json", "launch": "trials/t01/native-launch.json", "output": "trials/t01/agent-output.md"}
  ]
}
```

Manifest paths resolve relative to its directory and must remain inside it. Exactly 16 unique case/repeat/variant combinations and native agent IDs are required. native-launch.json envelope retains the actual `request` (including fork_turns="none") and actual `response` (with task_name matching manifest); other raw envelope fields are allowed. Native final raw output stays in output; do not reconstruct unavailable tool transcripts. Comparator still owns evidence schema and condition matching. summary outputs 8 per-case pairs, missing/invalid entries and fail→pass/pass→fail transitions; concrete candidate failure outranks missing/invalid coverage, otherwise missing coverage is incomplete.

Transport preview API (copy just scripts/browser_harness.mjs to the common tool snapshot):

```js
import { withBrowser } from './browser_harness.mjs';
await withBrowser(productPath, screenshotDirectory, async ({ origin, page, evaluate, call, screenshot, pause, exceptions }) => {
  await page('Page.navigate', { url: origin + '/index.html' });
  // Wait for page readiness in the caller; master case entry is compare.html/master.html.
  await screenshot('preview.png');
});
```

Helper serves only a loopback product path in a fresh temporary Chrome profile, with no assertions, seed or case logic. Exposed page/call use CDP; screenshots are local PNGs. Real Chrome and Node22+ are optional; honest unavailable observations are allowed. Final external collection remains separate.
