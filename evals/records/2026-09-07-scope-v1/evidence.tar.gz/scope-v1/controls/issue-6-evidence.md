# Issue 6 harness implementation evidence

Executor worktree: issue-6; branch test/issue-6-scope-trials; base main 69149804ea292a8a8589c9dde0ebf164d0dde8fc.
This record covers evaluator implementation and synthetic controls only. Parent owns actual native trials, evidence integration, independent review and GitHub actions. No actual trial output was read to tune evaluator criteria, no trial agent was launched by this executor, and evals/records was not authored here.

## Frozen contracts and simplifications

- Four independent TASK/product fixtures, source declarations/inventory checks, browser observations and separately required quality reviews.
- Initial fixture/TASK SHA-256: issue-6-frozen-fixtures.json; final evaluator source SHA-256: issue-6-frozen-evaluator.json. The four fixture digests were checked unchanged after harness verification.
- Exact parent preparation, invocation, collection, review and summary contracts: issue-6-handoff.md.
- Existing compare()/validate() schema 1 and default search-editor-v3 retained; explicit pinned suite injection added.
- Existing installed-Chrome transport extracted into browser_harness.mjs. Search-editor scenarios/readiness/seeding stayed in the existing adapter. Locale duplicate-key validation reuses the comparator's strict JSON helper.
- Product root type/mode is inventoried as '.', root symlinks/non-directories are not traversed, traversal errors are raised, and new scope browser collection refuses symlink roots.
- No runtime dependency, agent launcher or npm payload expansion. Source-only fixtures/checkers/evidence remain excluded. docs/verification.md links source-only contracts via canonical GitHub URL and manifest hashes are synced.

## Executed regression evidence

| Command / log | Observed result |
| --- | --- |
| New explicit-suite comparator regression before implementation | 23 tests: 1 error, compare() rejected unexpected keyword suite; after implementation all 23 passed. |
| Collector concrete-review-fail plus missing images regression before fix | New assertion saw not-run instead of fail; after fix all source/summary controls passed. |
| Summary candidate-failure plus own missing baseline regression before fix | New assertion saw incomplete instead of changes-required; after fix candidate failure survives with comparison_verdict=incomplete and no invented regression/improvement. Missing launch metadata is also covered. |
| python3 -m unittest discover -s tests -p test_scope_checks.py -q | Final 20 tests passed. Passing source controls, allowed whitespace/comments, read-only writes/new files/modes/directories/root symlink, shared/local token changes, locale variables/keys/ARIA/known invented action, DESIGN disagreement, missing review/images, missing/duplicate contexts/launches, condition drift and failure priority. |
| python3 -m unittest discover -s tests -p test_compare_evals.py -q | Final 23 tests passed, default search-editor-v3 still required without explicit suite. |
| AI_SLOP_BROWSER_TESTS=1 ... test_browser_checks.py -v | 18 existing Chrome regressions passed in 96.428s after transport extraction. Log: issue-6-existing-browser.log; JSON/images: issue-6-existing-browser/. |
| AI_SLOP_BROWSER_TESTS=1 ... test_scope_browser_checks.py -v | Initial 9 tests passed in 38.472s, including all four passing source/browser controls and single mutations. Log: issue-6-scope-browser.log; source reports/product patches/browser JSON/images: issue-6-scope-browser/scope-inprjc98/. The unavailable-Chrome control is an intentional not-run observation. |
| AI_SLOP_BROWSER_TESTS=1 ... test_scope_browser_checks.py -v -k replaced_product_root | Added root-symlink browser refusal test passed; source fail and browser not-run recorded without traversal. Evidence retained under issue-6-scope-browser/. All 10 current scope browser tests have executed successfully across these two runs. |
| python3 -m unittest discover -s tests -v | Final broad run: 149 tests, OK, 28 explicitly skipped browser tests. Log: issue-6-python-final.log. |
| npm test | 8 tests passed, including exact npm tarball payload and offline aliases. Log: issue-6-npm.log. |
| npm run check | 65 release hashes, 7 skill payloads, release links/dependencies, 19 catalog contracts and Python syntax validated. |
| npm run check:js | Existing and new drivers/helper/product JavaScript syntax passed. |
| ast.parse(... feature_version=(3, 9)) | All 11 scripts/tests Python files parse with Python 3.9 grammar. This is grammar compatibility, not execution under Python 3.9. |
| git diff --check | Passed before staging; staged diff checked separately before commit. |
| OMX lsp_diagnostics for check_scope.py/run_scope_checks.mjs | Not run: both tool calls returned Transport closed. Repository-native syntax checks and executable tests supplied verification. |

## Bounded screen inspection

The executor opened only known-good harness control screenshots, not actual trial output. Inspected images: issue-6-scope-browser/scope-inprjc98/good-{audit-read-only,empty-state-copy-only,master-page-consistency,narrow-spacing}/images/narrow.png.

At 375px the narrow setting control remains within its panel; the long copy control wraps the interpolated title/body within its panel; comparison rows use the expected contained horizontal table overflow. The audit fixture visibly retains its intentionally excessive promotion, delayed orders and cramped customer cells. This inspection confirms usable synthetic fixtures and observable intentional defects; it is not a semantic/visual verdict on any native trial.

## Environment and limits

Local macOS, Node v25.2.1, Python 3.14.7, installed Chrome in a fresh temporary profile with loopback-only synthetic fixtures. Node20/Python3.9 and other OS executions remain CI coverage, not local claims. Browser scope uses Node22+; no dependency install occurred.

Source matching establishes the declared edit contract, not general language or visual quality. The exact fabricated-recovery phrase guard is narrow; truthful-copy-and-name still needs independent review. AX tree/name capture is not a screen reader test. Final inventories do not prove absence of intermediate writes without real tool transcripts.

Harness-only delivery does not complete issue #6. Actual four cases x two variants x two repeats (16 fresh contexts), eight comparisons, raw launch/final outputs/diffs/inventory/browser images and independent reviews must be supplied and durably integrated by the parent. Snapshot-direct trials do not establish installed-host-explicit invocation or automatic discovery, which remain separately not-run. Repeated pass→pass outcomes do not establish general skill improvement.

## Harness commit

7ae3d287dfb0cd2b83a3ab608a74b0b96cb350e0 — 좁은 UI 요청의 범위 회귀를 실제 증거로 드러낸다

Staged diff whitespace check passed; commit succeeded with Lore trailers and exact OmX coauthor. Worktree was clean immediately after the harness commit. No push/PR/merge was performed.
