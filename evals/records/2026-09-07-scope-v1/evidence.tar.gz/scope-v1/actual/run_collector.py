from pathlib import Path
from datetime import datetime, timezone
import argparse, json, subprocess, sys

ROOT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument("operation", choices=("browser", "collect"))
parser.add_argument("trial")
args = parser.parse_args()
plan = json.loads((ROOT / "launch-plan.json").read_text())
item = next(p for p in plan if p["id"] == args.trial)
assert item["status"] == "completed", item
trial = Path(item["trial"])
evaluator = ROOT / "snapshots/evaluator"
argv = (["node", str(evaluator / "scripts/run_scope_checks.mjs"), item["case"], str(trial / "product"), str(trial)]
        if args.operation == "browser" else
        [sys.executable, "-B", str(evaluator / "scripts/check_scope.py"), "collect", item["case"], str(trial)])
start = datetime.now(timezone.utc).isoformat()
result = subprocess.run(argv, cwd=evaluator, text=True, capture_output=True, timeout=90)
record = {"argv": argv, "cwd": str(evaluator), "started_at": start,
          "finished_at": datetime.now(timezone.utc).isoformat(), "returncode": result.returncode,
          "stdout": result.stdout, "stderr": result.stderr}
with (trial / "external-executions.jsonl").open("a", encoding="utf-8") as output:
    output.write(json.dumps(record, ensure_ascii=False) + "\n")
print(json.dumps({"trial": item["id"], "operation": args.operation, "returncode": result.returncode,
                  "record": str(trial / "external-executions.jsonl")}))
sys.exit(result.returncode)
