`locales/ko.json`의 허용된 문구 세 개만 수정했습니다. 검색어 변경 안내를 구체화하고 표시 제목과 접근 가능한 이름을 맞췄습니다.

Chrome에서 결과 없음→검색어 변경→자료 2개 복구, 320px 줄바꿈, 접근성 트리를 확인했습니다. 실제 보조기술 음성 출력과 글자 확대는 미검증입니다.

[결과 보고서](/var/folders/dt/8hl_lk4517vfdrvql7_0n2b80000gn/T/lutriva-issue-delivery-mt6la1md/issue-6-evals/trials/t11/scratch/agent-output.md)
