from pathlib import Path
import hashlib
import json
import re

product = Path.cwd()
scratch = Path(__file__).parent
files = sorted(path for path in product.rglob('*') if path.is_file())
before_hashes = {str(path.relative_to(product)): hashlib.sha256(path.read_bytes()).hexdigest() for path in files}
copy_path = product / 'locales/ko.json'
before_text = copy_path.read_text()
before = json.loads(before_text)
changes = {
    'empty_title': '“{query}” 검색 결과가 없습니다.',
    'empty_body': '검색창에 다른 검색어를 입력해 보세요.',
    'empty_name': '“{query}” 검색 결과가 없습니다.',
}
after_text = before_text
for key, value in changes.items():
    old_line = json.dumps(key) + ': ' + json.dumps(before[key], ensure_ascii=False)
    new_line = json.dumps(key) + ': ' + json.dumps(value, ensure_ascii=False)
    assert after_text.count(old_line) == 1
    after_text = after_text.replace(old_line, new_line)
copy_path.write_text(after_text)
after = json.loads(copy_path.read_text())
assert list(before) == list(after), 'Locale keys changed'
assert {key for key in before if before[key] != after[key]} == set(changes), 'Unexpected string changes'
for key in before:
    assert re.findall(r'\{[^{}]*\}', before[key]) == re.findall(r'\{[^{}]*\}', after[key]), key
assert after['empty_title'] == after['empty_name']
after_files = sorted(path for path in product.rglob('*') if path.is_file())
after_hashes = {str(path.relative_to(product)): hashlib.sha256(path.read_bytes()).hexdigest() for path in after_files}
assert set(before_hashes) == set(after_hashes), 'Product file added or removed'
assert [name for name in before_hashes if before_hashes[name] != after_hashes[name]] == ['locales/ko.json']
report = {'before': before, 'after': after, 'before_hashes': before_hashes, 'after_hashes': after_hashes, 'checks': 'PASS: only three allowed values changed; all locale keys and per-string placeholders preserved; other product files unchanged'}
(scratch / 'copy-checks.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(report, ensure_ascii=False, indent=2))
