from pathlib import Path
import hashlib
import json

product = Path.cwd()
scratch = Path(__file__).parent
baseline = json.loads((scratch / 'copy-checks.json').read_text())
current = {str(path.relative_to(product)): hashlib.sha256(path.read_bytes()).hexdigest() for path in sorted(product.rglob('*')) if path.is_file()}
assert current == baseline['after_hashes'], 'Unexpected product modification after copy edit'
assert json.loads((product / 'locales/ko.json').read_text()) == baseline['after']
browser = json.loads((scratch / 'browser-checks.json').read_text())
assert browser['cleanup']['loopbackServerClosed']
assert browser['cleanup']['temporaryBrowserProfilesRemaining'] == []
print('PASS: final product file hashes match the verified edit; only locales/ko.json changed.')
print('PASS: browser shutdown and temporary profile cleanup were verified.')
print('No lint/typecheck/package configuration exists in this six-file static product; no such task was run.')
