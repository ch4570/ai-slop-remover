from pathlib import Path
import subprocess, shlex, sys
cmd = sys.argv[1:]
result = subprocess.run(cmd, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
log = Path(__file__).with_name("commands.log")
with log.open("a") as handle:
    handle.write("$ " + shlex.join(cmd) + "\n")
    handle.write("cwd: " + str(Path.cwd()) + "\n")
    handle.write("stdout:\n" + result.stdout + "\nstderr:\n" + result.stderr + "\n")
    handle.write("exit: " + str(result.returncode) + "\n\n")
print(result.stdout, end="")
print(result.stderr, end="", file=sys.stderr)
sys.exit(result.returncode)
