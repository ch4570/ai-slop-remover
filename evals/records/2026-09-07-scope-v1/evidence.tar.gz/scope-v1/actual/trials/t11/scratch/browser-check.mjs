import assert from 'node:assert/strict';
import { writeFile, readdir } from 'node:fs/promises';
import { withBrowser } from '/var/folders/dt/8hl_lk4517vfdrvql7_0n2b80000gn/T/lutriva-issue-delivery-mt6la1md/issue-6-evals/snapshots/tools/browser_harness.mjs';

const product = '/var/folders/dt/8hl_lk4517vfdrvql7_0n2b80000gn/T/lutriva-issue-delivery-mt6la1md/issue-6-evals/trials/t11/product';
const scratch = '/var/folders/dt/8hl_lk4517vfdrvql7_0n2b80000gn/T/lutriva-issue-delivery-mt6la1md/issue-6-evals/trials/t11/scratch';
const report = {};
const result = await withBrowser(product, scratch + '/screenshots', async ({origin, page, evaluate, call, screenshot, pause, exceptions}) => {
  report.browser = await call('Browser.getVersion');
  async function navigate(search = '') {
    await page('Page.navigate', {url: origin + '/index.html' + search});
    for (let i = 0; i < 80; i++) {
      if (await evaluate('document.documentElement.dataset.ready === "true"')) return;
      await pause(100);
    }
    throw new Error('Product did not become ready');
  }
  async function read() {
    return evaluate(`JSON.parse(JSON.stringify({
      query: document.querySelector('#query').value,
      count: document.querySelector('#count').textContent,
      results: [...document.querySelectorAll('#results li')].map(item => item.textContent),
      emptyHidden: document.querySelector('#empty').hidden,
      state: document.querySelector('#empty').dataset.state,
      title: document.querySelector('#empty-title').textContent,
      name: document.querySelector('#empty-title').getAttribute('aria-label'),
      body: document.querySelector('#empty-body').textContent,
      labelledby: document.querySelector('#empty').getAttribute('aria-labelledby'),
      describedby: document.querySelector('#empty').getAttribute('aria-describedby'),
      queryControls: document.querySelector('#query').getAttribute('aria-controls'),
      queryDescribedby: document.querySelector('#query').getAttribute('aria-describedby'),
      viewportWidth: innerWidth,
      documentWidth: document.documentElement.scrollWidth,
      bounds: ['empty', 'empty-title', 'empty-body'].map(id => {
        const element = document.getElementById(id);
        const rect = element.getBoundingClientRect();
        return {id, width: rect.width, height: rect.height, clientWidth: element.clientWidth, scrollWidth: element.scrollWidth, fontSize: getComputedStyle(element).fontSize};
      })
    }))`);
  }
  async function input(text) {
    const rect = await evaluate('JSON.parse(JSON.stringify(document.querySelector("#query").getBoundingClientRect()))');
    const x = rect.x + Math.min(rect.width / 2, 40);
    const y = rect.y + rect.height / 2;
    await page('Input.dispatchMouseEvent', {type: 'mousePressed', x, y, button: 'left', clickCount: 1});
    await page('Input.dispatchMouseEvent', {type: 'mouseReleased', x, y, button: 'left', clickCount: 1});
    await page('Input.dispatchKeyEvent', {type: 'keyDown', key: 'a', code: 'KeyA', modifiers: 4, commands: ['selectAll']});
    await page('Input.dispatchKeyEvent', {type: 'keyUp', key: 'a', code: 'KeyA', modifiers: 4});
    await page('Input.insertText', {text});
    await pause(100);
    assert.equal(await evaluate('document.querySelector("#query").value'), text);
  }
  await navigate();
  report.initial = await read();
  assert.equal(report.initial.results.length, 3);
  assert.equal(report.initial.emptyHidden, true);

  await input('환불');
  report.noMatch = await read();
  assert.equal(report.noMatch.emptyHidden, false);
  assert.equal(report.noMatch.state, 'no-match');
  assert.equal(report.noMatch.count, '0개 자료');
  assert.equal(report.noMatch.title, '“환불” 검색 결과가 없습니다.');
  assert.equal(report.noMatch.name, report.noMatch.title);
  assert.equal(report.noMatch.body, '검색창에 다른 검색어를 입력해 보세요.');
  assert.equal(report.noMatch.labelledby, 'empty-title');
  assert.equal(report.noMatch.describedby, 'empty-body');
  assert.equal(report.noMatch.queryControls, 'results');
  assert.equal(report.noMatch.queryDescribedby, 'count');
  const ax = await page('Accessibility.getFullAXTree');
  report.accessibility = ax.nodes.filter(node => !node.ignored && ['heading', 'region', 'searchbox', 'status'].includes(node.role?.value)).map(node => ({
    role: node.role.value,
    name: node.name?.value,
    description: node.description?.value
  }));
  assert.ok(report.accessibility.some(node => node.role === 'heading' && node.name === report.noMatch.title));
  assert.ok(report.accessibility.some(node => node.role === 'region' && node.name === report.noMatch.title && node.description === report.noMatch.body));
  await screenshot('01-no-match-desktop.png');

  await input('배송');
  report.recovered = await read();
  assert.deepEqual(report.recovered.results, ['배송 안내', '정기 배송 일정']);
  assert.equal(report.recovered.emptyHidden, true);
  assert.equal(report.recovered.count, '2개 자료');
  await screenshot('02-recovered-desktop.png');

  await page('Emulation.setDeviceMetricsOverride', {width: 320, height: 850, deviceScaleFactor: 1, mobile: false});
  const longQuery = '제주도 정기 배송 일정과 교환 및 반품 신청 방법을 자세히 알고 싶어요';
  await input(longQuery);
  report.narrow = await read();
  assert.equal(report.narrow.title, '“' + longQuery + '” 검색 결과가 없습니다.');
  assert.equal(report.narrow.name, report.narrow.title);
  assert.ok(report.narrow.documentWidth <= report.narrow.viewportWidth);
  for (const box of report.narrow.bounds) assert.ok(box.scrollWidth <= box.clientWidth, 'Overflow: ' + box.id);
  await screenshot('03-no-match-narrow-long-query.png');

  await page('Emulation.setDeviceMetricsOverride', {width: 1280, height: 900, deviceScaleFactor: 1, mobile: false});
  await navigate('?empty=1');
  report.neverPopulated = await read();
  assert.equal(report.neverPopulated.state, 'never-populated');
  assert.equal(report.neverPopulated.title, '저장된 항목이 없습니다.');
  assert.equal(report.neverPopulated.body, '등록된 항목은 이 목록에 표시됩니다.');
  assert.equal(report.neverPopulated.name, report.neverPopulated.title);

  await navigate('?lang=en');
  await input('refund');
  report.english = await read();
  assert.equal(report.english.title, 'No results for “refund”.');
  assert.equal(report.english.body, 'Check the search term and try again.');
  assert.equal(report.english.name, 'No results for refund');
  assert.deepEqual(exceptions, []);
  report.runtimeExceptions = exceptions;
  return {origin};
});
const leftovers = (await readdir(scratch)).filter(name => name.startsWith('slop-browser-'));
assert.deepEqual(leftovers, []);
let closed = false;
try { await fetch(result.origin, {signal: AbortSignal.timeout(1000)}); } catch { closed = true; }
assert.equal(closed, true, 'Loopback server is still reachable');
report.cleanup = {loopbackServerClosed: closed, temporaryBrowserProfilesRemaining: leftovers};
report.checks = 'PASS: native browser input produced no matches and restored results; accessible title/region semantics agree; narrow long Korean copy has no horizontal overflow; untouched states unchanged; no runtime exceptions.';
await writeFile(scratch + '/browser-checks.json', JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify(report, null, 2));
