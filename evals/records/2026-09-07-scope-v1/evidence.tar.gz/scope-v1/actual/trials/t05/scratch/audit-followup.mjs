import { withBrowser } from '/var/folders/dt/8hl_lk4517vfdrvql7_0n2b80000gn/T/lutriva-issue-delivery-mt6la1md/issue-6-evals/snapshots/tools/browser_harness.mjs';
import {writeFile} from 'node:fs/promises';
const product=process.argv[2],scratch=process.argv[3],out={};
await withBrowser(product,scratch,async({origin,page,evaluate,pause})=>{
  await page('Page.navigate',{url:origin+'/index.html'});
  for(let i=0;i<100;i++){if(await evaluate("document.readyState==='complete' && !!document.querySelector('[data-order]')"))break;await pause(50);}
  const shot=async name=>{const r=await page('Page.captureScreenshot',{format:'png',captureBeyondViewport:false});await writeFile(scratch+'/'+name,Buffer.from(r.data,'base64'));};
  await shot('desktop-viewport.png');
  const press=async key=>{const code=key==='Tab'?9:13;await page('Input.dispatchKeyEvent',{type:'keyDown',key,code:key,windowsVirtualKeyCode:code,nativeVirtualKeyCode:code,...(key==='Enter'?{text:'\r',unmodifiedText:'\r'}:{})});await page('Input.dispatchKeyEvent',{type:'keyUp',key,code:key,windowsVirtualKeyCode:code,nativeVirtualKeyCode:code});await pause(80);};
  await press('Tab');await press('Tab');await press('Tab');
  out.focusBefore=await evaluate(`({tag:document.activeElement.tagName,order:document.activeElement.dataset.order,focusVisible:document.activeElement.matches(':focus-visible'),outline:getComputedStyle(document.activeElement).outline,shadow:getComputedStyle(document.activeElement).boxShadow})`);
  await shot('desktop-focus-viewport.png');
  await press('Enter');
  out.afterKeyboardEnter=await evaluate(`({detail:document.querySelector('#detail').textContent,url:location.href,dialogs:document.querySelectorAll('dialog,[role=dialog]').length,bodyText:document.body.innerText})`);
  await shot('desktop-detail-viewport.png');
  out.afterProgrammaticClick=await evaluate(`(()=>{document.querySelector('[data-order="M-102"]').click();return {detail:document.querySelector('#detail').textContent,url:location.href,dialogs:document.querySelectorAll('dialog,[role=dialog]').length};})()`);
  await evaluate("document.querySelector('#order-search').focus();");await page('Input.insertText',{text:'존재없음'});await pause(80);
  out.afterSelectionThenNoMatch=await evaluate(`({detail:document.querySelector('#detail').textContent,visibleRows:document.querySelectorAll('tbody tr:not([hidden])').length})`);
  await shot('desktop-stale-detail-viewport.png');
  await page('Emulation.setDeviceMetricsOverride',{width:390,height:844,deviceScaleFactor:1,mobile:false});
  await page('Page.navigate',{url:origin+'/index.html'});
  for(let i=0;i<100;i++){if(await evaluate("document.readyState==='complete' && !!document.querySelector('#orders')"))break;await pause(50);}
  await shot('narrow-viewport.png');
  await evaluate("document.querySelector('#orders').scrollIntoView();");await pause(80);
  await shot('narrow-orders-viewport.png');
  out.narrowCellGeometry=await evaluate(`[...document.querySelectorAll('tbody tr:first-child td')].map(e=>({text:e.innerText,width:e.getBoundingClientRect().width,whiteSpace:getComputedStyle(e).whiteSpace}))`);
});
console.log(JSON.stringify(out,null,2));
await writeFile(scratch+'/browser-followup.json',JSON.stringify(out,null,2));
