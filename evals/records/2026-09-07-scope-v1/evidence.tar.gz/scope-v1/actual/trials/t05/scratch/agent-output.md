읽기 전용 진단을 완료했습니다. 변경 파일과 적용한 단순화는 없습니다. 제품 4개 파일의 내용 해시·파일 종류·권한·목록이 전후 동일합니다.

범위는 `product/index.html`의 배송 대기 주문 화면입니다. 운영자가 주문을 찾아 상세를 확인하는 작업과 `DESIGN.md:3`의 키보드 접근·브랜드 초록·상태와 행동 구분 기준으로 판단했습니다. 지정된 `source-a/skills/ui-slop-audit/SKILL.md`와 연결된 참고 문서를 직접 읽었으며, 설치 스킬의 자동 발견이나 호출을 검증한 것은 아닙니다.

1. **blocker — 상세 보기가 실제 상세를 제공하지 않습니다.** 위치: `product/app.js:4–5`, `product/index.html:3`의 `[data-order]`, `#detail`. Tab으로 M-101 버튼에 이동해 Enter를 누르면 “M-101 상세를 확인 중입니다.”로 문구만 바뀌고 상세 정보가 나타나지 않았습니다. 운영자는 주문을 찾은 뒤 확인 업무를 끝낼 수 없습니다. **제한된 교정:** 해당 버튼과 결과 영역을 실제 상세 제공 동작에 연결하고, 진행 안내와 실제 결과를 구분합니다. 제공 코드에는 상세 데이터 경로가 없어 그 내용은 별도 확인이 필요합니다. **재확인:** 각 주문 버튼을 키보드로 실행하면 해당 주문의 상세 정보가 표시되는지 확인합니다. 근거: `browser-followup.json`의 `afterKeyboardEnter`, 직접 본 `desktop-detail-viewport.png`; 문구 변경만 있는 소스도 확인했습니다.

2. **important — 키보드 포커스 위치를 볼 수 없습니다.** 위치: `product/style.css:14`의 `input:focus, button:focus, a:focus`. Tab 순서는 링크 → 검색 → M-101 상세 버튼으로 정상 이동하고 Enter도 작동하지만, 활성 버튼에 시각적 표시가 없습니다. 현재 어느 주문을 실행할지 눈으로 식별하기 어렵습니다. **제한된 교정:** 이 규칙의 포커스 제거를 해제하거나 대비가 분명한 `:focus-visible` 표시를 추가합니다. **재확인:** Tab과 Shift+Tab으로 검색·두 상세 버튼을 이동할 때 현재 위치가 명확하고 Enter 실행 대상과 일치해야 합니다. 근거: `browser-followup.json`의 `focusBefore`와 직접 본 `desktop-focus-viewport.png`.

3. **important — 입력 형식 차이로 존재하는 주문이 검색에서 빠집니다.** 위치: `product/app.js:1–2`, `#order-search`, `tbody tr[data-search]`. `M-101`과 `김민지`는 1건이지만 `m-101`, ` M-101 `은 0건이었습니다. 소문자 입력이나 복사한 값의 공백 때문에 주문이 없다고 오해할 수 있습니다. **제한된 교정:** 검색어와 검색 대상의 비교 형식을 맞추고 검색어 앞뒤 공백을 제거합니다. **재확인:** 세 주문번호 입력이 같은 M-101을 찾고, 고객명 검색도 유지되어야 합니다. 근거: `browser-observations.json`의 각 `search_*` 결과. 입력을 지우면 2건이 복원되는 동작은 정상입니다.

4. **important — 검색 결과가 없어도 이유와 복구 안내가 없습니다.** 위치: `product/app.js:2`, `product/index.html:3`의 `tbody`, `#detail[role=status]`. `존재없음` 입력 시 머리글만 남고 “주문을 선택해 주세요.”가 유지됩니다. 주문 선택 후 검색하면 이전 주문의 “상세를 확인 중입니다.”가 남았습니다. 사용자는 검색 0건과 조회 중인 상태를 구분하기 어렵습니다. **제한된 교정:** 결과 영역에 0건과 검색어 수정·지우기 안내를 제공하고 상세 상태와 검색 결과 상태를 구분합니다. **재확인:** 선택 전후 각각 0건 검색을 실행해 현재 검색 결과가 명확하고, 지우면 2건이 복원되는지 확인합니다. 근거: 직접 본 `desktop-no-results.png`, `desktop-stale-detail-viewport.png`와 두 JSON 기록.

5. **important — 홍보 영역이 주문 찾기를 첫 화면 밖으로 밀어냅니다.** 위치: `product/style.css:5–8`, `product/index.html:3`의 `.promotion`, `#orders`. 610px 높이의 홍보 영역 때문에 1280×900에서 검색창은 y≈859, 첫 주문은 y≈985에 시작합니다. 390×844에서도 검색 입력이 첫 화면 밖입니다. 반복 조회 업무에 매번 스크롤이나 링크 이동이 필요합니다. **제한된 교정:** 이 화면의 홍보 영역 높이·여백을 줄이거나 주문 목록 아래로 내려 검색과 주문을 먼저 보이게 합니다. **재확인:** 두 뷰포트의 최초 진입에서 검색과 첫 주문을 확인할 수 있어야 합니다. 근거: `browser-observations.json`의 geometry와 직접 본 `desktop-viewport.png`, `narrow-viewport.png`.

6. **important — 좁은 화면에서 고객명과 주문번호가 잘게 줄바꿈됩니다.** 위치: `product/style.css:11–13`의 `table`, `th, td`, `.badge, button`; 주문·고객 열은 `product/index.html:3`. 390px에서 고객 열 너비가 약 47px이고 좌우 여백을 빼면 이름이 한 글자씩 줄바꿈됩니다. M-101도 두 줄이 되어 주문·고객 대조가 느려집니다. 상태와 버튼은 각각 약 99px을 유지합니다. **제한된 교정:** 좁은 화면에서 셀 여백과 상태·행동 폭을 조정해 주문번호와 고객명에 읽을 폭을 확보합니다. **재확인:** 390px에서 현재 두 주문의 번호·이름이 읽기 좋은 단위로 유지되고 상세 버튼도 접근 가능해야 합니다. 근거: `browser-followup.json`의 `narrowCellGeometry`와 직접 본 `narrow-orders-viewport.png`. 이 크기에서 페이지 가로 넘침은 없었습니다.

7. **polish — 상태가 행동 버튼과 같은 강조를 사용합니다.** 위치: `product/style.css:13`의 `.badge, button` 공유 규칙. 배송 대기 상태와 상세 보기 버튼의 배경·테두리·글자색·굵기가 같습니다. 열 제목과 문구로 구분은 가능하지만 클릭 대상의 식별을 방해할 여지가 있습니다. 실제 사용자 오클릭은 측정하지 않았으므로 앞선 기능·가독성 문제보다 후순위입니다. **제한된 교정:** `DESIGN.md:3`에 맞게 주요 행동에는 브랜드 초록을 적용하고 상태는 텍스트 중심의 낮은 강조로 분리합니다. **재확인:** 상태가 읽히면서 상세 버튼이 행동 대상으로 구분되는지 확인합니다. 근거: `browser-observations.json`의 `styles`와 직접 본 `desktop-focus-viewport.png`.

유지할 패턴은 검색 입력의 명시적 label 연결, 기본 button의 키보드 동작, 주문·고객·상태·작업의 표 구조, 읽을 수 있는 상태 문구입니다. 교정은 제안만 했으며 제품 전역 재설계나 의존성 추가는 하지 않았습니다.

검증은 기존 Chrome과 제공된 공통 preview transport를 이용한 loopback 검사로 수행했습니다. 1280×900 및 390×844 뷰포트 화면을 캡처한 뒤 직접 열어 확인했고, Tab 이동·Enter 실행·주문번호/고객 검색·0건·검색 지우기를 실행했습니다. 초기 Enter 이벤트는 문자 필드가 빠져 활성화되지 않았으나, 후속 검사에서 해당 필드를 포함해 정상 동작을 확인했습니다. 이를 제품의 키보드 실행 결함으로 판정하지 않았습니다. 브라우저 서버 2개는 종료되고 임시 profile은 남지 않았습니다(`verification.json`).

남은 미검증: 실제 상세 데이터/API, 보조기기 음성 안내, 물리적 모바일 기기·터치, 다른 브라우저, 장문·대량 주문입니다. 화면 영향 설명은 관찰에 근거한 진단이며 사용자 연구로 측정한 결과는 아닙니다. 빌드·린트·타입 검사 설정은 없고 제품 변경도 없어 해당 명령은 실행하지 않았습니다. 전체 접근성 준수 여부를 판정한 것은 아닙니다.

명령 및 stdout/stderr: `scratch/commands.log`. 관찰 자료: `scratch/browser-observations.json`, `scratch/browser-followup.json`, 화면 PNG. 무변경 증거: `scratch/product-before.json`, `scratch/product-after.json`, `scratch/verification.json`.
