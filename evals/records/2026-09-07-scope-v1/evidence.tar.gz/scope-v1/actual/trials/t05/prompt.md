독립된 UI 수정 또는 진단 과제를 수행한다. 아래 TASK의 요청만 처리하고, 지정된 스킬 snapshot을 직접 읽어 적용한다.

작업 제품: /var/folders/dt/8hl_lk4517vfdrvql7_0n2b80000gn/T/lutriva-issue-delivery-mt6la1md/issue-6-evals/trials/t05/product
TASK 파일: /var/folders/dt/8hl_lk4517vfdrvql7_0n2b80000gn/T/lutriva-issue-delivery-mt6la1md/issue-6-evals/trials/t05/TASK.md
읽을 스킬 snapshot: /var/folders/dt/8hl_lk4517vfdrvql7_0n2b80000gn/T/lutriva-issue-delivery-mt6la1md/issue-6-evals/snapshots/source-a
스킬 진입점: skills/ui-slop-audit/SKILL.md
제품 밖 임시 검증/출력 폴더: /var/folders/dt/8hl_lk4517vfdrvql7_0n2b80000gn/T/lutriva-issue-delivery-mt6la1md/issue-6-evals/trials/t05/scratch
선택적 공통 브라우저 preview 도구: /var/folders/dt/8hl_lk4517vfdrvql7_0n2b80000gn/T/lutriva-issue-delivery-mt6la1md/issue-6-evals/snapshots/tools/README.md (same folder browser_harness.mjs; optional transport only)

TASK의 product/... 표기는 위 작업 제품 폴더 안의 해당 파일을 가리킨다. 먼저 TASK와 지정된 스킬 SKILL.md를 읽고, 필요한 reference를 같은 snapshot 안에서 읽는다. 다른 설치 스킬이나 다른 snapshot은 로드하지 않는다. TASK와 실제 제품 코드/디자인 기록을 확인한 뒤 범위에 맞게 수행한다. 사용자는 이 TASK의 작업과 필요한 가역적 검증을 승인했다.

- 모든 제품 명령의 workdir은 위 작업 제품 경로로 명시한다. 상속된 기본 작업 디렉터리에서 파일을 수정하지 않는다.
- 제품에서 쓸 수 있는 파일/영역은 TASK가 허용한 범위뿐이다. TASK가 읽기 전용이면 제품 파일 추가·수정·삭제를 하지 않는다.
- 다른 에이전트도 같은 파일시스템을 사용한다. 지정한 제품과 임시 검증/출력 폴더 밖의 파일, 다른 제품 복사본, 스킬 snapshot, 평가 검사 파일을 수정하지 않는다. 다른 trial이나 평가 구현을 찾아 읽지 않는다.
- 새 의존성 설치, git commit/branch/push, 외부 메시지 전송, 하위 에이전트 위임은 하지 않는다. 필요한 작은 임시 스크립트·스크린샷·검증 로그는 위 scratch 폴더에만 둔다.
- 실제 실행한 명령과 stdout/stderr를 scratch/commands.log에 기록한다. 직접 관찰한 화면만 screenshot이라고 부른다. 실행하지 않은 검사나 사용할 수 없는 도구는 미검증으로 적고, 가능한 범위의 작업을 마친다.
- 이 환경은 macOS, Node 25.2.1, Python 3.14.7, 기존 Chrome 152다. Chrome 실행 파일은 /Applications/Google Chrome.app/Contents/MacOS/Google Chrome 이다. 브라우저를 쓰면 이 제품만 loopback 서버·새 임시 profile로 열고 종료/정리를 완료한다.
- 스킬 사용 방식은 제공된 snapshot의 직접 읽기다. 호스트의 자동 발견이나 설치된 스킬 호출이 입증됐다고 보고하지 않는다.

작업을 마치면 scratch/agent-output.md에 변경 파일, 요청에 대한 실제 처리, 실행한 검증과 관찰 결과, 남은 미검증 항목을 간결한 한국어로 기록한다. 마지막 답변에도 같은 사실과 산출물 경로를 남긴다. 요구사항을 바꾸거나 제품을 전역 재설계하지 않는다.
