결과: [agent-output.md](/var/folders/dt/8hl_lk4517vfdrvql7_0n2b80000gn/T/lutriva-issue-delivery-mt6la1md/issue-6-evals/trials/t05/scratch/agent-output.md)

제품 수정 없이 7개 문제를 우선순위로 진단했습니다. 상세 정보 미표시, 포커스 표시 부재, 검색 누락·빈 결과 안내 부족을 먼저 다뤘습니다.

Chrome 두 뷰포트에서 화면·키보드·검색 동작을 확인했고, 제품 파일의 내용·종류·권한이 그대로임을 검증했습니다. 임시 브라우저와 서버도 정리했습니다.

실제 상세 API, 보조기기, 물리적 모바일 기기는 미검증입니다.
