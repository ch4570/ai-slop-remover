import os, subprocess, sys, shlex
from pathlib import Path
cmd = sys.argv[1:]
p = subprocess.run(cmd, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
with (Path(__file__).parent / "commands.log").open("a") as f:
    f.write("$ " + shlex.join(cmd) + "\nCWD: " + os.getcwd() + "\nSTDOUT:\n" + p.stdout + "\nSTDERR:\n" + p.stderr + "\nEXIT: " + str(p.returncode) + "\n\n")
print(p.stdout, end="")
print(p.stderr, end="", file=sys.stderr)
sys.exit(p.returncode)
