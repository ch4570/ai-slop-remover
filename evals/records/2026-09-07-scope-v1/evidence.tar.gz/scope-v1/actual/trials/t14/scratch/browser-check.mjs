import { withBrowser } from '/var/folders/dt/8hl_lk4517vfdrvql7_0n2b80000gn/T/lutriva-issue-delivery-mt6la1md/issue-6-evals/snapshots/tools/browser_harness.mjs';
import { writeFile, mkdir } from 'node:fs/promises';
import assert from 'node:assert/strict';
import path from 'node:path';
const product = process.cwd();
const scratch = path.dirname(new URL(import.meta.url).pathname);
const phase = process.argv[2];
assert(['before','after'].includes(phase));
const output = path.join(scratch, phase);
await mkdir(output, {recursive:true});
const results = [];
await withBrowser(product, output, async ({origin, page, evaluate, screenshot, pause, exceptions}) => {
  const key = async (key, code, virtual, text) => {
    await page('Input.dispatchKeyEvent', {type:'keyDown', key, code, windowsVirtualKeyCode:virtual, ...(text ? {text} : {})});
    await page('Input.dispatchKeyEvent', {type:'keyUp', key, code, windowsVirtualKeyCode:virtual});
  };
  for (const width of [1280,390]) {
    const height = width === 1280 ? 900 : 844;
    await page('Emulation.setDeviceMetricsOverride', {width,height,deviceScaleFactor:1,mobile:false});
    for (const route of ['master.html','compare.html']) {
      await page('Page.navigate', {url:origin+'/'+route});
      let ready = false;
      for (let n=0;n<100;n++) {
        ready = await evaluate(`location.pathname === '/${route}' && document.readyState === 'complete' && !!document.querySelector('tbody tr')`);
        if(ready) break;
        await pause(20);
      }
      assert(ready, `${route} did not load`);
      await evaluate('document.fonts.ready');
      const metrics = await evaluate(`(() => {
        const table = document.querySelector('table');
        const scroll = document.querySelector('.table-scroll');
        const cell = table.querySelector('td');
        const button = document.querySelector('[data-order]');
        const css = getComputedStyle(cell);
        const rect = e => {const r=e.getBoundingClientRect(); return {x:r.x,y:r.y,width:r.width,height:r.height}};
        return {title:document.title,width:innerWidth,documentWidth:document.documentElement.scrollWidth,table:rect(table),scroll:rect(scroll),scrollClient:scroll.clientWidth,scrollWidth:scroll.scrollWidth,overflowX:getComputedStyle(scroll).overflowX,paddingBlock:css.paddingBlockStart,headerPadding:getComputedStyle(table.querySelector('th')).paddingBlockStart,font:css.font,color:css.color,brand:getComputedStyle(document.documentElement).getPropertyValue('--brand').trim(),radius:getComputedStyle(scroll).borderRadius,rows:[...table.querySelectorAll('tbody tr')].map(row=>({text:row.innerText,height:row.getBoundingClientRect().height})),button:rect(button),detail:document.getElementById('detail').textContent};
      })()`);
      const expectedPadding = phase === 'after' && route === 'compare.html' ? '10px' : '16px';
      assert.equal(metrics.paddingBlock, expectedPadding);
      assert.equal(metrics.headerPadding, expectedPadding);
      assert.equal(metrics.rows.length, 3);
      assert.equal(metrics.documentWidth, width, 'Page overflow');
      assert.equal(metrics.brand,'#235942');
      assert.equal(metrics.radius,'8px');
      assert.equal(metrics.detail,'주문을 선택해 주세요.');
      await screenshot(`${route.replace('.html','')}-${width}.png`);
      const focusSequence = [];
      for (const expected of ['모아 주문','비교','M-101']) {
        let got;
        for(let tries=0;tries<3;tries++) {
          await key('Tab','Tab',9);
          got=await evaluate(`({name:document.activeElement.dataset.order || document.activeElement.textContent,tag:document.activeElement.tagName,focusVisible:document.activeElement.matches(':focus-visible'),outline:getComputedStyle(document.activeElement).outline,outlineOffset:getComputedStyle(document.activeElement).outlineOffset})`);
          if(got.tag==='DIV' && got.name.includes('M-101')) continue;
          break;
        }
        assert.equal(got.name,expected, `Unexpected Tab order in ${route}`);
        assert(got.focusVisible,'Focus was not visible');
        assert(got.outline.includes('3px'),'Expected focus outline');
        focusSequence.push(got);
      }
      await evaluate('new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve)))');
      const focusGeometry = await evaluate(`(() => {const a=document.activeElement.getBoundingClientRect();const s=document.querySelector('.table-scroll').getBoundingClientRect();return {left:a.left,right:a.right,top:a.top,bottom:a.bottom,scrollLeft:document.querySelector('.table-scroll').scrollLeft,containerLeft:s.left,containerRight:s.right,viewportWidth:innerWidth};})()`);
      console.log(JSON.stringify({phase,route,width,focusGeometry}));
      await screenshot(`${route.replace('.html','')}-${width}-tab-focus.png`);
      let scrollEvidence = null;
      if(width === 390) {
        assert(metrics.scrollWidth>metrics.scrollClient,'Expected table to scroll at narrow width');
        assert.equal(metrics.overflowX,'auto');
        const start=await evaluate("document.querySelector('.table-scroll').scrollLeft");
        await page('Input.dispatchMouseEvent', {type:'mouseWheel',x:200,y:260,deltaX:800,deltaY:0});
        for(let attempt=0;attempt<30;attempt++) {
          const atEnd=await evaluate("Math.abs(document.querySelector('.table-scroll').scrollWidth-document.querySelector('.table-scroll').clientWidth-document.querySelector('.table-scroll').scrollLeft)<1");
          if(atEnd) break;
          await pause(20);
        }
        scrollEvidence=await evaluate(`(() => {const s=document.querySelector('.table-scroll');return {start:${start},end:s.scrollLeft,max:s.scrollWidth-s.clientWidth,method:'CDP horizontal mouseWheel'};})()`);
        assert(scrollEvidence.end>0);
        assert.equal(scrollEvidence.end,scrollEvidence.max);
      }
      const revealedFocus=await evaluate(`(() => {const a=document.activeElement.getBoundingClientRect();const s=document.querySelector('.table-scroll').getBoundingClientRect();return {left:a.left,right:a.right,containerLeft:s.left,containerRight:s.right,focusVisible:document.activeElement.matches(':focus-visible'),order:document.activeElement.dataset.order};})()`);
      assert(revealedFocus.left>=revealedFocus.containerLeft && revealedFocus.right<=revealedFocus.containerRight,'Focused action inaccessible after horizontal scroll');
      assert(revealedFocus.focusVisible);
      assert.equal(revealedFocus.order,'M-101');
      await screenshot(`${route.replace('.html','')}-${width}-focus.png`);
      await key('Enter','Enter',13,'\r');
      assert.equal(await evaluate(`document.getElementById('detail').textContent`),'M-101 주문을 선택했습니다.');
      await key('Tab','Tab',9);
      assert.equal(await evaluate('document.activeElement.dataset.order'),'M-102');
      await key(' ','Space',32,' ');
      assert.equal(await evaluate(`document.getElementById('detail').textContent`),'M-102 주문을 선택했습니다.');
      await key('Tab','Tab',9);
      assert.equal(await evaluate('document.activeElement.dataset.order'),'M-103');
      await key('Enter','Enter',13,'\r');
      assert.equal(await evaluate(`document.getElementById('detail').textContent`),'M-103 주문을 선택했습니다.');
      await screenshot(`${route.replace('.html','')}-${width}-selected.png`);
      results.push({route,width,height,metrics,focusSequence,focusGeometry,revealedFocus,scrollEvidence,details:'M-101 Enter, M-102 Space, M-103 Enter: expected status observed'});
    }
  }
  assert.equal(exceptions.length,0,'Uncaught runtime exception');
});
await writeFile(path.join(scratch,`${phase}-browser.json`),JSON.stringify({phase,results},null,2)+'\n');
console.log(JSON.stringify({phase,results},null,2));
console.log('Browser callback finished; transport closed Chrome/server and removed its temporary profile.');
