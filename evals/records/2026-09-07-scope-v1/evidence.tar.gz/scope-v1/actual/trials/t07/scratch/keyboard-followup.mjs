import { withBrowser } from "/var/folders/dt/8hl_lk4517vfdrvql7_0n2b80000gn/T/lutriva-issue-delivery-mt6la1md/issue-6-evals/snapshots/tools/browser_harness.mjs";
import { writeFile, readdir } from 'node:fs/promises';
const scratch = "/var/folders/dt/8hl_lk4517vfdrvql7_0n2b80000gn/T/lutriva-issue-delivery-mt6la1md/issue-6-evals/trials/t07/scratch";
process.env.TMPDIR = scratch + '/browser-temp';
const result = {};
await withBrowser("/var/folders/dt/8hl_lk4517vfdrvql7_0n2b80000gn/T/lutriva-issue-delivery-mt6la1md/issue-6-evals/trials/t07/product", scratch + '/screenshots', async ({ origin, page, evaluate, pause, exceptions }) => {
  result.origin = origin;
  await page('Page.navigate', {url: origin + '/index.html'});
  for (let i=0; i<100; i++) {
    if (await evaluate("document.readyState === 'complete'")) break;
    await pause(30);
  }
  await evaluate("window.auditEvents = []; ['keydown', 'keypress', 'keyup', 'click'].forEach(type => document.addEventListener(type, event => window.auditEvents.push({type, key:event.key, tag:event.target.tagName, order:event.target.dataset.order, trusted:event.isTrusted})))");
  const key = async (name, code, vk, text) => {
    await page('Input.dispatchKeyEvent', {type:'keyDown', key:name, code, windowsVirtualKeyCode:vk, ...(text ? {text, unmodifiedText:text} : {})});
    await page('Input.dispatchKeyEvent', {type:'keyUp', key:name, code, windowsVirtualKeyCode:vk});
    await pause(80);
  };
  const state = () => evaluate("({status: document.getElementById('detail').textContent, active: document.activeElement.outerHTML, visibleOrders:[...document.querySelectorAll('tbody tr')].filter(r => !r.hidden).map(r=>r.cells[0].textContent), url:location.href, bodyText:document.body.innerText, dialogs:document.querySelectorAll('dialog,[role=dialog]').length})");
  const capture = async (name) => {
    const shot = await page('Page.captureScreenshot', {format:'png', captureBeyondViewport:false});
    await writeFile(scratch+'/screenshots/'+name, Buffer.from(shot.data,'base64'));
  };
  for(let i=0;i<3;i++) await key('Tab','Tab',9);
  result.beforeEnter = await state();
  await capture('desktop-detail-focus-viewport.png');
  await key('Enter','Enter',13,'\r');
  result.afterEnter = await state();
  await pause(1200);
  result.afterWait = await state();
  await capture('desktop-detail-corrected.png');
  await key('Tab','Tab',9);
  await key(' ','Space',32,' ');
  result.afterSpace = await state();
  await evaluate("document.getElementById('order-search').focus()");
  await page('Input.insertText',{text:'아무주문없음'});
  result.afterEmptyQuery = await state();
  result.events = await evaluate('window.auditEvents');
  await page('Emulation.setDeviceMetricsOverride',{width:320,height:740,deviceScaleFactor:1,mobile:false});
  await page('Page.navigate',{url:origin+'/index.html'});
  await pause(200);
  for(let i=0;i<3;i++) await key('Tab','Tab',9);
  result.smallFocus = await evaluate("(() => {const order=document.getElementById('orders'),button=document.activeElement;return {orderScrollLeft:order.scrollLeft,section:order.getBoundingClientRect().toJSON(),button:button.getBoundingClientRect().toJSON(),active:button.outerHTML}})()");
  await capture('small-keyboard-focus.png');
  result.exceptions = exceptions;
  await writeFile(scratch+'/keyboard-followup.json',JSON.stringify(result,null,2)+'\n');
  console.log(JSON.stringify(result,null,2));
});
let listenerClosed=false;
try{await fetch(result.origin,{signal:AbortSignal.timeout(1000)})}catch{listenerClosed=true}
const cleanup={listenerClosed,profilesLeft:await readdir(scratch+'/browser-temp')};
await writeFile(scratch+'/keyboard-cleanup.json',JSON.stringify(cleanup,null,2)+'\n');
console.log('Cleanup: '+JSON.stringify(cleanup));
