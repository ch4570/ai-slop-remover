import { withBrowser } from "/var/folders/dt/8hl_lk4517vfdrvql7_0n2b80000gn/T/lutriva-issue-delivery-mt6la1md/issue-6-evals/snapshots/tools/browser_harness.mjs";
import { mkdir, writeFile, readdir } from 'node:fs/promises';
const product = "/var/folders/dt/8hl_lk4517vfdrvql7_0n2b80000gn/T/lutriva-issue-delivery-mt6la1md/issue-6-evals/trials/t07/product";
const scratch = "/var/folders/dt/8hl_lk4517vfdrvql7_0n2b80000gn/T/lutriva-issue-delivery-mt6la1md/issue-6-evals/trials/t07/scratch";
const temp = scratch + '/browser-temp';
await mkdir(temp, { recursive: true });
process.env.TMPDIR = temp;
const results = {};
await withBrowser(product, scratch + '/screenshots', async ({ origin, page, evaluate, screenshot, pause, exceptions }) => {
  results.origin = origin;
  results.browser = await page('Browser.getVersion');
  await page('Page.navigate', { url: origin + '/index.html' });
  for (let i = 0; i < 100; i++) {
    if (await evaluate("document.readyState === 'complete' && !!document.getElementById('order-search')")) break;
    await pause(30);
  }
  const rects = () => evaluate(`(() => {
    const out = {};
    for (const selector of ['.promotion', '.promotion a', '#orders', '#orders h2', '#order-search', 'table', 'tbody tr', '.badge', '[data-order]', '#detail']) {
      const node = document.querySelector(selector);
      const box = node.getBoundingClientRect();
      const style = getComputedStyle(node);
      out[selector] = { x: box.x, y: box.y, width: box.width, height: box.height, right: box.right, bottom: box.bottom, clientWidth: node.clientWidth, scrollWidth: node.scrollWidth, background: style.backgroundColor, color: style.color, border: style.border, outline: style.outline, shadow: style.boxShadow };
    }
    return { viewport: {width: innerWidth, height: innerHeight}, scrollY, pageWidth: document.documentElement.scrollWidth, elements: out };
  })()`);
  const state = () => evaluate(`(() => ({
    query: document.getElementById('order-search').value,
    visibleOrders: [...document.querySelectorAll('tbody tr')].filter(row => !row.hidden).map(row => row.cells[0].textContent),
    status: document.getElementById('detail').textContent,
    active: { tag: document.activeElement.tagName, id: document.activeElement.id, order: document.activeElement.dataset.order || null },
    text: document.getElementById('orders').innerText
  }))()`);
  const key = async (key, code, virtualKeyCode) => {
    await page('Input.dispatchKeyEvent', { type: 'keyDown', key, code, windowsVirtualKeyCode: virtualKeyCode, nativeVirtualKeyCode: virtualKeyCode });
    await page('Input.dispatchKeyEvent', { type: 'keyUp', key, code, windowsVirtualKeyCode: virtualKeyCode, nativeVirtualKeyCode: virtualKeyCode });
    await pause(50);
  };
  results.desktopInitial = await rects();
  results.initialState = await state();
  await screenshot('desktop-initial.png');
  await key('Tab', 'Tab', 9);
  results.firstTab = { state: await state(), geometry: await rects(), focus: await evaluate("({text: document.activeElement.textContent, outline: getComputedStyle(document.activeElement).outline, shadow: getComputedStyle(document.activeElement).boxShadow})") };
  await screenshot('desktop-first-tab.png');
  await key('Tab', 'Tab', 9);
  results.secondTab = { state: await state(), geometry: await rects(), focus: await evaluate("({outline: getComputedStyle(document.activeElement).outline, shadow: getComputedStyle(document.activeElement).boxShadow})") };
  await screenshot('desktop-search-focus.png');
  await key('Tab', 'Tab', 9);
  results.thirdTab = { state: await state(), focus: await evaluate("({outline: getComputedStyle(document.activeElement).outline, shadow: getComputedStyle(document.activeElement).boxShadow})") };
  await screenshot('desktop-detail-focus.png');
  await key('Enter', 'Enter', 13);
  await pause(250);
  results.detailAfterEnter = await state();
  await pause(1200);
  results.detailAfterWait = await state();
  results.detailUrl = await evaluate('location.href');
  await screenshot('desktop-detail-result.png');
  results.searches = [];
  for (const query of ['M-102', '박도윤', 'm-102', ' M-102 ', '존재하지않음', '']) {
    await evaluate("(() => { const input = document.getElementById('order-search'); input.focus(); input.value = ''; input.dispatchEvent(new Event('input', { bubbles: true })); })()");
    if (query) await page('Input.insertText', { text: query });
    await pause(50);
    results.searches.push(await state());
    if (query === '존재하지않음') await screenshot('desktop-no-results.png');
  }
  await page('Page.navigate', { url: origin + '/index.html' });
  await pause(200);
  await page('Emulation.setDeviceMetricsOverride', { width: 390, height: 844, deviceScaleFactor: 1, mobile: false });
  await evaluate('window.scrollTo(0, 0)');
  await pause(100);
  results.narrowInitial = await rects();
  await screenshot('narrow-initial.png');
  await evaluate("document.getElementById('orders').scrollIntoView()");
  await pause(100);
  results.narrowOrders = await rects();
  await screenshot('narrow-orders.png');
  await page('Emulation.setDeviceMetricsOverride', { width: 320, height: 740, deviceScaleFactor: 1, mobile: false });
  await evaluate("document.getElementById('orders').scrollIntoView()");
  await pause(100);
  results.smallOrders = await rects();
  await screenshot('small-orders.png');
  results.exceptions = exceptions;
  await writeFile(scratch + '/browser-observations.json', JSON.stringify(results, null, 2) + '\n');
  console.log(JSON.stringify(results, null, 2));
});
const profilesLeft = await readdir(temp);
let listenerClosed = false;
try {
  await fetch(results.origin, { signal: AbortSignal.timeout(1000) });
} catch {
  listenerClosed = true;
}
const cleanup = { listenerClosed, profilesLeft };
await writeFile(scratch + '/browser-cleanup.json', JSON.stringify(cleanup, null, 2) + '\n');
console.log('Cleanup: ' + JSON.stringify(cleanup));
