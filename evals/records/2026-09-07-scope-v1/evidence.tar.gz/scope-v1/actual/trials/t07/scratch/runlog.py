from pathlib import Path
import subprocess, sys, datetime
root = Path("/var/folders/dt/8hl_lk4517vfdrvql7_0n2b80000gn/T/lutriva-issue-delivery-mt6la1md/issue-6-evals/trials/t07/product")
log = Path("/var/folders/dt/8hl_lk4517vfdrvql7_0n2b80000gn/T/lutriva-issue-delivery-mt6la1md/issue-6-evals/trials/t07/scratch/commands.log")
command = sys.argv[1]
result = subprocess.run(command, shell=True, executable="/bin/zsh", cwd=root, text=True, capture_output=True)
with log.open("a") as stream:
    stream.write("\n" + datetime.datetime.now().isoformat() + "\nworkdir: " + str(root) + "\n$ " + command + "\nstdout:\n" + result.stdout + "\nstderr:\n" + result.stderr + "\nexit: " + str(result.returncode) + "\n")
sys.stdout.write(result.stdout)
sys.stderr.write(result.stderr)
raise SystemExit(result.returncode)
