import datetime
import json
from pathlib import Path
import subprocess
import sys

scratch = Path(__file__).resolve().parent
product = scratch.parent / 'product'
args = sys.argv[1:]
with (scratch / 'commands.log').open('a') as log:
    log.write('\nTIME: ' + datetime.datetime.now(datetime.timezone.utc).isoformat() + '\n')
    log.write('CWD: ' + str(product) + '\nCOMMAND: ' + json.dumps(args, ensure_ascii=False) + '\n')
    log.flush()
    result = subprocess.run(args, cwd=product, capture_output=True, text=True)
    log.write('STDOUT:\n' + result.stdout + '\nSTDERR:\n' + result.stderr + '\nEXIT: ' + str(result.returncode) + '\n')
sys.stdout.write(result.stdout)
sys.stderr.write(result.stderr)
sys.exit(result.returncode)
