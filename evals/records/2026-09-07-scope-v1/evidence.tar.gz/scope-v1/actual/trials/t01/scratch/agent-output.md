`product/settings.css:1`의 `.actions`에 있는 `margin-top`만 `var(--space-6)`에서 `var(--space-4)`로 변경했다. 기존 16px 토큰을 재사용했으며 제품 파일 추가·삭제나 다른 변경은 없다.

- `DESIGN.md`와 지정된 source-a의 `ui-visual-refine` 스냅샷 및 관련 참조를 직접 읽어 적용했다. 호스트 자동 발견·설치 호출을 사용한 것은 아니다.
- 기존 Chrome의 375×812 화면을 변경 전후 캡처해 직접 관찰했다. 버튼 위 실제 간격은 24px→16px이며 가로 넘침, 잘림, 겹침 없이 폼과 상태 문구가 읽힌다.
- Tab으로 입력란→저장 버튼, Shift+Tab으로 역방향 이동을 확인했다. 입력란과 버튼의 갈색 3px 포커스 외곽선이 보이고 잘리지 않는다.
- 이름 입력 후 키보드 Enter로 저장 성공 문구와 localStorage 값을 확인했고, 새로고침 후 같은 이름이 복구됐다. 런타임 예외는 없었다. 첫 저장 검증은 합성 Enter의 문자 전달 누락으로 실패했으며, scratch 검증 스크립트를 보완한 재실행은 통과했다.
- 전체 제품 파일 해시·파일 목록·문자열 diff로 허용된 선언만 변경됐음을 확인했다. `node --check app.js`도 통과했다.
- loopback 서버 종료와 임시 Chrome 프로필 삭제를 확인했다. 검증 스크립트·기록·이미지는 scratch에만 저장했다.

미검증: 별도 lint·build·typecheck·기존 테스트 명령은 제품에 설정이 없어 실행하지 않았다. 다른 브라우저·화면 폭은 검사하지 않았다. 요청 범위 안에서 남은 결함은 관찰되지 않았다.

증거: `commands.log`, `before-browser.json`, `after-browser.json`, `visual-verdict.json`, `before-375.png`, `after-375.png`, `after-375-input-focus.png`, `after-375-button-focus.png`, `after-375-saved.png`.

산출물: `/var/folders/dt/8hl_lk4517vfdrvql7_0n2b80000gn/T/lutriva-issue-delivery-mt6la1md/issue-6-evals/trials/t01/scratch/agent-output.md`
