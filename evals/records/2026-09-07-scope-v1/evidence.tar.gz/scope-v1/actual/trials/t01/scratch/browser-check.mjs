import assert from 'node:assert/strict';
import { mkdir, readdir, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { withBrowser } from '/var/folders/dt/8hl_lk4517vfdrvql7_0n2b80000gn/T/lutriva-issue-delivery-mt6la1md/issue-6-evals/snapshots/tools/browser_harness.mjs';

const scratch = path.dirname(new URL(import.meta.url).pathname);
const product = path.resolve(scratch, '../product');
const mode = process.argv[2];
assert.ok(['before', 'after'].includes(mode));
const temp = path.join(scratch, 'browser-tmp');
await mkdir(temp, { recursive: true });
process.env.TMPDIR = temp;
let origin;
const report = await withBrowser(product, scratch, async ({ origin: address, page, evaluate, screenshot, pause, exceptions }) => {
  origin = address;
  await page('Emulation.setDeviceMetricsOverride', { width: 375, height: 812, deviceScaleFactor: 1, mobile: false });
  await page('Page.navigate', { url: origin + '/index.html' });
  for (let i = 0; i < 100; i++) {
    if (await evaluate("document.readyState === 'complete' && !!document.getElementById('save')")) break;
    await pause(30);
  }
  const layout = await evaluate(`(() => {
    const rect = selector => { const r = document.querySelector(selector).getBoundingClientRect(); return { x: r.x, y: r.y, width: r.width, height: r.height, right: r.right, bottom: r.bottom }; };
    return { viewport: innerWidth, documentWidth: document.documentElement.scrollWidth,
      marginTop: getComputedStyle(document.querySelector('.actions')).marginTop,
      input: rect('#name'), button: rect('#save'), status: rect('#status'),
      name: document.querySelector('#name').value,
      buttonBackground: getComputedStyle(document.querySelector('#save')).backgroundColor,
      statusText: document.querySelector('#status').textContent };
  })()`);
  assert.equal(layout.viewport, 375);
  assert.equal(layout.documentWidth, 375);
  assert.equal(layout.marginTop, mode === 'before' ? '24px' : '16px');
  assert.equal(layout.button.y - layout.input.bottom, mode === 'before' ? 24 : 16);
  for (const control of [layout.input, layout.button, layout.status]) {
    assert.ok(control.x >= 0 && control.right <= 375);
  }
  assert.equal(layout.buttonBackground, 'rgb(35, 89, 66)');
  await screenshot(`${mode}-375.png`);

  const key = async (name, code, vk) => {
    await page('Input.dispatchKeyEvent', { type: 'keyDown', key: name, code, windowsVirtualKeyCode: vk, ...(name === 'Enter' ? { text: '\r', unmodifiedText: '\r' } : {}) });
    await page('Input.dispatchKeyEvent', { type: 'keyUp', key: name, code, windowsVirtualKeyCode: vk });
  };
  const focusState = () => evaluate(`(() => { const el = document.activeElement; const style = getComputedStyle(el); return { id: el.id, visible: el.matches(':focus-visible'), outline: style.outlineStyle, color: style.outlineColor, width: style.outlineWidth }; })()`);
  await key('Tab', 'Tab', 9);
  const inputFocus = await focusState();
  assert.deepEqual(inputFocus, { id: 'name', visible: true, outline: 'solid', color: 'rgb(163, 72, 27)', width: '3px' });
  await screenshot(`${mode}-375-input-focus.png`);
  await key('Tab', 'Tab', 9);
  const buttonFocus = await focusState();
  assert.deepEqual(buttonFocus, { id: 'save', visible: true, outline: 'solid', color: 'rgb(163, 72, 27)', width: '3px' });
  await screenshot(`${mode}-375-button-focus.png`);

  let saved = null;
  if (mode === 'after') {
    await page('Input.dispatchKeyEvent', { type: 'keyDown', key: 'Tab', code: 'Tab', windowsVirtualKeyCode: 9, modifiers: 8 });
    await page('Input.dispatchKeyEvent', { type: 'keyUp', key: 'Tab', code: 'Tab', windowsVirtualKeyCode: 9, modifiers: 8 });
    assert.equal((await focusState()).id, 'name');
    await evaluate("document.querySelector('#name').select()");
    await page('Input.insertText', { text: '검증용 이름' });
    assert.equal(await evaluate("document.querySelector('#name').value"), '검증용 이름');
    await key('Tab', 'Tab', 9);
    assert.equal((await focusState()).id, 'save');
    await key('Enter', 'Enter', 13);
    for (let i = 0; i < 100; i++) {
      if (await evaluate("document.querySelector('#status').dataset.state === 'success'")) break;
      await pause(20);
    }
    saved = await evaluate(`({ state: document.querySelector('#status').dataset.state, text: document.querySelector('#status').textContent, stored: localStorage.getItem('display-name'), disabled: document.querySelector('#save').disabled })`);
    assert.deepEqual(saved, { state: 'success', text: '변경 사항을 저장했습니다.', stored: '검증용 이름', disabled: false });
    await screenshot('after-375-saved.png');
    await page('Page.reload');
    for (let i = 0; i < 100; i++) {
      if (await evaluate("document.readyState === 'complete' && document.querySelector('#name')?.value === '검증용 이름'")) break;
      await pause(30);
    }
    assert.equal(await evaluate("document.querySelector('#name').value"), '검증용 이름');
    saved.restoredAfterReload = true;
  }
  assert.deepEqual(exceptions, []);
  return { mode, layout, inputFocus, buttonFocus, saved, runtimeExceptions: exceptions };
});
assert.deepEqual(await readdir(temp), []);
let serverClosed = false;
try { await fetch(origin); } catch { serverClosed = true; }
assert.ok(serverClosed);
report.cleanup = { profileRemoved: true, serverClosed };
await writeFile(path.join(scratch, `${mode}-browser.json`), JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify(report, null, 2));
