`settings.css:1`의 `.actions` 간격만 `var(--space-4)`로 변경했습니다(24px→16px).

375px 화면, 갈색 키보드 포커스, 저장·새로고침 복구, JS 구문 검사와 변경 범위 검증이 통과했습니다. 별도 lint/build/typecheck 설정은 없어 미실행했습니다.

산출물: [agent-output.md](/var/folders/dt/8hl_lk4517vfdrvql7_0n2b80000gn/T/lutriva-issue-delivery-mt6la1md/issue-6-evals/trials/t01/scratch/agent-output.md)
