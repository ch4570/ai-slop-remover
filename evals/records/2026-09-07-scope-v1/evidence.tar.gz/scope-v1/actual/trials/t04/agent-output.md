`settings.css:1`의 `.actions` 간격만 기존 `--space-4`로 변경했습니다(24px → 16px).

375px 화면, 키보드 포커스, 저장·새로고침 복구, 변경 범위 검사 모두 통과했습니다. 브라우저 정리도 완료했습니다. 다른 화면 폭·브라우저·확대 배율은 미검증입니다.

산출물: [agent-output.md](/var/folders/dt/8hl_lk4517vfdrvql7_0n2b80000gn/T/lutriva-issue-delivery-mt6la1md/issue-6-evals/trials/t04/scratch/agent-output.md)
