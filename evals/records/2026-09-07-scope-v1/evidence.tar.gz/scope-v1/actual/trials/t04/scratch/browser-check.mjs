import assert from 'node:assert/strict';
import { writeFile } from 'node:fs/promises';
import { withBrowser } from '/var/folders/dt/8hl_lk4517vfdrvql7_0n2b80000gn/T/lutriva-issue-delivery-mt6la1md/issue-6-evals/snapshots/tools/browser_harness.mjs';
const root = '/var/folders/dt/8hl_lk4517vfdrvql7_0n2b80000gn/T/lutriva-issue-delivery-mt6la1md/issue-6-evals/trials/t04';
const stage = process.argv[2];
assert(['before', 'after'].includes(stage));
const expectedGap = stage === 'before' ? 24 : 16;
const result = await withBrowser(root + '/product', root + '/scratch/screenshots', async ({ origin, page, evaluate, screenshot, pause, exceptions }) => {
  await page('Emulation.setDeviceMetricsOverride', { width: 375, height: 812, deviceScaleFactor: 1, mobile: false });
  await page('Page.navigate', { url: origin + '/index.html' });
  const waitFor = async (expression) => {
    for (let i = 0; i < 100; i += 1) {
      if (await evaluate(expression)) return;
      await pause(25);
    }
    throw new Error('Readiness check timed out: ' + expression);
  };
  await waitFor("document.readyState === 'complete' && document.querySelector('#name')?.value === '민지'");
  const layout = await evaluate(`(() => {
    const rect = selector => {
      const r = document.querySelector(selector).getBoundingClientRect();
      return { x: r.x, y: r.y, width: r.width, height: r.height, right: r.right, bottom: r.bottom };
    };
    return { viewportWidth: innerWidth, documentWidth: document.documentElement.scrollWidth,
      marginTop: getComputedStyle(document.querySelector('.actions')).marginTop,
      gap: rect('.actions').y - rect('#name').bottom,
      main: rect('main'), input: rect('#name'), button: rect('#save'), status: rect('#status'),
      brand: getComputedStyle(document.querySelector('#save')).backgroundColor,
      surface: getComputedStyle(document.querySelector('main')).backgroundColor,
      radius: getComputedStyle(document.querySelector('main')).borderRadius,
      bodyOverflowX: getComputedStyle(document.body).overflowX,
      text: document.querySelector('main').innerText };
  })()`);
  assert.equal(layout.marginTop, expectedGap + 'px');
  assert.equal(layout.gap, expectedGap);
  assert.equal(layout.viewportWidth, 375);
  assert(layout.documentWidth <= 375, 'Horizontal overflow');
  for (const box of [layout.main, layout.input, layout.button, layout.status]) {
    assert(box.x >= 0 && box.right <= 375, 'Control or content outside narrow viewport');
    assert(box.bottom <= 812, 'Control or content outside initial screen');
  }
  assert.equal(layout.brand, 'rgb(35, 89, 66)');
  assert.equal(layout.surface, 'rgb(255, 255, 255)');
  assert.equal(layout.radius, '8px');
  await screenshot(stage + '-375.png');
  const press = async (key, code, virtualCode) => {
    await page('Input.dispatchKeyEvent', { type: 'keyDown', key, code, windowsVirtualKeyCode: virtualCode, ...(key === 'Enter' ? { text: '\r', unmodifiedText: '\r' } : {}) });
    await page('Input.dispatchKeyEvent', { type: 'keyUp', key, code, windowsVirtualKeyCode: virtualCode });
  };
  const focusInfo = () => evaluate(`(() => {
    const e = document.activeElement, s = getComputedStyle(e);
    return { id: e.id, visible: e.matches(':focus-visible'), outline: s.outlineStyle,
      width: s.outlineWidth, color: s.outlineColor, offset: s.outlineOffset };
  })()`);
  await press('Tab', 'Tab', 9);
  const inputFocus = await focusInfo();
  assert.equal(inputFocus.id, 'name');
  await press('Tab', 'Tab', 9);
  const buttonFocus = await focusInfo();
  assert.equal(buttonFocus.id, 'save');
  for (const focus of [inputFocus, buttonFocus]) {
    assert.equal(focus.visible, true);
    assert.equal(focus.outline, 'solid');
    assert.equal(focus.width, '3px');
    assert.equal(focus.color, 'rgb(163, 72, 27)');
    assert.equal(focus.offset, '3px');
  }
  await screenshot(stage + '-375-button-focus.png');
  let save = null;
  if (stage === 'after') {
    await page('Input.dispatchKeyEvent', { type: 'keyDown', key: 'Tab', code: 'Tab', windowsVirtualKeyCode: 9, modifiers: 8 });
    await page('Input.dispatchKeyEvent', { type: 'keyUp', key: 'Tab', code: 'Tab', windowsVirtualKeyCode: 9, modifiers: 8 });
    assert.equal((await focusInfo()).id, 'name');
    await evaluate("document.getElementById('name').select()");
    await page('Input.insertText', { text: '지수 검증' });
    await press('Tab', 'Tab', 9);
    assert.equal((await focusInfo()).id, 'save');
    await press('Enter', 'Enter', 13);
    await waitFor("document.getElementById('status').dataset.state === 'success'");
    save = await evaluate(`({ field: document.getElementById('name').value,
      stored: localStorage.getItem('display-name'), state: document.getElementById('status').dataset.state,
      message: document.getElementById('status').textContent, buttonDisabled: document.getElementById('save').disabled })`);
    assert.equal(save.field, '지수 검증');
    assert.equal(save.stored, '지수 검증');
    assert.equal(save.message, '변경 사항을 저장했습니다.');
    assert.equal(save.buttonDisabled, false);
    await screenshot('after-375-saved.png');
    await page('Page.reload', { ignoreCache: true });
    await waitFor("document.readyState === 'complete' && document.getElementById('name')?.value === '지수 검증'");
    save.restoredAfterReload = await evaluate("document.getElementById('name').value");
    assert.equal(save.restoredAfterReload, '지수 검증');
  }
  assert.deepEqual(exceptions, []);
  return { stage, layout, inputFocus, buttonFocus, save, runtimeExceptions: exceptions };
});
result.transportCleanup = 'withBrowser completed its finally block: Chrome terminated, loopback server closed, temporary profile removed';
await writeFile(root + '/scratch/' + stage + '-browser-results.json', JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify(result, null, 2));
