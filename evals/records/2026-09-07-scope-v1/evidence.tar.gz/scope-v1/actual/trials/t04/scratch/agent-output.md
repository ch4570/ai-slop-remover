변경: product/settings.css:1의 .actions에서 margin-top: var(--space-6)만 var(--space-4)로 변경했다(24px → 16px). 공통 토큰과 다른 제품 파일은 동일하며 파일 추가·삭제가 없음을 SHA-256 비교로 확인했다.

지정된 source-a의 ui-visual-refine/SKILL.md와 관련 reference, 제품 DESIGN.md를 직접 읽어 적용했다. 호스트 자동 발견이나 설치 스킬 호출을 검증한 것은 아니다. 수정 전 계획은 cleanup-plan.md에 기록했다.

확인 결과:

- Chrome 152, 375×812 화면에서 실제 간격 24px → 16px를 측정했다. 문서 폭은 375px이며 폼·버튼·피드백의 잘림과 겹침이 보이지 않았다.
- 직접 본 이미지: before-375.png, after-375.png, after-375-button-focus.png, after-375-saved.png(모두 screenshots 폴더).
- 실제 Tab 이동으로 이름 입력란 → 저장 버튼 순서를 확인했다. 양쪽의 갈색 3px 포커스 외곽선과 3px offset을 측정했고 버튼 외곽선이 온전히 보이는 것을 이미지에서 확인했다.
- 이름을 바꿔 Enter로 저장한 뒤 성공 문구·버튼 재활성화·localStorage 값·새로고침 후 같은 이름 복구를 확인했다. 첫 실행은 임시 CDP 스크립트의 Enter 텍스트 전달 누락으로 시간 초과했으며, 스크립트만 보정한 재실행은 통과했다. 제품의 저장 코드는 변경하지 않았다.
- node --check app.js, 간격·화면 폭·포커스·저장 상태 assertion, 제품 변경 범위 검사를 통과했다. 브라우저 runtime exception은 0건이었다.
- 이 제품만 loopback으로 열었다. Chrome·서버 종료와 scratch의 새 임시 profile 삭제가 완료됐다.

미검증: 다른 화면 폭·브라우저·확대 배율, 매우 짧은 저장 중 상태의 시각 검수. 별도 lint·typecheck·build 명령은 제품에 구성이 없어 실행하지 않았다.

실행 명령과 stdout/stderr: commands.log. 상세 증거: before-browser-results.json, after-browser-results.json, scope-check.json, visual-verdict.json.
