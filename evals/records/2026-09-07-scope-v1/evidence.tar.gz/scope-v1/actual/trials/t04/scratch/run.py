from pathlib import Path
import subprocess, sys, shlex
scratch = Path(__file__).resolve().parent
product = scratch.parent / "product"
command = sys.argv[1:]
result = subprocess.run(command, cwd=product, capture_output=True, text=True)
block = "\n$ " + shlex.join(command) + "\n[cwd] " + str(product) + "\n[stdout]\n" + result.stdout + "\n[stderr]\n" + result.stderr + "\n[exit] " + str(result.returncode) + "\n"
with (scratch / "commands.log").open("a") as log:
    log.write(block)
print(block)
sys.exit(result.returncode)
