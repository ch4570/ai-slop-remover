from pathlib import Path
import difflib
import hashlib
import json
import sys

scratch = Path(__file__).resolve().parent
product = scratch.parent / 'product'
files = {str(p.relative_to(product)): hashlib.sha256(p.read_bytes()).hexdigest()
         for p in product.rglob('*') if p.is_file()}
if sys.argv[1] == 'before':
    (scratch / 'product-before.json').write_text(json.dumps(files, indent=2) + '\n')
    (scratch / 'settings-before.css').write_bytes((product / 'settings.css').read_bytes())
    print('Recorded baseline for product files:', ', '.join(sorted(files)))
else:
    before = json.loads((scratch / 'product-before.json').read_text())
    assert files.keys() == before.keys(), 'Product file set changed'
    changed = [name for name in files if files[name] != before[name]]
    assert changed == ['settings.css'], changed
    old = (scratch / 'settings-before.css').read_bytes()
    new = (product / 'settings.css').read_bytes()
    expected_old = b'.actions { margin-top: var(--space-6); }\n'
    expected_new = b'.actions { margin-top: var(--space-4); }\n'
    assert old == expected_old and new == expected_new, 'Unexpected CSS change'
    print('PASS: Only .actions margin-top changed; other product files match baseline.')
    print(''.join(difflib.unified_diff(old.decode().splitlines(True), new.decode().splitlines(True),
                                     fromfile='before/settings.css', tofile='after/settings.css')))
    print('Remaining temporary Chrome profiles:', len(list(scratch.glob('slop-browser-*'))))
