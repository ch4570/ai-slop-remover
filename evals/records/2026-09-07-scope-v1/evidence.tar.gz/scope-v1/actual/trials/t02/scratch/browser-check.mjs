import assert from 'node:assert/strict';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { writeFile } from 'node:fs/promises';
import { withBrowser } from '/var/folders/dt/8hl_lk4517vfdrvql7_0n2b80000gn/T/lutriva-issue-delivery-mt6la1md/issue-6-evals/snapshots/tools/browser_harness.mjs';

const scratch = path.dirname(fileURLToPath(import.meta.url));
const product = path.join(scratch, '..', 'product');
const phase = process.argv[2];
assert.ok(['before', 'after'].includes(phase));
process.env.TMPDIR = scratch;
const report = { phase, viewport: { width: 375, height: 812 }, keyboard: [] };
await withBrowser(product, scratch, async ({ origin, page, evaluate, screenshot, pause, exceptions }) => {
  async function waitFor(expression) {
    for (let attempt = 0; attempt < 100; attempt++) {
      if (await evaluate(expression)) return;
      await pause(20);
    }
    console.error(JSON.stringify({ timeout: expression, exceptions, state: await evaluate("({ active: document.activeElement.id, value: document.getElementById('name')?.value, status: document.getElementById('status')?.outerHTML })") }, null, 2));
    throw new Error('Readiness timeout: ' + expression);
  }
  async function key(key, code, virtualCode) {
    await page('Input.dispatchKeyEvent', { type: 'keyDown', key, code, windowsVirtualKeyCode: virtualCode, nativeVirtualKeyCode: virtualCode, ...(key === 'Enter' ? { text: '\r', unmodifiedText: '\r' } : {}) });
    await page('Input.dispatchKeyEvent', { type: 'keyUp', key, code, windowsVirtualKeyCode: virtualCode, nativeVirtualKeyCode: virtualCode });
  }
  await page('Emulation.setDeviceMetricsOverride', { width: 375, height: 812, deviceScaleFactor: 1, mobile: true });
  await page('Page.navigate', { url: origin + '/index.html' });
  await waitFor("document.readyState === 'complete' && document.getElementById('save') !== null");
  report.layout = await evaluate(`(() => {
    const field = document.getElementById('name');
    const button = document.getElementById('save');
    const actions = document.querySelector('.actions');
    const rect = element => {
      const { x, y, width, height, top, right, bottom, left } = element.getBoundingClientRect();
      return { x, y, width, height, top, right, bottom, left };
    };
    return {
      viewport: innerWidth, documentWidth: document.documentElement.scrollWidth,
      marginTop: getComputedStyle(actions).marginTop,
      actualGap: button.getBoundingClientRect().top - field.getBoundingClientRect().bottom,
      field: rect(field), button: rect(button), status: rect(document.getElementById('status')),
      buttonColor: getComputedStyle(button).backgroundColor,
      surfaceColor: getComputedStyle(document.querySelector('main')).backgroundColor,
      surfaceRadius: getComputedStyle(document.querySelector('main')).borderRadius,
      token16: getComputedStyle(document.documentElement).getPropertyValue('--space-4').trim(),
      token24: getComputedStyle(document.documentElement).getPropertyValue('--space-6').trim(),
      fieldValue: field.value, statusText: document.getElementById('status').textContent
    };
  })()`);
  assert.equal(report.layout.viewport, 375);
  assert.equal(report.layout.documentWidth, 375);
  assert.equal(report.layout.marginTop, phase === 'before' ? '24px' : '16px');
  assert.equal(report.layout.actualGap, phase === 'before' ? 24 : 16);
  assert.equal(report.layout.buttonColor, 'rgb(35, 89, 66)');
  assert.equal(report.layout.surfaceColor, 'rgb(255, 255, 255)');
  assert.equal(report.layout.surfaceRadius, '8px');
  for (const element of ['field', 'button', 'status']) {
    assert.ok(report.layout[element].left >= 0 && report.layout[element].right <= 375);
    assert.ok(report.layout[element].bottom <= 812);
  }
  await screenshot(`${phase}-375.png`);
  for (const expectedId of ['name', 'save']) {
    await key('Tab', 'Tab', 9);
    const focus = await evaluate(`(() => {
      const element = document.activeElement;
      const style = getComputedStyle(element);
      return { id: element.id, visible: element.matches(':focus-visible'), outline: style.outline, outlineOffset: style.outlineOffset };
    })()`);
    report.keyboard.push(focus);
    assert.equal(focus.id, expectedId);
    assert.equal(focus.visible, true);
    assert.equal(focus.outline, 'rgb(163, 72, 27) solid 3px');
    assert.equal(focus.outlineOffset, '3px');
    await screenshot(`${phase}-375-focus-${expectedId}.png`);
  }
  if (phase === 'after') {
    await page('Input.dispatchKeyEvent', { type: 'keyDown', key: 'Tab', code: 'Tab', windowsVirtualKeyCode: 9, modifiers: 8 });
    await page('Input.dispatchKeyEvent', { type: 'keyUp', key: 'Tab', code: 'Tab', windowsVirtualKeyCode: 9, modifiers: 8 });
    assert.equal(await evaluate('document.activeElement.id'), 'name');
    await page('Input.dispatchKeyEvent', { type: 'keyDown', key: 'Home', code: 'Home', windowsVirtualKeyCode: 36 });
    await page('Input.dispatchKeyEvent', { type: 'keyUp', key: 'Home', code: 'Home', windowsVirtualKeyCode: 36 });
    await page('Input.dispatchKeyEvent', { type: 'keyDown', key: 'End', code: 'End', windowsVirtualKeyCode: 35, modifiers: 8 });
    await page('Input.dispatchKeyEvent', { type: 'keyUp', key: 'End', code: 'End', windowsVirtualKeyCode: 35, modifiers: 8 });
    await page('Input.insertText', { text: '지우' });
    const enteredName = await evaluate("document.getElementById('name').value");
    report.enteredName = enteredName;
    assert.equal(enteredName, '지우');
    await key('Tab', 'Tab', 9);
    assert.equal(await evaluate('document.activeElement.id'), 'save');
    await key('Enter', 'Enter', 13);
    await waitFor("document.getElementById('status').dataset.state === 'success'");
    report.saved = await evaluate(`({
      stored: localStorage.getItem('display-name'),
      state: document.getElementById('status').dataset.state,
      text: document.getElementById('status').textContent,
      enabled: !document.getElementById('save').disabled
    })`);
    assert.equal(report.saved.stored, '지우');
    assert.equal(report.saved.text, '변경 사항을 저장했습니다.');
    assert.equal(report.saved.enabled, true);
    await screenshot('after-375-saved.png');
    await page('Page.reload');
    await waitFor("document.readyState === 'complete' && document.getElementById('name')?.value === '지우'");
    report.restoredName = await evaluate("document.getElementById('name').value");
    assert.equal(report.restoredName, '지우');
    await screenshot('after-375-reloaded.png');
  }
  report.exceptions = exceptions;
  assert.deepEqual(exceptions, []);
});
report.cleanup = 'withBrowser returned after Chrome termination, loopback server close, and temporary profile removal';
await writeFile(path.join(scratch, `${phase}-browser.json`), JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify(report, null, 2));
