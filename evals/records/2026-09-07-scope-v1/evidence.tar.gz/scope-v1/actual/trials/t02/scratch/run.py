from pathlib import Path
import shlex
import subprocess
import sys

scratch = Path(__file__).resolve().parent
product = scratch.parent / 'product'
result = subprocess.run(sys.argv[1:], cwd=product, text=True, capture_output=True)
entry = ('$ ' + shlex.join(sys.argv[1:]) + '\n[cwd] ' + str(product)
         + '\n[stdout]\n' + result.stdout + '\n[stderr]\n' + result.stderr
         + '\n[exit] ' + str(result.returncode) + '\n')
with (scratch / 'commands.log').open('a') as log:
    log.write(entry)
print(entry, end='')
sys.exit(result.returncode)
