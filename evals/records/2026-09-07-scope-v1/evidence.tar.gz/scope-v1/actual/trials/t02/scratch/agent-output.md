`product/settings.css:1`의 `.actions`에서 `margin-top`을 `var(--space-6)`에서 `var(--space-4)`로 바꿨다. 기존 토큰을 재사용해 저장 버튼 위 간격만 24px에서 16px로 줄였다. 제품 파일 해시와 단일 선언 diff로 다른 변경이 없음을 확인했다.

- 지정된 `source-b/skills/ui-visual-refine/SKILL.md`와 필요한 참조, 제품 `DESIGN.md`를 직접 읽어 적용했다. 호스트 자동 발견·설치 스킬 호출을 검증한 것은 아니다.
- Chrome 375×812에서 변경 전후 화면을 직접 확인했다. DOM 실측 간격은 24px → 16px이고 가로 넘침, 문구 잘림, 겹침은 없었다. 초록 버튼, 흰 표면, 8px 모서리는 유지됐다.
- Tab으로 입력창과 저장 버튼에 차례로 이동했고, 두 요소의 갈색 3px 포커스 외곽선을 실제 화면에서 확인했다. Enter 저장 성공, 버튼 재활성화, 새로고침 후 `지우` 복구도 통과했다. 브라우저 JavaScript 예외는 0건이었다.
- `node --check app.js`와 제품 변경 범위 검사가 통과했다. 최초 저장 검증은 임시 CDP 스크립트의 Enter 텍스트 이벤트 누락으로 실패했으며, 스크립트 보정 후 전체 확인이 통과했다. 실패·재실행의 stdout/stderr를 모두 `commands.log`에 남겼다.
- 제품 전용 loopback 서버와 임시 Chrome을 종료했고, scratch 내 임시 프로필 잔여 수는 0개다.

미검증: 다른 브라우저·화면 폭, 확대 화면, 순간적인 저장 중 상태의 시각 표현. 저장소에 별도 lint·타입 검사·빌드·테스트 실행 설정이 없어 해당 검사는 실행하지 않았다.

근거: `commands.log`, `before-browser.json`, `after-browser.json`, `visual-verdict.md`, 변경 전후 375px 및 포커스·저장·복구 PNG. 모든 검증 스크립트와 산출물은 이 scratch 폴더에만 두었다.
