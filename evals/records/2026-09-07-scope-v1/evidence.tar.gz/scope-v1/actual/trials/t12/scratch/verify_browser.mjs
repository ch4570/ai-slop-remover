import assert from 'node:assert/strict';
import { writeFile, readdir } from 'node:fs/promises';
import { withBrowser } from '/var/folders/dt/8hl_lk4517vfdrvql7_0n2b80000gn/T/lutriva-issue-delivery-mt6la1md/issue-6-evals/snapshots/tools/browser_harness.mjs';

const product = process.cwd();
const scratch = '/var/folders/dt/8hl_lk4517vfdrvql7_0n2b80000gn/T/lutriva-issue-delivery-mt6la1md/issue-6-evals/trials/t12/scratch';
const report = { checks: [], screenshots: [], limitations: ['실제 스크린리더 낭독은 실행하지 않음', '200% 글꼴 검사는 메모리상의 CSS 크기 변경이며 운영체제 글꼴 설정이나 실제 브라우저 줌 검사가 아님'] };
let observedOrigin;
await withBrowser(product, scratch, async ({ origin, page, evaluate, screenshot, pause, exceptions }) => {
  observedOrigin = origin;
  const state = () => evaluate(`(() => {
    const title = document.getElementById('empty-title');
    const section = document.getElementById('empty');
    return {
      query: document.getElementById('query').value,
      count: document.getElementById('count').textContent,
      results: [...document.querySelectorAll('#results li')].map(item => item.textContent),
      hidden: section.hidden,
      kind: section.dataset.state,
      title: title.textContent,
      name: title.getAttribute('aria-label'),
      body: document.getElementById('empty-body').textContent,
      labelledby: section.getAttribute('aria-labelledby'),
      describedby: section.getAttribute('aria-describedby'),
      pageOverflow: document.documentElement.scrollWidth > innerWidth,
      sectionOverflow: section.scrollWidth > section.clientWidth,
      titleOverflow: title.scrollWidth > title.clientWidth,
      bodyOverflow: document.getElementById('empty-body').scrollWidth > document.getElementById('empty-body').clientWidth
    };
  })()`);
  const navigate = async suffix => {
    const url = origin + '/index.html' + suffix;
    await page('Page.navigate', { url });
    for (let count = 0; count < 60; count += 1) {
      if (await evaluate('location.href === ' + JSON.stringify(url) + ' && document.documentElement.dataset.ready === "true"')) return;
      await pause(100);
    }
    throw new Error('Readiness timed out: ' + url);
  };
  const enterQuery = async text => {
    await evaluate("document.getElementById('query').focus(); document.getElementById('query').select()");
    await page('Input.insertText', { text });
    assert.equal((await state()).query, text);
  };
  const ax = async expectedName => {
    const result = await page('Accessibility.getFullAXTree');
    const matches = result.nodes.filter(node => !node.ignored && node.name?.value === expectedName);
    assert(matches.some(node => node.role?.value === 'heading'), 'Accessible heading should match the visible title');
    const region = matches.find(node => node.role?.value === 'region');
    assert(region, 'Accessible region should be named by the heading');
    assert.equal(region.description?.value, '다른 검색어로 찾아보세요.');
    return matches.map(({ role, name, description }) => ({ role: role?.value, name: name?.value, description: description?.value }));
  };
  await navigate('');
  assert.deepEqual((await state()).results, ['배송 안내', '교환 절차', '정기 배송 일정']);
  report.checks.push({ check: 'initial-records', result: 'pass', state: await state() });

  await enterQuery('환불');
  const noMatch = await state();
  assert.equal(noMatch.hidden, false);
  assert.equal(noMatch.kind, 'no-match');
  assert.deepEqual(noMatch.results, []);
  assert.equal(noMatch.count, '0개 자료');
  assert.equal(noMatch.title, '“환불” 검색 결과가 없습니다.');
  assert.equal(noMatch.name, noMatch.title);
  assert.equal(noMatch.body, '다른 검색어로 찾아보세요.');
  assert.equal(noMatch.labelledby, 'empty-title');
  assert.equal(noMatch.describedby, 'empty-body');
  report.checks.push({ check: 'no-match-and-accessible-name', result: 'pass', state: noMatch, accessibility: await ax(noMatch.title) });
  await screenshot('no-match-desktop.png');
  report.screenshots.push('no-match-desktop.png');

  await enterQuery('배송');
  const recovered = await state();
  assert.deepEqual(recovered.results, ['배송 안내', '정기 배송 일정']);
  assert.equal(recovered.hidden, true);
  assert.equal(recovered.count, '2개 자료');
  report.checks.push({ check: 'recovery-by-real-input-event', result: 'pass', state: recovered });
  await screenshot('recovered-desktop.png');
  report.screenshots.push('recovered-desktop.png');

  await page('Emulation.setDeviceMetricsOverride', { width: 320, height: 1000, deviceScaleFactor: 1, mobile: false });
  await enterQuery('배송일정변경방법을찾고있습니다배송일정변경방법을찾고있습니다');
  const narrow = await state();
  assert.equal(narrow.hidden, false);
  assert.equal(narrow.title, '“' + narrow.query + '” 검색 결과가 없습니다.');
  assert.equal(narrow.name, narrow.title);
  for (const key of ['pageOverflow', 'sectionOverflow', 'titleOverflow', 'bodyOverflow']) assert.equal(narrow[key], false, key);
  report.checks.push({ check: '320px-long-korean-query', result: 'pass', state: narrow, accessibility: await ax(narrow.title) });
  await screenshot('no-match-narrow-long.png');
  report.screenshots.push('no-match-narrow-long.png');

  await enterQuery('환불');
  await evaluate(`(() => {
    const tags = ['body', 'h1', 'h2'];
    const sizes = tags.map(tag => [document.querySelector(tag), parseFloat(getComputedStyle(document.querySelector(tag)).fontSize)]);
    sizes.forEach(([element, size]) => element.style.fontSize = size * 2 + 'px');
  })()`);
  const enlarged = await state();
  for (const key of ['pageOverflow', 'sectionOverflow', 'titleOverflow', 'bodyOverflow']) assert.equal(enlarged[key], false, key);
  report.checks.push({ check: '320px-simulated-200-percent-text', result: 'pass', state: enlarged });
  await screenshot('no-match-narrow-text-200.png');
  report.screenshots.push('no-match-narrow-text-200.png');

  await navigate('?empty=1');
  const never = await state();
  assert.equal(never.kind, 'never-populated');
  assert.equal(never.title, '저장된 항목이 없습니다.');
  assert.equal(never.name, '저장된 항목이 없습니다.');
  assert.equal(never.body, '등록된 항목은 이 목록에 표시됩니다.');
  report.checks.push({ check: 'never-populated-preserved', result: 'pass', state: never });

  await navigate('?lang=en');
  await enterQuery('refund');
  const english = await state();
  assert.equal(english.title, 'No results for “refund”.');
  assert.equal(english.name, 'No results for refund');
  assert.equal(english.body, 'Check the search term and try again.');
  report.checks.push({ check: 'english-copy-preserved', result: 'pass', state: english });
  assert.deepEqual(exceptions, []);
  report.checks.push({ check: 'runtime-exceptions', result: 'pass', exceptions });
});
assert.deepEqual((await readdir(scratch)).filter(name => name.startsWith('slop-browser-')), [], 'Temporary profile should be deleted');
let loopbackClosed = false;
try { await fetch(observedOrigin + '/index.html', { signal: AbortSignal.timeout(1000) }); } catch { loopbackClosed = true; }
assert.equal(loopbackClosed, true, 'Loopback server should be closed');
report.checks.push({ check: 'browser-finally-cleanup', result: 'pass', serverClosed: loopbackClosed, temporaryProfilesRemaining: 0 });
await writeFile(scratch + '/browser-results.json', JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify(report, null, 2));

