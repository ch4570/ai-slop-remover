`locales/ko.json`의 세 문자열만 수정했습니다. 제목과 접근 가능한 이름을 통일하고, “다른 검색어로 찾아보세요.”로 안내를 간결하게 바꿨습니다.

Chrome에서 결과 없음 → 검색어 변경 → 결과 2개 복구, 접근성 이름, 좁은 화면 줄바꿈을 확인했습니다. 보간 변수와 나머지 파일은 보존했습니다. 실제 스크린리더·브라우저 줌은 미검증입니다.

산출물: [agent-output.md](/var/folders/dt/8hl_lk4517vfdrvql7_0n2b80000gn/T/lutriva-issue-delivery-mt6la1md/issue-6-evals/trials/t12/scratch/agent-output.md)
