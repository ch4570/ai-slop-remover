import difflib, hashlib, json, pathlib, re
scratch = pathlib.Path("/var/folders/dt/8hl_lk4517vfdrvql7_0n2b80000gn/T/lutriva-issue-delivery-mt6la1md/issue-6-evals/trials/t12/scratch")
before = json.loads((scratch / "before.json").read_text())
product = pathlib.Path.cwd()
current = {str(path.relative_to(product)): hashlib.sha256(path.read_bytes()).hexdigest() for path in product.rglob("*") if path.is_file()}
assert set(current) == set(before), "Product file list changed"
changed = sorted(path for path, digest in current.items() if digest != before[path]["sha256"])
assert changed == ["locales/ko.json"], changed
old_raw = before["locales/ko.json"]["content"]
new_raw = (product / "locales/ko.json").read_text()
old, new = json.loads(old_raw), json.loads(new_raw)
assert list(old) == list(new), "Locale key contract changed"
allowed = {"empty_title", "empty_body", "empty_name"}
assert {key for key in old if old[key] != new[key]} == allowed
for key in old:
    assert type(new[key]) is str
    assert re.findall(r"\{[^{}]*\}", old[key]) == re.findall(r"\{[^{}]*\}", new[key]), key
expected_raw = old_raw
for key in allowed:
    expected_raw = expected_raw.replace(json.dumps(key) + ": " + json.dumps(old[key], ensure_ascii=False), json.dumps(key) + ": " + json.dumps(new[key], ensure_ascii=False), 1)
assert expected_raw == new_raw, "Unexpected formatting or out-of-scope changes"
assert new["empty_title"] == new["empty_name"], "Visible and accessible names differ"
json.loads((product / "locales/en.json").read_text())
report = {
    "result": "pass",
    "changed_files": changed,
    "changed_keys": sorted(allowed),
    "interpolation_preserved": True,
    "no_files_added_or_removed": True,
    "other_product_files_byte_identical": True,
    "json_valid": ["locales/ko.json", "locales/en.json"],
    "visible_accessible_titles_identical": True,
}
(scratch / "scope-results.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
print(json.dumps(report, ensure_ascii=False, indent=2))
print("".join(difflib.unified_diff(old_raw.splitlines(keepends=True), new_raw.splitlines(keepends=True), fromfile="before/locales/ko.json", tofile="after/locales/ko.json")))

