# 검색 결과 없음 문구 수정 결과

수정 완료. 제공된 `source-a/skills/ux-writing/SKILL.md`와 관련 reference를 직접 읽어 적용했다. 호스트의 스킬 자동 발견·설치 호출은 실행하지 않았다.

변경 파일: `product/locales/ko.json` 한 개. 아래 세 문자열 값만 변경했다.

| 키 | 변경 전 | 변경 후 |
| --- | --- | --- |
| `empty_title` | “{query}” 검색 결과가 0건입니다. | “{query}” 검색 결과가 없습니다. |
| `empty_body` | 조회된 결과가 없습니다. 검색어를 확인하십시오. | 다른 검색어로 찾아보세요. |
| `empty_name` | {query} 검색 결과 0건 | “{query}” 검색 결과가 없습니다. |

중복된 결과 없음 설명을 줄이고, 현재 검색창에서 할 수 있는 검색어 변경을 안내했다. 제목과 접근 가능한 이름은 같은 문장으로 맞췄다.

검증 결과:

- 전체 제품 파일의 변경 전후 해시 및 JSON 값을 비교했다. 세 문자열 외에 변경된 값·파일이 없으며, 파일 추가·삭제도 없다. 기존 키와 각 문자열의 보간 변수 구성, 영어 locale, 미등록 상태 문구, HTML·ARIA 연결, 동작·스타일 파일을 보존했다.
- JSON 구문 검사와 `node --check app.js`를 통과했다.
- 기존 Chrome의 새 임시 프로필과 제품 전용 loopback 서버로 실행했다. 실제 브라우저 입력 이벤트로 ‘환불’을 입력해 결과 0개와 새 문구를 확인한 뒤, ‘배송’으로 바꾸어 ‘배송 안내’·‘정기 배송 일정’ 두 결과가 복구되고 결과 없음 영역이 숨겨지는 것을 확인했다.
- Chrome 접근성 트리에서 heading과 region의 이름이 표시 제목과 일치하고, region 설명이 새 본문을 전달하는 것을 확인했다.
- 320px 폭의 긴 한국어 검색어와 임시 CSS로 글꼴을 200% 확대한 화면에서 수정 문구가 줄바꿈되며 잘리지 않는 것을 DOM 치수와 실제 캡처 열람으로 확인했다. 200% 검사는 실제 브라우저 줌 검사가 아니다.
- `?empty=1`과 `?lang=en` 상태의 기존 문구가 유지됐다. 수집된 런타임 예외는 0건이다.
- 브라우저 검증의 종료 처리가 완료됐고, loopback 서버 종료와 scratch 내 임시 프로필 삭제를 확인했다.

직접 열어 관찰한 스크린샷: [결과 없음](no-match-desktop.png), [검색 결과 복구](recovered-desktop.png), [320px 긴 검색어](no-match-narrow-long.png), [320px 글꼴 200% 모의 검사](no-match-narrow-text-200.png).

실행 명령과 stdout/stderr: [commands.log](commands.log). 상세 결과: [scope-results.json](scope-results.json), [browser-results.json](browser-results.json).

남은 미검증 항목: 실제 스크린리더 낭독·발표 순서, 운영체제 글꼴 확대, 실제 브라우저 줌, 다른 브라우저. 제품에는 lint·typecheck·테스트 실행 설정이 없어 별도 프로젝트 검사기는 실행하지 않았다.

