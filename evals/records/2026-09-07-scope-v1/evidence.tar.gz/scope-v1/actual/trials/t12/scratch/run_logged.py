#!/usr/bin/env python3
import json, pathlib, shlex, subprocess, sys, time
PRODUCT = pathlib.Path("/var/folders/dt/8hl_lk4517vfdrvql7_0n2b80000gn/T/lutriva-issue-delivery-mt6la1md/issue-6-evals/trials/t12/product")
LOG = pathlib.Path(__file__).with_name("commands.log")
command = sys.argv[1:]
if command and command[0] == "--":
    command = command[1:]
result = subprocess.run(command, cwd=PRODUCT, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
record = "\n$ " + shlex.join(command) + "\nworkdir: " + str(PRODUCT) + "\nstdout:\n" + result.stdout + "\nstderr:\n" + result.stderr + "\nexit_code: " + str(result.returncode) + "\n"
with LOG.open("a") as handle:
    handle.write(record)
sys.stdout.write(record)
raise SystemExit(result.returncode)

