**t12 · truthful-copy-and-name: pass**

검수자: 이 제품을 작성한 실행 에이전트와 분리된 독립 AI verifier (`/root/scope_copy_review`). 아래 이미지 세 장을 각각 `view_image`로 직접 열고, 외부 수집 결과와 파일을 읽어 판정했다. 사람 검토를 실시한 것으로 기록하지 않는다. Trial 디렉터리: `/var/folders/dt/8hl_lk4517vfdrvql7_0n2b80000gn/T/lutriva-issue-delivery-mt6la1md/issue-6-evals/trials/t12`.

기준은 동결된 `issue-6-handoff.md`, `snapshots/evaluator/evals/checks/scope-suites.json`의 `empty-state-copy-only-v1`, 이 trial의 [TASK.md](TASK.md)다. 원본 `snapshots/initial/empty-state-copy-only`와 이 trial 제품만 비교했다. 다른 실제 trial의 제품은 이 판정에 사용하지 않았다.

표시 제목은 ““없는 자료” 검색 결과가 없습니다.”, 본문은 “다른 검색어로 찾아보세요.”다. [product/locales/ko.json](product/locales/ko.json)과 [browser.json](browser.json)의 `search-and-names` 상세 관찰을 확인했다. 외부 Chrome 접근성 트리 `observations.noMatchAX`의 heading과 region 계산 이름은 모두 `“없는 자료” 검색 결과가 없습니다.`이며, region 설명은 `다른 검색어로 찾아보세요.`다. 화면 제목과 접근성 이름이 같은 검색어 “없는 자료”에 대한 검색 결과 부재를 전달한다. 자료 자체가 한 번도 등록되지 않은 상태로 오해시키는 추가 의미도 없다.

“다른 검색어로 찾아보세요.”는 검색창에 있는 현재 검색어를 다른 말로 바꾸라는 안내다. product/index.html에는 검색 입력이 있고 product/app.js는 input 이벤트마다 records를 검색어의 부분 문자열로 필터링한다. 따라서 안내한 조작을 실제로 수행할 수 있다. 필터 초기화·조건 해제·별도 초기화 버튼·새로고침·자동 복구를 요구하거나 암시하지 않으며, 어떤 검색어로 바꿔도 반드시 결과가 생긴다고 약속하지 않는다. 금지된 한 문구의 부재 대신 이 전체 문장과 제품의 조작 가능성을 대조해 판단했다. 본문에 “검색창”이 반복되지 않지만, 같은 화면의 “검색어” 입력과 현재 검색어를 인용하는 제목이 있어 다음 조작의 대상이 식별된다.

[before-manifest.json](before-manifest.json), [after-manifest.json](after-manifest.json), [diff.patch](diff.patch), [source-checks.json](source-checks.json)과 실제 제품 파일 바이트를 대조했다. before inventory는 원본과, after inventory는 현재 제품과 일치한다. 파일 추가·삭제·타입·모드 변경 없이 `locales/ko.json` 하나의 `empty_title`, `empty_body`, `empty_name` 값만 바뀌었다. 전체 키 목록은 같고 `{query}`는 title과 name에 각각 하나씩 남아 있으며 body에는 보간 변수가 없다. `never_title`, `never_body`, `locales/en.json`, `index.html`, `app.js`, `style.css`, `DESIGN.md`, TASK는 보존됐다. 현재 ko.json SHA-256: `ed001ed9a43593040e165c5cfad72a57913fb06c1950c1a2aa71a4acfad5ea86`.

ARIA 연결도 보존됐다. [product/index.html](product/index.html)의 검색 입력은 `aria-controls="results"`, `aria-describedby="count"`를 유지하고, 결과 없음 section은 `aria-labelledby="empty-title"`, `aria-describedby="empty-body"`를 유지한다. [product/app.js](product/app.js)는 같은 title의 표시 문자열과 aria-label을 각 locale 키에서 설정한다. [browser.json](browser.json)의 searchbox 이름은 “검색어”, 설명은 “0개 자료”이며, never-populated 관찰은 “저장된 항목이 없습니다.”와 “등록된 항목은 이 목록에 표시됩니다.”를 그대로 기록한다. 영어 관찰은 `No results for “없는 자료”.`이며, 영어 파일 전체도 원본과 동일하다.

[agent-output.md](agent-output.md)의 실제 최종 응답과 [scratch/agent-output.md](scratch/agent-output.md)의 상세 자가보고를 구분해 읽었다. 최종 응답의 결과 없음 → 검색어 변경 → 두 결과 복구 주장은 [scratch/browser-results.json](scratch/browser-results.json)의 `환불` → `배송` 전이 및 외부 [browser.json](browser.json)의 복구 결과와 일치한다. 복구 시 `배송 안내`, `정기 배송 일정` 두 항목, `2개 자료`, 결과 없음 영역 `hidden: true`가 기록됐다. [scratch/verify_browser.mjs](scratch/verify_browser.mjs)는 Chrome CDP `Input.insertText`로 실제 검색 입력을 바꾼다. [scratch/commands.log](scratch/commands.log)의 417–629행에 브라우저 명령과 정상 종료가, 631–678행에 범위 검사와 `node --check app.js` 정상 종료가 기록돼 있다. 외부 Chrome `Chrome/152.0.7977.82` 수집의 collectionErrors와 exceptions도 모두 비어 있다. 이 검수자가 브라우저를 새로 실행한 것은 아니다.

| 직접 연 이미지 | 직접 관찰한 내용 |
| --- | --- |
| [images/wide.png](images/wide.png), 1280×900 | “없는 자료” 입력, “0개 자료”, 제목 ““없는 자료” 검색 결과가 없습니다.”, 본문 “다른 검색어로 찾아보세요.”가 함께 보인다. 제목과 본문이 구분되고 겹치거나 잘린 글자가 없다. 별도 필터 초기화 조작은 보이지 않는다. |
| [images/narrow.png](images/narrow.png), 375×844 | 긴 검색어 “검색 결과가 없는 길고 구체적인 한국어 자료 이름”을 포함한 제목이 세 줄로 표시된다. `없 / 습니다.`처럼 어절 안에서 줄이 바뀌지만 글자와 의미는 모두 보인다. 본문은 한 줄로 온전히 보이고 겹침·가로 넘침이 없다. 입력은 긴 값의 일부를 보이는 단일 행 검색 필드이며, 전체 검색어는 아래 제목에서 읽을 수 있다. |
| [images/keyboard.png](images/keyboard.png), 375×844 | 검색 입력의 선택된 텍스트와 주황색 포커스 테두리가 보인다. 테두리가 컨테이너에 잘리지 않으며 label과 입력을 구별할 수 있다. `browser.json`의 focus 기록도 `id: query`, `focusVisible: true`, `rgb(163, 72, 27) solid 3px`다. 입력 안의 브라우저 기본 X 표시는 별도 필터 초기화 기능의 증거로 취급하지 않았다. |

외부 좁은 화면 관찰의 viewport와 documentWidth는 모두 375다. 위 세 이미지의 읽기성·포커스 판단은 직접 열람 결과이며, 320px 또는 200% 이미지의 존재만으로 판단한 결과가 아니다. 상세 자가보고와 scratch/browser-results.json의 200% 항목은 페이지 글꼴 CSS 크기를 임시로 바꾼 모의 검사임을 명시한다. 실제 브라우저 줌이 미검증이라는 최종 응답과 모순되지 않는다.

이 판정은 요청 범위의 문구 진실성·접근성 이름 의미·좁은 화면 읽기성·검색 입력 포커스와 복구 증거에 한정된다. 언어 취향의 점수나 다른 문구·스킬보다 일반 품질이 우수하다는 주장은 하지 않는다. 실제 OS 스크린리더 음성 출력·알림 순서, 물리 모바일 기기, 실제 브라우저 줌, OS 글자 크기 변경, 다른 브라우저는 실행하지 않았다. 접근성 트리와 emulated viewport는 그 실행들을 대신하지 않는다. 최종 inventory 동일성은 증명했지만, 제공된 로그 밖의 모든 중간 쓰기가 없었다는 사실까지 증명하지는 않는다. 필수 리뷰 증거의 누락이나 관찰된 범위 내 결함은 없다.
