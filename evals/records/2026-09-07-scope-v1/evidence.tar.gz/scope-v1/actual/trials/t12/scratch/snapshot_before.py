import hashlib, json, pathlib
product = pathlib.Path.cwd()
scratch = pathlib.Path("/var/folders/dt/8hl_lk4517vfdrvql7_0n2b80000gn/T/lutriva-issue-delivery-mt6la1md/issue-6-evals/trials/t12/scratch")
data = {str(path.relative_to(product)): {"sha256": hashlib.sha256(path.read_bytes()).hexdigest()} for path in sorted(product.rglob("*")) if path.is_file()}
data["locales/ko.json"]["content"] = (product / "locales/ko.json").read_text()
(scratch / "before.json").write_text(json.dumps(data, ensure_ascii=False, indent=2))
print(json.dumps(data, ensure_ascii=False, indent=2))

