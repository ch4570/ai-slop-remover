import json, pathlib, re
target = pathlib.Path("locales/ko.json")
before = target.read_text()
old = json.loads(before)
replacements = {
    "empty_title": "“{query}” 검색 결과가 없습니다.",
    "empty_body": "다른 검색어로 찾아보세요.",
    "empty_name": "“{query}” 검색 결과가 없습니다.",
}
after = before
for key, value in replacements.items():
    assert re.findall(r"\{[^{}]*\}", old[key]) == re.findall(r"\{[^{}]*\}", value)
    previous = json.dumps(old[key], ensure_ascii=False)
    replacement = json.dumps(value, ensure_ascii=False)
    needle = json.dumps(key) + ": " + previous
    assert after.count(needle) == 1
    after = after.replace(needle, json.dumps(key) + ": " + replacement, 1)
target.write_text(after)
print(json.dumps({"file": str(target), "changes": {key: {"before": old[key], "after": value} for key, value in replacements.items()}}, ensure_ascii=False, indent=2))

