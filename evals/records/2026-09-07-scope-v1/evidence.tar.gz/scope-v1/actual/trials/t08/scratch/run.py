import datetime, json, subprocess, sys
from pathlib import Path
base=Path(__file__).resolve().parent
product=base.parent/'product'
args=sys.argv[1:]
with (base/'commands.log').open('a') as log:
 log.write('\nTIME '+datetime.datetime.now(datetime.timezone.utc).isoformat()+'\nCWD '+str(product)+'\nCOMMAND '+json.dumps(args,ensure_ascii=False)+'\n')
 log.flush()
 result=subprocess.run(args,cwd=product,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 log.write('STDOUT\n'+result.stdout+'\nSTDERR\n'+result.stderr+'\nEXIT '+str(result.returncode)+'\n')
print(result.stdout,end='')
print(result.stderr,end='',file=sys.stderr)
sys.exit(result.returncode)
