`locales/ko.json`의 허용된 세 문구만 수정했습니다. 검색어 변경 안내와 접근 가능한 이름을 맞췄고, 보간 변수를 보존했습니다.

Chrome에서 결과 없음 → 검색어 변경 → 결과 2개 복구를 확인했습니다. 좁은 화면과 접근성 트리 검사도 통과했습니다. 실제 보조기술과 브라우저 확대는 미검증입니다.

산출물: [agent-output.md](/var/folders/dt/8hl_lk4517vfdrvql7_0n2b80000gn/T/lutriva-issue-delivery-mt6la1md/issue-6-evals/trials/t09/scratch/agent-output.md)
