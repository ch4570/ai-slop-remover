from pathlib import Path
import shlex
import subprocess
import sys

result = subprocess.run(sys.argv[1:], text=True, capture_output=True)
record = (
    '$ ' + shlex.join(sys.argv[1:]) + '\n'
    + 'stdout:\n' + result.stdout + '\nstderr:\n' + result.stderr
    + f'\n[exit {result.returncode}]\n'
)
with (Path(__file__).parent / 'commands.log').open('a') as log:
    log.write(record)
print(record)
sys.exit(result.returncode)
