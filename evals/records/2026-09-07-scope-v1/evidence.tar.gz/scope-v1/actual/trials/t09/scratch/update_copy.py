from pathlib import Path
import hashlib
import json
import re

scratch = Path(__file__).parent
before = json.loads((scratch / 'before.json').read_text())
locale_path = Path('locales/ko.json')
locale = json.loads(locale_path.read_text())
changes = {
    'empty_title': '“{query}” 검색 결과가 없어요.',
    'empty_body': '검색창에서 다른 검색어로 찾아보세요.',
    'empty_name': '“{query}” 검색 결과가 없어요.',
}
locale.update(changes)
locale_path.write_text(json.dumps(locale, ensure_ascii=False, indent=2) + '\n')
after = json.loads(locale_path.read_text())
assert set(after) == set(before['ko'])
changed_keys = {key for key in after if after[key] != before['ko'][key]}
assert changed_keys == set(changes), changed_keys
for key in after:
    assert re.findall(r'\{[^{}]*\}', after[key]) == re.findall(r'\{[^{}]*\}', before['ko'][key]), key
assert after['empty_title'] == after['empty_name']
files = {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in Path('.').rglob('*') if p.is_file()}
assert files.keys() == before['files'].keys(), 'Unexpected file additions or removals'
changed_files = [name for name in files if files[name] != before['files'][name]]
assert changed_files == ['locales/ko.json'], changed_files
result = {'changed_files': changed_files, 'changed_keys': sorted(changed_keys), 'preserved_interpolations': True, 'visible_and_accessible_copy_equal': True}
(scratch / 'static-checks.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(result, ensure_ascii=False, indent=2))
for key in changes:
    print(f'{key}: {before["ko"][key]} -> {after[key]}')
