from pathlib import Path
import hashlib
import json
import re

scratch = Path(__file__).parent
before = json.loads((scratch / 'before.json').read_text())
files = {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in Path('.').rglob('*') if p.is_file()}
assert files.keys() == before['files'].keys()
assert [name for name in files if files[name] != before['files'][name]] == ['locales/ko.json']
after = json.loads(Path('locales/ko.json').read_text())
assert after.keys() == before['ko'].keys()
assert {key for key in after if after[key] != before['ko'][key]} == {'empty_title', 'empty_body', 'empty_name'}
for key in after:
    assert re.findall(r'\{[^{}]*\}', after[key]) == re.findall(r'\{[^{}]*\}', before['ko'][key])
for name in ['agent-output.md', 'commands.log', 'static-checks.json', 'browser-checks.json', 'accessibility-tree.json']:
    assert (scratch / name).stat().st_size > 0, name
print('PASS: only locales/ko.json and its three permitted string values changed; keys and variables preserved.')
print('PASS: report and verification artifacts exist.')
print('Output artifact:', scratch / 'agent-output.md')
