요청한 한국어 검색 결과 없음 문구 수정을 완료했습니다. 제공된 `source-a/skills/ux-writing/SKILL.md`와 필요한 reference를 직접 읽어 적용했습니다.

변경 파일: `product/locales/ko.json` 한 개. 세 문자열만 수정했습니다.

| 키 | 이전 | 변경 |
| --- | --- | --- |
| `empty_title` | “{query}” 검색 결과가 0건입니다. | “{query}” 검색 결과가 없어요. |
| `empty_body` | 조회된 결과가 없습니다. 검색어를 확인하십시오. | 검색창에서 다른 검색어로 찾아보세요. |
| `empty_name` | {query} 검색 결과 0건 | “{query}” 검색 결과가 없어요. |

중복된 결과 없음 설명을 줄이고, 실제로 가능한 검색어 변경을 안내했습니다. 표시 제목과 접근 가능한 이름을 같은 문장으로 맞췄습니다. 초기화 기능을 안내하지 않습니다.

실행한 검증과 관찰:

- JSON 파싱, 전체 키·문자열별 보간 변수 보존, 변경 파일 해시 비교와 `node --check app.js` 구문 검사를 통과했습니다. `empty_title`·`empty_name`의 `{query}`를 유지했고, `empty_body`에는 변수를 추가하지 않았습니다. 다른 locale, 최초 빈 상태 문구, HTML·ARIA 연결·동작·스타일과 제품 파일 목록은 그대로입니다.
- 설치된 Chrome 152를 이 제품의 loopback 서버와 새 임시 profile로 실행했습니다. Tab으로 검색창에 접근한 뒤 실제 입력 경로로 `환불`을 입력해 결과 0개와 새 문구를 확인했습니다. 같은 검색창에서 `배송`으로 바꾸자 `배송 안내`, `정기 배송 일정` 2개가 나타나고 결과 없음 영역이 숨겨졌습니다.
- Chrome 접근성 트리에서 제목과 영역의 이름이 `“환불” 검색 결과가 없어요.`로 일치하고, 영역 설명이 새 본문으로 연결된 것을 확인했습니다. `?empty=1`의 기존 최초 빈 상태 문구도 확인했습니다. 관찰된 JavaScript 실행 예외는 없었습니다.
- 직접 열어 본 screenshot: [결과 없음](screenshots/no-match-desktop.png), [결과 복구](screenshots/recovered-desktop.png), [320px·긴 검색어](screenshots/no-match-narrow-long.png), [320px·글자 200% 모의 확대](screenshots/no-match-narrow-text-200.png). 결과 없음 제목·본문은 줄바꿈되어 전체 내용이 보였고 가로 넘침이나 잘림이 없었습니다. 모의 확대는 임시 페이지 스타일로만 적용했으며 제품 파일에는 반영하지 않았습니다.
- 브라우저 실행을 종료했고 loopback 서버의 연결 종료와 임시 profile 제거를 확인했습니다.

남은 미검증: VoiceOver 등 실제 보조기술의 음성 출력·알림 순서, 실제 브라우저 확대 및 OS 글자 크기 설정, 다른 브라우저. 이 제품에는 별도 빌드·린트·타입 검사·테스트 실행 설정이 없어 해당 명령은 실행하지 않았습니다. 대신 JSON·보간·파일 범위 검사와 Chrome 동작 검증을 수행했습니다.

실행 기록은 [commands.log](commands.log), 정적 검사 결과는 [static-checks.json](static-checks.json), 브라우저 결과는 [browser-checks.json](browser-checks.json), 접근성 트리는 [accessibility-tree.json](accessibility-tree.json)에 남겼습니다.
