import { withBrowser } from '/var/folders/dt/8hl_lk4517vfdrvql7_0n2b80000gn/T/lutriva-issue-delivery-mt6la1md/issue-6-evals/snapshots/tools/browser_harness.mjs';
import assert from 'node:assert/strict';
import { readFile, readdir, writeFile } from 'node:fs/promises';
import path from 'node:path';

const product = process.cwd();
const scratch = path.dirname(new URL(import.meta.url).pathname);
const copy = JSON.parse(await readFile(path.join(product, 'locales/ko.json'), 'utf8'));
const evidence = { browser: 'Installed Chrome, headless CDP', checks: [] };
let usedOrigin;
await withBrowser(product, path.join(scratch, 'screenshots'), async ({ origin, page, evaluate, call, screenshot, pause, exceptions }) => {
  usedOrigin = origin;
  evidence.version = await call('Browser.getVersion');
  const ready = async () => {
    for (let i = 0; i < 100; i++) {
      if (await evaluate('document.documentElement.dataset.ready === "true"')) return;
      await pause(50);
    }
    throw new Error('Product did not become ready');
  };
  const state = () => evaluate(`(() => {
    const empty = document.getElementById('empty');
    const title = document.getElementById('empty-title');
    return {
      query: document.getElementById('query').value,
      count: document.getElementById('count').textContent,
      matches: [...document.querySelectorAll('#results li')].map(item => item.textContent),
      hidden: empty.hidden, state: empty.dataset.state,
      title: title.textContent, name: title.getAttribute('aria-label'),
      body: document.getElementById('empty-body').textContent,
      labelledby: empty.getAttribute('aria-labelledby'),
      describedby: empty.getAttribute('aria-describedby'),
      viewport: innerWidth, documentWidth: document.documentElement.scrollWidth,
      overflowing: [...document.querySelectorAll('main, #empty, #empty-title, #empty-body')]
        .filter(node => node.scrollWidth > node.clientWidth).map(node => node.id || node.tagName),
    };
  })()`);
  const input = async text => {
    await page('Input.dispatchKeyEvent', {type: 'keyDown', key: 'a', code: 'KeyA', modifiers: 4, commands: ['selectAll']});
    await page('Input.dispatchKeyEvent', {type: 'keyUp', key: 'a', code: 'KeyA', modifiers: 4});
    await page('Input.insertText', {text});
    await pause(60);
    assert.equal((await state()).query, text);
  };

  await page('Page.navigate', {url: origin + '/index.html'});
  await ready();
  assert.equal((await state()).matches.length, 3);
  await page('Input.dispatchKeyEvent', {type: 'keyDown', key: 'Tab', code: 'Tab', windowsVirtualKeyCode: 9});
  await page('Input.dispatchKeyEvent', {type: 'keyUp', key: 'Tab', code: 'Tab', windowsVirtualKeyCode: 9});
  assert.equal(await evaluate('document.activeElement.id'), 'query');
  await input('환불');
  const noMatch = await state();
  assert.equal(noMatch.hidden, false);
  assert.equal(noMatch.state, 'no-match');
  assert.equal(noMatch.count, '0개 자료');
  assert.deepEqual(noMatch.matches, []);
  assert.equal(noMatch.title, copy.empty_title.replaceAll('{query}', '환불'));
  assert.equal(noMatch.name, noMatch.title);
  assert.equal(noMatch.body, copy.empty_body);
  assert.equal(noMatch.labelledby, 'empty-title');
  assert.equal(noMatch.describedby, 'empty-body');
  await page('Accessibility.enable');
  const ax = await page('Accessibility.getFullAXTree');
  const heading = ax.nodes.find(node => node.role?.value === 'heading' && node.name?.value === noMatch.title);
  const region = ax.nodes.find(node => node.role?.value === 'region' && node.name?.value === noMatch.title);
  assert(heading && region, 'Heading and region accessible names must match visible copy');
  assert.equal(region.description?.value, copy.empty_body);
  evidence.checks.push({case: 'no-match and computed accessibility tree', ...noMatch, axName: region.name.value, axDescription: region.description.value});
  await writeFile(path.join(scratch, 'accessibility-tree.json'), JSON.stringify(ax, null, 2));
  await screenshot('no-match-desktop.png');

  await input('배송');
  const recovered = await state();
  assert.deepEqual(recovered.matches, ['배송 안내', '정기 배송 일정']);
  assert.equal(recovered.hidden, true);
  assert.equal(recovered.count, '2개 자료');
  assert.equal(await evaluate('document.activeElement.id'), 'query');
  evidence.checks.push({case: 'recovery by changing the actual input', ...recovered});
  await screenshot('recovered-desktop.png');

  await page('Emulation.setDeviceMetricsOverride', {width: 320, height: 1000, deviceScaleFactor: 1, mobile: false});
  await input('배송교환정기안내자료찾기검색어');
  const narrow = await state();
  assert.equal(narrow.hidden, false);
  assert(narrow.documentWidth <= narrow.viewport);
  assert.deepEqual(narrow.overflowing, []);
  evidence.checks.push({case: '320px viewport with long Korean query', ...narrow});
  await screenshot('no-match-narrow-long.png');
  await evaluate(`document.body.style.fontSize = '32px'; document.querySelector('h1').style.fontSize = '56px'; document.querySelector('#empty h2').style.fontSize = '40px';`);
  const scaled = await state();
  assert(scaled.documentWidth <= scaled.viewport);
  assert.deepEqual(scaled.overflowing, []);
  evidence.checks.push({case: '320px viewport, temporary 200% text-size simulation (not browser zoom)', ...scaled});
  await screenshot('no-match-narrow-text-200.png');

  await page('Page.navigate', {url: origin + '/index.html?empty=1'});
  await ready();
  const never = await state();
  assert.equal(never.state, 'never-populated');
  assert.equal(never.title, copy.never_title);
  assert.equal(never.body, copy.never_body);
  assert.equal(never.name, copy.never_title);
  evidence.checks.push({case: 'never populated wording preserved', ...never});
  assert.deepEqual(exceptions, []);
  evidence.runtimeExceptions = exceptions;
});
evidence.cleanup = {
  origin: usedOrigin,
  serverClosed: await fetch(usedOrigin).then(() => false, () => true),
  temporaryProfilesRemaining: (await readdir(scratch)).filter(name => name.startsWith('slop-browser-')),
  harnessCompleted: true,
};
assert.equal(evidence.cleanup.serverClosed, true);
assert.deepEqual(evidence.cleanup.temporaryProfilesRemaining, []);
await writeFile(path.join(scratch, 'browser-checks.json'), JSON.stringify(evidence, null, 2));
console.log(JSON.stringify(evidence, null, 2));
