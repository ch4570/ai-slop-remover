import {withBrowser} from '/var/folders/dt/8hl_lk4517vfdrvql7_0n2b80000gn/T/lutriva-issue-delivery-mt6la1md/issue-6-evals/snapshots/tools/browser_harness.mjs';
import {writeFile,readdir} from 'node:fs/promises';
import assert from 'node:assert/strict';
const product="/var/folders/dt/8hl_lk4517vfdrvql7_0n2b80000gn/T/lutriva-issue-delivery-mt6la1md/issue-6-evals/trials/t15/product";
const scratch="/var/folders/dt/8hl_lk4517vfdrvql7_0n2b80000gn/T/lutriva-issue-delivery-mt6la1md/issue-6-evals/trials/t15/scratch";
process.env.TMPDIR=scratch;
const phase=process.argv[2];
assert(['baseline','final'].includes(phase));
const observations={phase,viewports:[],exceptions:[]};
let browserOrigin;
await withBrowser(product,scratch,async ({origin,page,evaluate,screenshot,pause,exceptions})=>{
  browserOrigin=origin;
  async function waitFor(expression){
    for(let i=0;i<60;i++){if(await evaluate(expression)) return; await pause(50);}
    throw new Error('Readiness timeout: '+expression);
  }
  async function key(key,code,keyCode){
    const text=key==='Enter'?'\r':key===' '?' ':undefined;
    await page('Input.dispatchKeyEvent',{type:'keyDown',key,code,windowsVirtualKeyCode:keyCode,...(text?{text,unmodifiedText:text}:{})});
    await page('Input.dispatchKeyEvent',{type:'keyUp',key,code,windowsVirtualKeyCode:keyCode});
  }
  for(const route of ['master.html','compare.html']){
    for(const width of [1280,390]){
      const height=width===1280?900:844;
      await page('Emulation.setDeviceMetricsOverride',{width,height,deviceScaleFactor:1,mobile:false});
      await page('Page.navigate',{url:origin+'/'+route});
      await waitFor("location.pathname === '/"+route+"' && document.readyState === 'complete' && document.querySelectorAll('[data-order]').length === 3");
      await evaluate("document.fonts.ready.then(()=>true)");
      const snapshot=await evaluate(`(()=>{
        const rect=el=>{const r=el.getBoundingClientRect();return {x:r.x,y:r.y,width:r.width,height:r.height}};
        const cells=[...document.querySelectorAll('th,td')];
        const scroller=document.querySelector('.table-scroll');
        const s=getComputedStyle(cells[0]), b=getComputedStyle(document.querySelector('button'));
        return {
          title:document.title,viewport:{width:innerWidth,height:innerHeight},
          pageWidth:document.documentElement.scrollWidth,clientWidth:document.documentElement.clientWidth,
          scroll: {clientWidth:scroller.clientWidth,scrollWidth:scroller.scrollWidth,left:scroller.scrollLeft,rect:rect(scroller)},
          padding: [...new Set(cells.map(cell=>getComputedStyle(cell).paddingTop))],
          rows:[...document.querySelectorAll('tr')].map(rect),
          buttons:[...document.querySelectorAll('[data-order]')].map(button=>({order:button.dataset.order,rect:rect(button)})),
          brand:getComputedStyle(document.querySelector('header')).backgroundColor,
          font:getComputedStyle(document.body).font,
          buttonStyle:{padding:b.padding,font:b.font,borderRadius:b.borderRadius},
          detail:document.querySelector('#detail').textContent
        }
      })()`);
      const expectedPadding=phase==='final' && route==='compare.html'?'10px':'16px';
      assert.deepEqual(snapshot.padding,[expectedPadding]);
      assert.equal(snapshot.pageWidth,snapshot.clientWidth,'Page must not overflow horizontally');
      assert.equal(snapshot.detail,'주문을 선택해 주세요.');
      const stem=phase+'-'+route.replace('.html','')+'-'+width;
      await screenshot(stem+'.png');
      const result={route,...snapshot,screenshot:stem+'.png',keyboard:[],pointer:null};
      if(width<600){
        assert(snapshot.scroll.scrollWidth>snapshot.scroll.clientWidth,'Narrow table must retain internal horizontal scrolling');
        const x=snapshot.scroll.rect.x+snapshot.scroll.rect.width/2;
        const y=snapshot.scroll.rect.y+80;
        await page('Input.dispatchMouseEvent',{type:'mouseWheel',x,y,deltaX:600,deltaY:0});
        await waitFor("document.querySelector('.table-scroll').scrollLeft > 0");
        result.horizontalScroll=await evaluate("({left:document.querySelector('.table-scroll').scrollLeft,pageLeft:document.documentElement.scrollLeft})");
        assert.equal(result.horizontalScroll.pageLeft,0);
        await page('Input.dispatchMouseEvent',{type:'mouseWheel',x,y,deltaX:-600,deltaY:0});
        await waitFor("document.querySelector('.table-scroll').scrollLeft === 0");
      }
      for(const order of ['M-101','M-102','M-103']){
        let active;
        const traversed=[];
        for(let n=0;n<9;n++){
          await key('Tab','Tab',9);
          await pause(150);
          active=await evaluate(`(()=>{
            const el=document.activeElement,s=getComputedStyle(el),r=el.getBoundingClientRect(),c=document.querySelector('.table-scroll').getBoundingClientRect();
            return {tag:el.tagName,text:el.textContent,order:el.dataset.order||null,focusVisible:el.matches(':focus-visible'),outlineStyle:s.outlineStyle,outlineWidth:s.outlineWidth,outlineColor:s.outlineColor,rect:{x:r.x,y:r.y,width:r.width,height:r.height},withinScroller:r.left>=c.left&&r.right<=c.right,scrollLeft:document.querySelector('.table-scroll').scrollLeft};
          })()`);
          traversed.push({tag:active.tag,order:active.order,text:active.text});
          if(active.order===order)break;
        }
        assert.equal(active.order,order,'Tab must reach ordered row actions');
        assert(active.focusVisible,'Keyboard focus must be visible');
        assert.equal(active.outlineStyle,'solid');
        assert.equal(active.outlineWidth,'3px');
        if(!active.withinScroller){
          result.initialFocusClipping={order,active};
          console.log(JSON.stringify({phase,route,width,initialFocusClipping:active}));
          await screenshot(stem+'-focus-clipped.png');
          await key('ArrowRight','ArrowRight',39);
          await pause(250);
          const recovery=await evaluate("(()=>{const r=document.activeElement.getBoundingClientRect(),c=document.querySelector('.table-scroll').getBoundingClientRect();return {scrollLeft:document.querySelector('.table-scroll').scrollLeft,withinScroller:r.left>=c.left&&r.right<=c.right}})()");
          result.keyboardHorizontalRecovery=recovery;
          assert(recovery.withinScroller,'ArrowRight must reveal the focused row action within the table');
        }
        const activation=order==='M-102'?[' ','Space',32]:['Enter','Enter',13];
        await key(...activation);
        await waitFor("document.querySelector('#detail').textContent === "+JSON.stringify(order+' 주문을 선택했습니다.'));
        const detail=await evaluate("document.querySelector('#detail').textContent");
        assert.equal(detail,order+' 주문을 선택했습니다.');
        result.keyboard.push({order,traversed,active,activation:activation[1],detail});
        if(width<600 && order==='M-101'){
          result.focusScreenshot=stem+'-focus.png';
          await screenshot(result.focusScreenshot);
        }
      }
      const target=await evaluate("(()=>{const r=document.querySelector('[data-order=\"M-101\"]').getBoundingClientRect();return{x:r.x+r.width/2,y:r.y+r.height/2}})()");
      await page('Input.dispatchMouseEvent',{type:'mousePressed',button:'left',clickCount:1,...target});
      await page('Input.dispatchMouseEvent',{type:'mouseReleased',button:'left',clickCount:1,...target});
      await waitFor("document.querySelector('#detail').textContent === 'M-101 주문을 선택했습니다.'");
      result.pointer={order:'M-101',detail:await evaluate("document.querySelector('#detail').textContent")};
      observations.viewports.push(result);
      console.log(JSON.stringify({phase,route,width,padding:result.padding,rowHeight:result.rows[1].height,tableHeight:result.scroll.rect.height,horizontalScroll:result.horizontalScroll||null,keyboardOrders:result.keyboard.map(x=>x.order),pointer:result.pointer}));
    }
  }
  observations.exceptions=exceptions;
  assert.deepEqual(exceptions,[]);
});
observations.cleanup={profileDirectories:(await readdir(scratch)).filter(name=>name.startsWith('slop-browser-'))};
assert.deepEqual(observations.cleanup.profileDirectories,[],'Temporary browser profile must be removed');
try{await fetch(browserOrigin);observations.cleanup.loopbackClosed=false;}catch{observations.cleanup.loopbackClosed=true;}
assert(observations.cleanup.loopbackClosed,'Preview server must be closed');
await writeFile(scratch+'/'+phase+'-browser.json',JSON.stringify(observations,null,2));
console.log(JSON.stringify({phase,cleanup:observations.cleanup,exceptions:observations.exceptions,result:'pass'}));
