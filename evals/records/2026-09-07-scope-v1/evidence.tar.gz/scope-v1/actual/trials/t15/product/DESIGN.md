# 모아 주문 화면 기준

브랜드 초록은 탐색과 행동에 사용한다. 흰 표면, 8px 모서리, 공통 16px 셀 위아래 간격을 기본으로 한다. master.html은 이 기준 화면이다.
비교 화면도 브랜드 역할, 열 내용, 행의 상세 보기, 키보드 포커스를 유지한다. 작은 화면에서는 표 영역 안에서 가로로 스크롤할 수 있다.

<!-- comparison-exception:start -->
```css
/*
 * 이유: 주문을 한 화면에서 더 많이 비교하도록 셀 위아래 간격을 줄인다.
 * 적용 페이지: compare.html. 코드 위치: compare.css.
 * 기본 주문 화면 master.html은 공통 16px 간격을 유지한다.
 * 브랜드, 글자와 버튼 크기, 상세 보기 및 키보드 동작은 공통 기준을 따른다.
 */
.comparison-table th, .comparison-table td { padding-block: 10px; }
```
<!-- comparison-exception:end -->

새 예외를 다른 화면의 공통 토큰 변경으로 확대하지 않는다.
