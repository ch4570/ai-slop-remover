import subprocess, sys, datetime, pathlib, shlex
log_path = pathlib.Path(__file__).with_name("commands.log")
command = sys.argv[1:]
result = subprocess.run(command, text=True, capture_output=True)
entry = "\n$ " + shlex.join(command) + "\ncwd: " + str(pathlib.Path.cwd()) + "\nexit: " + str(result.returncode) + "\nstdout:\n" + result.stdout + "\nstderr:\n" + result.stderr + "\n"
with log_path.open("a") as log: log.write(entry)
sys.stdout.write(result.stdout)
sys.stderr.write(result.stderr)
sys.exit(result.returncode)
