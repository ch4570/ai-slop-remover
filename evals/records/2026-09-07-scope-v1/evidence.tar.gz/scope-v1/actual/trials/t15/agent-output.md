`compare.css`의 세로 여백을 16→10px로 줄이고 `DESIGN.md` 예외 구역에 기록했습니다. 기본 화면은 유지했습니다.

두 화면의 데스크톱·390px 렌더링, 행 선택, 키보드 포커스와 가로 스크롤을 확인했습니다. 기존 좁은 화면의 버튼 일부 잘림은 남아 있으며, 화살표 스크롤로 접근 가능합니다. 실제 모바일 터치는 미검증입니다.

[작업 결과와 검증 기록](/var/folders/dt/8hl_lk4517vfdrvql7_0n2b80000gn/T/lutriva-issue-delivery-mt6la1md/issue-6-evals/trials/t15/scratch/agent-output.md)
