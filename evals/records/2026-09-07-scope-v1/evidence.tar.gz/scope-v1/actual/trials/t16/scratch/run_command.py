import sys, subprocess, shlex
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
command = sys.argv[1:]
result = subprocess.run(command, cwd=ROOT / "product", text=True, capture_output=True)
with (ROOT / "scratch/commands.log").open("a") as f:
    f.write("$ " + shlex.join(command) + "\nworkdir: " + str(ROOT / "product") + "\nstdout:\n" + result.stdout + "\nstderr:\n" + result.stderr + "\nexit_code: " + str(result.returncode) + "\n\n")
print(result.stdout, end="")
print(result.stderr, end="", file=sys.stderr)
sys.exit(result.returncode)
