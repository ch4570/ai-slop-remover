import { withBrowser } from '/var/folders/dt/8hl_lk4517vfdrvql7_0n2b80000gn/T/lutriva-issue-delivery-mt6la1md/issue-6-evals/snapshots/tools/browser_harness.mjs';
import { writeFile } from 'node:fs/promises';
import assert from 'node:assert/strict';
import path from 'node:path';
const product = process.cwd();
const scratch = path.resolve(product, '../scratch');
const phase = process.argv[2];
assert.ok(['before', 'after'].includes(phase));
const reports = [];
await withBrowser(product, path.join(scratch, phase), async ({ origin, page, evaluate, screenshot, pause, exceptions }) => {
  const key = async (key, code, value) => {
    const params = {key, code, windowsVirtualKeyCode:value, nativeVirtualKeyCode:value};
    await page('Input.dispatchKeyEvent', {type:'keyDown', ...params, ...(['Enter', ' '].includes(key) ? {text: key === 'Enter' ? '\r' : ' ', unmodifiedText: key === 'Enter' ? '\r' : ' '} : {})});
    await page('Input.dispatchKeyEvent', {type:'keyUp', ...params});
    await pause(80);
  };
  for (const route of ['master', 'compare']) {
    for (const width of [1280, 390]) {
      await page('Emulation.setDeviceMetricsOverride', { width, height: width === 390 ? 844 : 900, deviceScaleFactor:1, mobile:false });
      await page('Page.navigate', {url:origin + '/' + route + '.html'});
      let ready = false;
      for (let n = 0; n < 60; n++) {
        ready = await evaluate("location.pathname === '/" + route + ".html' && document.readyState === 'complete' && document.querySelectorAll('[data-order]').length === 3");
        if (ready) break;
        await pause(50);
      }
      assert.ok(ready, route + ' document ready');
      await pause(100);
      const metrics = await evaluate(`(() => {
        const cell = document.querySelector('tbody td'), head = document.querySelector('th'), row = document.querySelector('tbody tr'), table = document.querySelector('table'), scroller = document.querySelector('.table-scroll'), button = document.querySelector('button');
        const styles = getComputedStyle(cell);
        return { route:location.pathname, viewport:innerWidth, cellPadding:styles.paddingBlock, headPadding:getComputedStyle(head).paddingBlock, rowHeight:row.getBoundingClientRect().height, tableHeight:table.getBoundingClientRect().height, buttonHeight:button.getBoundingClientRect().height, brand:getComputedStyle(document.documentElement).getPropertyValue('--brand').trim(), documentWidth:document.documentElement.scrollWidth, scrollerWidth:scroller.clientWidth, scrollerContent:scroller.scrollWidth, rows:[...document.querySelectorAll('tbody tr')].map(row=>row.innerText), detail:document.querySelector('#detail').textContent };
      })()`);
      assert.equal(metrics.cellPadding, phase === 'after' && route === 'compare' ? '10px' : '16px');
      assert.equal(metrics.headPadding, metrics.cellPadding);
      assert.equal(metrics.brand, '#235942');
      assert.equal(metrics.documentWidth, width, 'document should not overflow');
      assert.equal(metrics.rows.length, 3);
      await screenshot(route + '-' + width + '.png');
      if (width === 390) {
        assert.ok(metrics.scrollerContent > metrics.scrollerWidth, 'table owns narrow horizontal overflow');
        const point = await evaluate("(() => { const r = document.querySelector('.table-scroll').getBoundingClientRect(); return {x:r.left + 100, y:r.top + 70}; })()");
        await page('Input.dispatchMouseEvent', {type:'mouseWheel', x:point.x, y:point.y, deltaX:400, deltaY:0});
        await pause(180);
        metrics.wheelScrollLeft = await evaluate("document.querySelector('.table-scroll').scrollLeft");
        assert.ok(metrics.wheelScrollLeft > 0, 'horizontal wheel scroll works');
        const focusHistory = [];
        let firstFocused = false;
        for (let n = 0; n < 9; n++) {
          await key('Tab', 'Tab', 9);
          const focus = await evaluate("({tag:document.activeElement.tagName, text:document.activeElement.textContent, order:document.activeElement.dataset.order || null})");
          focusHistory.push(focus);
          if (focus.order === 'M-101') { firstFocused = true; break; }
        }
        assert.ok(firstFocused, 'Tab reaches first order action');
        metrics.focusHistory = focusHistory;
        metrics.focus = await evaluate(`(() => {
          const b=document.activeElement, r=b.getBoundingClientRect(), c=document.querySelector('.table-scroll').getBoundingClientRect(), s=getComputedStyle(b);
          return {visible:b.matches(':focus-visible'), outline:s.outline, outlineWidth:s.outlineWidth, outlineOffset:s.outlineOffset, fullyVisible:r.left-5>=c.left && r.right+5<=c.right && r.top-5>=c.top && r.bottom+5<=c.bottom, scrollLeft:document.querySelector('.table-scroll').scrollLeft};
        })()`);
        assert.equal(metrics.focus.visible, true);
        assert.equal(metrics.focus.outlineWidth, '3px');
        assert.equal(metrics.focus.fullyVisible, true);
        await screenshot(route + '-390-focus.png');
        await key('Enter','Enter',13);
        assert.equal(await evaluate("document.querySelector('#detail').textContent"), 'M-101 주문을 선택했습니다.');
        await key('Tab','Tab',9);
        assert.equal(await evaluate("document.activeElement.dataset.order"), 'M-102');
        await key(' ','Space',32);
        assert.equal(await evaluate("document.querySelector('#detail').textContent"), 'M-102 주문을 선택했습니다.');
        await key('Tab','Tab',9);
        assert.equal(await evaluate("document.activeElement.dataset.order"), 'M-103');
        await key('Enter','Enter',13);
        assert.equal(await evaluate("document.querySelector('#detail').textContent"), 'M-103 주문을 선택했습니다.');
        metrics.keyboardResults = ['M-101 Enter', 'M-102 Space', 'M-103 Enter'];
      }
      reports.push(metrics);
    }
  }
  assert.equal(exceptions.length, 0, 'no JavaScript runtime exceptions');
});
await writeFile(path.join(scratch, phase + '-metrics.json'), JSON.stringify(reports, null, 2) + '\n');
console.log(JSON.stringify({phase, reports, cleanup:'withBrowser returned after Chrome, loopback server, and temporary profile cleanup'}, null, 2));
