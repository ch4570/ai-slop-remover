# 주문 비교 화면 밀도 예외 완료

판정: **pass** — 허용된 간격 수정과 두 화면의 대표 너비·키보드 동작 검증 범위.

- 변경 파일: `product/compare.css`, `product/DESIGN.md`.
- `.comparison-table th, .comparison-table td`의 기존 `padding-block` 값만 **16px → 10px**로 줄였다. 디자인 문서의 지정 예외 구역에는 이유, 적용 페이지·선택자, 실제 규칙을 하나의 CSS 코드 블록으로 기록했다.
- 나머지 제품 파일은 바이트 단위로 동일하며 파일 추가·삭제가 없다. 기본 화면은 16px, 공통 브랜드·토큰·데이터·행 동작은 유지된다. 구조나 추상화를 추가하지 않고 로컬 값 하나로 밀도를 조정했다.

실행 및 관찰:
- 지정된 source-a snapshot의 SKILL.md와 관련 reference를 직접 읽어 적용했다. 호스트의 자동 발견이나 설치 스킬 호출은 주장하지 않는다.
- 기존 Chrome과 공통 preview transport로 `master.html`, `compare.html`을 수정 전후 **1280×900, 390×844**에서 열었다. 캡처 12장을 `view_image`로 직접 확인했다.
- 비교 화면 행 높이는 **76.59375px → 64.59375px**, 표 높이는 **288.375px → 240.375px**였다. 버튼 높이는 **43.59375px**로 유지됐다. 기본 화면의 수정 전후 세 캡처는 파일 해시도 동일했다.
- 390px에서 표의 가로 휠 입력이 `scrollLeft=30`을 만들었고 문서 전체의 가로 넘침은 없었다. 처음에는 작업 칸 일부가 표 영역에 가려지는 기존 동작이며, 스크롤 후 버튼과 3px 포커스 테두리가 온전히 보였다. 새 겹침이나 정렬 문제는 관찰하지 못했다.
- 양 화면에서 Tab으로 세 행을 순서대로 이동하고 M-101 Enter, M-102 Space, M-103 Enter를 실행해 각 주문의 상태 문구를 검증했다. JavaScript 실행 예외는 없었다.
- `node --check app.js`와 변경 범위·문서 CSS 일치 검사가 통과했다. 최초 자동화 Enter 입력 검사 실패는 scratch 스크립트에 문자 이벤트를 보완한 뒤 수정 전후 재실행하여 통과했다. 실패 로그도 보존했다.
- loopback 서버와 Chrome 종료, 임시 profile 정리가 완료됐으며 scratch에 남은 profile이 없음을 확인했다.

근거: [명령과 stdout/stderr](commands.log), [제품 변경분](product.diff), [범위 검사](scope-check.json), [수정 전 측정](before-metrics.json), [수정 후 측정](after-metrics.json), [시각 판정](visual-verdict.json), [수정 후 넓은 비교 화면](after/compare-1280.png), [수정 후 좁은 비교 화면 포커스](after/compare-390-focus.png).

미검증: 실제 모바일 기기의 터치, 다른 브라우저·화면 크기, 확대·보조기기 사용, 제공된 세 행 이외의 대량 데이터. 별도 빌드·lint·타입 검사 설정은 제품에 없어 실행하지 않았다.
