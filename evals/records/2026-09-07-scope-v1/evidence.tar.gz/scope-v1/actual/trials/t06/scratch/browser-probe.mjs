import { withBrowser } from '/var/folders/dt/8hl_lk4517vfdrvql7_0n2b80000gn/T/lutriva-issue-delivery-mt6la1md/issue-6-evals/snapshots/tools/browser_harness.mjs';
import { writeFile, readdir } from 'node:fs/promises';
const product = "/var/folders/dt/8hl_lk4517vfdrvql7_0n2b80000gn/T/lutriva-issue-delivery-mt6la1md/issue-6-evals/trials/t06/product";
const scratch = "/var/folders/dt/8hl_lk4517vfdrvql7_0n2b80000gn/T/lutriva-issue-delivery-mt6la1md/issue-6-evals/trials/t06/scratch";
const screenshots = scratch + '/screenshots';
const results = { route: '/index.html', checks: [] };
let lastOrigin;
await withBrowser(product, screenshots, async ({ origin, page, evaluate, screenshot, pause, exceptions }) => {
  lastOrigin = origin;
  results.origin = origin;
  const ready = async () => {
    for (let i = 0; i < 100; i++) {
      if (await evaluate("document.readyState === 'complete' && !!document.querySelector('#order-search')")) {
        await evaluate('document.fonts.ready.then(() => true)');
        return;
      }
      await pause(50);
    }
    throw new Error('Document readiness timeout');
  };
  const press = async (key, code, keyCode, modifiers = 0) => {
    await page('Input.dispatchKeyEvent', { type: key === 'Enter' ? 'keyDown' : 'rawKeyDown', key, code, windowsVirtualKeyCode: keyCode, modifiers, ...(key === 'Enter' ? { text: '\r', unmodifiedText: '\r' } : {}), ...(key === 'a' && modifiers === 4 ? { commands: ['selectAll'] } : {}) });
    await page('Input.dispatchKeyEvent', { type: 'keyUp', key, code, windowsVirtualKeyCode: keyCode, modifiers });
    await pause(60);
  };
  const state = () => evaluate(`(() => {
    const input = document.querySelector('#order-search');
    const active = document.activeElement;
    const style = getComputedStyle(active);
    const rect = element => {
      const r = element.getBoundingClientRect();
      return { top: r.top, bottom: r.bottom, left: r.left, right: r.right, width: r.width, height: r.height };
    };
    return {
      viewport: { width: innerWidth, height: innerHeight },
      scroll: { x: scrollX, y: scrollY },
      documentWidth: document.documentElement.scrollWidth,
      promotion: rect(document.querySelector('.promotion')),
      orders: rect(document.querySelector('#orders')),
      search: rect(input),
      table: rect(document.querySelector('table')),
      rows: [...document.querySelectorAll('tbody tr')].map(row => ({ id: row.cells[0].textContent, hidden: row.hidden, rect: rect(row) })),
      query: input.value,
      detail: document.querySelector('#detail').textContent,
      active: { tag: active.tagName, id: active.id, text: active.textContent.slice(0, 60), focusVisible: active.matches(':focus-visible'), outlineStyle: style.outlineStyle, outlineWidth: style.outlineWidth, boxShadow: style.boxShadow, borderColor: style.borderColor, background: style.backgroundColor }
    };
  })()`);
  const record = async name => {
    const value = await state();
    results.checks.push({ name, ...value });
    console.log(JSON.stringify({ name, ...value }));
  };
  const replaceQuery = async text => {
    await press('a', 'KeyA', 65, 4);
    await press('Backspace', 'Backspace', 8);
    if (text) await page('Input.insertText', { text });
    await pause(80);
    const actual = await evaluate("document.querySelector('#order-search').value");
    if (actual !== text) throw new Error('Search input transport mismatch: ' + JSON.stringify({ expected: text, actual }));
  };
  await page('Page.navigate', { url: origin + '/index.html' });
  await ready();
  await page('Emulation.setDeviceMetricsOverride', { width: 1280, height: 900, deviceScaleFactor: 1, mobile: false });
  await record('wide-initial');
  await screenshot('wide-initial.png');
  await press('Tab', 'Tab', 9);
  await record('wide-tab-1-promotion-link');
  await press('Tab', 'Tab', 9);
  await record('wide-tab-2-search');
  await screenshot('wide-search-focus.png');
  await page('Input.insertText', { text: 'M-101' });
  await record('search-exact-order');
  await press('Tab', 'Tab', 9);
  await record('wide-tab-3-detail');
  await screenshot('wide-detail-focus.png');
  await press('Enter', 'Enter', 13);
  await record('detail-keyboard-activated');
  await press('Tab', 'Tab', 9, 8);
  await replaceQuery('김민지');
  await record('search-customer');
  await replaceQuery('m-101');
  await record('search-lowercase-order');
  await replaceQuery(' M-101 ');
  await record('search-padded-order');
  await replaceQuery('없는주문');
  await record('search-zero-results');
  await screenshot('wide-zero-results.png');
  await replaceQuery('');
  await record('search-cleared');
  await evaluate("document.querySelector('#orders').scrollIntoView({block: 'start'})");
  await screenshot('wide-orders.png');
  results.styles = await evaluate(`(() => {
    const read = selector => {
      const element = document.querySelector(selector);
      const style = getComputedStyle(element);
      return { selector, background: style.backgroundColor, color: style.color, border: style.border, padding: style.padding, fontWeight: style.fontWeight, fontSize: style.fontSize };
    };
    return ['.promotion a', '.badge', 'button', 'header'].map(read);
  })()`);
  await page('Emulation.setDeviceMetricsOverride', { width: 390, height: 844, deviceScaleFactor: 1, mobile: false });
  await page('Page.navigate', { url: origin + '/index.html' });
  await ready();
  await record('narrow-initial');
  await screenshot('narrow-initial.png');
  await press('Tab', 'Tab', 9);
  await press('Tab', 'Tab', 9);
  await record('narrow-keyboard-search');
  await evaluate("document.querySelector('#orders').scrollIntoView({block: 'start'})");
  await record('narrow-orders-scrolled');
  results.narrowOverflow = await evaluate(`(() => {
    const orders = document.querySelector('#orders');
    const button = document.querySelector('button');
    const rect = button.getBoundingClientRect();
    return { ordersClientWidth: orders.clientWidth, ordersScrollWidth: orders.scrollWidth, ordersOverflowX: getComputedStyle(orders).overflowX, button: { left: rect.left, right: rect.right, width: rect.width } };
  })()`);
  await screenshot('narrow-orders.png');
  results.exceptions = exceptions;
});
let serverClosed = false;
try { await fetch(lastOrigin + '/index.html', { signal: AbortSignal.timeout(1500) }); } catch { serverClosed = true; }
results.cleanup = { serverClosed, remainingTemporaryProfiles: (await readdir(scratch)).filter(name => name.startsWith('slop-browser-')) };
await writeFile(scratch + '/browser-observations.json', JSON.stringify(results, null, 2));
console.log(JSON.stringify({ styles: results.styles, narrowOverflow: results.narrowOverflow, exceptions: results.exceptions, cleanup: results.cleanup }, null, 2));
if (!serverClosed || results.cleanup.remainingTemporaryProfiles.length) throw new Error('Preview cleanup incomplete');
