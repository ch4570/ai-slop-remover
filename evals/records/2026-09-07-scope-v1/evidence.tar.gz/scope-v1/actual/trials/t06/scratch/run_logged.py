from pathlib import Path
import subprocess, sys, time, shlex
root = Path(__file__).resolve().parent
cmd = sys.argv[1:]
result = subprocess.run(cmd, capture_output=True, text=True)
record = '$ ' + shlex.join(cmd) + '\n[cwd] ' + str(Path.cwd()) + '\n[stdout]\n' + result.stdout + '\n[stderr]\n' + result.stderr + '\n[exit] ' + str(result.returncode) + '\n'
with (root / 'commands.log').open('a') as log:
    log.write(record)
sys.stdout.write(result.stdout)
sys.stderr.write(result.stderr)
sys.exit(result.returncode)
