from pathlib import Path
import json, re, hashlib, difflib
root=Path("/var/folders/dt/8hl_lk4517vfdrvql7_0n2b80000gn/T/lutriva-issue-delivery-mt6la1md/issue-6-evals/trials/t13/product")
scratch=Path("/var/folders/dt/8hl_lk4517vfdrvql7_0n2b80000gn/T/lutriva-issue-delivery-mt6la1md/issue-6-evals/trials/t13/scratch")
before=json.loads((scratch/"product-before.json").read_text())
current={f.name:f for f in root.iterdir() if f.is_file()}
assert set(current)==set(before), "No product files may be added or deleted"
changed=[name for name,f in current.items() if hashlib.sha256(f.read_bytes()).hexdigest()!=before[name]["sha256"]]
assert sorted(changed)==["DESIGN.md","compare.css"], changed
assert current["compare.css"].read_text()==before["compare.css"]["text"].replace("padding-block: 16px","padding-block: 10px")
start="<!-- comparison-exception:start -->"
end="<!-- comparison-exception:end -->"
old=before["DESIGN.md"]["text"]
new=current["DESIGN.md"].read_text()
assert old.split(start)[0]==new.split(start)[0]
assert old.split(end)[1]==new.split(end)[1]
section=new.split(start)[1].split(end)[0]
blocks=re.findall(r"```css\n(.*?)\n```",section,re.S)
assert len(blocks)==1
assert blocks[0].strip()==current["compare.css"].read_text().strip()
for width in (1280,375):
    for suffix in ("","-focus"):
        image=f"master-{width}{suffix}.png"
        assert (scratch/"before"/image).read_bytes()==(scratch/"after"/image).read_bytes(),image
diff=[]
for name in sorted(changed):
    diff.extend(difflib.unified_diff(before[name]["text"].splitlines(True),current[name].read_text().splitlines(True),fromfile="before/"+name,tofile="after/"+name))
(scratch/"product.diff").write_text("".join(diff))
result={"verdict":"pass","changed_files":sorted(changed),"preserved_files":sorted(set(current)-set(changed)),"rules":"Only one CSS value and the DESIGN exception region changed; exact documented CSS match","master_images":"All 4 comparable initial/focus desktop/narrow screenshots are byte-identical"}
(scratch/"scope-check.json").write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps(result,ensure_ascii=False,indent=2))
print("".join(diff))
