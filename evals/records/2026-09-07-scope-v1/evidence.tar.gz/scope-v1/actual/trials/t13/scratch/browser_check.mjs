import { withBrowser } from "/var/folders/dt/8hl_lk4517vfdrvql7_0n2b80000gn/T/lutriva-issue-delivery-mt6la1md/issue-6-evals/snapshots/tools/browser_harness.mjs";
import { readFile, writeFile, readdir } from 'node:fs/promises';
import assert from 'node:assert/strict';
import path from 'node:path';
const product="/var/folders/dt/8hl_lk4517vfdrvql7_0n2b80000gn/T/lutriva-issue-delivery-mt6la1md/issue-6-evals/trials/t13/product", scratch="/var/folders/dt/8hl_lk4517vfdrvql7_0n2b80000gn/T/lutriva-issue-delivery-mt6la1md/issue-6-evals/trials/t13/scratch";
const phase=process.argv[2];
assert.ok(['before','after'].includes(phase));
const results=[];
const metricExpression = `(() => {
  const table=document.querySelector('table'), wrap=document.querySelector('.table-scroll');
  const rect=e=>{const r=e.getBoundingClientRect(); return {x:r.x,y:r.y,width:r.width,height:r.height,right:r.right,bottom:r.bottom};};
  return {page:location.pathname,width:innerWidth,documentWidth:document.documentElement.scrollWidth,
    cells:[...document.querySelectorAll('th,td')].map(e=>({text:e.textContent,paddingTop:getComputedStyle(e).paddingTop,paddingBottom:getComputedStyle(e).paddingBottom})),
    table:rect(table),rows:[...document.querySelectorAll('tr')].map(rect),
    scroller:{...rect(wrap),scrollWidth:wrap.scrollWidth,clientWidth:wrap.clientWidth,scrollLeft:wrap.scrollLeft,overflowX:getComputedStyle(wrap).overflowX},
    brand:getComputedStyle(document.querySelector('header')).backgroundColor,
    font:getComputedStyle(document.body).fontFamily,
    buttons:[...document.querySelectorAll('button')].map(e=>({order:e.dataset.order,...rect(e)}))};
})()`;
await withBrowser(product,path.join(scratch,phase),async ({origin,page,evaluate,screenshot,pause,exceptions})=>{
  async function navigate(file) {
    await page('Page.navigate',{url:origin+'/'+file});
    for(let i=0;i<100;i++){
      if(await evaluate(`location.pathname===${JSON.stringify('/'+file)} && document.readyState==='complete' && !!document.querySelector('table')`)) break;
      if(i===99) throw new Error('Document readiness timeout');
      await pause(40);
    }
    await evaluate('document.fonts.ready.then(()=>true)');
  }
  async function key(key,code,vkey) {
    await page('Input.dispatchKeyEvent',{type:key==='Enter'?'keyDown':'rawKeyDown',key,code,windowsVirtualKeyCode:vkey,...(key==='Enter'?{text:'\r',unmodifiedText:'\r'}:{})});
    await page('Input.dispatchKeyEvent',{type:'keyUp',key,code,windowsVirtualKeyCode:vkey});
  }
  for(const width of [1280,375]) {
    await page('Emulation.setDeviceMetricsOverride',{width,height:width===375?812:900,deviceScaleFactor:1,mobile:false});
    for(const file of ['master.html','compare.html']) {
      console.log('Checking '+phase+' '+file+' '+width);
      await navigate(file);
      const metrics=await evaluate(metricExpression);
      const expected=phase==='after'&&file==='compare.html'?'10px':'16px';
      assert.ok(metrics.cells.every(c=>c.paddingTop===expected&&c.paddingBottom===expected));
      assert.ok(metrics.documentWidth<=width,'page must not overflow horizontally');
      assert.equal(metrics.brand,'rgb(35, 89, 66)');
      assert.equal(metrics.buttons.length,3);
      if(width===375) assert.ok(metrics.scroller.scrollWidth>metrics.scroller.clientWidth&&metrics.scroller.overflowX==='auto');
      const prefix=file.replace('.html','')+'-'+width;
      await screenshot(prefix+'.png');
      // Exercise the visible first row with a real browser pointer event.
      const position=await evaluate(`(() => { const b=document.querySelector('button'); b.scrollIntoView({block:'nearest',inline:'nearest'}); const r=b.getBoundingClientRect(); return {x:r.x+r.width/2,y:r.y+r.height/2}; })()`);
      await page('Input.dispatchMouseEvent',{type:'mousePressed',...position,button:'left',clickCount:1});
      await page('Input.dispatchMouseEvent',{type:'mouseReleased',...position,button:'left',clickCount:1});
      assert.equal(await evaluate("document.querySelector('#detail').textContent"),'M-101 주문을 선택했습니다.');
      await navigate(file);
      await key('Tab','Tab',9);
      assert.equal(await evaluate('document.activeElement.textContent'),'모아 주문');
      await key('Tab','Tab',9);
      assert.equal(await evaluate('document.activeElement.textContent'),'비교');
      const keyboard=[];
      for(const order of ['M-101','M-102','M-103']) {
        await key('Tab','Tab',9);
        for(let wait=0;wait<20;wait++){
          if(await evaluate("document.activeElement.getBoundingClientRect().right<=document.querySelector('.table-scroll').getBoundingClientRect().right")) break;
          await pause(50);
        }
        let focus=await evaluate(`(() => {const e=document.activeElement,r=e.getBoundingClientRect(),s=getComputedStyle(e),w=document.querySelector('.table-scroll'),q=w.getBoundingClientRect();return {order:e.dataset.order,visible:e.matches(':focus-visible'),outline:s.outlineStyle,outlineWidth:s.outlineWidth,outlineColor:s.outlineColor,x:r.x,right:r.right,y:r.y,bottom:r.bottom,scrollLeft:w.scrollLeft,scrollerLeft:q.left,scrollerRight:q.right};})()`);
        assert.equal(focus.order,order);
        assert.equal(focus.visible,true);
        assert.equal(focus.outline,'solid');
        assert.equal(focus.outlineWidth,'3px');
        const initialFocus={...focus};
        if(focus.right>focus.scrollerRight){
          await screenshot(prefix+'-initial-focus.png');
          await page('Input.dispatchMouseEvent',{type:'mouseWheel',x:200,y:focus.y+20,deltaX:500,deltaY:0});
          for(let wait=0;wait<20;wait++){
            if(await evaluate("document.querySelector('.table-scroll').scrollLeft>0")) break;
            await pause(50);
          }
          focus=await evaluate(`(() => {const e=document.activeElement,r=e.getBoundingClientRect(),w=document.querySelector('.table-scroll'),q=w.getBoundingClientRect();return {order:e.dataset.order,visible:e.matches(':focus-visible'),x:r.x,right:r.right,scrollLeft:w.scrollLeft,scrollerLeft:q.left,scrollerRight:q.right};})()`);
        }
        assert.ok(focus.x>=focus.scrollerLeft && focus.right<=focus.scrollerRight,'horizontal scroll must expose action: '+JSON.stringify(focus));
        await key('Enter','Enter',13);
        const detail=await evaluate("document.querySelector('#detail').textContent");
        assert.equal(detail,order+' 주문을 선택했습니다.');
        keyboard.push({initialFocus,afterScrollFocus:focus,detail});
      }
      await screenshot(prefix+'-focus.png');
      results.push({file,width,metrics,pointerOrder:'M-101',keyboard});
    }
  }
  assert.deepEqual(exceptions,[]);
});
if(phase==='after'){
  const before=JSON.parse(await readFile(path.join(scratch,'before.json'),'utf8'));
  for(const current of results){
    const previous=before.results.find(r=>r.file===current.file&&r.width===current.width);
    if(current.file==='master.html') assert.deepEqual(current.metrics,previous.metrics);
    else {
      assert.equal(previous.metrics.table.height-current.metrics.table.height,48);
      for(let i=0;i<current.metrics.rows.length;i++) assert.equal(previous.metrics.rows[i].height-current.metrics.rows[i].height,12);
    }
  }
}
const leftoverProfiles=(await readdir(scratch)).filter(f=>f.startsWith('slop-browser-'));
assert.deepEqual(leftoverProfiles,[],'temporary browser profile must be removed');
await writeFile(path.join(scratch,phase+'.json'),JSON.stringify({phase,results,cleanup:'withBrowser returned after browser and server shutdown; no temporary profiles remain'},null,2));
console.log(JSON.stringify({phase,checks:'PASS',screens:results.map(r=>({page:r.file,width:r.width,tableHeight:r.metrics.table.height,rowHeight:r.metrics.rows[1].height,cellPadding:r.metrics.cells[0].paddingTop,keyboardOrders:r.keyboard.map(k=>k.afterScrollFocus.order),narrowScroll:r.metrics.scroller.scrollWidth>r.metrics.scroller.clientWidth})),cleanup:'browser/server cleanup completed; no temporary profiles remain'},null,2));
