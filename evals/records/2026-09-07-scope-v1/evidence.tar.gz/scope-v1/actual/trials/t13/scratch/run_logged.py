from pathlib import Path
import datetime, os, subprocess, sys
log=Path(__file__).with_name("commands.log")
cmd=sys.argv[1:]
result=subprocess.run(cmd, cwd=os.getcwd(), text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
with log.open("a") as f:
    f.write("\nTIME: "+datetime.datetime.now().isoformat()+"\nCWD: "+os.getcwd()+"\nCOMMAND: "+repr(cmd)+"\nSTDOUT:\n"+result.stdout+"\nSTDERR:\n"+result.stderr+"\nEXIT: "+str(result.returncode)+"\n")
sys.stdout.write(result.stdout)
sys.stderr.write(result.stderr)
sys.exit(result.returncode)
