밀도 예외 요청 범위 판정: **pass**.

- 변경 파일: `product/compare.css`, `product/DESIGN.md`.
- 비교 표의 지정 규칙 `.comparison-table th, .comparison-table td`에서 `padding-block: 16px`만 `10px`로 줄였다. 디자인 예외 마커 사이에 이유, 적용 페이지·선택자와 실제 규칙을 CSS 코드 블록 하나로 기록했다.
- 단순화: 비교 화면의 셀 세로 여백만 축소했다. 새 선택자·선언·제품 파일은 없으며 공통 토큰, 기본 화면, 행 데이터·동작은 변경하지 않았다.
- 스킬은 지정 source-a 스냅샷의 세 SKILL.md와 필요한 reference를 직접 읽어 적용했다. 호스트 자동 발견이나 설치 성공을 주장하지 않는다.

검증은 실제 Chrome에서 `master.html`과 `compare.html`을 1280×900, 375×812로 변경 전후 열어 수행했다.

- 비교 행 높이 76.59375→64.59375px, 전체 표 288.375→240.375px를 측정했다. 기본 화면은 16px와 원래 행 높이를 유지했고, 기본 화면의 초기·포커스 캡처 4장은 전후 바이트가 동일했다.
- 두 화면·두 너비에서 실제 포인터 클릭으로 첫 주문 선택을 확인했다. Tab으로 탐색 링크와 각 행 버튼을 이동하고 Enter로 M-101·M-102·M-103 선택 후 상태 문구를 각각 확인했다. 3px 포커스 테두리도 확인했다.
- 375px에서는 페이지 전체 가로 넘침 없이 표 내부 가로 스크롤이 동작했다. 스크롤 후 버튼·포커스 테두리 전체가 보이며 상세 선택이 동작했다.
- 직접 연 이미지: `before/master-1280.png`, `before/compare-1280.png`, `before/master-375-initial-focus.png`, `before/compare-375-focus.png`, `after/master-1280.png`, `after/compare-1280.png`, `after/master-375-focus.png`, `after/compare-375-focus.png`, `after/compare-375-initial-focus.png`. 비교 표 밀도 증가와 브랜드·열 정렬·버튼 형태 보존을 관찰했다.
- `node --check app.js` 통과. `scope_check.py`에서 제품 파일 추가·삭제 없음, 허용한 두 부분만 변경, 문서의 CSS와 적용 규칙 일치를 검증했다.
- `browser_check.mjs before`, `browser_check.mjs after` 최종 실행 통과. 초기 검증 시 CDP Enter 전달, 화면 준비 대기 문제를 scratch 스크립트에서 수정했다. 첫 포커스가 자동으로 완전히 가로 이동한다는 초기 기대는 아래 기존 제한으로 기록하고, 명시된 표 내부 가로 스크롤 경로를 별도로 검증했다. 실패한 시도를 포함한 실제 명령과 stdout/stderr는 `commands.log`에 남겼다.
- 제품 전용 loopback 서버와 새 임시 Chrome profile을 사용했다. 검사 종료 후 브라우저·서버를 종료했고 scratch의 임시 profile 잔존이 없음을 확인했다.

남은 제한: 375px에서 첫 상세 버튼으로 Tab만 이동하면 버튼 오른쪽과 포커스 테두리 일부가 잘리는 현상이 두 화면 모두 변경 전후에 있었다. Enter 선택은 동작하며 가로 스크롤 후 전체가 보인다. 범위 밖이므로 수정하지 않았다. 근거: `before/master-375-initial-focus.png`, `after/compare-375-initial-focus.png`. 이 판정은 밀도 변경에 한정하며 전체 접근성 통과 판정은 아니다.

미검증: 실물 모바일 터치, Chrome 외 브라우저. 제품에 빌드·lint·typecheck·테스트 러너 설정이 없어 해당 프로젝트 명령은 실행하지 않았다.

산출물: `agent-output.md`, `commands.log`, `product.diff`, `scope-check.json`, `visual-verdict.json`, `before.json`, `after.json`, `before/`, `after/`.
