`compare.css`의 셀 세로 여백을 16→10px로 줄이고 `DESIGN.md` 예외 구역에 기록했습니다.

Chrome 1280px·375px에서 두 화면의 행 선택, Tab/Enter, 가로 스크롤을 검증했습니다. 비교 행은 12px 줄었고 기본 화면은 동일합니다.

기존 좁은 화면의 초기 포커스 일부 잘림은 기록했습니다. 실물 모바일·다른 브라우저·미설정 빌드 도구는 미검증입니다.

[결과 보고서 및 증거 경로](/var/folders/dt/8hl_lk4517vfdrvql7_0n2b80000gn/T/lutriva-issue-delivery-mt6la1md/issue-6-evals/trials/t13/scratch/agent-output.md)
