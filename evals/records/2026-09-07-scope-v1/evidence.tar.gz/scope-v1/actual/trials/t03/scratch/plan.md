# 작업 계획

`DESIGN.md`와 코드에서 `.actions`의 24px 간격과 기존 16px 토큰을 확인했다. 수정 전 375px 화면을 관찰한 뒤 `settings.css`의 `margin-top` 값만 `var(--space-6)`에서 `var(--space-4)`로 바꾼다. 브랜드·문구·폼·저장 동작과 갈색 포커스를 유지하며, 375px 렌더링, Tab 포커스, 저장·새로고침 복구 및 파일 변경 범위를 확인한다. 제품에 테스트나 문서를 추가하지 않고 검증 자료는 이 scratch 폴더에만 남긴다.

스킬은 지정된 source-b 스냅샷의 `ui-visual-refine/SKILL.md`와 해당 reference를 직접 읽었다. 설치된 다른 스킬은 호출하지 않는다.
