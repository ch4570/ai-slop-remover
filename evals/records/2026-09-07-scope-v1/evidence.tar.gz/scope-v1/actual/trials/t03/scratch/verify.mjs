import assert from 'node:assert/strict';
import { readFile, writeFile, readdir } from 'node:fs/promises';
import path from 'node:path';
import { withBrowser } from '/var/folders/dt/8hl_lk4517vfdrvql7_0n2b80000gn/T/lutriva-issue-delivery-mt6la1md/issue-6-evals/snapshots/tools/browser_harness.mjs';

const product = '/var/folders/dt/8hl_lk4517vfdrvql7_0n2b80000gn/T/lutriva-issue-delivery-mt6la1md/issue-6-evals/trials/t03/product';
const scratch = '/var/folders/dt/8hl_lk4517vfdrvql7_0n2b80000gn/T/lutriva-issue-delivery-mt6la1md/issue-6-evals/trials/t03/scratch';
const phase = process.argv[2];
assert.ok(['before', 'after'].includes(phase));
const files = (await readdir(product)).sort();
const source = Object.fromEntries(await Promise.all(files.map(async name => [name, await readFile(path.join(product, name), 'utf8')])));
if (phase === 'before') {
  await writeFile(path.join(scratch, 'source-before.json'), JSON.stringify(source, null, 2));
} else {
  const before = JSON.parse(await readFile(path.join(scratch, 'source-before.json'), 'utf8'));
  assert.deepEqual(files, Object.keys(before).sort(), 'No product files added or deleted');
  for (const name of files) {
    const expected = name === 'settings.css' ? before[name].replace('margin-top: var(--space-6)', 'margin-top: var(--space-4)') : before[name];
    assert.equal(source[name], expected, 'Allowed product content: ' + name);
  }
  console.log('PASS: settings.css margin-top is the only product change.');
}

const results = await withBrowser(product, scratch, async ({ origin, page, evaluate, screenshot, pause, exceptions }) => {
  await page('Emulation.setDeviceMetricsOverride', { width: 375, height: 812, deviceScaleFactor: 1, mobile: false });
  await page('Page.navigate', { url: origin + '/index.html' });
  async function ready() {
    for (let i = 0; i < 100; i += 1) {
      if (await evaluate("document.readyState === 'complete' && !!document.querySelector('#save')")) return;
      await pause(25);
    }
    throw new Error('Document readiness timed out');
  }
  await ready();
  await evaluate('document.fonts.ready.then(() => true)');
  const layout = await evaluate(`(() => {
    const actions = document.querySelector('.actions');
    const input = document.querySelector('#name');
    const button = document.querySelector('#save');
    const status = document.querySelector('#status');
    const rect = element => {
      const r = element.getBoundingClientRect();
      return { left: r.left, top: r.top, right: r.right, bottom: r.bottom, width: r.width, height: r.height };
    };
    return {
      viewport: innerWidth, scrollWidth: document.documentElement.scrollWidth,
      marginTop: getComputedStyle(actions).marginTop,
      measuredGap: actions.getBoundingClientRect().top - input.getBoundingClientRect().bottom,
      input: rect(input), button: rect(button), status: rect(status),
      buttonBackground: getComputedStyle(button).backgroundColor,
      surface: getComputedStyle(document.querySelector('main')).backgroundColor,
      surfaceRadius: getComputedStyle(document.querySelector('main')).borderRadius,
      text: document.body.innerText,
    };
  })()`);
  assert.equal(layout.viewport, 375);
  assert.equal(layout.scrollWidth, 375, 'No horizontal overflow');
  assert.equal(layout.marginTop, phase === 'before' ? '24px' : '16px');
  assert.equal(layout.measuredGap, phase === 'before' ? 24 : 16);
  for (const name of ['input', 'button', 'status']) {
    assert.ok(layout[name].left >= 0 && layout[name].right <= 375, name + ' stays within viewport');
    assert.ok(layout[name].bottom <= 812, name + ' stays visible');
  }
  assert.equal(layout.buttonBackground, 'rgb(35, 89, 66)');
  assert.equal(layout.surface, 'rgb(255, 255, 255)');
  assert.equal(layout.surfaceRadius, '8px');
  await screenshot(phase + '-375.png');

  async function key(key, code = key, extra = {}) {
    const virtualKeyCode = key === 'Enter' ? 13 : key === 'Tab' ? 9 : key === 'a' ? 65 : 0;
    await page('Input.dispatchKeyEvent', { type: 'keyDown', key, code, windowsVirtualKeyCode: virtualKeyCode, ...(key === 'Enter' ? { text: '\r' } : {}), ...extra });
    await page('Input.dispatchKeyEvent', { type: 'keyUp', key, code, windowsVirtualKeyCode: virtualKeyCode });
  }
  async function focus() {
    return evaluate(`(() => {
      const el = document.activeElement;
      const css = getComputedStyle(el);
      return { id: el.id, focusVisible: el.matches(':focus-visible'), outlineColor: css.outlineColor, outlineWidth: css.outlineWidth, outlineStyle: css.outlineStyle, outlineOffset: css.outlineOffset };
    })()`);
  }
  await key('Tab');
  const inputFocus = await focus();
  assert.equal(inputFocus.id, 'name');
  assert.equal(inputFocus.focusVisible, true);
  assert.equal(inputFocus.outlineColor, 'rgb(163, 72, 27)');
  assert.equal(inputFocus.outlineWidth, '3px');
  await screenshot(phase + '-375-input-focus.png');

  if (phase === 'after') {
    await key('a', 'KeyA', { modifiers: 4, commands: ['selectAll'] });
    await page('Input.insertText', { text: '지우' });
    assert.equal(await evaluate("document.querySelector('#name').value"), '지우');
    await evaluate(`(() => {
      window.observedSaveStates = [];
      const status = document.querySelector('#status');
      new MutationObserver(() => window.observedSaveStates.push({ state: status.dataset.state, text: status.textContent, disabled: document.querySelector('#save').disabled })).observe(status, { attributes: true, childList: true, subtree: true });
    })()`);
  }
  await key('Tab');
  const buttonFocus = await focus();
  assert.equal(buttonFocus.id, 'save');
  assert.equal(buttonFocus.focusVisible, true);
  assert.equal(buttonFocus.outlineColor, 'rgb(163, 72, 27)');
  assert.equal(buttonFocus.outlineWidth, '3px');
  assert.equal(buttonFocus.outlineStyle, 'solid');
  assert.equal(buttonFocus.outlineOffset, '3px');
  await screenshot(phase + '-375-save-focus.png');

  let save = null;
  if (phase === 'after') {
    await key('Enter');
    for (let i = 0; i < 100; i += 1) {
      if (await evaluate("document.querySelector('#status').dataset.state === 'success'")) break;
      await pause(25);
    }
    save = await evaluate(`({ state: document.querySelector('#status').dataset.state, text: document.querySelector('#status').textContent, stored: localStorage.getItem('display-name'), disabled: document.querySelector('#save').disabled, transitions: window.observedSaveStates })`);
    assert.equal(save.state, 'success');
    assert.equal(save.text, '변경 사항을 저장했습니다.');
    assert.equal(save.stored, '지우');
    assert.equal(save.disabled, false);
    assert.ok(save.transitions.some(item => item.state === 'saving' && item.disabled && item.text === '저장 중입니다.'));
    await screenshot('after-375-saved.png');
    await page('Page.reload', { ignoreCache: true });
    await pause(100);
    await ready();
    save.restored = await evaluate("document.querySelector('#name').value");
    assert.equal(save.restored, '지우');
    await screenshot('after-375-restored.png');
  }
  assert.deepEqual(exceptions, [], 'No browser runtime exceptions');
  return { phase, layout, inputFocus, buttonFocus, save, runtimeExceptions: exceptions };
});
results.cleanup = { browserAndServer: 'withBrowser completed its finally cleanup', temporaryProfilesRemaining: (await readdir(scratch)).filter(name => name.startsWith('slop-browser-')) };
assert.deepEqual(results.cleanup.temporaryProfilesRemaining, []);
await writeFile(path.join(scratch, phase + '-results.json'), JSON.stringify(results, null, 2));
console.log(JSON.stringify(results, null, 2));
