# t03 독립 UI 검수

판정: **pass** (`narrow-focus-review`). 동결된 TASK의 단일 간격 변경과 요구된 375px·키보드 검수 범위에서 구체적인 제품 결함이나 범위 위반을 관찰하지 못했다. 이 판정은 아래에 열거한 화면과 입력 데이터에 한정한다.

검수 기준은 초기 `narrow-spacing/TASK.md`, 제품 `DESIGN.md`, 동결된 `scope-suites.json`과 handoff다. 이 trial의 TASK, 제품 6개 파일, before/after manifest, `diff.patch`, `browser.json`, 실제 native final인 `agent-output.md`, `scratch/agent-output.md`와 필요한 실행 기록을 읽었다. 외부 브라우저 결과는 기존 수집물을 검토했으며 제품이나 평가기를 다시 실행·변경하지 않았다.

최종 제품의 변경은 `product/settings.css:1`의 `.actions { margin-top: var(--space-6); }`를 `var(--space-4)`로 바꾼 한 선언뿐이다. TASK는 초기본과 바이트가 같고, before/after manifest의 파일 목록·종류·모드는 동일하다. 최종 제품 바이트의 SHA-256을 다시 계산해 after manifest와 대조했으며 `DESIGN.md`, `app.js`, `index.html`, `style.css`, `tokens.css`는 초기본과 일치했다. 공통 토큰, 녹색 브랜드, 문구, 폼, 저장 코드는 보존됐다. manifest와 diff는 최종 상태의 범위 준수 증거이며 중간 쓰기가 전혀 없었다는 증거로 확대하지 않았다.

아래 세 이미지는 파일 존재나 geometry만 확인한 것이 아니라 `view_image`로 원본을 각각 열어 직접 관찰했다.

| 이미지 | 직접 본 화면 |
| --- | --- |
| `images/wide.png` · 1280×900 | 밝은 배경 위 중앙의 흰 설정 표면, 녹색 저장 버튼, 제목·설명·입력 라벨·안내 문구가 선명하게 보인다. 이름 입력란과 버튼은 왼쪽 기준선이 맞고 서로 떨어져 있다. 페이지 내용이 화면 안에 온전히 들어오며 잘림·겹침이 보이지 않는다. |
| `images/narrow.png` · 375×844 | 표면 양쪽에 여백이 남고 입력란·버튼·상태 문구가 모두 표면 안에 있다. `주문 알림에 사용할 이름을 관리합니다.`와 `변경 후 저장해 주세요.`가 읽힌다. 주입된 `긴 한국어 이름을 저장하고 다시 확인합니다`도 입력란 안에서 보이며 페이지 바깥으로 밀려나지 않는다. 현재 문구는 한 줄에 들어오므로 여러 줄 자동 줄바꿈이 실제 발생한 사례로 판정하지 않았다. 폼 아래의 빈 배경까지 확인했고 전체 페이지의 가로 넘침·잘림·겹침은 보이지 않는다. |
| `images/keyboard.png` · 375×844 | 녹색 `변경 저장` 버튼 둘레에 갈색 외곽선과 버튼 사이의 흰 간격이 분명하다. 외곽선이 네 변 모두 보이고 화면 경계나 주변 요소에 잘리지 않는다. 텍스트와 버튼 색은 일반 narrow 화면과 같다. |

외부 `browser.json`은 Chrome 152.0.7977.82에서 `margin: 16px`, 녹색 `rgb(35, 89, 66)`, 제목·버튼 문구 보존, `documentWidth: 375`를 기록했다. geometry는 위 직접 시각 관찰을 보완하는 근거로 사용했다. focus 관찰은 `name` 입력란 다음 `save` 버튼이며 양쪽 모두 `focusVisible: true`, 갈색 `rgb(163, 72, 27) solid 3px`다. 해당 scratch 검증 스크립트가 CDP Tab 키 이벤트를 보내고 실제 `document.activeElement`를 검사하는 것도 읽었다. 따라서 단순한 `.focus()` 호출이나 스타일 문자열만으로 Tab 도달성을 추정한 판정이 아니다.

외부 수집은 긴 한국어 이름의 저장 성공, `변경 사항을 저장했습니다.`, 버튼 재활성화, 새로고침 후 동일한 이름 복구를 확인했고 collection error와 런타임 예외는 없다. wide/narrow의 안내가 `변경 후 저장해 주세요.`인 것은 새로고침 후 초기 상태를 보여주는 것으로, 별도로 기록된 저장 성공 결과와 모순되지 않는다.

추가로 `scratch/after-375-input-focus.png`와 `scratch/after-375-saved.png`를 직접 열었다. 입력란 전체를 둘러싼 갈색 외곽선은 잘리지 않고, 저장 화면의 이름 `지우`와 성공 문구가 375×812에서 온전히 읽힌다. `scratch/before-results.json`·`after-results.json`은 간격 24→16px와 저장·복구를 기록한다. `after-results.json`의 `transitions`에는 `saving`/`저장 중입니다.`/disabled true에서 `success`/성공 안내/disabled false로 바뀐 DOM 관찰이 있다. `scratch/verify.mjs`의 MutationObserver와 assertion을 읽었으므로 이 상태 전환 주장은 코드에서만 추정한 것이 아니다. 다만 저장 중 화면 자체를 눈으로 확인한 증거는 아니다.

실제 final의 단일 간격 변경, 375px·갈색 포커스·저장/복구·JS 구문 검사 주장은 관찰·기록과 맞으며, 다른 화면 크기·브라우저를 미검증으로 표시했다. `scratch/commands.log`의 `node --check app.js`는 exit 0이다. 최초 불완전한 Enter 전송으로 `idle`과 `success` assertion이 실패한 기록도 읽었다. scratch 보고서는 키 전송 보정 후 재실행을 명시하고, 후속 실행 및 독립 외부 수집은 성공했다. 자가기록은 전체 native 도구 transcript로 취급하지 않았다.

미검증: 관찰한 1280×900·375×844 외부 화면과 375×812 scratch 화면 외의 크기, 다른 브라우저, 확대 배율, 실기기, 스크린리더, OS IME 조합 입력, 임의 장문 피드백의 여러 줄 줄바꿈, 순간적인 저장 중 상태의 시각 표현. 저장 중 상태의 DOM 전환 확인과 시각 검수는 구분한다. 별도 lint/typecheck/build/test 설정은 없다. 한글 문자열 주입·저장 성공이나 현재 포커스 검수는 OS IME·전체 접근성·전체 회귀 검사의 완료를 뜻하지 않는다.
