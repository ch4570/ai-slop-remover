`settings.css:1`의 `.actions` 위 여백만 기존 `--space-4` 토큰으로 24→16px 변경했습니다.

375px 화면, 갈색 키보드 포커스, 저장·새로고침 복구, JS 문법 검사를 통과했습니다. 다른 화면 크기·브라우저는 미검증입니다.

[결과 기록](/var/folders/dt/8hl_lk4517vfdrvql7_0n2b80000gn/T/lutriva-issue-delivery-mt6la1md/issue-6-evals/trials/t03/scratch/agent-output.md)
