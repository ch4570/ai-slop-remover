import hashlib
import json
import pathlib

product = pathlib.Path.cwd()
scratch = pathlib.Path(__file__).resolve().parent
names = ['app.js', 'DESIGN.md', 'style.css', 'locales/ko.json', 'locales/en.json', 'index.html']
baseline = {name: hashlib.sha256((product / name).read_bytes()).hexdigest() for name in names}
locale_path = product / 'locales/ko.json'
old = json.loads(locale_path.read_text())
(scratch / 'baseline.json').write_text(json.dumps({'sha256': baseline, 'locale': old}, ensure_ascii=False, indent=2) + '\n')
new_values = {
    'empty_title': '“{query}” 검색 결과가 없습니다.',
    'empty_body': '검색창에서 다른 검색어로 찾아보세요.',
    'empty_name': '“{query}” 검색 결과가 없습니다.',
}
new = {**old, **new_values}
locale_path.write_text(json.dumps(new, ensure_ascii=False, indent=2) + '\n')
for key, value in new_values.items():
    print(f'{key}: {old[key]} -> {value}')
