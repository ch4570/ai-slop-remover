import assert from 'node:assert/strict';
import { mkdir, readdir, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { withBrowser } from '../../../snapshots/tools/browser_harness.mjs';

const product = process.cwd();
const scratch = path.dirname(new URL(import.meta.url).pathname);
await mkdir(path.join(scratch, 'browser-temp'), { recursive: true });
process.env.TMPDIR = path.join(scratch, 'browser-temp');
const observations = [];
let usedOrigin;
await withBrowser(product, scratch, async ({ origin, page, evaluate, screenshot, pause, exceptions }) => {
  usedOrigin = origin;
  const ready = async () => {
    for (let i = 0; i < 100; i++) {
      if (await evaluate('document.documentElement.dataset.ready === "true"')) return;
      await pause(50);
    }
    throw new Error('Product did not become ready');
  };
  const state = () => evaluate(`(() => {
    const empty = document.getElementById('empty');
    const heading = document.getElementById('empty-title');
    return {
      query: document.getElementById('query').value,
      hidden: empty.hidden,
      state: empty.dataset.state,
      title: heading.textContent,
      name: heading.getAttribute('aria-label'),
      body: document.getElementById('empty-body').textContent,
      count: document.getElementById('count').textContent,
      results: [...document.querySelectorAll('#results li')].map(node => node.textContent),
      labelledby: empty.getAttribute('aria-labelledby'),
      describedby: empty.getAttribute('aria-describedby'),
      horizontalOverflow: document.documentElement.scrollWidth > innerWidth,
      emptyOverflow: empty.scrollWidth > empty.clientWidth,
      inputEvents: window.__inputEvents || 0
    };
  })()`);
  const type = async text => {
    await evaluate('document.getElementById("query").focus()');
    await page('Input.dispatchKeyEvent', { type: 'keyDown', key: 'a', code: 'KeyA', modifiers: 4, commands: ['selectAll'] });
    await page('Input.dispatchKeyEvent', { type: 'keyUp', key: 'a', code: 'KeyA', modifiers: 4 });
    await page('Input.insertText', { text });
    await pause(100);
    assert.equal((await state()).query, text);
  };
  await page('Page.navigate', { url: origin + '/index.html' });
  await ready();
  await evaluate('window.__inputEvents = 0; document.getElementById("query").addEventListener("input", () => window.__inputEvents++)');
  assert.deepEqual((await state()).results, ['배송 안내', '교환 절차', '정기 배송 일정']);

  await type('반품');
  const empty = await state();
  assert.equal(empty.hidden, false);
  assert.equal(empty.state, 'no-match');
  assert.equal(empty.title, '“반품” 검색 결과가 없습니다.');
  assert.equal(empty.name, empty.title);
  assert.equal(empty.body, '검색창에서 다른 검색어로 찾아보세요.');
  assert.equal(empty.count, '0개 자료');
  assert.deepEqual(empty.results, []);
  assert.equal(empty.labelledby, 'empty-title');
  assert.equal(empty.describedby, 'empty-body');
  const ax = await page('Accessibility.getFullAXTree');
  const relevantAX = ax.nodes.filter(node => !node.ignored && ['heading', 'region'].includes(node.role?.value) && node.name?.value === empty.title);
  assert.ok(relevantAX.some(node => node.role.value === 'heading'));
  assert.ok(relevantAX.some(node => node.role.value === 'region'));
  assert.ok(relevantAX.some(node => node.description?.value === empty.body));
  await screenshot('no-match-desktop.png');
  observations.push({ check: 'No matching results and accessible names', ...empty, ax: relevantAX });

  await type('배송');
  const restored = await state();
  assert.equal(restored.hidden, true);
  assert.equal(restored.count, '2개 자료');
  assert.deepEqual(restored.results, ['배송 안내', '정기 배송 일정']);
  assert.ok(restored.inputEvents >= 2, 'Expected actual browser input events');
  await screenshot('results-restored.png');
  observations.push({ check: 'Results restored through real input events', ...restored });

  await page('Emulation.setDeviceMetricsOverride', { width: 320, height: 900, deviceScaleFactor: 1, mobile: false });
  await type('아주 긴 검색어로 찾는 정기 배송 일정과 자료 검색 결과 확인');
  const narrow = await state();
  assert.equal(narrow.hidden, false);
  assert.equal(narrow.name, narrow.title);
  assert.equal(narrow.horizontalOverflow, false);
  assert.equal(narrow.emptyOverflow, false);
  await screenshot('no-match-narrow.png');
  observations.push({ check: '320px viewport with long Korean query', ...narrow });

  await evaluate('document.body.style.fontSize = "32px"; document.getElementById("empty-title").style.fontSize = "40px"');
  const enlarged = await state();
  assert.equal(enlarged.horizontalOverflow, false);
  assert.equal(enlarged.emptyOverflow, false);
  await screenshot('no-match-narrow-text-200.png');
  observations.push({ check: '200 percent affected text-size simulation, not OS text scaling or browser zoom', ...enlarged });

  await page('Page.navigate', { url: origin + '/index.html?empty=1' });
  await ready();
  const never = await state();
  assert.equal(never.state, 'never-populated');
  assert.equal(never.title, '저장된 항목이 없습니다.');
  assert.equal(never.name, '저장된 항목이 없습니다.');
  assert.equal(never.body, '등록된 항목은 이 목록에 표시됩니다.');
  observations.push({ check: 'Never-populated state unchanged', ...never });

  await page('Page.navigate', { url: origin + '/index.html?lang=en' });
  await ready();
  await type('반품');
  const english = await state();
  assert.equal(english.title, 'No results for “반품”.');
  assert.equal(english.name, 'No results for 반품');
  assert.equal(english.body, 'Check the search term and try again.');
  observations.push({ check: 'English copy unchanged', ...english });
  assert.deepEqual(exceptions, []);
  observations.push({ check: 'No captured JavaScript runtime exceptions', exceptions });
});
assert.deepEqual(await readdir(path.join(scratch, 'browser-temp')), [], 'Browser profile not removed');
let serverStopped = false;
try { await fetch(usedOrigin); } catch { serverStopped = true; }
assert.equal(serverStopped, true, 'Product server still running');
observations.push({ check: 'Browser harness completed; temporary profile removed and loopback server stopped' });
await writeFile(path.join(scratch, 'browser-observations.json'), JSON.stringify(observations, null, 2) + '\n');
console.log('PASS: empty results, query-edit recovery, visible/AX names, 320px long Korean text, 200% text simulation, preserved no-data and English states; no runtime exceptions.');
console.log('PASS: browser session completed, temporary profile removed, loopback server stopped.');
console.log('Limitations: no screen-reader/assistive-technology execution, OS text scaling, or actual browser zoom.');
