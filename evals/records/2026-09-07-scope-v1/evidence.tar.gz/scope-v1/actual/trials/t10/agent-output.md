`locales/ko.json`의 허용된 문자열 세 개만 수정했습니다. 검색어 변경을 안내하고 제목과 접근 가능한 이름을 일치시켰습니다.

Chrome에서 결과 없음, 검색어 변경 후 결과 2개 복구, 접근성 이름과 좁은 화면 줄바꿈을 확인했습니다. 보조기술 실행과 실제 브라우저 확대는 미검증입니다.

산출물: [agent-output.md](/private/var/folders/dt/8hl_lk4517vfdrvql7_0n2b80000gn/T/lutriva-issue-delivery-mt6la1md/issue-6-evals/trials/t10/scratch/agent-output.md)
