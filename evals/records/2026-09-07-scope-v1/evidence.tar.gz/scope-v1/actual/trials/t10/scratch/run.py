import datetime
import pathlib
import shlex
import subprocess
import sys

scratch = pathlib.Path(__file__).resolve().parent
command = sys.argv[1:]
result = subprocess.run(command, capture_output=True, text=True)
with (scratch / 'commands.log').open('a', encoding='utf-8') as log:
    log.write(f'\nTIME: {datetime.datetime.now().isoformat()}\n')
    log.write(f'CWD: {pathlib.Path.cwd()}\nCOMMAND: {shlex.join(command)}\n')
    log.write(f'EXIT: {result.returncode}\nSTDOUT:\n{result.stdout}\nSTDERR:\n{result.stderr}\n')
sys.stdout.write(result.stdout)
sys.stderr.write(result.stderr)
sys.exit(result.returncode)
