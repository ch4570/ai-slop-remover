import collections
import hashlib
import json
import pathlib
import re

product = pathlib.Path.cwd()
scratch = pathlib.Path(__file__).resolve().parent
baseline = json.loads((scratch / 'baseline.json').read_text())
new = json.loads((product / 'locales/ko.json').read_text())
old = baseline['locale']
assert list(new) == list(old), 'Locale keys/order changed'
changed = {key for key in old if old[key] != new[key]}
assert changed == {'empty_title', 'empty_body', 'empty_name'}, changed
for key in old:
    tokens = lambda text: collections.Counter(re.findall(r'\{[^{}]+\}', text))
    assert tokens(old[key]) == tokens(new[key]), f'Interpolation changed: {key}'
assert new['empty_title'] == new['empty_name']
expected_files = set(baseline['sha256'])
actual_files = {str(path.relative_to(product)) for path in product.rglob('*') if path.is_file()}
assert actual_files == expected_files, 'Product files added or removed'
for name, digest in baseline['sha256'].items():
    if name != 'locales/ko.json':
        assert hashlib.sha256((product / name).read_bytes()).hexdigest() == digest, f'Out-of-scope change: {name}'
print('PASS: only the 3 allowed Korean string values changed; keys, per-string variables, other locale, never-populated copy, HTML, CSS, and behavior source preserved.')
