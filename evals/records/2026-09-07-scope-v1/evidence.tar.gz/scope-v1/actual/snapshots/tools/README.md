# Optional product preview transport

This is a fixed snapshot of a generic Chrome transport, with no case checks or scoring logic. Both variants receive the same file. Import withBrowser from the absolute path in a temporary .mjs file outside product:

```js
import { withBrowser } from './browser_harness.mjs';
await withBrowser(productPath, screenshotDirectory, async ({origin, page, evaluate, call, screenshot, pause, exceptions}) => {
  await page('Page.navigate', {url: origin + '/index.html'});
  // Wait until the requested document and its local scripts are ready.
  await screenshot('preview.png');
});
```

The callback owns readiness and any keyboard interaction. The comparison fixture has compare.html and master.html instead of index.html. page sends a CDP command to the current page session; call sends a browser-level command. evaluate executes JavaScript in the page and returns its value. screenshot writes a PNG within the provided screenshotDirectory. Use scratch output paths, never product output paths. No runtime packages or browser downloads are installed. Node22+ and existing Chrome are required. Report actual observations and limitations; this helper does not evaluate the result.
