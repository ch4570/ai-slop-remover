import { withBrowser } from './snapshots/tools/browser_harness.mjs';
import { mkdir, writeFile } from 'node:fs/promises';
import path from 'node:path';
const root = path.resolve(process.argv[2]);
const output = path.resolve(process.argv[3]);
await mkdir(output, {recursive: true});
for (const id of ['narrow-spacing', 'audit-read-only', 'empty-state-copy-only', 'master-page-consistency']) {
  const target = path.join(root, 'evals/fixtures', id, 'product');
  const folder = path.join(output, id);
  await withBrowser(target, folder, async ({origin, page, evaluate, screenshot, pause, call}) => {
    const entry = id === 'master-page-consistency' ? '/compare.html' : '/index.html';
    await page('Page.navigate', {url: origin + entry});
    let ready = false;
    for (let i=0;i<100;i++) {
      try { ready = await evaluate('location.origin === ' + JSON.stringify(origin) + ' && document.readyState === "complete"' + (id === 'empty-state-copy-only' ? ' && document.documentElement.dataset.ready === "true"' : '')); } catch {}
      if (ready) break;
      await pause(50);
    }
    if (!ready) throw new Error('Initial fixture readiness timed out: ' + id);
    if (id === 'empty-state-copy-only') await evaluate('document.querySelector("#query").value="없는 자료"; document.querySelector("#query").dispatchEvent(new Event("input", {bubbles:true}));');
    await screenshot('wide.png');
    await page('Emulation.setDeviceMetricsOverride', {width:375,height:844,deviceScaleFactor:1,mobile:true});
    await screenshot('narrow.png');
    const observed = await evaluate('({title:document.title, width:innerWidth, scrollWidth:document.documentElement.scrollWidth})');
    const browser = await call('Browser.getVersion');
    await writeFile(path.join(folder,'observation.json'),JSON.stringify({case:id,observed,browser:browser.product,kind:'initial fixture preview only; no result verdict'},null,2)+'\n');
  });
  console.log('Captured initial fixture: ' + id);
}
