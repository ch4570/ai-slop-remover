from pathlib import Path
from datetime import datetime, timezone
import argparse, json

ROOT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description="Record already-observed native receipts; never launch agents.")
parser.add_argument("operation", choices=("launch", "complete"))
parser.add_argument("trial")
parser.add_argument("--task-name")
args = parser.parse_args()
plan = json.loads((ROOT / "launch-plan.json").read_text())
manifest = json.loads((ROOT / "manifest.json").read_text())
index = next(i for i, item in enumerate(plan) if item["id"] == args.trial)
item = plan[index]
trial = Path(item["trial"])
def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
if args.operation == "launch":
    assert item["status"] == "prepared"
    assert args.task_name == "/root/" + item["task_name"], "Pass the task_name actually returned by spawn_agent."
    raw = {"request": {"task_name": item["task_name"], "agent_type": "default",
           "fork_turns": "none", "message": item["message"]},
           "response": {"task_name": args.task_name},
           "receipt_recorded_at": datetime.now(timezone.utc).isoformat()}
    write(trial / "native-launch.json", raw)
    invocation = json.loads((trial / "invocation.json").read_text())
    invocation["native_agent_id"] = args.task_name
    write(trial / "invocation.json", invocation)
    item.update(status="running", native_agent_id=args.task_name)
    manifest["trials"][index]["native_agent_id"] = args.task_name
else:
    assert item["status"] == "running"
    assert (trial / "agent-output.md").is_file() and (trial / "agent-output.md").stat().st_size
    write(trial / "native-completion.json", {"status": "completed",
          "native_agent_id": item["native_agent_id"], "final_output": "agent-output.md",
          "completion_observed_at": datetime.now(timezone.utc).isoformat(),
          "record_kind": "parent record of received native FINAL_ANSWER; raw final text is preserved separately"})
    item["status"] = "completed"
write(ROOT / "manifest.json", manifest)
write(ROOT / "launch-plan.json", plan)
print(json.dumps({state: sum(item["status"] == state for item in plan) for state in ("prepared", "running", "completed")}))
