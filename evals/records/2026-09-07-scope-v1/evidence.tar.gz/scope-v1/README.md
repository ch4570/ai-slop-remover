# 범위 평가 원본

`actual/`은 실제 16개 native 실행 원본이다. `controls/`는 합성 harness 대조군이며 실제 실행 수에 포함하지 않는다.

원래 절대 경로를 그대로 보존했다. 원본 `issue-6-evals/`는 이 압축의 `actual/`에 대응한다. `trials/tNN/agent-output.md`는 수신한 native 최종 응답이고 `scratch/agent-output.md`는 구현 에이전트의 상세 보고다. native launch/final, 실제 기록된 scratch 명령 로그와 외부 수집 로그를 보존했으며 전체 도구 transcript는 제공되지 않았다.

`shasum -a 256 -c SHA256SUMS`로 파일을 확인한다. 저장된 판정 재현은 다음과 같다.

```sh
python3 -B actual/snapshots/evaluator/scripts/summarize_scope_trials.py actual/manifest.json
```

종료 코드 0은 candidate 필수 검사 통과, 1은 관찰된 candidate 실패, 3은 누락으로 인한 incomplete이다. 이 명령은 저장된 증거를 집계한다. 에이전트나 Chrome을 다시 실행하거나 독립 AI 검수를 대신하지 않는다.
